# TLM Agent — Strategic Approach, Architecture & Demo Plan

## For Leadership, Peers, and Team Presentations

**Version:** 3.0 | **Last Updated:** February 2026

---

## 1. THE APP MOD PROBLEM & OUR SOLUTION

### The Problem Developers Reported

"App Mod fixed Spring Boot but broke everything else. Internal libraries failed. I ended up with a project that doesn't compile."

This happens because the App Mod extension:
- Has recipes for standard open-source migrations (Spring Boot 2→3, Jakarta, Java 17)
- Does NOT know about Fidelity internal libraries (JSCI, FMR, AMT FSF)
- Does NOT continue fixing after the recipe completes
- Leaves the project in an incomplete state — partially upgraded, non-compilable

### Our Architecture: Completion Agent (Not Sub-Agent)

**We do NOT need a separate sub-agent.** Here's why:

A "sub-agent" implies a separate, independently running agent that talks to the App Mod extension. This creates complexity: two agents, coordination overhead, handoff logic, failure modes when one agent doesn't know what the other did.

Instead, our TLM Agent acts as a **Completion Agent** — a single unified agent that:

1. **Uses App Mod recipes first** (where available) — leveraging the deterministic, tested recipes
2. **Continues seamlessly** after the recipe finishes — the same agent reads the post-recipe state
3. **Fixes what App Mod can't** — internal libraries, transitive dependencies, compilation errors
4. **Validates the whole thing** — builds, tests, verifies no regressions

```
┌─────────────────────────────────────────────────────┐
│                  TLM AGENT (One Agent)               │
│                                                       │
│  Phase 1: RECIPE LAYER                               │
│  ┌─────────────────────────────────────────┐         │
│  │ App Mod Extension (where recipe exists)  │         │
│  │ ✅ Spring Boot 2→3 recipe               │         │
│  │ ✅ Jakarta javax→jakarta recipe         │         │
│  │ ✅ Java 17 upgrade recipe               │         │
│  │ ❌ No recipe: Security, Hibernate, JSCI │         │
│  └─────────────────────────────────────────┘         │
│           │ Recipe completes (partial fix)            │
│           ▼                                           │
│  Phase 2: COMPLETION LAYER (Agent Intelligence)      │
│  ┌─────────────────────────────────────────┐         │
│  │ 🧠 Opus: Spring Security 5→6 refactor   │         │
│  │ 🧠 Opus: Hibernate 5→6 API changes      │         │
│  │ 🏢 Skill: JSCI → dp-* replacements      │         │
│  │ 🏢 Skill: FMR library decoupling        │         │
│  │ 🏢 Skill: AMT FSF EOL handling          │         │
│  │ 🤖 Sonnet: Jackson, Log4j, etc.         │         │
│  └─────────────────────────────────────────┘         │
│           │ Agent fixes everything else               │
│           ▼                                           │
│  Phase 3: VALIDATION LAYER                           │
│  ┌─────────────────────────────────────────┐         │
│  │ Build → Fix errors → Test → Fix failures │         │
│  │ Verify no JSCI/FMR references remain     │         │
│  │ CVE check → No new vulnerabilities       │         │
│  │ ✅ Working, compilable project            │         │
│  └─────────────────────────────────────────┘         │
│                                                       │
│  Result: COMPLETE. No partial state. No broken code. │
└─────────────────────────────────────────────────────┘
```

### Why Completion Agent > Sub-Agent

| Aspect | Sub-Agent Approach | Our Completion Agent |
|---|---|---|
| **Architecture** | Two separate agents, need coordination | One agent, three layers |
| **Context** | Sub-agent doesn't know what App Mod did | Same agent reads the full state after recipe |
| **Failure handling** | If sub-agent fails, who recovers? | Single agent retries, escalates, recovers |
| **Developer UX** | Run App Mod, then run sub-agent separately | Say "hi" → one workflow end to end |
| **Maintenance** | Two sets of instructions to maintain | One instruction file, multiple skills |
| **Internal libraries** | Sub-agent needs to know about JSCI/FMR | Skills already contain all migration knowledge |
| **Compilation** | Who owns the final build verification? | Agent owns it — builds, tests, reports |

### How Internal/Fidelity Libraries Are Handled

The critical differentiator: **Enterprise Skills.**

When the agent encounters `fmr-commons-jwt` in the project:
1. It matches against the `jsci-eol-retirement` skill
2. It knows: fmr-commons-jwt → dp-commons-jwt (imports, API changes, everything)
3. It applies the replacement intelligently — not just removing imports, but mapping them to meaningful new packages
4. It checks transitive dependencies
5. It verifies no JSCI references remain

When it encounters an unknown internal library:
1. It stops and asks: "Do you have a migration guide?"
2. User provides info → agent applies changes
3. Agent offers: "Save this as a reusable skill?"
4. Next developer gets the fix automatically

**This is why teams should use our solution over raw App Mod:** App Mod alone cannot handle Fidelity internals. Our agent wraps App Mod AND handles internals.

---

## 2. SPRING BOOT MICROSERVICES UPGRADE — DEMO PLAN

### The Scenario

A team has a microservices architecture with 5-8 Spring Boot services. They need to upgrade from Spring Boot 2.7 → 3.2 across all services. They want to see:
- How the agent handles multi-service projects
- How it manages internal libraries
- How it ensures compilable output with no logic changes
- Clear plan, progress, and outcome

### Demo Setup

**Use a real-ish project structure:**
```
my-platform/
├── pom.xml (parent BOM)
├── common-lib/ (shared utilities, JSCI dependencies)
├── user-service/ (Spring Boot 2.7, REST API)
├── order-service/ (Spring Boot 2.7, REST + messaging)
├── payment-service/ (Spring Boot 2.7, security-heavy)
├── gateway/ (Spring Cloud Gateway)
└── config-server/ (Spring Cloud Config)
```

**Pre-load with real pain points:**
- JSCI fmr-commons-jwt in common-lib
- Spring Security with WebSecurityConfigurerAdapter in payment-service
- javax.persistence imports throughout
- Old Hibernate APIs
- Jackson CVE in all services
- UBN22/RHEL8 references in CI/CD

### Demo Script (Step by Step for Presenting)

**Step 1: Opening (2 min)**
"We've all experienced the pain of TLM upgrades. App Mod helps with Spring Boot but breaks internal libraries. Today I'll show you our TLM Agent that handles the complete migration — recipes AND internal libraries — and delivers a compilable project."

**Step 2: First Impression — Say "Hi" (3 min)**
- Type "hi" in Copilot Agent Mode
- Agent auto-scans → shows Project Health Dashboard
- Point out: "Notice it detected our multi-module structure, found JSCI libraries, identified Spring Boot 2.7, found CVEs, and even detected our RHEL8 buildpack references — all automatically."
- Point out: "It shows which items have App Mod recipes and which don't."

**Step 3: The Plan (3 min)**
- Pick "Fix All TLM Items"
- Agent shows the upgrade plan:
  ```
  Phase 1: Parent BOM update
  Phase 2: Runtime — Java 11→17 (📦 App Mod recipe)
  Phase 3: Framework — Spring Boot 2.7→3.2 (📦 App Mod recipe)
  Phase 4: Jakarta migration (📦 App Mod recipe)
  Phase 5: Spring Security 5→6 (🧠 Opus — no recipe available)
  Phase 6: Hibernate 5→6 (🧠 Opus)
  Phase 7: Enterprise — JSCI fmr-commons → dp-* (🏢 enterprise skill)
  Phase 8: Libraries — Jackson, Log4j, etc. (🤖 Sonnet)
  Phase 9: Infrastructure — UBN22→UBN24 (🏢 enterprise skill)
  Phase 10: Validation — build all modules, run tests
  ```
- Key talking point: "See phases 5-7? App Mod can't do these. That's where our agent takes over — seamlessly, in the same workflow."

**Step 4: Execution — The Key Moment (5 min)**
- Approve the plan
- Show real-time progress as agent works through each phase
- **Highlight the transition**: "App Mod recipe just finished Spring Boot upgrade. Now watch — the agent automatically continues to fix Spring Security, which has no recipe."
- **Highlight enterprise skill**: "Now it's fixing our JSCI libraries. It knows exactly which package maps to which replacement. No Confluence lookup needed."
- **Highlight multi-module**: "Notice it upgraded common-lib first, then built it, then moved to the services that depend on it. It understands the module dependency order."

**Step 5: Validation (2 min)**
- Agent builds all modules → all green
- Agent runs tests → shows results
- Agent checks CVEs → no new vulnerabilities
- Key talking point: "The project compiles. Tests pass. No new security issues. No logic was changed — only migrations applied."

**Step 6: Summary (2 min)**
- Show the final summary with files changed, effort saved, areas to review
- Key talking point: "What would have taken the team 2-3 days across 6 services was done in 15 minutes. And every developer gets the same quality."

**Step 7: Q&A Prep**

| Likely Question | Your Answer |
|---|---|
| "What if it breaks something?" | "It shows a plan first and waits for approval. It builds and tests after every phase. If something breaks, it fixes it — up to 5 attempts, then escalates to Opus." |
| "What about our internal libraries?" | "Enterprise skills contain the migration knowledge. JSCI, AMT FSF, RHEL — all handled. For new libraries, we create a skill once and it serves every developer." |
| "Is this just App Mod with extra steps?" | "App Mod handles about 40% of a typical migration. Our agent handles the full 100% — including the hardest parts that App Mod can't touch." |
| "What if the recipe doesn't have the latest version?" | "Our agent checks for this. If a recipe targets an older version, the agent continues the upgrade to the latest stable version after the recipe completes." |
| "How do we know the code is correct?" | "The agent doesn't just delete and replace. It maps every import to a meaningful replacement, refactors APIs to match new patterns, and verifies with build + tests." |

### Sample Open-Source Projects for Demo

| Project | What It Demonstrates | GitHub |
|---|---|---|
| Spring PetClinic | Single Spring Boot app, straightforward | spring-projects/spring-petclinic |
| Spring PetClinic Microservices | Multi-service architecture | spring-petclinic/spring-petclinic-microservices |
| PiggyMetrics | Microservices + Spring Cloud | sqshq/piggymetrics |
| JHipster Sample App | Full stack (Spring Boot + Angular) | jhipster/jhipster-sample-app |

For the demo, fork one of these and add mock JSCI dependencies and RHEL8 references to simulate the real scenario.

---

## 3. CLI CONCEPT: COPILOT CLI & CLAUDE CODE

### What Are They?

**GitHub Copilot CLI** (coming/evolving):
- Command-line interface to Copilot outside VS Code
- Run Copilot commands directly from terminal
- Can execute agent workflows without opening an IDE

**Claude Code** (Anthropic's CLI):
- Command-line tool for running Claude as a coding agent
- Reads project files, makes changes, runs builds — all from terminal
- Supports tool use: file editing, terminal commands, etc.
- Can run autonomously with minimal human intervention

### How CLI Changes the Game for TLM

**Current (IDE-based):**
```
Developer opens VS Code → opens Copilot Chat → types "hi" → interacts with agent → reviews changes
```

**With CLI:**
```
Developer runs from terminal:
$ copilot-cli agent tlm --fix-all --auto-approve

Or:
$ claude-code --instructions .github/copilot-instructions.md --auto

The agent runs autonomously:
  ✅ Scans project
  ✅ Creates plan
  ✅ Executes upgrades
  ✅ Builds and tests
  ✅ Generates summary
  ✅ Creates PR with all changes

Developer reviews the PR — that's it.
```

### Why CLI Is Powerful for TLM

| Aspect | IDE Agent (Current) | CLI Agent (Future) |
|---|---|---|
| **Triggering** | Manual — developer must open IDE and type | Automated — can be triggered by CI/CD, cron, script |
| **Scale** | One project at a time | Run across 50 repos in a loop |
| **Intervention** | Developer watches and interacts | Minimal/zero intervention — auto-approve mode |
| **CI/CD Integration** | Not possible | Can be a pipeline step: "Fix TLM → Build → PR" |
| **Batch processing** | Manual, sequential | Parallel across multiple repos |
| **Scheduling** | Not possible | Run nightly/weekly TLM scans |

### Real Scenario: CLI for TLM at Scale

```bash
# Run TLM Agent across all team repositories
for repo in $(cat team-repos.txt); do
  cd /repos/$repo
  claude-code \
    --instructions .github/copilot-instructions.md \
    --prompt "Fix all TLM items. Auto-approve the plan. Build and test. Create a summary." \
    --auto \
    --output tlm-report.json
  
  # If successful, create a PR
  if [ $? -eq 0 ]; then
    git checkout -b tlm-fix-$(date +%Y%m%d)
    git add -A
    git commit -m "TLM: Automated library upgrades and EOL fixes"
    gh pr create --title "TLM: Automated upgrades" --body "$(cat tlm-report.json)"
  fi
done
```

**Result:** 50 repos scanned, upgraded, built, tested, and PRs created — overnight, no developer time.

### Our Solution in CLI

**Our workflow files (.github/copilot-instructions.md + skills) work in CLI too.** The markdown files are tool-agnostic:
- Copilot Agent Mode reads them in VS Code
- Claude Code reads them from the filesystem
- Any CLI agent that supports instructions can read them

**This is a major advantage of our approach** — we built on markdown files, not on a custom extension. When CLI becomes available, our entire workflow runs in CLI with zero changes.

### What CLI Can't Do (Yet)

- Visual interactions (showing dashboards in terminal is limited)
- Design decisions that need human judgment (but can pause and ask)
- Access to App Mod extension recipes (these are VS Code extension features)
- Note: When running in CLI, the agent would use its own intelligence instead of App Mod recipes — which actually works fine for most migrations

---

## 4. COMPETITIVE POSITIONING: WHY OUR SOLUTION STANDS OUT

### The Landscape — What Other Teams Are Doing

| Approach | Who Does It | Limitations |
|---|---|---|
| **Raw App Mod Extension** | Some teams | Only handles recipe items. Leaves project broken for non-recipe items. Zero knowledge of internal libraries. |
| **Individual Prompt Files** | Angular upgrade team | Single-use (Angular only). No multi-language. No enterprise skills. No scan/plan/validate flow. |
| **Manual Confluence + Copy-Paste** | Most teams | Inconsistent quality. Goes stale. No automation. No tracking. |
| **Custom scripts per library** | Some platform teams | Brittle, hard to maintain, no AI intelligence for edge cases. |

### Our Solution: What Makes It Different

**1. End-to-End Completion (not partial)**

Other approaches leave the developer with a partially upgraded, non-compilable project. Our agent guarantees:
- A compilable project at the end
- All imports replaced with meaningful alternatives (not just deleted)
- Build verified, tests verified, CVEs checked

"You get a working project back. Not a half-finished upgrade."

**2. Recipe + Intelligence + Enterprise Skills (three layers)**

No other solution combines all three:
- App Mod recipes (deterministic, tested — where they exist)
- Agent intelligence with Opus (for complex migrations — where no recipe exists)
- Enterprise skills (for internal/Fidelity libraries — what nobody else handles)

"We use the right tool for each part of the problem."

**3. One Workflow for Everything (not fragmented)**

Developer says "hi" → sees everything → picks an option → gets a working project. Not: "run App Mod for Spring, then use this prompt for Angular, then check Confluence for JSCI, then manually fix the build."

"One agent. One workflow. Every language. Every library. Every enterprise change."

**4. Knowledge Compounds (not throwaway)**

Every manual fix can become a skill. Every enterprise announcement becomes a skill. The system gets smarter over time:
- Month 1: 6 enterprise skills
- Month 6: 20 enterprise skills (from enterprise changes + auto-generated)
- Month 12: 35+ skills — most internal libraries handled automatically

"Other teams solve the same problem repeatedly. We solve it once and every developer benefits."

**5. Measurable ROI (not invisible effort)**

Telemetry tracks: items fixed, time saved, methods used, failure rates. Leadership can see real numbers.

"Confluence can't tell you if anyone read the page. We can tell you exactly how many hours we saved."

**6. Future-Ready (CLI, CI/CD, Scale)**

Built on markdown files — works in IDE today, works in CLI tomorrow, works in CI/CD pipelines next. No lock-in to a specific tool or extension.

"When CLI agents arrive, our entire workflow runs autonomously at scale with zero changes."

### The Elevator Pitch (30 seconds)

"Our TLM Agent is the only solution that handles the complete migration — not just the parts App Mod covers, but also the internal libraries that break your build. It uses recipes where they exist, AI intelligence where they don't, and enterprise skills for Fidelity-specific libraries. One workflow, every language, guaranteed compilable output. And it gets smarter over time as we add skills."

### The One-Liner

"App Mod gets you 40% there. We get you to 100% — including internal libraries."

---

## 5. SELLING TO LEADERSHIP: THE ROI STORY

### Current State (without our solution)
- Average TLM fix per project: **2-3 days** developer time
- 200 projects × 2.5 days = **500 developer-days per TLM cycle**
- Quality: **Inconsistent** — depends on who does it
- Internal libraries: **Each developer figures it out independently**
- Tracking: **No visibility** into progress or completion

### Future State (with our solution)
- Average TLM fix per project: **15-30 minutes** agent time + 30 min review
- 200 projects × 1 hour = **200 developer-hours per TLM cycle** (25 days)
- Quality: **Consistent** — same workflow, same skills, same validation
- Internal libraries: **Enterprise skills handle automatically**
- Tracking: **Full telemetry** — items fixed, time saved, compliance progress

### The Numbers
- **Time saved: 475 developer-days per TLM cycle** (500 → 25)
- **Consistency: 100%** of projects get same quality
- **Compliance velocity: 10x faster** to complete TLM across the org
- **Risk reduction:** No partial upgrades, no broken builds
- **Knowledge retention:** Skills persist even when people change teams
