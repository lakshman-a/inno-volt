# TLM Agent — Developer Guide

## Fixing TLM Items Seamlessly with AI-Powered Workflows

**Version:** 2.0 | **Last Updated:** February 2026 | **Owner:** Platform DevAssist Team

---

## What is TLM Agent?

TLM Agent is a **pre-built AI workflow** that runs inside GitHub Copilot Agent Mode in VS Code. It scans your project, identifies all TLM (Technology Lifecycle Management) items — outdated libraries, frameworks, runtimes, CVEs, and internal package changes — then creates a plan, executes the upgrades, builds, tests, and delivers a **working, compilable project**.

**Think of it as a senior developer pair who:**
- Knows every library migration path
- Never forgets edge cases (Jakarta migration, transitive dependencies)
- Validates the build after every change
- Fixes what breaks automatically
- Works across Java, Angular, Python, and enterprise internal libraries

---

## What Problems Does It Solve?

| Pain Point | How TLM Agent Solves It |
|---|---|
| "I upgraded Spring Boot but now 10 other things are broken" | Agent upgrades in the correct dependency order, handles cascading changes, rebuilds and fixes iteratively until green |
| "I don't know what version to upgrade to" | Agent identifies the latest stable compatible version for every dependency |
| "Enterprise changed an internal library but I can't find the migration doc" | Enterprise skills are embedded in the workflow — agent applies changes automatically |
| "The App Mod extension fixed Spring but didn't handle the rest" | Agent uses App Mod recipes where available AND handles everything App Mod can't with agent intelligence |
| "I waste hours researching migration guides" | Skills contain migration knowledge — agent reads them and applies automatically |
| "My build breaks after upgrades and I spend hours fixing compilation errors" | Agent runs build after every phase, fixes errors iteratively (up to 5 attempts), escalates to Opus model for complex issues |
| "I forget about transitive dependency conflicts" | Agent checks dependency tree, resolves conflicts, tries alternate versions if artifacts aren't available |
| "Different team members do TLM differently, inconsistent quality" | Same workflow for everyone — same quality regardless of experience level |

---

## Supported Languages & Frameworks

| Language | Frameworks & Libraries | Upgrade Method |
|---|---|---|
| **Java** | Spring Boot, Spring Security, Spring Cloud, Hibernate, Jackson, Log4j, Lombok, Guava, Commons, MapStruct, Flyway, JUnit | 📦 App Mod Recipes + 🧠 Opus/Sonnet Agent |
| **Angular** | Angular Core, Angular Material, RxJS, TypeScript, Zone.js, NgRx, internal packages | 🧠 Opus Agent (always — Angular migrations are complex) |
| **Python** | Django, Flask, Pydantic, SQLAlchemy, pytest, requests | 🧠 Opus/Sonnet Agent |
| **Enterprise** | Any internal library with a migration skill | 🏢 Enterprise Skills |

---

## How to Install & Set Up

### Prerequisites
- VS Code with GitHub Copilot extension installed
- Copilot Chat enabled with Agent Mode access
- Claude Sonnet / Opus model available in Copilot

### Setup Steps

**Step 1:** Download or clone the TLM Agent files

**Step 2:** Copy these folders into your project root:
```
your-project/
├── .github/
│   ├── copilot-instructions.md      ← Agent brain (auto-loaded)
│   ├── prompts/                      ← Saved prompt shortcuts
│   └── skills/tlm/                   ← Upgrade knowledge base
│       ├── java/                     ← Java upgrade skills
│       ├── angular/                  ← Angular upgrade skills
│       ├── python/                   ← Python upgrade skills
│       ├── enterprise/               ← Internal library skills
│       └── general/                  ← Fallback & validation skills
├── tlm-config/                       ← Telemetry output
└── .vscode/settings.json            ← VS Code settings
```

**Step 3:** Open your project in VS Code

**Step 4:** Open Copilot Chat and switch to **Agent Mode**

**Step 5:** Type **"hi"** or **"menu"**

That's it. The agent takes over from here.

---

## What Happens When You Start

### 1. Automatic Project Scan

The moment you say "hi", the agent scans your entire project:

- **Detects** your language, build system, framework versions
- **Scans** all dependencies for outdated versions
- **Checks** for CVEs and security vulnerabilities
- **Identifies** enterprise/internal libraries
- **Checks** if a TLM list file exists in your project
- **Maps** available App Mod recipes and upgrade skills
- **Calculates** estimated effort savings

### 2. Project Health Dashboard

You see a real-time health report:

```
📋 PROJECT HEALTH DASHBOARD

📁 Project: my-service
☕ Language: Java 11 (⚠️ upgrade available → Java 17)
🍃 Framework: Spring Boot 2.7.18 (⚠️ → 3.2.x)

📦 Dependencies: 45 total | 20 outdated | 3 CVEs | 4 enterprise
🛡️ Vulnerabilities: 1 critical | 2 high | 4 medium
📦 App Mod Recipes: 3 available (Spring Boot, Jakarta, Java 17)
```

### 3. Smart Menu Based on YOUR Project

The menu adapts to what's actually in your project — you only see relevant options.

---

## Menu Options — What Each One Does

### [1] Fix All TLM Items (Recommended)

**What it does:**
Upgrades every outdated dependency, fixes every CVE, handles enterprise libraries — end to end. The agent manages the entire lifecycle.

**What it covers:**
- Runtime upgrades (Java 11→17, Node.js, Python)
- Framework upgrades (Spring Boot 2→3, Angular 15→18, Django)
- All library upgrades (Jackson, Log4j, Hibernate, RxJS, etc.)
- Jakarta migration (javax→jakarta) for Java projects
- Enterprise/internal library migrations
- CVE and vulnerability fixes
- Transitive dependency resolution

**What it uses:**
- 📦 App Mod Extension recipes where available (Spring Boot, Jakarta, Java runtime)
- 🧠 Opus model for complex migrations (Spring Security, Hibernate, Angular)
- 🤖 Sonnet model for standard version bumps
- 🏢 Enterprise skills for internal library changes
- Build validation with iterative error fixing
- Test execution with TLM-caused failure fixing

**What you get:**
A fully compilable, tested, working project with all TLM items resolved. Summary report with every change documented.

---

### [2] Java TLM Fixes / Angular TLM Fixes / Python TLM Fixes

**What it does:**
Focuses on a specific language's TLM items only. Useful when you want to tackle one language at a time in a multi-language project.

**Java TLM Fixes covers:**
- Spring Boot version upgrade (with App Mod recipe when available)
- Spring Security migration (WebSecurityConfigurerAdapter → SecurityFilterChain)
- Spring Data / Spring Cloud compatibility alignment
- Hibernate version upgrade with API changes
- Jakarta namespace migration (javax.* → jakarta.*)
- Jackson, Log4j, Lombok, Guava, Commons, MapStruct, Flyway
- JUnit 4→5 migration
- Build plugin updates

**Angular TLM Fixes covers:**
- Angular major version upgrades (step-by-step, never skips versions)
- Angular Material / CDK updates
- RxJS migration (toPromise→firstValueFrom, etc.)
- TypeScript version upgrade
- Zone.js updates
- Internal Angular packages
- ng update schematics where available
- Control flow migration (@if/@for for Angular 17+)
- Build system migration (browser→application builder)

**Python TLM Fixes covers:**
- Django major version upgrades
- Flask upgrades
- Pydantic v1→v2 (major API rewrite)
- SQLAlchemy 1→2 (query API overhaul)
- pytest, requests, and common libraries

**What it uses:**
Same toolchain as Fix All, but scoped to one language.

---

### [3] CVE & Vulnerability Fixes

**What it does:**
Targets only security vulnerabilities. Fast, focused, high-impact.

**What it covers:**
- Critical and High CVEs in your dependencies
- Libraries past End-of-Life
- Known security advisories
- Transitive dependency vulnerabilities

**What it uses:**
- Maven dependency check / npm audit / pip-audit for scanning
- Version bumps for patch-level CVE fixes
- Agent mode for CVEs requiring code changes
- Build validation after every fix

**What you get:**
All critical/high CVEs resolved. Remaining medium/low CVEs listed for your review.

---

### [4] Runtime Upgrade (Java 11→17, etc.)

**What it does:**
Upgrades your runtime version. This is often a prerequisite for framework upgrades (e.g., Java 17 required for Spring Boot 3).

**What it covers:**
- Build configuration updates (pom.xml, build.gradle, package.json)
- Removed API handling (JAXB, javax.annotation for Java)
- JVM flag cleanup (removed GC options, illegal-access)
- Dockerfile/CI pipeline version references
- Compatibility verification with existing code

**What it uses:**
- 📦 App Mod recipe for Java runtime upgrades
- 🤖 Agent mode for config and code adjustments

---

### [5] Enterprise / Internal Library Upgrades

**What it does:**
Handles upgrades for your organization's internal libraries that don't have public migration guides.

**What it covers:**
- **JSCI EOL Retirement (March 2026):** Complete replacement of all fmr-commons-* libraries with dp-* alternatives and open-source replacements. Includes fmr-commons-jwt → dp-commons-jwt, fmr-commons-crypto → dp-crypto-utils, fmr-commons-cs203 → dp-http-request-guard, fmr-commons-core → SLF4J + java.util.concurrent
- **AMT FSF 7.5 EOL (June 2026):** Config Utils, Identity, Rest, Secret, Usage Metrics — requires target version guidance
- **RHEL8 → RHEL9 Buildpacks:** UBN22/RHEL8 → UBN24/RHEL9 image migration in Dockerfiles, Jenkinsfiles, CI/CD configs. Uses App Mod plugin scan where available
- **Infrastructure:** References to jil.fmr.com and jsci.fmr.com (going offline April 2026) — auto-detected and flagged
- Package renames, API method changes, configuration property changes
- Internal dependency chain resolution

**What it uses:**
- 🏢 Enterprise skills (automatically loaded from .github/skills/tlm/enterprise/)
- The agent auto-detects JSCI, AMT FSF, FMR, and RHEL references during scan
- If no skill exists: asks you for a migration doc, Confluence link, or description
- Offers to save your input as a reusable skill for the team

**What you get:**
Internal libraries upgraded cleanly. All JSCI references removed. Build pack images updated. If you provide migration info for an unknown library, a reusable skill file is created so the next person doesn't need to provide it again.

---

### [6] Fix from TLM List

**What it does:**
Takes items from the enterprise **SW EOL List** spreadsheet and fixes exactly those items.

**What it covers:**
- Parses the enterprise SW EOL spreadsheet format (Application ID, Software Model, Campaign, Java Category, SW EOL, SWL EOL Timeline)
- Matches items against your project dependencies
- Shows which items match, which don't apply
- Prioritizes by EOL date: 🔴 Past Due → 🟠 This Quarter → 🟡 Next Quarter
- Fixes matching items in priority order

**Input formats accepted:**
- Copy-paste directly from the SW EOL spreadsheet (tab or comma separated)
- CSV file upload
- Plain text: one item per line (e.g., "AMT FSF Config Utils 7.5", "Python 3.10")
- JSON array
- Or just paste the items in chat — the agent will figure it out

**Example:**
```
Just paste these from your SW EOL list:
AMT FSF Config Utils 7.5, Java, 2026-06-30
AMT FSF Rest 7.5, Java, 2026-06-30
Python Software Foundation Python 3.10, Non-Java / Python, 2026-10-01
```

---

### [7] Show Skills & Capabilities

**What it does:**
Lists every upgrade skill available, grouped by language and type.

**What it covers:**
- All Java, Angular, Python skills with descriptions
- Enterprise skills: JSCI EOL, AMT FSF, RHEL8→9, SW EOL parser
- What has App Mod recipes vs. agent mode
- Option to add new custom skills

---

## How the Upgrade Process Works (End to End)

### The Complete Flow

```
You type "hi"
    │
    ▼
AUTO-SCAN: Agent scans your entire project
    │
    ▼
DASHBOARD: Shows project health, dependencies, CVEs, recipes
    │
    ▼
SMART MENU: Options based on your specific project
    │
    ▼
You pick an option (e.g., "1" or "Fix all")
    │
    ▼
PLAN: Agent shows detailed upgrade plan
  • Each item: library, from→to version, method, model
  • Dependency order: runtime → framework → libraries
  • Clearly shows: which use App Mod recipes, which use agent
  • Shows: current item, what changes, internal dependency impact
  • Effort estimate
    │
    ▼
YOU APPROVE: "proceed" / "skip 5,8" / "only 1-4"
    │
    ▼
EXECUTE: Agent upgrades item by item
  • Shows real-time progress for every step
  • Uses App Mod recipes where available
  • Uses Opus for complex items, Sonnet for simple ones
  • For enterprise items: reads skill or asks you for docs
    │
    ▼
BUILD: After each phase, agent compiles the project
  • If build fails → reads errors → fixes them → rebuilds
  • Up to 5 attempts per phase
  • Tries alternate dependency versions if artifact not found
  • If stuck: pauses and shows you options
    │
    ▼
DEPENDENCY CHECK: Verifies transitive dependencies
  • Checks for conflicts in dependency tree
  • Resolves version mismatches
  • Verifies all artifacts are downloadable
  • If artifact not in Nexus/Artifactory: tries nearby versions
    or pauses and asks you what to do
    │
    ▼
CVE CHECK: Verifies no new vulnerabilities introduced
  • Runs vulnerability scan on the upgraded dependencies
  • Reports any new CVEs introduced by upgrades
  • Fixes or flags them
    │
    ▼
TEST: Runs all existing tests
  • Fixes test failures caused by the upgrade
  • Adds safety tests for major refactors
  • Provides list of suggested test cases for changed code
  • Does NOT touch pre-existing test failures
    │
    ▼
FINAL BUILD: Clean build from scratch
  • mvn clean install / npm run build / pytest
  • Must be GREEN before completing
    │
    ▼
REPORT: Comprehensive summary
  • Every item: what changed, which method, result
  • Build status, test results
  • Files changed
  • CVEs resolved
  • Suggested test cases for review
  • Effort saved
  • Items needing manual attention (if any)
    │
    ▼
NEXT: menu / show diff / commit message / create skill
```

---

## How App Mod Extension Is Used

The TLM Agent integrates with the **GitHub Copilot Application Modernization extension** where recipes are available:

**Where App Mod recipes are used:**
- ✅ Spring Boot 2.x → 3.x upgrade
- ✅ Jakarta EE namespace migration (javax → jakarta)
- ✅ Java runtime upgrade (11 → 17/21)

**Where App Mod recipes are NOT available (agent handles it):**
- ❌ Spring Security 5 → 6 (agent uses Opus)
- ❌ Hibernate 5 → 6 (agent uses Opus)
- ❌ Angular version upgrades (agent uses Opus)
- ❌ Enterprise/internal libraries (agent uses enterprise skills)
- ❌ Python library upgrades (agent uses Sonnet/Opus)

**In the plan, you always see which method is used:**
```
│ 2 │ Spring Boot      │ 2.7→3.2  │ 📦 App Mod Recipe + 🧠 Opus edge cases │
│ 4 │ Spring Security  │ 5.8→6.2  │ ❌ No recipe → 🧠 Opus Agent Mode       │
```

**After App Mod recipe runs, the agent continues** to fix everything the recipe didn't handle — this is exactly what solves the problem your user reported where App Mod fixed Spring but broke other dependencies.

---

## Handling Dependency Issues

### When an Artifact Is Not Found

If a dependency version doesn't exist in your artifact repository:

```
⚠️ Artifact not found: com.example:library:2.5.0
   Not available in Nexus/Artifactory.

   Options:
   (a) Try nearest available version (2.4.8 found in repo)
   (b) Try latest available version (2.3.2 found in repo)
   (c) Skip this item and continue with others
   (d) Let me check — provide the correct version

   What would you like to do?
```

The agent never silently fails — it pauses and gives you options.

### Transitive Dependency Conflicts

After upgrades, agent checks the full dependency tree:
```
🔍 Checking transitive dependencies...
   ⚠️ Conflict: jackson-core pulled as 2.14.0 (via spring-boot)
      but jackson-databind needs 2.17.0
   → Resolution: Adding explicit jackson-bom 2.17.0 to manage versions ✅
```

---

## Using Your Own Prompts

The TLM Agent doesn't restrict you. You can always:

**Use the workflow:** Type "hi", pick an option, let the agent guide you

**Use your own prompt:** Type anything directly in Copilot chat:
```
"Upgrade only jackson-databind to 2.17.0 and fix any breaking changes"
"Show me what would change if I upgrade Angular from 15 to 17"
"Fix the CVE in log4j-core but don't touch anything else"
```

**Combine both:** Start with the workflow, then add custom instructions:
```
Agent shows plan → You say:
"Proceed but also update the Dockerfile Java version
 and add a migration note to CHANGELOG.md"
```

The workflow is a **starting point**, not a cage.

---

## Memory: Converting Fixes to Reusable Skills

When you fix an internal library upgrade manually or with agent help, the agent offers to **save that knowledge as a skill**:

```
✅ Successfully upgraded com.enterprise.payments-lib 2.0 → 3.0

💡 Want me to save this as a reusable skill?
   This way, any developer upgrading payments-lib in the future
   gets the same migration applied automatically.

   "Yes" — I'll create .github/skills/tlm/enterprise/payments-lib-v3.md
   "No"  — That's fine, moving on
```

If you say yes, the agent:
1. Creates a skill file documenting the package changes, API changes, config changes
2. Saves it to `.github/skills/tlm/enterprise/`
3. Next time anyone runs the TLM Agent on a project with payments-lib, it's automatic

**This is how the system gets smarter over time.** Every manual fix becomes a reusable skill.

---

## Pre-Upgrade Compile Check

Before making any changes, the agent offers:

```
📋 Current project state:
   Source files: 142 Java files in src/main/java
   Test files: 67 test files in src/test/java
   Current build status: [checking...]

   ⏳ Running: mvn clean compile -q
   ✅ Current project compiles successfully

   ⏳ Running: mvn test -q
   ✅ 140 tests pass, 2 pre-existing failures, 1 skipped

   This is the baseline. After upgrades, I'll make sure we're
   at least at this level (no new failures introduced).

   Ready to proceed with the upgrade plan?
```

---

## Suggested Test Cases After Upgrade

After completing upgrades, the agent provides:

```
🧪 SUGGESTED TEST CASES FOR CHANGED CODE

The following areas were modified during upgrades. Consider
adding or reviewing tests for:

Security Configuration (SecurityConfig.java — refactored):
  □ Test authenticated endpoint access
  □ Test public endpoint access without auth
  □ Test CSRF protection configuration
  □ Test CORS headers on cross-origin requests
  □ Test role-based access control

Enterprise Library Migration (jsci-common → platform-common):
  □ Test CommonUtils.convert() with various input types
  □ Test DateHelper.formatISO() output format
  □ Test cache configuration with new property names
  □ Test error handling with new exception types

Hibernate Upgrade (5→6):
  □ Test repository queries with new typed query API
  □ Test entity persistence with Jakarta annotations
  □ Test custom dialect behavior (if applicable)

These are suggestions — the existing tests pass, but these
areas have significant code changes worth additional coverage.
```

---

## Sample Workflows

### Example 1: Full Java TLM Fix

```
Developer: hi

Agent: [scans project]
       Project: payment-service | Java 11 | Maven | Spring Boot 2.7
       20 outdated | 3 CVEs | 4 enterprise libs
       [shows menu]

Developer: 1

Agent: [shows plan: 20 items in 4 phases]
       Phase 1: Java 17 (📦 App Mod Recipe)
       Phase 2: Spring Boot 3 (📦 App Mod + 🧠 Opus)
       Phase 3: CVEs (🤖 Sonnet)
       Phase 4: Libraries + Enterprise (🤖🏢)

Developer: proceed

Agent: [executes all items with real-time progress]
       [builds after each phase]
       [fixes 6 compilation errors automatically]
       [runs tests, fixes 3 TLM-caused failures]
       [final clean build: GREEN]
       [report: 19/20 fixed, 1 needs manual input]
       [suggested test cases for changed code]

Developer: show diff
Developer: looks good, committing
```

### Example 2: Angular Migration

```
Developer: hi

Agent: [scans project]
       Project: customer-portal | Angular 15.2 | npm
       15 outdated | 2 vulnerabilities
       [shows menu with Angular options]

Developer: 2 (Angular TLM Fixes)

Agent: [shows plan]
       Angular upgrade path: 15→16→17 (step-by-step)
       🧠 Using Opus model (Angular upgrades are complex)
       Includes: RxJS, TypeScript, Material, internal packages
       All transitive dependencies will be resolved

Developer: proceed

Agent: [upgrades 15→16 first]
       [runs ng build — verifies]
       [upgrades 16→17]
       [runs control flow migration schematic]
       [resolves transitive dependency conflicts]
       [final build: GREEN]
       [tests pass]
```

### Example 3: Enterprise Library with No Skill

```
Developer: 5 (Enterprise Library Upgrades)

Agent: Found 4 enterprise libraries:
       ✅ jsci-common → skill available
       ✅ auth-lib → skill available
       ❓ payments-lib 2.0→3.0 → no skill
       ❓ reporting-lib → no skill

       For payments-lib, can you provide:
       📄 Confluence link, changelog, or description of changes?

Developer: Here's the Confluence page: [link]
           Main changes: package renamed from com.enterprise.pay to
           com.enterprise.payments, and PaymentProcessor.execute()
           now returns CompletableFuture instead of void

Agent: [applies changes based on user input]
       [builds and tests]
       
       💡 Want me to save this as a reusable skill?
       
Developer: yes

Agent: [creates payments-lib-v3.md skill file]
       ✅ Skill saved. Next time anyone upgrades payments-lib,
       this will be applied automatically.
```

---

## Frequently Asked Questions

**Q: Does this replace my ability to use Copilot normally?**
A: No. The TLM Agent is an opt-in workflow. You can use Copilot Chat normally for any other work. The agent only activates when you say "hi" or "menu" in a project with TLM Agent files.

**Q: What if the agent makes a wrong change?**
A: Every change goes through your review. The agent shows a plan before starting and you approve it. After completion, you review the diff before committing. Nothing goes to production without your approval.

**Q: What if a dependency version isn't available in our Nexus?**
A: The agent will detect this, try the nearest available version, and if that doesn't work, pause and ask you for guidance with clear options.

**Q: Can I fix just one specific library?**
A: Yes. Just type: "Upgrade jackson-databind to 2.17.0" — you don't have to use the menu.

**Q: Does it work for multi-module Maven projects?**
A: Yes. The agent detects the project structure and handles parent POMs and module dependencies.

**Q: How do I add a skill for our internal library?**
A: Either ask the agent (option 7 → Add skill) and it will walk you through it, or manually copy the SKILL-TEMPLATE.md and fill it in.

**Q: What model does it use?**
A: Sonnet for standard upgrades (fast, cost-effective). Opus for complex migrations like Spring Boot 2→3, Angular major versions, Hibernate 5→6. App Mod recipes where available (no LLM needed — deterministic).

---

## How to Contribute

### Adding a New Skill
1. Copy `.github/skills/tlm/SKILL-TEMPLATE.md`
2. Fill in the metadata, steps, and code changes
3. Save to the appropriate folder:
   - `java/` for Java libraries
   - `angular/` for Angular packages
   - `python/` for Python libraries
   - `enterprise/` for internal libraries
4. Commit and push — all team members get the skill

### Reporting Issues
If the agent doesn't handle something correctly, please report it to the Platform DevAssist team with:
- What you were trying to upgrade
- What went wrong
- The project type and framework versions

### Requesting New Skills
Open a request with the Platform DevAssist team for:
- New enterprise library migration skills
- New framework version support
- Language support (e.g., .NET, Go)
