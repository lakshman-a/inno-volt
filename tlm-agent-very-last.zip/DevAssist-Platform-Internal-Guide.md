# DevAssist Agent Platform — Internal Management Guide

## For Platform Team: Managing TLM, QA, and Dev Agent Workflows

**Version:** 1.0 | **Classification:** Internal | **Owner:** Platform DevAssist Team

---

## What is the Agent Platform?

We provide **pre-built AI agent workflows** that run inside GitHub Copilot Agent Mode. These are NOT custom extensions or tools. They are **structured markdown files** — instructions, skills, and prompts — that tell Copilot how to perform specific workflows.

**Current Agents:**

| Agent | Purpose | Status |
|---|---|---|
| **TLM Agent** | Library, framework, runtime upgrades + CVE fixes | ✅ Active |
| **QA Agent** | Functional test generation and automation | ✅ Active |
| **Dev Agent** | Developer productivity (sonar, unit tests) | 🔜 Planned |

All agents follow the **same architecture pattern** and can be managed the same way.

---

## Architecture: What Each Piece Does

```
.github/
├── copilot-instructions.md          ← THE BRAIN
│   The master workflow file. Copilot reads this automatically
│   when Agent Mode is active. Contains:
│   • Greeting behavior (what happens on "hi")
│   • Menu structure and options
│   • Workflow phases (scan, plan, execute, validate, report)
│   • Rules and guardrails
│   • Model selection logic (when Sonnet vs Opus)
│
├── prompts/                          ← SHORTCUT TRIGGERS
│   Saved prompt files that users can invoke from Copilot's
│   prompt picker. Each file = one action.
│   • fix-all-tlm.md
│   • scan-tlm-only.md
│   • fix-from-tlm-list.md
│   These are OPTIONAL — users can also just type commands.
│
└── skills/                           ← THE KNOWLEDGE BASE
    └── tlm/                          (or qa/, dev/)
        ├── SKILL-TEMPLATE.md         ← Template for new skills
        ├── java/                     ← Language-specific skills
        │   ├── spring-boot-3.md      Each skill contains:
        │   ├── java-17.md            • Metadata (language, versions, method)
        │   └── common-libs.md        • Step-by-step upgrade instructions
        ├── angular/                  • Import/API/config changes
        ├── python/                   • Common errors and fixes
        ├── enterprise/               • Build verification steps
        │   ├── README.md
        │   └── jsci-common.md
        └── general/
            ├── unknown-upgrades.md
            └── build-validation.md

tlm-config/
└── telemetry-schema.md              ← TELEMETRY DEFINITION
    Defines the JSON schema for run reports.
    Telemetry files are auto-generated here.
```

### How The Pieces Connect

```
User says "hi"
    │
    ▼
Copilot reads: copilot-instructions.md
    │  (This tells Copilot the entire workflow)
    │
    ▼
Instructions say: "Scan the project first"
    │
    ▼
Instructions say: "Show menu based on scan results"
    │
    ▼
User picks an option
    │
    ▼
Instructions say: "For each item, check skills/ folder first"
    │
    ▼
Copilot reads: skills/tlm/java/spring-boot-3.md
    │  (Gets step-by-step migration knowledge)
    │
    ▼
Instructions say: "After changes, build and test"
    │
    ▼
Instructions say: "Generate telemetry report"
    │
    ▼
Done — all driven by markdown files, no code
```

---

## How to Manage Each Component

### Managing the Instructions File

**File:** `.github/copilot-instructions.md`

**When to update:**
- Copilot behavior changes (new model, new features)
- Workflow needs modification (new phases, different menu structure)
- New language support added
- New agent capabilities needed

**How to update:**
- Edit the markdown directly
- Test with a real project before rolling out
- Version control — use PRs for changes
- Changes propagate when developers pull latest

**What NOT to change without testing:**
- The greeting/scan behavior (Step 1-4)
- The plan approval flow (users expect approval before changes)
- Model selection logic (wrong model = bad results)
- Build validation rules

### Managing Skills

**When to add a new skill:**
- New major version of a framework drops (e.g., Spring Boot 4)
- Enterprise announces an internal library change
- Users report that agent doesn't handle a specific upgrade well
- New language or framework needs support

**How to add a skill:**

1. Copy `SKILL-TEMPLATE.md`
2. Fill in metadata:
```yaml
name: [descriptive-name]
language: [java|angular|python|enterprise]
category: [framework|library|runtime|enterprise|security]
type: [recipe|agent|enterprise]
from_version: [what version users are coming from]
to_version: [target version]
app_mod_recipe: [true|false]
estimated_complexity: [simple|moderate|complex]
```
3. Document the upgrade steps with before/after code
4. List import changes, API changes, config changes
5. List common errors and fixes
6. Add build verification command
7. Save to appropriate folder
8. Test with a real project
9. Commit and distribute

**Skill file quality checklist:**
- [ ] Metadata is complete and accurate
- [ ] Steps are in the correct upgrade order
- [ ] Before/After code examples are provided
- [ ] All import renames are listed
- [ ] All API changes are listed
- [ ] Common errors have documented fixes
- [ ] Build verification command is specified
- [ ] Tested with at least one real project

### Managing Enterprise Skills

**Trigger:** Enterprise team announces internal library change

**Process:**
1. Get the migration guide from the enterprise team (Confluence, email, etc.)
2. Extract: package renames, API changes, config changes
3. Create skill file at `.github/skills/tlm/enterprise/[library]-migration.md`
4. Test with a project that uses the library
5. Distribute to all project templates
6. Notify teams via Slack/email

**Auto-learning:** When users fix an enterprise library manually through the agent and say "yes" to saving it as a skill, a skill file is auto-generated. Review these for accuracy before distributing widely.

### Managing Prompts

**Prompts are optional shortcuts.** The main workflow runs from `copilot-instructions.md`. Prompts just provide convenient entry points.

**When to add a prompt:**
- When a common action needs a one-click shortcut
- When you want to standardize how a specific task is triggered

**How:**
1. Create a `.md` file in `.github/prompts/`
2. Include a description and the prompt text
3. Copilot's prompt picker shows these automatically

### Managing Telemetry

**Telemetry is auto-generated** by the agent after every run.

**Schema:** Defined in `tlm-config/telemetry-schema.md`

**Collection strategy:**
- Files saved to `tlm-config/tlm-telemetry-[timestamp].json`
- Can be committed to repo (tracked with code changes)
- Can be collected by CI/CD pipeline to central dashboard
- Used for ROI reporting to leadership

**Key metrics to track:**
| Metric | What it tells you |
|---|---|
| items_fixed / items_found | Success rate |
| method breakdown | Recipe vs Agent coverage |
| effort saved | ROI in developer hours |
| build_attempts | Quality of agent fixes |
| model usage | Cost optimization opportunity |
| developer_action (accepted/rejected) | Trust and adoption |

---

## When Enterprise Gives a New Update

### Real Example: JSCI EOL Retirement — March 2026

**What happened:**
Enterprise announced JSCI is being fully retired. All `fmr-commons-*` libraries must be replaced. Sites `jil.fmr.com` and `jsci.fmr.com` going offline April 2026.

**What we did:**

1. **Got the details:** Read the JSCI EOL Confluence page (component replacement mapping, alternative libraries, infrastructure changes)
2. **Created the skill:**
```
File: .github/skills/tlm/enterprise/jsci-eol-retirement.md

Contains:
- Complete component mapping (fmr-commons-jwt → dp-commons-jwt, etc.)
- Import changes for each component
- Open-source alternatives for fmr-commons-core (SLF4J, java.util.concurrent)
- Infrastructure references to remove (jil.fmr.com, jsci.fmr.com)
- Transitive dependency cleanup
- Common errors and fixes
```
3. **Tested:** Applied to a project using JSCI libraries
4. **Distributed:** Pushed to shared template repo — now every developer who says "hi" and has JSCI libraries will see them flagged automatically
5. **Notified:** Told teams the skill is available
6. **Result:** What was a multi-day manual migration per project is now a 30-minute guided workflow

**Time required:** 2 hours (one-time, serves all projects)

### Real Example: UBN22/RHEL8 → RHEL9 Buildpack Migration

**What happened:**
Enterprise Jenkins Core Buildpacks moving to multi-CPU architecture (UBN24/RHEL9). UBN22/RHEL8 EOL November 2025.

**What we did:**

1. **Created skill:** `.github/skills/tlm/enterprise/rhel8-to-rhel9-buildpack.md`
2. **Integrated App Mod:** The GHCP App Mod plugin can scan for UBN22/RHEL8 occurrences and generate image mapping, usage locations, and missing-upgrade reports. Skill references this.
3. **Distributed:** Same flow — skill auto-detected during scan

**Time required:** 1 hour

### Real Example: AMT FSF 7.5 EOL

**What happened:**
AMT FSF components (Config Utils, Identity, Rest, Secret, Usage Metrics) all reaching EOL June 2026.

**What we did:**

1. **Created skill:** `.github/skills/tlm/enterprise/amt-fsf-eol.md`
2. **Note:** Target versions TBD from enterprise — skill asks user for guidance on replacement
3. **When enterprise provides upgrade path:** Update the skill file with specific version mappings

**Time required:** 30 minutes (will update when enterprise provides target versions)

### General Process: Any New Enterprise Change

1. **Get the details:** Obtain migration guide from enterprise team
2. **Copy template:** `cp SKILL-TEMPLATE.md enterprise/[library]-migration.md`
3. **Fill in:** Package renames, API changes, config changes, common errors
4. **Test:** Apply the skill to one project
5. **Distribute:** Push to shared template repo
6. **Notify:** Tell teams the skill is available
7. **Verify:** Check telemetry to see adoption

**Time required:** 1-2 hours including testing

### Scenario: New Framework Version Drops

**What happens:** Spring Boot 4 is released (hypothetical)

**What you do:**

1. **Read the migration guide** from Spring
2. **Create/update skill:** `.github/skills/tlm/java/spring-boot-4-upgrade.md`
3. **Check App Mod:** Does the App Mod extension have a recipe? Update the `app_mod_recipe` flag
4. **Test thoroughly** — major framework upgrades need careful testing
5. **Update instructions** if the menu or workflow needs changes
6. **Distribute and notify**

**Time required:** 4-8 hours including testing

### Scenario: New Language Requested

**What happens:** Teams want .NET support

**What you do:**

1. **Add detection** in copilot-instructions.md (check for .csproj files)
2. **Create skill folder:** `.github/skills/tlm/dotnet/`
3. **Create initial skills:** Common .NET upgrades, framework migrations
4. **Update menu logic** in instructions to show .NET options
5. **Test with a .NET project**
6. **Distribute**

**Time required:** 1-2 weeks for initial setup

---

## Managing Across Agents (TLM, QA, Dev)

### Common Pattern

All agents follow the same structure:

```
TLM Agent:                    QA Agent:                     Dev Agent:
.github/                      .github/                      .github/
├── copilot-instructions.md   ├── copilot-instructions.md   ├── copilot-instructions.md
├── prompts/                  ├── prompts/                  ├── prompts/
│   └── tlm-specific.md       │   └── qa-specific.md        │   └── dev-specific.md
└── skills/                   └── skills/                   └── skills/
    └── tlm/                      └── qa/                       └── dev/
        ├── java/                     ├── api-testing/            ├── sonar/
        ├── angular/                  ├── ui-testing/             ├── unit-tests/
        └── enterprise/               └── data-testing/           └── refactoring/
```

### When Multiple Agents Exist in One Project

If a project needs both TLM and QA agents, the instructions should be combined into a single `copilot-instructions.md` OR use separate prompt files to trigger different workflows.

**Recommended approach:** Single instructions file with mode selection:
```
User says "hi" → Show mode selection:
  [T] TLM Agent — Fix library/framework upgrades
  [Q] QA Agent — Generate functional tests
  [D] Dev Agent — Sonar fixes, unit tests
```

### Shared Skills

Some skills can be shared across agents:
- Build validation (used by TLM and Dev)
- Test execution (used by TLM and QA)
- Enterprise knowledge (used by all)

Place shared skills in a `general/` folder accessible to all agents.

---

## Why This Approach vs Individual Confluence Pages

### For leadership discussions:

| Aspect | Individual Confluence | Agent Workflow Platform |
|---|---|---|
| **Discovery** | Developer must find the right page | Agent shows relevant options automatically |
| **Consistency** | Each team writes differently | Same workflow, same quality |
| **Maintenance** | Distributed, often neglected | Centralized, clear ownership |
| **Measurability** | None — can't track usage or results | Telemetry on every run |
| **Distribution** | Email/Slack links, hope people find it | Lives in repo, travels with code |
| **Scalability** | More pages = more chaos | More skills = more capability |
| **Knowledge retention** | Leaves when author leaves | Embedded in version-controlled files |
| **Junior developer support** | Must read and understand the doc | Agent guides them step by step |
| **Enterprise updates** | Update N Confluence pages | Update 1 skill file |
| **Cost** | Hidden (everyone's partial time) | Visible (platform team's focused time) |
| **Quality** | Varies by author | Consistent, reviewed, tested |

### Key talking points for leaders:

1. **"Single source of truth"** — Skills are version-controlled, reviewed, tested. Confluence pages are wiki chaos.

2. **"Executable documentation"** — A Confluence page tells you what to do. A skill file actually does it. The knowledge IS the automation.

3. **"Measurable ROI"** — We can show: X items fixed, Y hours saved, Z% adoption. Confluence can't show any of this.

4. **"Scales with the org"** — Adding a new migration path = adding one file. Supporting 100 developers = the same effort as supporting 10.

5. **"Not replacing flexibility"** — Developers can still use their own prompts. The agent is an addition, not a restriction.

### Issues with the Confluence approach (honest assessment):

1. Pages go stale — 50%+ become outdated within 6 months
2. No one owns cross-team consistency
3. Copy-paste errors when following instructions manually
4. No way to measure if anyone is actually using them
5. Enterprise updates require updating multiple pages
6. New team members don't know which pages to read
7. Knowledge leaves when the author changes teams

---

## Maintenance Calendar

| Frequency | Task | Effort |
|---|---|---|
| **Weekly** | Check if any agent runs failed (telemetry review) | 30 min |
| **Monthly** | Review newly auto-generated enterprise skills for accuracy | 1-2 hours |
| **Quarterly** | Update skills for new library major versions | 4-8 hours |
| **Quarterly** | Review and update copilot-instructions if Copilot behavior changed | 2-4 hours |
| **Ad-hoc** | Enterprise library migration announced → create skill | 1-2 hours |
| **Ad-hoc** | User reports issue → fix skill or instruction | 1-2 hours |
| **Yearly** | Major review of all skills, remove obsolete ones | 1 day |

**Total ongoing maintenance: ~8-12 hours per month**
(Compare to distributed Confluence: ~20+ hours/month across all teams, but invisible)

---

## Troubleshooting Guide

| Issue | Cause | Fix |
|---|---|---|
| Agent doesn't show menu on "hi" | Instructions file not loaded | Check `.github/copilot-instructions.md` exists and Copilot is in Agent Mode |
| Agent uses wrong model | Model selection logic in instructions | Update the model selection table in copilot-instructions.md |
| Skill not being used | Skill file path or name mismatch | Verify file is in correct `.github/skills/tlm/[language]/` folder |
| App Mod recipe not triggered | Extension not installed or recipe not applicable | Check App Mod extension is active, verify recipe compatibility in skill metadata |
| Build keeps failing after 5 attempts | Complex dependency issue | Review the error logs, may need manual intervention or a skill update |
| Enterprise skill is outdated | Library had another update | Update the skill file with new version info |
| Telemetry not generated | Agent workflow interrupted | Check if report phase was reached, review instructions for telemetry step |

---

## Getting Started for New Platform Team Members

1. **Read this document** — understand the architecture
2. **Try the TLM Agent yourself** — set up a test project, run "hi", try all options
3. **Read 2-3 skill files** — understand the format and level of detail
4. **Create a test skill** — pick any library, write a skill, test it
5. **Review the copilot-instructions.md** — understand the workflow logic
6. **Look at telemetry output** — understand what gets tracked
7. **Talk to users** — understand their pain points and feedback

---

## Scalable Pattern: How to Approach ANY New Enterprise TLM Change

This process is designed to scale. Whether it's JSCI, RHEL, AMT FSF, or something that doesn't exist yet — the pattern is the same.

### Step 1: Categorize the Change

When enterprise announces a new EOL/migration, ask:

| Question | Category | Approach |
|---|---|---|
| Is it a library replacement? (old package → new package) | **Library Migration** | Create skill with dependency swap + import mapping + API changes |
| Is it an infrastructure change? (OS images, buildpacks, hosts) | **Infrastructure Migration** | Create skill with file scan + reference mapping + replacement rules |
| Is it a version upgrade? (same library, new major version) | **Version Upgrade** | Create skill with breaking changes + migration steps |
| Is it a retirement with no replacement? | **Decommission** | Create skill that removes dependency + replaces with alternatives |

### Step 2: Gather Information

For **library migrations** (like JSCI EOL):
- Component-to-replacement mapping table
- Package/import rename mapping
- API method changes (old → new)
- Configuration property changes
- Infrastructure/host changes
- Common errors and their fixes

For **infrastructure migrations** (like RHEL8→9):
- Image name mapping (old → new)
- File types to scan (Dockerfile, Jenkinsfile, YAML, etc.)
- Removed/deprecated utilities
- Architecture compatibility notes
- Official documentation URL

### Step 3: Create the Skill File

```bash
# Copy template
cp .github/skills/tlm/SKILL-TEMPLATE.md .github/skills/tlm/enterprise/[name].md

# Fill in:
# 1. Metadata (name, language, priority, EOL date)
# 2. Context (why this change, what's the deadline)
# 3. Component mapping table (old → new, for every component)
# 4. Upgrade steps (scan → categorize → replace → verify)
# 5. Common errors and fixes
# 6. Final summary template
```

### Step 4: Wire Into Auto-Detection

Add detection patterns to `copilot-instructions.md` section 7 (Auto-detect enterprise libraries):
```
- Scan for [PATTERN]: `[old-package-name]` → match to [skill-name] skill
```

This ensures the agent automatically flags these items during the initial "hi" scan.

### Step 5: Test with a Real Project

Run the full workflow against a project that uses the affected library:
1. "Hi" → verify it appears in the dashboard
2. Pick the enterprise option → verify plan is accurate
3. Approve → verify execution is clean
4. Check build passes
5. Check the final summary is correct

### Step 6: Distribute and Monitor

Push to shared repo → notify teams → monitor telemetry for adoption and issues.

### Key Principle: The Skill IS the Documentation AND the Automation

When you create a skill file, you're simultaneously:
- **Documenting** the migration path (replaces Confluence)
- **Automating** the migration (agent reads and executes)
- **Standardizing** the approach (every developer gets the same quality)
- **Tracking** adoption (telemetry shows usage)

This means you never need a separate Confluence page AND a separate tool/script. The skill file serves both purposes.

