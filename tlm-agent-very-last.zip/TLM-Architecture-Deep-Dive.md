# TLM Agent — Architecture Deep Dive: Prompts, CLI, Orchestration & Platform Strategy

## For Internal Planning — Understand Before Building

---

## 1. SLASH PROMPTS vs WORKFLOW: Should We Have Both?

### What Are Slash Prompts?

In GitHub Copilot, you can create `.github/prompts/*.md` files. When a user types `/` in Copilot Chat, they see a list of available prompts. For example:

```
/fix-java-tlm        → Loads the Java TLM fix prompt
/fix-angular          → Loads the Angular upgrade prompt
/fix-enterprise-libs  → Loads the enterprise library fix prompt
/scan-project         → Loads the scan-only prompt
```

### We Already Have These!

Look at our package — we already have 5 prompt files:
```
.github/prompts/
├── fix-all-tlm.md
├── fix-enterprise-tlm.md
├── fix-from-tlm-list.md
├── scan-tlm-only.md
└── show-tlm-skills.md
```

These are slash prompts that shortcut directly to a specific menu option. But here's the key question:

### Do Prompts Replace the Workflow? NO.

| Aspect | Slash Prompts | Workflow (copilot-instructions.md) |
|---|---|---|
| **What it is** | A shortcut to start a specific task | The full brain — rules, phases, validation |
| **Entry point** | User types `/fix-java-tlm` | User types "hi" or picks a menu option |
| **What it loads** | A focused instruction for one task | The entire workflow context |
| **Who benefits** | Power users who know exactly what they want | Everyone — especially new users who need the scan/menu |
| **Rules/guardrails** | Only if duplicated from instructions | Full rules always active |
| **Skill awareness** | Only if the prompt references skills | Always reads all skills |

### The Right Architecture: Prompts Are Entry Points, Workflow Is the Engine

```
                   ┌─────────────────────────────┐
                   │  copilot-instructions.md     │
                   │  (THE BRAIN — always loaded) │
                   │  • Scan logic                │
                   │  • Plan/Approve flow         │
                   │  • Execution rules           │
                   │  • Validation rules           │
                   │  • Model selection           │
                   │  • Summary format            │
                   └──────────┬──────────────────┘
                              │ Always active
                              │
              ┌───────────────┼───────────────┐
              │               │               │
     User says "hi"    User types /fix-java   User types /scan
              │               │               │
              ▼               ▼               ▼
         Shows menu      Jumps to Java     Jumps to scan
         (full flow)     TLM workflow       (scan only)
              │               │               │
              └───────┬───────┘               │
                      ▼                       │
              Same execution engine ──────────┘
              Same validation rules
              Same skills loading
              Same summary format
```

### So What Should the Prompts Do?

**They should NOT duplicate the instructions.** They should be thin entry points:

```markdown
# .github/prompts/fix-java-tlm.md
---
mode: agent
description: "Fix all Java TLM items — libraries, frameworks, CVEs"
---

Focus on Java TLM items only. Skip Angular and Python.
Follow the standard workflow phases (scan → plan → execute → validate → report)
as defined in copilot-instructions.md.

Start by scanning Java dependencies, then show the plan for Java items only.
```

The prompt says WHAT to focus on. The instructions say HOW to do it. No duplication.

### Analysis: Is It Worth Having Both?

**YES — zero extra maintenance cost.** Here's why:

- Prompts are 5-10 lines each (they just point to the instructions)
- They don't duplicate logic — they reference the workflow
- Power users get faster access to specific tasks
- New users still get the full menu experience
- Both use the same skills, same rules, same validation

**Risk of NOT having prompts:** Power users complain "I don't need the scan, just fix my Java stuff." Without prompts, they have to go through the menu every time.

**Risk of having prompts with duplicated logic:** Now you maintain rules in two places. When you update the plan format, you forget to update the prompt. Drift happens. Bad.

### Recommendation

✅ **Keep the prompts we have** — they're already thin entry points
✅ **Make sure they reference the instructions, not duplicate them**
✅ **Add a few more for common requests:**
   - `/fix-jsci` — Jump straight to JSCI EOL migration
   - `/fix-rhel` — Jump straight to RHEL8→9 buildpack migration
   - `/fix-cves` — Jump straight to CVE fixes only
✅ **Don't create one prompt per library** — that's overkill. Keep it at category level.

---

## 2. AGENT ORCHESTRATION: What Is It and Do We Need It?

### What Is Agent Orchestration?

Agent orchestration is when **multiple AI agents work together**, coordinated by a controller, to complete a complex task. Think of it like a team of specialists managed by a project manager.

```
┌─────────────────────────────────────────────┐
│           ORCHESTRATOR (Controller)          │
│  Decides which agent to call, in what order  │
│  Manages state, handles handoffs             │
└───────┬──────────┬──────────┬───────────────┘
        │          │          │
        ▼          ▼          ▼
   ┌─────────┐ ┌─────────┐ ┌─────────┐
   │ Agent A  │ │ Agent B  │ │ Agent C  │
   │ (Java)   │ │ (Angular)│ │ (Testing)│
   └─────────┘ └─────────┘ └─────────┘
```

### What Are Handoffs?

A "handoff" is when one agent finishes its part and passes the work to the next agent:

```
Agent A (Java upgrade):
  "I've upgraded Spring Boot and fixed JSCI. 
   Build passes. Handing off to Agent B for Angular."
         │
         ▼ HANDOFF (passes project state + what was done)
         
Agent B (Angular upgrade):
  "Received from Agent A. Java is done.
   Now upgrading Angular 15→17..."
         │
         ▼ HANDOFF
         
Agent C (Validation):
  "Received from A and B. Running full build,
   tests, CVE check, generating report..."
```

### Real Example with What We Currently Do

**Scenario: Multi-language project (Java backend + Angular frontend)**

**WITH orchestration (if we had it):**
```
Orchestrator: "This is a multi-language project."
  → Calls Java Agent: "Fix Java TLM items"
  → Java Agent completes, hands off
  → Calls Angular Agent: "Fix Angular TLM items"  
  → Angular Agent completes, hands off
  → Calls Validation Agent: "Build everything, run tests"
  → Validation Agent reports results
```

**WITHOUT orchestration (what we do now):**
```
TLM Agent (single): "This is a multi-language project."
  → Phase 1: Fix Java items (reads Java skills)
  → Phase 2: Fix Angular items (reads Angular skills)
  → Phase 3: Validate everything (build, test)
  → Report results
```

### Do We Need Orchestration?

**RIGHT NOW: NO.** Here's why:

| Factor | Our Current State | When You'd Need Orchestration |
|---|---|---|
| **Complexity** | One project, multiple languages | Multiple projects, multiple agents, parallel work |
| **Agent count** | One agent, multiple skills | 3+ independent agents that need coordination |
| **State management** | Agent holds context throughout | Agents run separately, need to share state |
| **Failure recovery** | Agent retries in same session | Need to recover across agent boundaries |
| **Current Copilot** | Single agent mode | Multi-agent mode (not yet available in Copilot) |

**Our single-agent-with-skills approach IS the right architecture for now** because:
1. One agent maintains full context — no state loss between handoffs
2. Skills give it the specialist knowledge without needing separate agents
3. Simpler to maintain, debug, and explain
4. GitHub Copilot doesn't support multi-agent orchestration yet

### When Would We Need Orchestration?

**Future scenarios where orchestration makes sense:**

1. **Scale (50+ repos):** CLI agent orchestrates: scan all repos → prioritize → fix each → create PRs
2. **Different tool chains:** One agent uses App Mod extension, another uses CLI, another creates PRs — orchestrator coordinates
3. **QA + TLM combined:** TLM Agent fixes code → hands off to QA Agent to generate tests → hands off to PR Agent to create the pull request
4. **Human-in-the-loop at scale:** Orchestrator queues items needing human decisions, continues with automatable items

**For now:** Keep our single-agent architecture. Plan for orchestration when CLI + multi-agent support matures. The skills architecture we built makes the transition easy — skills can be loaded by any agent.

---

## 3. CLI DEEP DIVE: What Changes for Platform Team and Developers

### What Exists Today

**Copilot CLI** — GitHub is evolving this. Currently limited. The full agent mode is IDE-only.

**Claude Code** — Anthropic's CLI tool. Available now. Can:
- Read files in a project
- Make code changes
- Run terminal commands (build, test, git)
- Work with custom instructions
- Run autonomously or interactively

### How Our Files Map to CLI

```
WHAT WE BUILT              → HOW IT WORKS IN CLI
──────────────────────────────────────────────────
copilot-instructions.md    → Claude Code reads this as its system prompt
                              (or Copilot CLI reads it when supported)

.github/skills/tlm/*.md   → Agent reads these as context files
                              Same skill files, same knowledge

.github/prompts/*.md       → Becomes CLI flags or commands
                              e.g., --prompt "fix-java-tlm"

Terminal commands           → CLI agent runs them directly
(mvn, npm, ng, etc.)         No VS Code needed
```

**Key insight: Our markdown files are tool-agnostic.** They work in:
- VS Code Copilot Agent Mode (today)
- Claude Code CLI (today, if someone wants to try)
- Future Copilot CLI (when available)
- Any LLM agent that supports file-based instructions

### What CLI Changes for a DEVELOPER

**Today (IDE):**
```
1. Open VS Code
2. Open project
3. Open Copilot Chat
4. Type "hi"
5. Interact with agent
6. Review changes
7. Commit
```

**With CLI:**
```
1. Open terminal
2. cd into project
3. Run: claude-code --instructions .github/copilot-instructions.md
4. Agent runs autonomously (or interactively)
5. Review changes (git diff)
6. Commit
```

**Or fully automated:**
```
1. Run a script that does everything
2. Review the PR that appears in GitHub
3. Approve and merge
```

**Developer benefit:** Less context switching. Faster. Can run in background while doing other work.

### What CLI Changes for YOU (Platform Team)

**Today:**
```
You build:     Instruction files + skill files + prompts
You distribute: Put in GitHub template repo, tell teams to copy
Devs use:      Open VS Code, use Copilot Agent Mode
You track:     Telemetry from agent runs (if devs remember to use it)
```

**With CLI:**
```
You build:     Same instruction files + skill files + prompts (no change!)
You distribute: Same GitHub repo (no change!)
You ALSO can:
  • Run TLM fixes across multiple repos via script
  • Schedule nightly TLM scans via CI/CD
  • Auto-create PRs for TLM compliance
  • Track telemetry centrally (every run produces output)
  • Enforce compliance: "All projects must run TLM scan monthly"
```

**Platform team superpowers with CLI:**
```bash
# Nightly TLM compliance scan across all team repos
#!/bin/bash
for repo in $(cat /repos/all-java-repos.txt); do
  git clone $repo /tmp/scan-$repo
  cd /tmp/scan-$repo
  
  claude-code \
    --instructions .github/copilot-instructions.md \
    --prompt "Scan only. Report TLM health. Don't fix anything." \
    --output /reports/$repo-tlm-health.json
  
  cd /
done

# Aggregate reports into dashboard
python3 aggregate-tlm-reports.py /reports/ > /dashboard/tlm-status.html
```

### Is It a Package You Deploy?

**No.** It's not a server or a microservice. Think of it more like:

- **Claude Code** = a CLI binary you install (like `git` or `node`)
- **Our instructions/skills** = configuration files that tell it what to do (like `.gitconfig` or `package.json`)
- **Running it** = invoking the CLI with our config against a project

```
CLI tool (Claude Code / Copilot CLI)
  + Our config files (instructions + skills)
  + Target project (the code to fix)
  = Automated TLM fixes
```

Nothing to deploy. Nothing to host. The CLI tool runs locally (or in CI/CD runners).

### Does It Replace IDE-Based Agent?

**No — it complements it.**

| Use Case | Best Tool |
|---|---|
| Developer fixing their own project interactively | IDE (VS Code + Copilot) |
| Developer who prefers terminal | CLI |
| Platform team running batch scans | CLI |
| CI/CD automated TLM compliance | CLI |
| Nightly auto-fix across repos | CLI |
| Demo/presentation with visual | IDE |

Both use the same files. Maintain once, run anywhere.

---

## 4. SUB-AGENTS: What Are They and When Do We Need Them?

### What Is a Sub-Agent?

A sub-agent is a specialized agent that runs WITHIN the context of a parent agent. The parent delegates specific tasks to sub-agents.

```
Parent Agent (TLM Agent):
  "I need to fix JSCI libraries. Let me call my JSCI specialist."
     │
     ├── Sub-Agent: JSCI Migration Expert
     │   Reads: jsci-eol-retirement.md
     │   Knows: Every component mapping, every import change
     │   Returns: "Done. Here's what I changed."
     │
     ├── Sub-Agent: Build Validator  
     │   Runs: mvn clean compile
     │   Returns: "Build passed" or "3 errors, here they are"
     │
     └── Sub-Agent: Security Scanner
         Runs: dependency-check
         Returns: "No new CVEs"
```

### How Is This Different From Skills?

| | Skills (What We Have) | Sub-Agents (Future) |
|---|---|---|
| **What** | Text files the agent reads | Independent agents that execute |
| **Intelligence** | The main agent interprets and applies | Sub-agent has its own reasoning |
| **Context** | Loaded into main agent's context window | Runs in its own context (more capacity) |
| **Autonomy** | Main agent decides everything | Sub-agent decides within its scope |
| **Today** | Works now in Copilot | Not supported in Copilot yet |

### Do We Need Sub-Agents Now?

**NO.** Our skills architecture gives us 90% of the benefit:
- Skills provide specialist knowledge (same as a sub-agent would know)
- The main agent is smart enough to apply skills correctly
- No coordination overhead
- Works in current Copilot

### When Would Sub-Agents Help?

**Future scenario where sub-agents add value:**

1. **Context window limits:** If a project has 500 files and 20 TLM items, the main agent might run out of context. Sub-agents could each handle a subset.

2. **Parallel execution:** Fix Java items AND Angular items simultaneously (not sequentially).

3. **Specialist reasoning:** A JSCI sub-agent that deeply understands crypto migration patterns — better than the main agent reading a skill file.

4. **Agent-to-agent handoff:** TLM Agent fixes code → QA Agent generates tests → Deploy Agent creates PR. Each is a sub-agent in an orchestrated flow.

**Our preparation:** Skills are the stepping stone to sub-agents. When sub-agent support arrives, each skill file becomes the instruction for a sub-agent. Zero rewrite.

---

## 5. PLATFORM STRATEGY: LLM Gateway vs CLI vs IDE Agent

### The Options on the Table

| Approach | What It Is | Effort | Reach | Autonomy |
|---|---|---|---|---|
| **IDE Agent (current)** | Copilot Agent Mode in VS Code with our instructions + skills | Done ✅ | Developers using VS Code | Interactive |
| **CLI Agent (future)** | Claude Code or Copilot CLI running our same files | Low (files already built) | Terminal users + CI/CD + batch | Fully autonomous possible |
| **LLM Gateway** | Build a service that calls LLM API, processes code, returns fixes | HIGH | Any client | Fully autonomous |

### LLM Gateway: Is It Worth Building?

An LLM Gateway approach means:
```
Developer → Calls API → Gateway Service → Calls Claude/GPT API 
→ Reads project code → Makes fixes → Returns diff → Developer applies
```

**Advantages:**
- Centralized control over prompts and model selection
- Can enforce policies (rate limits, approved models, audit logging)
- Works regardless of developer's IDE
- Can integrate with existing internal tools

**Disadvantages:**
- Significant engineering effort to build and maintain
- Need to handle: file upload, project structure parsing, dependency resolution, build execution, error fixing — all server-side
- The LLM needs to run builds and tests — requires compute infrastructure
- Authentication, authorization, scaling, monitoring
- You're rebuilding what Copilot/Claude Code already provides

### Recommendation: Don't Build an LLM Gateway for TLM

**Why:** CLI tools (Claude Code, Copilot CLI) will give you everything an LLM Gateway would, with near-zero infrastructure effort:

| LLM Gateway | CLI Agent |
|---|---|
| Build a server | Install a CLI tool |
| Handle file uploads | CLI reads files locally |
| Run builds server-side | CLI runs builds locally |
| Manage compute for builds | Uses local/CI compute |
| Build API, auth, scaling | Already handled by the CLI tool |
| 3-6 months to build | Available now (Claude Code) or soon (Copilot CLI) |

The only reason to build an LLM Gateway:
- If you need a web UI for non-technical users (unlikely for TLM)
- If corporate policy requires centralized API access
- If you want to build a product/service on top of it

For TLM, the answer is: **Use CLI tools with our instruction/skill files.**

### The Efficient Platform Strategy

```
PHASE 1 (NOW): IDE Agent ← We are here
  • Instructions + Skills + Prompts in GitHub
  • Developers use Copilot Agent Mode in VS Code
  • Manual adoption — teams opt in
  
PHASE 2 (NEXT 3-6 MONTHS): CLI Integration
  • Same files, run via CLI (Claude Code or Copilot CLI)
  • Platform team runs batch scans
  • CI/CD integration for automated compliance checks
  • Auto-PR creation for TLM fixes
  
PHASE 3 (6-12 MONTHS): Orchestration at Scale
  • CLI agents across all repos
  • Nightly TLM scans with dashboards
  • Sub-agents for specialized tasks (if supported)
  • Full compliance automation
  
WHAT WE DON'T NEED TO BUILD:
  ✗ LLM Gateway service (CLI gives us this for free)
  ✗ Custom VS Code extension (instructions work without one)
  ✗ Sub-agent framework (skills give us the same knowledge)
  ✗ Separate agents per language (one agent handles all)
```

### What About Other Teams Building LLM Gateway?

If other platform teams are building an LLM Gateway for similar purposes:

**Our advantage:** We already have the intelligence layer built (instructions + skills). If someone builds a gateway, they still need what we have — the knowledge of HOW to fix JSCI, HOW to upgrade Angular, HOW to handle multi-module projects. Our skills are the portable knowledge layer that works in ANY execution environment.

**Our position:** "We don't compete with the execution platform (gateway, CLI, IDE). We provide the intelligence layer that any execution platform can use. Our skills and instructions work in Copilot, Claude Code, any LLM gateway, or any future tool."

---

## 6. SUMMARY: What to Tell Leaders and Peers

### Quick Decision Matrix

| Question | Answer | Why |
|---|---|---|
| Do we need slash prompts? | Yes, keep them thin — they're entry points to the workflow | Zero extra maintenance, power users love them |
| Do we need a sub-agent? | No, not now. Skills give us the same benefit | Copilot doesn't support it yet, skills work great |
| Do we need agent orchestration? | Not now. Plan for it with CLI | Single agent is simpler and works for current scale |
| Does CLI change our files? | No! Same files work in IDE and CLI | This is our biggest design advantage |
| Should we build an LLM Gateway? | No. CLI tools give us the same result for free | Don't build infrastructure when CLI handles it |
| What's our selling point? | "40% → 100%. Including internal libraries." | Nobody else handles the complete migration |
| How do we stand out from other teams? | Our intelligence layer (skills) is portable | Works in any execution environment |

### The Pitch to Leadership

"We've built a portable TLM intelligence layer — instructions and skills that contain the knowledge of how to fix every library, every framework, every internal package. Today it runs in VS Code via Copilot. Tomorrow it runs in CLI for batch processing. It doesn't require infrastructure to build or maintain. It uses App Mod recipes where they exist and fills the gap where they don't — including Fidelity internal libraries that no other solution handles. One workflow, every language, guaranteed compilable output."

### The Pitch to Peers (Other Platform Teams)

"We're not competing with your execution platform. We're providing the intelligence layer. Whether you run it through Copilot, Claude Code, your LLM gateway, or a CI/CD pipeline — you still need to know HOW to migrate JSCI, HOW to handle FMR library conflicts, HOW to upgrade Angular step by step. That's what our skills provide. We should collaborate: you build the execution platform, we provide the TLM knowledge."

### The Pitch to Developers

"Say 'hi' to the TLM Agent. It scans your project, shows you everything that's outdated, creates a plan, asks for your approval, then fixes everything — including the internal libraries that usually break your build. You get a working project back. Not a half-finished upgrade."
