# DevAssist Agents — Unified Multi-Agent Framework

> **One repo. Three agents. Shared architecture. Zero duplication.**

## Agents

| Agent | Purpose | Key Capabilities |
|-------|---------|------------------|
| **Senior Developer** | Code quality & development | Sonar fixes, unit tests, scaffolding, feature design, code review, refactoring |
| **QA Automation** | Functional & API testing | Cucumber+Serenity, Karate DSL, JaCoCo coverage, test gap analysis |
| **TLM** | Technology Lifecycle Mgmt | Library upgrades, CVE fixes, enterprise migrations, App Mod recipes |

---

## Folder Structure

```
.github/
├── copilot-instructions.md              ← SHARED: Global rules for ALL agents (THE BRAIN)
│
├── common/                              ← SHARED: Cross-agent shared knowledge
│   ├── telemetry-schema.md              ← Unified telemetry format
│   ├── model-selection.md               ← Opus vs Sonnet decision guide
│   ├── multi-module.md                  ← Multi-module project handling
│   └── enterprise-standards.md          ← Naming, logging, error handling, config
│
├── agents/                              ← AGENT PERSONAS & WORKFLOWS
│   ├── sr-developer/
│   │   └── sr-developer.agent.md        ← NEW — Sr Dev persona + 8 workflows
│   ├── qa-automation/
│   │   └── qa-automation.agent.md       ← QA agent persona + workflow summary
│   └── tlm/
│       └── tlm.agent.md                 ← TLM agent persona + workflow summary
│
├── skills/                              ← DOMAIN KNOWLEDGE (per agent)
│   ├── dev/                             ← Sr Developer skills (NEW)
│   │   ├── sonar/SKILL.md              ← Sonar API + local scan + fix strategies
│   │   ├── testing/SKILL.md            ← Unit test gen (Java/Angular/Python)
│   │   ├── scaffolding/SKILL.md        ← Enterprise project templates
│   │   ├── design/SKILL.md             ← Feature design + API contracts
│   │   └── refactoring/SKILL.md        ← Code review + refactoring patterns
│   │
│   ├── qa/                              ← QA skills (MOVE from existing QA agent)
│   │   ├── qa-cucumber-serenity/SKILL.md
│   │   ├── qa-jacoco-coverage/SKILL.md
│   │   ├── qa-karate-dsl/SKILL.md
│   │   ├── qa-test-data-assertions/SKILL.md
│   │   ├── qa-test-design/SKILL.md
│   │   └── qa-test-execution/SKILL.md
│   │
│   └── tlm/                             ← TLM skills (MOVE from existing TLM agent)
│       ├── java/                        ← Spring Boot 3, Java 17, Jakarta, libs
│       ├── angular/                     ← Angular enterprise upgrades
│       ├── python/                      ← Django, Flask, Pydantic, SQLAlchemy
│       ├── enterprise/                  ← JSCI, AMT FSF, RHEL, internal libs
│       ├── general/                     ← Build validation, unknown upgrades
│       └── SKILL-TEMPLATE.md            ← Template for new TLM skills
│
├── prompts/                             ← SLASH COMMANDS (per agent)
│   ├── dev/                             ← /fix-sonar, /write-tests, etc. (NEW)
│   ├── qa/                              ← /create-tests, /run-jacoco, etc.
│   └── tlm/                             ← /fix-all-tlm, /fix-cves-only, etc.
│
└── config/                              ← SHARED CONFIGURATION
    ├── sonar-config.json                ← Sonar connection (user fills in)
    └── agent-config.json                ← Defaults for all agents

.vscode/
└── settings.json                        ← VS Code + Copilot settings (SHARED)
```

---

## How to Set Up

### 1. Clone/Copy
Copy this entire `.github/` folder and `.vscode/` folder into your project root.

### 2. Configure Sonar (Optional)
Edit `.github/config/sonar-config.json` with your SonarQube details:
```json
{
  "sonarUrl": "https://sonar.fmr.com",
  "projectKey": "your-project-key",
  "branch": "develop",
  "token": "your-sonar-token"
}
```

### 3. Open in VS Code
- Ensure GitHub Copilot with Agent Mode is enabled (VS Code 1.106+)
- The `.vscode/settings.json` automatically loads `copilot-instructions.md`
- Type `hi` or `menu` in Copilot Chat to get started

### 4. Agent Auto-Routing
The shared `copilot-instructions.md` auto-routes to the right agent:
- "fix sonar issues" → **Sr Developer**
- "write unit tests" → **Sr Developer**
- "create API tests" → **QA Automation**
- "upgrade libraries" → **TLM**

Or invoke directly: `@sr-developer`, `@qa-automation`, `@tlm`

---

## 📋 File Placement Guide — Moving Existing Agent Files

### From Your Existing TLM Agent (`tlm-agent-v2-final/.github/`)

| Existing Location | Move To |
|---|---|
| `copilot-instructions.md` | `.github/agents/tlm/tlm.agent.md` (merge workflow details into it) |
| `skills/tlm/java/*` | `.github/skills/tlm/java/` (copy all .md files) |
| `skills/tlm/angular/*` | `.github/skills/tlm/angular/` |
| `skills/tlm/python/*` | `.github/skills/tlm/python/` |
| `skills/tlm/enterprise/*` | `.github/skills/tlm/enterprise/` |
| `skills/tlm/general/*` | `.github/skills/tlm/general/` |
| `skills/tlm/SKILL-TEMPLATE.md` | `.github/skills/tlm/SKILL-TEMPLATE.md` |
| `prompts/fix-all-tlm.md` | `.github/prompts/tlm/fix-all-tlm.md` |
| `prompts/fix-angular.md` | `.github/prompts/tlm/fix-angular.md` |
| `prompts/fix-cves-only.md` | `.github/prompts/tlm/fix-cves-only.md` |
| `prompts/scan-tlm-only.md` | `.github/prompts/tlm/scan-tlm-only.md` |
| (other prompts) | `.github/prompts/tlm/` |
| `tlm-config/` (telemetry) | Keep at project root — agent writes here |
| `.vscode/settings.json` | ❌ REPLACED by shared `.vscode/settings.json` |

### From Your Existing QA Agent (`qa-agent/.github/`)

| Existing Location | Move To |
|---|---|
| `copilot-instructions.md` (QA) | `.github/agents/qa-automation/qa-automation.agent.md` (merge workflow details) |
| `senior-qa-automation.agent.md` | `.github/agents/qa-automation/qa-automation.agent.md` (merge) |
| `skills/qa-cucumber-serenity/*` | `.github/skills/qa/qa-cucumber-serenity/` |
| `skills/qa-jacoco-coverage/*` | `.github/skills/qa/qa-jacoco-coverage/` |
| `skills/qa-karate-dsl/*` | `.github/skills/qa/qa-karate-dsl/` |
| `skills/qa-test-data-assertions/*` | `.github/skills/qa/qa-test-data-assertions/` |
| `skills/qa-test-design/*` | `.github/skills/qa/qa-test-design/` |
| `skills/qa-test-execution/*` | `.github/skills/qa/qa-test-execution/` |
| `prompts/create-tests.md` | `.github/prompts/qa/create-tests.md` |
| `prompts/run-jacoco.md` | `.github/prompts/qa/run-jacoco.md` |
| `prompts/enhance-tests.md` | `.github/prompts/qa/enhance-tests.md` |
| `.vscode/settings.json` | ❌ REPLACED by shared `.vscode/settings.json` |

### What's NEW (Sr Developer Agent)
All files in `skills/dev/`, `prompts/dev/`, and `agents/sr-developer/` are brand new.

### What's SHARED (Common to ALL agents — replaces per-agent duplicates)
| File | Replaces |
|---|---|
| `.github/copilot-instructions.md` | Individual copilot-instructions.md in each agent |
| `.github/common/telemetry-schema.md` | Separate telemetry schemas per agent |
| `.github/common/model-selection.md` | Model selection rules duplicated in each agent |
| `.github/common/multi-module.md` | Multi-module handling duplicated in each agent |
| `.github/common/enterprise-standards.md` | Coding standards scattered across agents |
| `.github/config/agent-config.json` | Hardcoded defaults in each agent |
| `.github/config/sonar-config.json` | Sonar settings asked every session |
| `.vscode/settings.json` | Separate settings.json per agent project |

---

## Agent Menu (What Users See)

When user types "hi" or "menu":

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛠️ DEVASSIST — PROJECT DASHBOARD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📁 Project: [auto-detected]
☕ Language: [Java X / Angular X / Python X]
🏗️ Build: [Maven / npm / pip]
🧪 Tests: [X files, ~Y% coverage]
🔍 Sonar: [configured / not configured]

🔧 DEVELOPER WORKFLOWS
  [1] 🔍 Fix Sonar Issues
  [2] 🧪 Write Unit Tests (target 90%+)
  [3] 🏗️ Create New Feature
  [4] 📐 Scaffold Enterprise Project
  [5] 🔄 Refactor Code
  [6] 📊 Code Review

🧪 QA WORKFLOWS
  [7] 🧪 Create API Test Suite
  [8] 📈 Run JaCoCo Coverage
  [9] ✨ Enhance Existing Tests

🔄 TLM WORKFLOWS
  [10] 🔄 Fix All TLM Items
  [11] 🛡️ Fix CVEs Only
  [12] 🏢 Enterprise Library Upgrades
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Future Agents

To add a new agent (e.g., DevOps Agent):
1. Create `.github/agents/devops/devops.agent.md`
2. Create `.github/skills/devops/` with skill files
3. Create `.github/prompts/devops/` with slash commands
4. Add routing rules to `.github/copilot-instructions.md`
5. Common files (telemetry, model selection, standards) are already shared — no duplication needed
