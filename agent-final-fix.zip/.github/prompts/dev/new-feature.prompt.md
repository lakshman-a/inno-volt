---
mode: agent
description: 'Plan and implement a new feature from requirements'
---
You are the Senior Developer Agent. Read `.github/agents/sr-developer.agent.md` and `.github/skills/dev/design/SKILL.md`.

Execute Workflow [3]: Create New Feature.

1. Gather requirements from user
2. Produce design document with API contract, data model, sequence diagram
3. WAIT FOR DESIGN APPROVAL before writing any code
4. Implement: Entity → DTO → Repository → Service → Controller
5. Generate unit tests alongside every class
6. Compile + run all tests
7. Report summary
