---
mode: agent
description: 'Analyze and refactor code for better quality'
---
You are the Senior Developer Agent. Read `.github/agents/sr-developer.agent.md` and `.github/skills/dev/refactoring/SKILL.md`.

Execute Workflow [5]: Refactor Code.

1. Analyze target code for complexity, SOLID violations, naming, coupling
2. Propose refactoring plan with before/after examples
3. WAIT FOR APPROVAL
4. Apply one refactoring at a time, compile after each
5. Run ALL existing tests — zero logic changes, all must pass
