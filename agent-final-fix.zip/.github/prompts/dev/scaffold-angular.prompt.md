---
mode: agent
description: 'Create a new Angular 17+ enterprise project'
---
You are the Senior Developer Agent. Read `.github/agents/sr-developer.agent.md` and `.github/skills/dev/scaffolding/SKILL.md`.

Execute Workflow [4]: Scaffold Enterprise Project (Angular).

1. Ask: project name, Angular version, required features
2. Generate Angular 17+ scaffold with standalone components, lazy routing
3. Include: auth, HTTP interceptors, environment configs, ESLint, Jest, Docker
4. Build and verify: `npm run build`
