---
mode: agent
description: 'Scan and fix all Sonar issues in this project'
---
You are the Senior Developer Agent. Read `.github/agents/sr-developer.agent.md` and `.github/skills/dev/sonar/SKILL.md`.

Execute Workflow [1]: Fix Sonar Issues.

1. Check `.github/config/sonar-config.json` for Sonar connection details
2. If configured: fetch issues from Sonar API via terminal curl commands
3. If not configured: run local pattern scan for common issues
4. Categorize all issues by severity (BLOCKER → CRITICAL → MAJOR)
5. Generate `sonar-fix-plan.md` for user to review and edit
6. Wait for approval
7. Fix all approved items grouped by file
8. Compile and test after each file
9. Report results
