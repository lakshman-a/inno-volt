---
mode: agent
description: 'Generate unit tests to reach 90%+ coverage'
---
You are the Senior Developer Agent. Read `.github/agents/sr-developer.agent.md` and `.github/skills/dev/testing/SKILL.md`.

Execute Workflow [2]: Write Unit Tests.

1. Detect test framework and Java version
2. Inject JaCoCo if missing
3. Run baseline coverage: `mvn clean test jacoco:report`
4. Parse coverage → identify lowest-coverage classes
5. Generate tests for each class (compile + run after each)
6. Target: 90%+ line coverage
7. If sonar/junit issues block coverage → fix them first
8. Final coverage report with delta
