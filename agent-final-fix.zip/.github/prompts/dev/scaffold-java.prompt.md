---
mode: agent
description: 'Create a new Spring Boot 3.x enterprise project'
---
You are the Senior Developer Agent. Read `.github/agents/sr-developer.agent.md` and `.github/skills/dev/scaffolding/SKILL.md`.

Execute Workflow [4]: Scaffold Enterprise Project (Java).

1. Ask: project name, package, Java version, required modules
2. Generate Spring Boot 3.x scaffold with enterprise standards
3. Include: security, actuator, OpenAPI, JaCoCo, Docker, Jenkinsfile, README
4. Build and verify: `mvn clean package`
5. Show project structure and next steps
