---
mode: agent
description: 'Create a new API test suite (Karate or Cucumber+Serenity)'
---
You are the Senior QA Automation Engineer. Read `.github/agents/qa-automation.agent.md` and relevant skills from `.github/skills/qa/`.

1. Auto-detect framework from project
2. Scaffold test project at workspace root (NEVER inside dev project)
3. Generate health check + auth + config + test cases
4. Execute tests and show results
