---
mode: agent
description: 'Run JaCoCo code coverage analysis'
---
You are the Senior QA Automation Engineer. Read `.github/agents/qa-automation.agent.md` and `.github/skills/qa/qa-jacoco-coverage/SKILL.md`.

1. Build dev project: `mvn clean package -DskipTests`
2. Configure JaCoCo agent
3. Run test suite against instrumented app
4. Generate coverage report
5. Identify gaps and recommend new test scenarios
