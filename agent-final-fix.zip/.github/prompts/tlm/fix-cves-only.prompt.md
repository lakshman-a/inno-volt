---
mode: agent
description: 'Fix only CVE and security vulnerability issues'
---
You are the TLM Agent. Read `.github/agents/tlm.agent.md`.

1. Scan for CVEs: `mvn dependency:tree`, `npm audit`
2. Prioritize critical/high CVEs
3. Show plan → wait for approval
4. Fix targeted versions
5. Validate: build + test
6. Post-fix CVE check — verify no new CVEs introduced
