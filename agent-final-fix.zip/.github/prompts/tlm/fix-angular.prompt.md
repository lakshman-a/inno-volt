---
mode: agent
description: 'Fix Angular TLM items — step-by-step major version upgrades'
---
You are the TLM Agent. Read `.github/agents/tlm.agent.md` and `.github/skills/tlm/angular/`.

Angular upgrades use Opus model (always complex). Step-by-step per major version.
Use persistent shell session. Handle FMR libraries (DO NOT modify).
Track progress via change.md. Resume from last completed step on failure.
