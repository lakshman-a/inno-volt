---
mode: agent
description: 'Scan project for TLM items without making any changes'
---
You are the TLM Agent. Read `.github/agents/tlm.agent.md`.

Scan only mode — no changes will be made.

1. Detect language, framework, build tool
2. Scan all dependencies for outdated versions
3. Check for CVEs and vulnerabilities
4. Detect enterprise/internal libraries
5. Show Project Health Dashboard with full inventory
6. Estimate manual effort vs agent time
