---
mode: agent
description: 'Fix enterprise and internal library upgrades (JSCI, AMT FSF, RHEL)'
---
You are the TLM Agent. Read `.github/agents/tlm.agent.md` and `.github/skills/tlm/enterprise/`.

1. Detect enterprise libraries: JSCI, AMT FSF, FMR, RHEL references
2. Match against available enterprise skills
3. For items with skills: apply migration automatically
4. For items without skills: ask for Confluence/docs, offer to create skill
5. Validate: build + test
