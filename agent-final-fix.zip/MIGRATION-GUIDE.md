# Fix: Agent Display Names, Prompt Loading, and Consistent Structure

## Issues Fixed

### 1. TLM shows as "tlm" instead of "TLM Agent"
**Cause:** Your TLM agent used `## Agent Metadata` with a yaml code block. VS Code reads the `name:` from the YAML **frontmatter** (between `---` markers), NOT from code blocks.

**Fix:** Rewrote `tlm.agent.md` to use standard frontmatter like QA and Sr Dev:
```yaml
---
name: TLM Agent          ← This is what shows in the dropdown
description: ...
tools: [...]
model: [...]
---
```

### 2. Prompts not loading when typing /
**Cause:** Prompt files were named `fix-sonar.md` — VS Code expects `*.prompt.md` extension for slash command discovery.

**Fix:** Renamed all prompts to `*.prompt.md`:
- `fix-sonar.md` → `fix-sonar.prompt.md`
- `write-tests.md` → `write-tests.prompt.md`
- etc.

### 3. Skills/Common not referenced
**Fix:** Each agent file now has explicit references:
```
**Skills:** Read from `.github/skills/dev/`
**Prompts:** Available at `.github/prompts/dev/`
**Common refs:** `.github/common/telemetry-schema.md`, ...
```

### 4. Inconsistent agent structure
**Fix:** All three agents now follow identical format:
- Same YAML frontmatter style
- Same section structure (Greet → Scan → Dashboard → Menu)
- Same 5-phase workflow reference
- Same rule format
- Explicit skill/prompt/common references

## Files to Replace

### Replace these in `.github/agents/` (delete old, copy new):
```
.github/agents/
├── sr-developer.agent.md     ← REPLACE (consistent format)
├── qa-automation.agent.md    ← REPLACE (added skill/common refs)
└── tlm.agent.md              ← REPLACE (fixed frontmatter)
```

### Replace these in `.github/prompts/` (delete old .md, copy new .prompt.md):
```
.github/prompts/
├── dev/
│   ├── fix-sonar.prompt.md        ← NEW (was fix-sonar.md)
│   ├── write-tests.prompt.md      ← NEW
│   ├── new-feature.prompt.md      ← NEW
│   ├── scaffold-java.prompt.md    ← NEW
│   ├── scaffold-angular.prompt.md ← NEW
│   ├── refactor.prompt.md         ← NEW
│   └── code-review.prompt.md      ← NEW
├── qa/
│   ├── create-tests.prompt.md     ← NEW
│   ├── run-jacoco.prompt.md       ← NEW
│   └── enhance-tests.prompt.md    ← NEW
└── tlm/
    ├── fix-all-tlm.prompt.md      ← NEW
    ├── fix-cves-only.prompt.md    ← NEW
    ├── fix-angular.prompt.md      ← NEW
    ├── scan-tlm-only.prompt.md    ← NEW
    └── fix-enterprise-tlm.prompt.md ← NEW
```

## Steps

1. **Delete old prompt files** (the .md ones without .prompt):
   ```bash
   rm .github/prompts/dev/*.md
   rm .github/prompts/qa/*.md
   rm .github/prompts/tlm/*.md
   ```

2. **Extract `agent-final-fix.zip`** over your `.github/` folder

3. **Keep your existing files** — skills/, common/, config/, copilot-instructions.md are unchanged

4. **Reload VS Code:** Ctrl+Shift+P → "Developer: Reload Window"

5. **Verify dropdown:** Should show "Senior Developer", "Senior QA Automation Engineer", "TLM Agent"

6. **Verify prompts:** Type `/` in chat — should see fix-sonar, write-tests, fix-all-tlm, etc.

## What Stays the Same (don't touch)
- `.github/copilot-instructions.md` — global brain, unchanged
- `.github/common/` — all shared files, unchanged
- `.github/config/` — sonar-config, agent-config, unchanged
- `.github/skills/` — all skill files, unchanged
- `.github/instructions/` — unchanged
- `.vscode/settings.json` — unchanged
