# Skill: Python Project Scan

Scan a Python project to detect structure, runtime, dependencies, and outdated/vulnerable packages.

---

## Step 1 — Detect Project Type

Search the workspace root (and one level deep for monorepos) for these files in priority order:

| File | Tool Ecosystem | How to read deps |
|---|---|---|
| `pyproject.toml` | Modern (PEP 621) / Poetry | Parse `[project.dependencies]` or `[tool.poetry.dependencies]` |
| `requirements.txt` | pip (most common in enterprise) | Each line: `package==version` |
| `requirements/*.txt` | pip with split files (dev, prod) | Scan all .txt files in the folder |
| `Pipfile` | Pipenv | Parse `[packages]` section |
| `setup.py` / `setup.cfg` | Legacy setuptools | Parse `install_requires` |

**Multi-module detection:** If multiple dependency files exist in subdirectories, treat each as a separate module. List them all in the dashboard.

## Step 2 — Detect Python Runtime Version

Check these locations (first match wins):

1. `.python-version` file (pyenv)
2. `Dockerfile` — look for `FROM python:X.Y` or `FROM *python*:X.Y`
3. `pyproject.toml` — `[project] requires-python`
4. `setup.py` / `setup.cfg` — `python_requires`
5. `runtime.txt` (Heroku-style)
6. `.github/workflows/*.yml` — `python-version:` field
7. `Jenkinsfile` — any python version reference
8. `tox.ini` — `envlist` for Python versions

Run `python --version` or `python3 --version` to detect the active runtime.

## Step 3 — Detect Package Registry

Check for custom registry configuration:

```bash
# Check pip config
pip config get global.index-url 2>/dev/null
# Check pip.conf / pip.ini directly
cat ~/.config/pip/pip.conf 2>/dev/null || cat ~/.pip/pip.conf 2>/dev/null
# Check environment variable
echo $PIP_INDEX_URL
# Check pyproject.toml for Poetry source
grep -A3 '\[\[tool.poetry.source\]\]' pyproject.toml 2>/dev/null
```

If `index-url` points to a non-PyPI host → flag as **Internal Artifactory**. All version lookups must use this registry.

## Step 4 — List Outdated Packages

```bash
# Create/activate venv if not exists
python -m venv .tlm-venv 2>/dev/null
source .tlm-venv/bin/activate  # Linux/Mac
# Install current deps
pip install -r requirements.txt --quiet
# List outdated
pip list --outdated --format=json
```

Parse the JSON output. Each entry has: `name`, `version` (current), `latest_version`, `latest_filetype`.

**Filter out non-stable versions** from `latest_version`: skip anything matching `a\d`, `b\d`, `rc\d`, `dev`, `post`.

## Step 5 — CVE Check

```bash
pip install pip-audit --quiet
pip-audit --format=json --output=audit-results.json
```

Parse results. Map each vulnerability to its package, severity (CVSS), and fix version.

If `pip-audit` is unavailable, note it in the report and skip CVE detail (still report outdated packages).

## Step 6 — Classify Findings

For each outdated package, assign severity:

- **🔴 CRITICAL**: Has CVE with CVSS ≥ 7.0, OR Python runtime is EOL
- **🟡 IMPORTANT**: Major version behind (e.g., 2.x → 3.x), OR CVE CVSS 4.0–6.9
- **🟢 RECOMMENDED**: Minor or patch behind, no CVEs
- **⚪ DEFERRED**: No stable newer version available, or internal-only with no update

## Step 7 — Display Dashboard

Use the dashboard format defined in the agent file. Include:
- Project metadata (name, path, Python version, dep file type, registry)
- Summary counts by severity
- Full table of findings sorted by severity (CRITICAL first)

**For multi-module projects**, show a combined dashboard with module column, then break down per-module if user asks.
