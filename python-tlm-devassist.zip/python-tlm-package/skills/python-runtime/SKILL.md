# Skill: Python Runtime Upgrade

Handle Python version upgrades (e.g., 3.8 → 3.12). This is the most impactful TLM change.

---

## Pre-Flight

1. Detect current Python version (see scan skill, Step 2)
2. Confirm target version with user (never assume)
3. Check that target Python is installed: `python3.12 --version` (adjust to target)
4. If not installed, tell user to install it and stop. Do NOT attempt to install Python runtimes.

## Config Files to Update

Update **every** file that pins the Python version:

| File | What to change |
|---|---|
| `.python-version` | Replace version string |
| `Dockerfile` | `FROM python:3.8` → `FROM python:3.12` (preserve slim/alpine/bookworm suffix) |
| `pyproject.toml` | `requires-python = ">=3.8"` → `">=3.12"` |
| `setup.py` / `setup.cfg` | `python_requires='>=3.8'` |
| `runtime.txt` | `python-3.8.x` → `python-3.12.x` |
| `.github/workflows/*.yml` | `python-version: ['3.8']` → `['3.12']` |
| `Jenkinsfile` | Any python version references |
| `tox.ini` | `envlist = py38` → `py312` |

## Syntax Modernization with pyupgrade

```bash
pip install pyupgrade --quiet
# Find all Python files and apply upgrades
find . -name '*.py' -not -path './.tlm-venv/*' -not -path './venv/*' | \
  xargs pyupgrade --py312-plus  # adjust to target version
```

**What pyupgrade fixes automatically:**
- Old-style `super(ClassName, self)` → `super()`
- `dict()` / `list()` / `set()` → literals where appropriate
- Old string formatting `%s` / `.format()` → f-strings
- Type hint modernization: `Optional[X]` → `X | None`, `Union[X, Y]` → `X | Y` (3.10+)
- `typing.Dict`, `typing.List` → `dict`, `list` (3.9+)

## Known Breaking Changes by Version

### 3.8 → 3.9
- `typing.Dict/List/Set/Tuple` → use builtins (`dict`, `list`, etc.)
- `math.gcd` now supports multiple arguments

### 3.9 → 3.10
- `distutils` deprecated (removed in 3.12) — replace with `setuptools` or `shutil`
- Match statements added (no migration needed, optional adoption)

### 3.10 → 3.11
- `tomllib` added to stdlib (can remove `tomli` dependency)
- Exception groups introduced

### 3.11 → 3.12
- **`distutils` fully removed** — all imports must change:
  - `from distutils.util import strtobool` → implement manually or use `setuptools`
  - `from distutils.version import LooseVersion` → use `packaging.version.Version`
- `imp` module removed → use `importlib`
- `asynchat`, `asyncore` removed → use `asyncio`
- Deprecated `unittest` methods removed

### 3.12 → 3.13
- `aifc`, `audioop`, `cgi`, `cgitb`, `chunk`, `crypt`, `imghdr`, `mailcap`, `msilib`, `nis`, `nntplib`, `ossaudiodev`, `pipes`, `sndhdr`, `spwd`, `sunau`, `telnetlib`, `uu`, `xdrlib` removed

## Post-Runtime-Upgrade Steps

1. Recreate venv with new Python: `python3.12 -m venv .tlm-venv --clear`
2. Reinstall all dependencies: `pip install -r requirements.txt`
3. Run pyupgrade for syntax modernization
4. Run tests
5. Check for `distutils` imports if upgrading to 3.12+ (critical)

## Confidence Indicators

After runtime upgrade, report:
```
🐍 Runtime: 3.8 → 3.12
📝 Config files updated: [N]
🔧 pyupgrade fixes applied: [N] across [N] files
⚠️ Manual review needed: [list any distutils/imp/removed module usage]
✅ All dependencies install cleanly on 3.12
✅ Tests: [pass/fail count]
```
