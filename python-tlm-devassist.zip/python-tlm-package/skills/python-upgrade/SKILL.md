# Skill: Python Library Upgrades

Execute dependency upgrades in a Python project safely.

---

## Pre-Upgrade Checklist

Before any changes:
1. Confirm venv is active (never install to system Python)
2. Confirm registry source (PyPI or internal Artifactory)
3. Take snapshot: `pip freeze > .tlm-before.txt`
4. Verify tests pass BEFORE upgrade: `pytest --tb=short -q`. Record result as baseline.

## Version Verification

**Never trust memory. Always verify a version exists:**

```bash
# Method 1: pip index (pip 21.2+)
pip index versions <package> 2>/dev/null

# Method 2: Fallback — intentional error lists versions
pip install <package>==FAKE_VERSION 2>&1 | grep "from versions:"

# Method 3: For internal Artifactory
pip install <package>== 2>&1 | grep "from versions:"
```

Filter output to stable-only: match `^\d+\.\d+(\.\d+)?$`, reject anything with `a`, `b`, `rc`, `dev`, `post`.

## Upgrade Order

1. **Runtime upgrade first** (if included) — see `python-runtime/SKILL.md`
2. **Framework packages** (flask, django, fastapi) — these drive compatibility
3. **Libraries with CVEs** — security priority
4. **Remaining outdated** — minor/patch updates last

## Executing Upgrades

**For `requirements.txt` projects:**
```bash
# Update the version pin in-place
sed -i 's/flask==2.0.1/flask==3.1.0/' requirements.txt
# Repeat for each package in plan order
# Then install all at once
pip install -r requirements.txt
```

**For `pyproject.toml` (PEP 621):**
Edit the `[project.dependencies]` list with new version specifiers.

**For `pyproject.toml` (Poetry):**
```bash
poetry update <package>
```

**For `Pipfile`:**
```bash
pipenv update <package>
```

## Conflict Resolution

If `pip install` fails with dependency conflict:
1. Read the error — it names the conflicting packages and version constraints
2. Check if the constraint comes from a package already in the upgrade plan (resolve by upgrading both)
3. If constraint comes from a package NOT in the plan, add it to the plan
4. If unresolvable, pin to the highest version that satisfies all constraints and flag to user

## Post-Upgrade Verification

```bash
# 1. Check install succeeded
pip check  # reports broken dependencies

# 2. Run tests
pytest --tb=short -q 2>&1 | tee .tlm-test-results.txt

# 3. Compare before/after
pip freeze > .tlm-after.txt
diff .tlm-before.txt .tlm-after.txt
```

## Test Failure Handling

If tests fail AFTER upgrade:
1. Compare with baseline. If same tests failed before upgrade → **pre-existing**, skip.
2. If NEW failure → **agent-caused**, attempt fix:
   - Read error message
   - Check if it's a known breaking change (deprecated API, renamed module)
   - Apply fix
   - Re-run tests
3. Max 3 fix attempts per failure. After 3 → report failure, stop, ask user.

## Internal Library Detection

A package is internal if:
- It's NOT found on public PyPI (`pip index versions <pkg>` against pypi.org returns nothing)
- It IS found on the configured internal index
- Its name matches known internal naming patterns (company prefix, etc.)

For internal packages:
- Only suggest versions available on the internal registry
- If no newer version exists → classify as ⚪ DEFERRED
- Never suggest replacing with a public alternative without explicit user request

## Report Generation

After all upgrades, generate the diff:

```bash
# Files changed
git diff --stat

# Detailed line changes
git diff --name-only

# Version comparison table
diff .tlm-before.txt .tlm-after.txt | grep '[<>]' | sort
```

Format into the report template defined in the agent file.
