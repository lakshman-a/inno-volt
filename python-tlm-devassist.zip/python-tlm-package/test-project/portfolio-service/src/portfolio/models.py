"""Portfolio domain models."""
from typing import Dict, List, Optional
from dataclasses import dataclass, field
import uuid


@dataclass
class Holding:
    symbol: str
    quantity: float
    value: float
    asset_type: str = "EQUITY"

    def to_dict(self) -> Dict:
        return {
            "symbol": self.symbol,
            "quantity": self.quantity,
            "value": self.value,
            "asset_type": self.asset_type,
        }


@dataclass
class Portfolio:
    name: str
    holdings: List[Holding] = field(default_factory=list)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    # In-memory store (simulated DB)
    _store: Dict[str, "Portfolio"] = field(default_factory=dict, repr=False, init=False)

    def save(self) -> None:
        Portfolio._store[self.id] = self

    @classmethod
    def get_by_id(cls, portfolio_id: str) -> Optional["Portfolio"]:
        return cls._store.get(portfolio_id, None)

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "holdings": [h.to_dict() for h in self.holdings],
            "total_value": sum(h.value for h in self.holdings),
        }
