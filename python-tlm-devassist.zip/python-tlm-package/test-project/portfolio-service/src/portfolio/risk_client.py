"""Client for risk engine integration."""
from typing import Dict, Optional
import requests


RISK_ENGINE_URL = "http://localhost:8081/api/risk"


def get_risk_score(portfolio) -> float:
    """Calculate risk score for a portfolio. Falls back to local calc if service unavailable."""
    try:
        holdings_data = [h.to_dict() for h in portfolio.holdings]
        resp = requests.post(
            RISK_ENGINE_URL,
            json={"holdings": holdings_data},
            timeout=5,
        )
        if resp.status_code == 200:
            return resp.json().get("risk_score", 0.5)
    except requests.exceptions.RequestException:
        pass

    # Fallback: simple local calculation
    if not portfolio.holdings:
        return 0.0
    total = sum(h.value for h in portfolio.holdings)
    if total == 0:
        return 0.0
    max_holding = max(h.value for h in portfolio.holdings)
    concentration = max_holding / total
    return min(concentration * 1.2, 1.0)
