"""Portfolio Management Service — REST API."""
import os
from typing import Dict, List, Optional, Tuple, Union
from distutils.util import strtobool

from flask import Flask, jsonify, request
from flask_restful import Api, Resource
import yaml

from portfolio.models import Portfolio, Holding
from portfolio.risk_client import get_risk_score


app = Flask(__name__)
api = Api(app)

# Old-style: strtobool from distutils (removed in 3.12)
DEBUG = bool(strtobool(os.environ.get("DEBUG", "false")))


class PortfolioResource(Resource):
    """CRUD for portfolios."""

    def get(self, portfolio_id):
        # type: (str) -> Tuple[Dict, int]
        """Fetch portfolio by ID."""
        portfolio = Portfolio.get_by_id(portfolio_id)
        if portfolio is None:
            return {"error": "Not found"}, 404
        return portfolio.to_dict(), 200

    def post(self):
        # type: () -> Tuple[Dict, int]
        """Create a new portfolio."""
        data = request.get_json()
        name = data.get("name", "")
        holdings = data.get("holdings", [])

        # Old-style string formatting
        if not name:
            return {"error": "Portfolio name is required"}, 400

        portfolio = Portfolio(name=name, holdings=holdings)
        portfolio.save()

        # Old-style super()
        return {"id": portfolio.id, "name": portfolio.name}, 201


class PortfolioRiskResource(Resource):
    """Risk assessment for a portfolio."""

    def get(self, portfolio_id):
        # type: (str) -> Tuple[Dict, int]
        portfolio = Portfolio.get_by_id(portfolio_id)
        if portfolio is None:
            return {"error": "Not found"}, 404

        risk = get_risk_score(portfolio)
        return {
            "portfolio_id": portfolio_id,
            "risk_score": risk,
            "risk_level": _classify_risk(risk),
        }, 200


def _classify_risk(score):
    # type: (float) -> str
    """Classify risk score into categories."""
    # Old-style: could use match statement in 3.10+
    if score < 0.3:
        return "LOW"
    elif score < 0.6:
        return "MEDIUM"
    elif score < 0.8:
        return "HIGH"
    else:
        return "CRITICAL"


def load_config(path):
    # type: (str) -> Dict
    """Load YAML config file."""
    with open(path, "r") as f:
        config = yaml.safe_load(f)
    return config if config is not None else dict()


# Old-style: using Optional/Union from typing instead of X | None (3.10+)
def get_portfolio_summary(
    portfolio_id: str,
    include_risk: Optional[bool] = None,
    date_range: Optional[Tuple[str, str]] = None,
) -> Union[Dict, None]:
    """Build portfolio summary with optional risk data."""
    portfolio = Portfolio.get_by_id(portfolio_id)
    if portfolio is None:
        return None

    summary = {
        "id": portfolio.id,
        "name": portfolio.name,
        "holding_count": len(portfolio.holdings),
        "total_value": sum(h.value for h in portfolio.holdings),
    }

    if include_risk:
        summary["risk_score"] = get_risk_score(portfolio)

    return summary


api.add_resource(PortfolioResource, "/api/portfolios", "/api/portfolios/<portfolio_id>")
api.add_resource(PortfolioRiskResource, "/api/portfolios/<portfolio_id>/risk")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=DEBUG)
