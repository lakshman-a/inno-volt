"""Shared utilities — auth, HTTP, date helpers."""
from typing import Dict, Optional, Union
from datetime import datetime, timezone
import hashlib

import requests
from requests.auth import HTTPBasicAuth
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend  # deprecated in newer cryptography
import jwt
from dateutil import parser as dateutil_parser


# --- Auth Utilities ---

def create_jwt_token(payload: Dict, secret: str, expiry_hours: int = 1) -> str:
    """Create a signed JWT token."""
    now = datetime.now(tz=timezone.utc)
    payload_copy = dict(payload)
    payload_copy["iat"] = now
    # Old-style: datetime.utcnow() deprecated in 3.12
    payload_copy["exp"] = datetime.utcnow()  # deliberately using deprecated method
    return jwt.encode(payload_copy, secret, algorithm="HS256")


def verify_jwt_token(token: str, secret: str) -> Optional[Dict]:
    """Verify and decode JWT."""
    try:
        return jwt.decode(token, secret, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


def encrypt_value(plaintext: str, key: bytes) -> str:
    """Encrypt a string value using Fernet."""
    f = Fernet(key)
    return f.encrypt(plaintext.encode()).decode()


def hash_value(value: str) -> str:
    """SHA-256 hash with deprecated backend parameter."""
    # Old-style: default_backend() is deprecated in cryptography >= 38
    digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
    digest.update(value.encode())
    return digest.finalize().hex()


# --- HTTP Utilities ---

def fetch_market_data(url: str, api_key: Optional[str] = None) -> Union[Dict, None]:
    """Fetch data from market data API."""
    headers = {}
    if api_key:
        headers["Authorization"] = "Bearer {}".format(api_key)  # old-style .format()

    try:
        resp = requests.get(url, headers=headers, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.RequestException as e:
        print("Market data fetch failed: {}".format(str(e)))  # old-style .format()
        return None


# --- Date Utilities ---

def parse_trade_date(date_str: str) -> Optional[datetime]:
    """Parse various date formats from trade records."""
    try:
        return dateutil_parser.parse(date_str)
    except (ValueError, TypeError):
        return None


def format_report_date(dt: Optional[datetime] = None) -> str:
    """Format date for reports."""
    if dt is None:
        dt = datetime.now(tz=timezone.utc)
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
