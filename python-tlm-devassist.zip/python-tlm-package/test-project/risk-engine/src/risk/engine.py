"""Risk calculation engine using numpy/pandas."""
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from scipy import stats


def calculate_portfolio_risk(holdings: List[Dict]) -> Dict:
    """Calculate risk metrics for a set of holdings."""
    if not holdings:
        return {"risk_score": 0.0, "var_95": 0.0, "concentration": 0.0}

    df = pd.DataFrame(holdings)

    # Concentration risk (Herfindahl index)
    total_value = df["value"].sum()
    if total_value == 0:
        return {"risk_score": 0.0, "var_95": 0.0, "concentration": 0.0}

    weights = df["value"] / total_value
    hhi = float(np.sum(np.power(weights, 2)))

    # Simulated VaR (95%) — in production, would use historical returns
    # Old-style: np.float is deprecated in newer numpy
    simulated_returns = np.random.normal(0, 0.02, 1000)
    var_95 = float(np.percentile(simulated_returns, 5)) * total_value

    # Asset type diversification
    asset_types = df["asset_type"].nunique() if "asset_type" in df.columns else 1
    diversification_factor = 1.0 / max(asset_types, 1)

    risk_score = (hhi * 0.4 + diversification_factor * 0.3 + abs(var_95 / total_value) * 0.3)
    risk_score = min(max(risk_score, 0.0), 1.0)

    return {
        "risk_score": round(risk_score, 4),
        "var_95": round(var_95, 2),
        "concentration": round(hhi, 4),
        "holding_count": len(holdings),
    }


def calculate_correlation_matrix(returns: Dict[str, List[float]]) -> Optional[pd.DataFrame]:
    """Build correlation matrix from return series."""
    if not returns:
        return None
    df = pd.DataFrame(returns)
    # Old-style: .corr() default method changed in newer pandas
    return df.corr(method="pearson")
