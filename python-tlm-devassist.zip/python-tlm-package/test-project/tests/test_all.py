"""Tests for FinOps Platform modules."""
import pytest
import numpy as np


# --- Portfolio Model Tests ---

class TestPortfolioModels:
    def test_holding_to_dict(self):
        from portfolio.models import Holding
        h = Holding(symbol="AAPL", quantity=100, value=15000.0)
        d = h.to_dict()
        assert d["symbol"] == "AAPL"
        assert d["quantity"] == 100
        assert d["value"] == 15000.0
        assert d["asset_type"] == "EQUITY"

    def test_portfolio_save_and_get(self):
        from portfolio.models import Portfolio, Holding
        holdings = [
            Holding(symbol="AAPL", quantity=100, value=15000.0),
            Holding(symbol="GOOGL", quantity=50, value=12000.0),
        ]
        p = Portfolio(name="Test Portfolio", holdings=holdings)
        p.save()
        fetched = Portfolio.get_by_id(p.id)
        assert fetched is not None
        assert fetched.name == "Test Portfolio"
        assert len(fetched.holdings) == 2

    def test_portfolio_total_value(self):
        from portfolio.models import Portfolio, Holding
        holdings = [
            Holding(symbol="AAPL", quantity=100, value=15000.0),
            Holding(symbol="MSFT", quantity=200, value=20000.0),
        ]
        p = Portfolio(name="Value Test", holdings=holdings)
        d = p.to_dict()
        assert d["total_value"] == 35000.0

    def test_portfolio_not_found(self):
        from portfolio.models import Portfolio
        assert Portfolio.get_by_id("nonexistent-id") is None


# --- Risk Engine Tests ---

class TestRiskEngine:
    def test_empty_holdings(self):
        from risk.engine import calculate_portfolio_risk
        result = calculate_portfolio_risk([])
        assert result["risk_score"] == 0.0

    def test_single_holding(self):
        from risk.engine import calculate_portfolio_risk
        result = calculate_portfolio_risk([
            {"symbol": "AAPL", "value": 10000.0, "asset_type": "EQUITY"}
        ])
        assert 0.0 <= result["risk_score"] <= 1.0
        assert result["concentration"] == 1.0  # single holding = max concentration

    def test_diversified_portfolio(self):
        from risk.engine import calculate_portfolio_risk
        holdings = [
            {"symbol": "AAPL", "value": 5000.0, "asset_type": "EQUITY"},
            {"symbol": "BND", "value": 5000.0, "asset_type": "BOND"},
            {"symbol": "GLD", "value": 5000.0, "asset_type": "COMMODITY"},
            {"symbol": "VNQ", "value": 5000.0, "asset_type": "REIT"},
        ]
        result = calculate_portfolio_risk(holdings)
        assert result["concentration"] == 0.25  # equal weights
        assert result["holding_count"] == 4

    def test_correlation_matrix(self):
        from risk.engine import calculate_correlation_matrix
        returns = {
            "AAPL": [0.01, -0.02, 0.03, 0.01, -0.01],
            "GOOGL": [0.02, -0.01, 0.02, 0.00, -0.02],
        }
        corr = calculate_correlation_matrix(returns)
        assert corr is not None
        assert corr.shape == (2, 2)
        assert corr.loc["AAPL", "AAPL"] == pytest.approx(1.0)

    def test_correlation_empty(self):
        from risk.engine import calculate_correlation_matrix
        assert calculate_correlation_matrix({}) is None


# --- Common Utils Tests ---

class TestCommonUtils:
    def test_jwt_create_and_verify(self):
        from utils.helpers import create_jwt_token, verify_jwt_token
        token = create_jwt_token({"user": "trader1"}, "secret123")
        assert token is not None
        assert isinstance(token, str)

    def test_encrypt_value(self):
        from utils.helpers import encrypt_value
        from cryptography.fernet import Fernet
        key = Fernet.generate_key()
        encrypted = encrypt_value("sensitive_data", key)
        assert encrypted != "sensitive_data"
        # Verify decryption
        f = Fernet(key)
        decrypted = f.decrypt(encrypted.encode()).decode()
        assert decrypted == "sensitive_data"

    def test_hash_value(self):
        from utils.helpers import hash_value
        h1 = hash_value("test")
        h2 = hash_value("test")
        assert h1 == h2  # deterministic
        assert len(h1) == 64  # SHA-256 hex length

    def test_parse_trade_date(self):
        from utils.helpers import parse_trade_date
        dt = parse_trade_date("2024-01-15T10:30:00Z")
        assert dt is not None
        assert dt.year == 2024
        assert dt.month == 1

    def test_parse_invalid_date(self):
        from utils.helpers import parse_trade_date
        assert parse_trade_date("not-a-date") is None

    def test_format_report_date(self):
        from utils.helpers import format_report_date
        result = format_report_date()
        assert "UTC" in result

    def test_fetch_market_data_timeout(self):
        from utils.helpers import fetch_market_data
        # Should return None for unreachable URL
        result = fetch_market_data("http://localhost:99999/fake", api_key="key123")
        assert result is None
