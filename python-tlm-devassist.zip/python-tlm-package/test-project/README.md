# Sample Test Project: FinOps Platform

A **deliberately outdated** Python project for testing the Python TLM Agent. Contains:

- 🐍 Python 3.8 runtime (EOL)
- 📦 Outdated dependencies with known CVEs
- 🏗️ 3 modules: portfolio-service, risk-engine, common-utils
- 🏢 Simulated internal library (`finops-common-lib`)
- 🧪 Tests that pass on current versions
- 📝 Dockerfile, .python-version, pyproject.toml

## Modules

| Module | Purpose | Key outdated deps |
|---|---|---|
| `portfolio-service` | REST API for portfolio management | Flask 2.0.1, SQLAlchemy 1.4.0 |
| `risk-engine` | Risk calculation engine | numpy 1.21.0, pandas 1.3.0, scipy 1.7.0 |
| `common-utils` | Shared utilities | requests 2.25.0, cryptography 3.4.0 (CVE) |

## How to test with the agent

1. Open this project in VS Code
2. Invoke `@python-tlm`
3. Type `scan` — expect: dashboard showing Python 3.8 EOL + all outdated deps + CVEs
4. Type `fix tlm` — expect: ordered plan, approval prompt, execution, report
5. Type `upgrade to 3.12` — expect: runtime config updates + pyupgrade + dep compatibility

## Expected CVEs (at time of creation)

- `cryptography 3.4.0` — multiple CVEs
- `flask 2.0.1` — potential CVEs in older Werkzeug
- `requests 2.25.0` — CVE-2023-32681 (proxy auth leak)
- `numpy 1.21.0` — potential buffer overflow CVEs
