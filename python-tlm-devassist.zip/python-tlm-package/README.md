# Python TLM DevAssist — README

## What Is It?

A GitHub Copilot Chat-based solution that scans, plans, and executes Python dependency and runtime upgrades inside VS Code. A developer invokes the agent, gets a clear upgrade plan, approves it, and the agent handles everything — version verification, file updates, syntax modernization, test runs, and a final report.

---

## Why This Approach?

### Python TLM ≠ Java TLM

Java TLM requires a complex multi-phase agent because Maven introduces layers of indirection: parent POMs, dependency management sections, profiles, settings.xml resolution chains, multi-module build ordering, and compile-time verification loops. A single wrong version cascades into build failures across modules.

**Python doesn't have these problems.** Dependencies live in a flat text file (`requirements.txt`) or a single config (`pyproject.toml`). There's no compilation step, no parent-child module hierarchy, no settings.xml. You update a version, install, and test. This changes the optimal solution shape:

| Factor | Java TLM → Multi-phase agent | Python TLM → Lightweight agent |
|---|---|---|
| Dependency resolution | Maven mediation, transitive conflicts | pip resolver, flat pins |
| Build verification | compile + test, iterative 3-attempt loops | install + test, single pass |
| Config detection | settings.xml, profiles, parent POM hierarchy | pip.conf + one dep file |
| Multi-module ordering | Parent-first cascade with inter-module deps | Independent modules, no cascade |
| Framework migration | Spring Boot namespace migration (dozens of patterns) | Straightforward, fewer breaking changes |
| Version verification | `mvn dependency:resolve` per artifact | `pip index versions` or `pip install ==` |

**Result:** A phased workflow agent would be over-engineering. We use a single agent file with 3 focused skills — total under 400 lines, easy to maintain, easy to extend.

### How Is This Different From Just Asking Copilot?

A developer could open Copilot Chat in Agent mode and say *"upgrade my Python dependencies."* Here's what goes wrong:

| Problem | Raw Copilot | This Solution |
|---|---|---|
| **Version hallucination** | The model may suggest versions that don't exist or aren't stable | Every version is verified via `pip index` or pip error output. Rule 1 in the agent. |
| **No registry awareness** | Ignores internal Artifactory, suggests public PyPI versions for internal packages | Detects `pip.conf`, routes all lookups through configured registry |
| **No severity triage** | Treats all outdated packages equally | Classifies 🔴 CRITICAL / 🟡 IMPORTANT / 🟢 RECOMMENDED / ⚪ DEFERRED with CVE data |
| **No upgrade ordering** | Random order, may break transitive deps | Framework-first, then CVEs, then remaining — respects dependency graph |
| **No before/after proof** | Makes changes, says "done" | `pip freeze` snapshot before and after, git diff, test comparison |
| **No pre-existing test awareness** | Tries to fix tests that were already broken | Baselines tests BEFORE upgrade, classifies new vs pre-existing failures |
| **Wasted tokens on discovery** | Spends tokens figuring out how Python packaging works | Skills encode the knowledge — agent reads skill, acts immediately |
| **No approval gate** | May start changing files immediately | Always shows plan, waits for explicit approval |
| **Inconsistent reporting** | Different output format every time | Structured dashboard + report format, same every run |

**Token efficiency:** A raw agent mode conversation to upgrade a project typically takes 8,000–15,000 tokens of back-and-forth as the model discovers the project structure, looks up how pip works, tries things, fails, and retries. This solution front-loads that knowledge in ~300 lines of skill files that the agent reads once (~800 tokens), then executes with precision. **Net savings: 60–70% fewer tokens per TLM task.**

---

## Architecture

```
┌─────────────────────────────────────────────────┐
│  Developer (VS Code + GitHub Copilot Chat)       │
│  Prompt: "scan" / "fix tlm" / "upgrade to 3.12" │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│  python-tlm.agent.md                             │
│  • Intent detection (scan / upgrade / CVE fix)   │
│  • Workflow orchestration                        │
│  • Approval gate                                 │
│  • Report generation                             │
│  • Rules: no hallucination, stable-only, etc.    │
└────────┬──────────┬──────────┬──────────────────┘
         │          │          │
         ▼          ▼          ▼
┌──────────┐ ┌────────────┐ ┌──────────────┐
│ python-  │ │ python-    │ │ python-      │
│ scan/    │ │ upgrade/   │ │ runtime/     │
│ SKILL.md │ │ SKILL.md   │ │ SKILL.md     │
│          │ │            │ │              │
│ • Detect │ │ • Version  │ │ • Config     │
│   project│ │   verify   │ │   file update│
│ • Find   │ │ • Upgrade  │ │ • pyupgrade  │
│   outdated│ │  order    │ │ • Breaking   │
│ • CVE    │ │ • Conflict │ │   change map │
│   audit  │ │   resolve  │ │ • Removed    │
│ • Classify│ │ • Test +  │ │   modules    │
│   severity│ │  fix cycle│ │              │
└──────────┘ └────────────┘ └──────────────┘
```

**Flow:** Agent detects intent → reads relevant skill(s) → executes steps → shows plan → gets approval → applies changes → tests → reports.

---

## File Structure

```
.github/
  agents/
    python-tlm.agent.md          ← Main agent (invoke via @python-tlm)
  skills/
    python-scan/SKILL.md         ← Project scanning logic
    python-upgrade/SKILL.md      ← Library upgrade procedures
    python-runtime/SKILL.md      ← Runtime version upgrade procedures
```

> **Adapting to your enterprise structure:** If your enterprise uses a different folder layout (e.g., `.github/copilot/agents/` or a custom instructions path), simply move the files accordingly. The agent references skills by relative path (`skills/python-scan/SKILL.md`), so adjust these paths if you restructure. If you have a formatter/template that standardizes file headers, sections, or naming conventions, apply it — the content is modular and won't break.

---

## How to Invoke

In VS Code with GitHub Copilot Chat:

1. **Select the agent** from the Copilot Chat agent picker: `@python-tlm`
2. **Type your intent:**

| What you want | What to type |
|---|---|
| See what's outdated | `scan` |
| Full upgrade with approval | `fix tlm` |
| Upgrade Python runtime | `upgrade to 3.12` |
| Fix security vulnerabilities only | `fix cves` |
| Upgrade a single package | `upgrade flask` or `upgrade pandas to 2.2` |
| Help / examples | `hi` or `help` |

The agent understands natural language — these are examples, not strict commands.

---

## What Manual Steps Remain?

Even with this agent, some things require human judgment:

| Step | Why it's manual |
|---|---|
| **Installing a new Python runtime** | System-level change, may need admin rights, varies by OS/container |
| **Reviewing the upgrade plan** | The developer must approve before changes are made |
| **Internal library decisions** | If no newer version exists internally, developer decides: wait, request update, or find alternative |
| **Complex breaking changes** | If a major framework upgrade changes application logic (not just imports/syntax), developer reviews |
| **CI/CD pipeline testing** | Agent runs local tests; full CI validation happens after commit |

**What the agent saves:** All the tedious parts — finding outdated packages, looking up latest stable versions, checking CVEs, updating version pins, running pyupgrade, testing, generating before/after reports. For a typical project with 15–20 dependencies, this saves **1–3 hours** of manual work per TLM cycle.

---

## Expanding to Other Models

The agent and skill files are plain markdown — they work with any LLM that supports instruction-following. If you need to run this outside GitHub Copilot (e.g., via Claude Code, or a custom CLI tool), the files serve as the prompt/instruction set. No code dependencies, no runtime requirements beyond the agent reading the markdown.
