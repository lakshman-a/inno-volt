package testcases;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Story;
import pages.demoblaze.DemoBlazeJunitPage;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import framework.core.BaseTest;
import framework.core.PlaywrightManager;

/**
 * Demo Blaze UI Test using JUnit and Page Object Pattern.
 * Mirrors the main-method scenario but with BaseTest + PageObject for reuse.
 */
@Epic("UI Testing Examples")
@Feature("E-Commerce Tests")
public class DemoBlazeSampleJunitTest extends BaseTest {

    @Test
    @DisplayName("Complete Purchase Flow on DemoBlaze")
    @Story("E-Commerce Purchase Flow")
    @Description("Login, pick Sony Vaio i5, add to cart, checkout, verify confirmation, and logout.")
    @Tag("ui")
    @Tag("e-commerce")
    public void completePurchaseFlow() {
        // Initialize the page object
        logStep("Initialize DemoBlaze page object");
        DemoBlazeJunitPage demoBlazePage = new DemoBlazeJunitPage(PlaywrightManager.getPage());

        // Navigate to home page
        logStep("Navigate to DemoBlaze homepage");
        demoBlazePage.navigateToHomePage();
        PlaywrightManager.takeScreenshot("01_homepage");

        // Verify home page
        logStep("Verify homepage is loaded");
        Assertions.assertTrue(demoBlazePage.isHomePageLoaded(), "Home page should be loaded");

        // Login
        logStep("Login to the website");
        demoBlazePage.login("aaabbbeccdddece", "123456");
        PlaywrightManager.takeScreenshot("02_after_login");

        // Navigate to Laptops
        logStep("Navigate to Laptops category");
        demoBlazePage.navigateToLaptopsCategory();
        PlaywrightManager.takeScreenshot("03_laptops_category");

        // Verify product visible
        logStep("Verify Sony Vaio product is visible");
        Assertions.assertTrue(demoBlazePage.isSonyVaioProductVisible(),
                "Sony Vaio product should be visible");

        // Open product
        logStep("Click on Sony Vaio product");
        demoBlazePage.clickSonyVaioProduct();
        PlaywrightManager.takeScreenshot("04_product_details");

        // Add to cart
        logStep("Add product to cart");
        demoBlazePage.addProductToCart();

        // Go to cart
        logStep("Go to cart");
        demoBlazePage.goToCart();
        PlaywrightManager.takeScreenshot("05_cart");

        // Verify product & price
        logStep("Verify product is in cart");
        Assertions.assertTrue(demoBlazePage.isProductInCart(), "Product should be in cart");

        logStep("Verify product price in cart");
        String cartContent = demoBlazePage.getCartContent();
        Assertions.assertTrue(cartContent.contains("790"),
                "Cart should contain the product with price 790");

        // Place order
        logStep("Place order");
        demoBlazePage.placeOrder();
        PlaywrightManager.takeScreenshot("06_order_form");

        // Fill order form
        logStep("Fill order form");
        demoBlazePage.fillOrderForm("a", "b", "cd", "e", "f", "g");

        // Submit order
        logStep("Submit order");
        demoBlazePage.submitOrder();
        PlaywrightManager.takeScreenshot("07_order_confirmation");

        // Verify confirmation message
        logStep("Verify order confirmation");
        String confirmationText = demoBlazePage.getConfirmationText();
        Assertions.assertTrue(confirmationText.contains("Thank you for your purchase"),
                "Order confirmation should contain thank you message");

        // Confirm order dialog
        logStep("Complete order");
        demoBlazePage.confirmOrder();

        // Logout
        logStep("Logout from the website");
        demoBlazePage.logout();
        PlaywrightManager.takeScreenshot("08_logged_out");

        // Verify logged out
        logStep("Verify logged out state");
        Assertions.assertTrue(demoBlazePage.isLoggedOut(), "User should be logged out");
    }
}
