package testcases;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.WaitForSelectorState;

import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * DemoBlaze Purchase Test using main method - beginner-friendly.
 * End-to-end purchase flow with element checks, logging, screenshots, and
 * logout.
 */
public class DemoBlazePurchaseMainTest {

    public static void main(String[] args) {
        Playwright playwright = null;
        Browser browser = null;
        BrowserContext context = null;
        Page page = null;

        try {
            println("Starting DemoBlaze purchase test");

            playwright = Playwright.create();
            println("Playwright initialized");

            browser = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)
                    .setSlowMo(50));
            println("Browser launched");

            context = browser.newContext(new Browser.NewContextOptions()
                    .setViewportSize(1280, 720));
            page = context.newPage();
            println("Page created");

            // Step 1: Navigate
            page.navigate("https://www.demoblaze.com/index.html");
            page.waitForLoadState(LoadState.NETWORKIDLE);
            println("Navigated to DemoBlaze website");
            takeScreenshot(page, "01_homepage");

            // Step 2: Verify main link visible
            Locator storeLink = page.locator("#nava");
            if (!storeLink.isVisible())
                throw new RuntimeException("PRODUCT STORE link not visible");

            // Step 3: Login
            println("Clicking Login link");
            page.locator("#login2").click();
            page.locator("#logInModal").waitFor();

            println("Filling login credentials");
            page.locator("#loginusername").fill("abc");
            page.locator("#loginpassword").fill("12345");
            takeScreenshot(page, "02_login_form");

            println("Clicking 'Log in' button");
            page.locator("button:has-text('Log in')").click();

            println("Waiting for welcome message after login");
            page.waitForLoadState(LoadState.NETWORKIDLE);
            page.locator("#nameofuser").waitFor(new Locator.WaitForOptions().setTimeout(10000));
            println("Successfully logged in!");

            // Step 4: Navigate to Laptops
            println("Clicking on Laptops category");
            page.locator("a:has-text('Laptops')").click();
            page.waitForLoadState(LoadState.NETWORKIDLE);
            takeScreenshot(page, "04_laptops_category");

            // Step 5: Select Sony Vaio i5
            println("Selecting Sony Vaio i5");
            Locator sonyVaio = page.locator("a:has-text('Sony vaio i5')");
            sonyVaio.waitFor();
            sonyVaio.click();

            page.locator("h2:has-text('Sony vaio i5')")
                    .waitFor(new Locator.WaitForOptions().setTimeout(10000));
            takeScreenshot(page, "05_product_details");

            // Step 6: Add to Cart
            println("Adding to cart");
            page.onceDialog(dialog -> {
                println("Dialog appeared: " + dialog.message());
                dialog.accept();
            });
            page.locator("a:has-text('Add to cart')").click();
            page.waitForLoadState(LoadState.NETWORKIDLE);

            // Step 7: Go to Cart
            println("Opening Cart");
            page.locator("#cartur").click();
            page.waitForLoadState(LoadState.NETWORKIDLE);
            takeScreenshot(page, "06_cart");

            String cartText = page.locator("#tbodyid").textContent();
            if (!cartText.contains("Sony vaio i5")) {
                throw new RuntimeException("Product not found in cart");
            }

            // Step 8: Place Order
            println("Clicking 'Place Order'");
            page.locator("button:has-text('Place Order')").click();
            page.locator(".modal-content:has(#totalm)").waitFor();
            takeScreenshot(page, "07_order_form");

            println("Filling order form");
            page.locator("#name").fill("a");
            page.locator("#country").fill("b");
            page.locator("#city").fill("c");
            page.locator("#card").fill("d");
            page.locator("#month").fill("f");
            page.locator("#year").fill("g");

            // Submit order
            println("Submitting order - clicking Purchase button");
            page.locator("button:has-text('Purchase')").click();

            // Wait for confirmation
            println("Waiting for order confirmation dialog");
            page.locator(".sweet-alert:has-text('Thank you for your purchase')").waitFor();
            takeScreenshot(page, "08_order_confirmation");

            // Verify confirmation
            println("Verifying order confirmation");
            if (!page.locator(".sweet-alert").isVisible()) {
                throw new RuntimeException("Order confirmation not displayed");
            }

            String confirmationText = page.locator(".sweet-alert").textContent();
            if (!confirmationText.contains("Thank you for your purchase")) {
                throw new RuntimeException("Order confirmation message not found");
            }

            // Click OK on confirmation
            println("Clicking OK on confirmation dialog");
            page.locator("button:has-text('OK')").click();

            // Wait until OK button hides
            page.locator("button:has-text('OK')")
                    .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));

            println("Waiting for page after confirmation");
            page.waitForLoadState(LoadState.NETWORKIDLE);

            // Step 9: Handle any modal close button
            println("Checking if any modal with Close button is visible");
            Locator visibleCloseButton = page.locator(".modal.show button:has-text('Close')").first();
            if (visibleCloseButton.count() > 0 && visibleCloseButton.isVisible()) {
                println("Found visible Close button in modal, clicking it");
                visibleCloseButton.click();
                page.waitForLoadState(LoadState.NETWORKIDLE);
            }

            // Step 10: Logout
            println("Logging out");
            page.locator("#logout2").click();
            page.waitForLoadState(LoadState.NETWORKIDLE);

            println("Waiting for login link to appear again");
            page.locator("#login2").waitFor(new Locator.WaitForOptions().setTimeout(5000));
            takeScreenshot(page, "09_logged_out");

            // Verify logout
            println("Verifying logged out state");
            if (!page.locator("#login2").isVisible()) {
                throw new RuntimeException("Not properly logged out");
            }

            println("Test completed successfully!");

        } catch (Exception e) {
            System.err.println(logWithTimestamp("Test failed: " + e.getMessage()));
            e.printStackTrace();
            if (page != null) {
                takeScreenshot(page, "error_screenshot");
                System.err.println(logWithTimestamp("Error screenshot saved"));
            }
        } finally {
            try {
                if (context != null)
                    context.close();
            } catch (Exception ignored) {
            }
            try {
                if (browser != null)
                    browser.close();
            } catch (Exception ignored) {
            }
            try {
                if (playwright != null)
                    playwright.close();
            } catch (Exception ignored) {
            }
        }
    }

    // ----------------- helpers -----------------
    private static String logWithTimestamp(String message) {
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        return "[" + ts + "] " + message;
    }

    private static void println(String message) {
        System.out.println(logWithTimestamp(message));
    }

    private static void takeScreenshot(Page page, String name) {
        try {
            page.screenshot(new Page.ScreenshotOptions()
                    .setPath(Paths.get("target/screenshots", name + ".png")));
            println("Saved screenshot: " + name);
        } catch (Exception e) {
            System.out.println(logWithTimestamp("Failed to take screenshot: " + e.getMessage()));
        }
    }
}
