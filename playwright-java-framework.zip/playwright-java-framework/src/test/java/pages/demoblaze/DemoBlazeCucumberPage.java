package pages.demoblaze;

import framework.core.BasePage;
import io.qameta.allure.Step;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Page Object for DemoBlaze site used by Cucumber step definitions.
 * Implements a full happy-path flow: login → browse → add to cart → checkout → confirm → logout.
 */
public class DemoBlazeCucumberPage extends BasePage {

    private static final Logger logger = LoggerFactory.getLogger(DemoBlazeCucumberPage.class);

    // ====== Home / Common ======
    private static final String PRODUCT_STORE_LOGO     = "#nava"; // "PRODUCT STORE" link
    private static final String LOGIN_LINK             = "#login2";
    private static final String LOGOUT_LINK            = "#logout2";
    private static final String SIGNIN_LINK            = "#signin2";
    private static final String WELCOME_MESSAGE        = "#nameofuser";
    private static final String CATEGORIES_HEADER      = "a:has-text('CATEGORIES')";
    private static final String LAPTOPS_CATEGORY       = "a:has-text('Laptops')";
    private static final String CART_LINK              = "#cartur";

    // ====== Login modal ======
    private static final String LOGIN_MODAL_TITLE      = "#logInModalLabel";
    private static final String USERNAME_FIELD         = "#loginusername";
    private static final String PASSWORD_FIELD         = "#loginpassword";
    private static final String LOGIN_BUTTON           = "button:has-text('Log in')";

    // ====== Products (listing) ======
    private static final String PRODUCT_SONY_VAIO      = "a:has-text('Sony vaio i5')";
    private static final String PRODUCT_PRICE          = "h4:has-text('$790')";
    private static final String PRODUCT_DESCRIPTION    = "#tbodyid:has-text('Sony is so confident')";

    // ====== Product details ======
    private static final String PRODUCT_TITLE          = "h2:has-text('Sony vaio i5')";
    private static final String PRODUCT_PRICE_DETAIL   = "h3:has-text('$790')";
    private static final String PRODUCT_DESCRIPTION_DETAIL = "#more-information:has-text('Sony is so confident'), #tbodyid:has-text('Sony is so confident')";
    private static final String ADD_TO_CART_BUTTON     = "a.btn-success:has-text('Add to cart')";
    private static final String PRODUCT_IMAGE          = "#imgp img";

    // ====== Cart ======
    private static final String CART_TABLE_HEADER      = "th:has-text('Pic')";
    private static final String CART_PRODUCT_IMAGE     = "tr:has-text('Sony vaio i5') img";
    private static final String CART_PRODUCT_NAME      = "#tbodyid:has-text('Sony vaio i5')";
    private static final String CART_PRODUCT_PRICE     = "#tbodyid:has-text('790')";
    private static final String CART_DELETE_LINK       = "a:has-text('Delete')";
    private static final String PLACE_ORDER_BUTTON     = "button:has-text('Place Order')";
    private static final String CART_TOTAL_PRICE       = "#totalp:has-text('790')";
    private static final String CLOSE_BUTTON           = ".modal-footer button:has-text('Close')";

    // ====== Order modal ======
    private static final String ORDER_MODAL_TITLE      = "h5:has-text('Place order')";
    private static final String ORDER_TOTAL            = "#totalm";
    private static final String NAME_FIELD             = "#name";
    private static final String COUNTRY_FIELD          = "#country";
    private static final String CITY_FIELD             = "#city";
    private static final String CARD_FIELD             = "#card";
    private static final String MONTH_FIELD            = "#month";
    private static final String YEAR_FIELD             = "#year";
    private static final String PURCHASE_BUTTON        = "button:has-text('Purchase')";

    // ====== Confirmation ======
    private static final String CONFIRMATION_ICON      = ".sa-placeholder";
    private static final String CONFIRMATION_MESSAGE   = "div.sweet-alert:has-text('Thank you for your purchase')";
    private static final String CONFIRMATION_ID        = "div.sweet-alert:has-text('Id:')";
    private static final String OK_BUTTON              = "button:has-text('OK')";

    // ---------- Workflows ----------

    /** Full happy-path flow (useful for quick manual runs). */
    public void completeShoppingFlow() {
        logger.info("Starting complete shopping flow");
        navigateToHomePage();
        verifyHomePageElements();
        loginWithValidCredentials("aaabbbcccddeee", "123456");
        verifyLoginSuccess("aaabbbcccddeee");
        browseLaptopsCategory();
        selectSonyVaioProduct();
        verifyProductDetails();
        addProductToCart();
        navigateToCart();
        verifyProductInCart();
        proceedToCheckout();
        fillOrderDetails("a", "b", "cd", "e", "f", "g");
        completePurchase();
        verifyPurchaseConfirmation();
        verifyUserStillLoggedIn("aaabbbcccddeee");
        logout();
        verifyLogoutSuccess();
        logger.info("Complete shopping flow finished successfully");
    }

    // ---------- Actions used by steps ----------

    @Step("Navigate to DemoBlaze homepage")
    public void navigateToHomePage() {
        logger.info("Navigating to DemoBlaze homepage");
        navigate("https://www.demoblaze.com/index.html");
        waitForPageLoad();
        logger.info("DemoBlaze homepage loaded");
    }

    @Step("Verify homepage elements")
    public void verifyHomePageElements() {
        logger.info("Verifying homepage elements");
        isVisible(PRODUCT_STORE_LOGO);
        isVisible(LOGIN_LINK);
        logger.info("Homepage elements verified");
    }

    @Step("Login with username: {0}")
    public void loginWithValidCredentials(String username, String password) {
        logger.info("Logging in with username: {}", username);
        click(LOGIN_LINK);
        isVisible(LOGIN_MODAL_TITLE);
        fill(USERNAME_FIELD, username);
        fill(PASSWORD_FIELD, password);
        isVisible(LOGIN_BUTTON);
        click(LOGIN_BUTTON);
        logger.info("Login form submitted");
    }

    @Step("Verify login success for user: {0}")
    public void verifyLoginSuccess(String username) {
        logger.info("Verifying login success for user: {}", username);
        isVisible(WELCOME_MESSAGE + ":has-text('Welcome " + username + "')");
        isVisible(LOGOUT_LINK);
        logger.info("Login successful - welcome message displayed");
    }

    @Step("Browse laptops category")
    public void browseLaptopsCategory() {
        logger.info("Browsing laptops category");
        isVisible(CATEGORIES_HEADER);
        isVisible(LAPTOPS_CATEGORY);
        click(LAPTOPS_CATEGORY);
        isVisible(PRODUCT_SONY_VAIO);
        isVisible(PRODUCT_PRICE);
        isVisible(PRODUCT_DESCRIPTION);
        logger.info("Laptops category loaded with products");
    }

    @Step("Select Sony Vaio product")
    public void selectSonyVaioProduct() {
        logger.info("Selecting Sony Vaio product");
        click(PRODUCT_SONY_VAIO);
        logger.info("Navigated to Sony Vaio product page");
    }

    @Step("Verify product details")
    public void verifyProductDetails() {
        logger.info("Verifying product details");
        isVisible(PRODUCT_TITLE);
        isVisible(PRODUCT_PRICE_DETAIL);
        isVisible(PRODUCT_DESCRIPTION_DETAIL);
        isVisible(ADD_TO_CART_BUTTON);
        isVisible(PRODUCT_IMAGE);
        logger.info("Product details verified");
    }

    @Step("Add product to cart")
    public void addProductToCart() {
        logger.info("Adding product to cart");
        withDialogHandler(DialogAction.ACCEPT); // accept JS alert "Product added"
        click(ADD_TO_CART_BUTTON);
        logger.info("Product added to cart");
    }

    @Step("Navigate to cart page")
    public void navigateToCart() {
        logger.info("Navigating to cart page");
        isVisible(CART_LINK);
        click(CART_LINK);
        logger.info("Cart page opened");
    }

    @Step("Verify product in cart")
    public void verifyProductInCart() {
        logger.info("Verifying product in cart details");
        isVisible(CART_TABLE_HEADER);
        isVisible(CART_PRODUCT_IMAGE);
        isVisible(CART_PRODUCT_NAME);
        isVisible(CART_PRODUCT_PRICE);
        isVisible(CART_DELETE_LINK);
        isVisible(PLACE_ORDER_BUTTON);
        isVisible(CART_TOTAL_PRICE);
        logger.info("Product verified in cart with correct details");
    }

    @Step("Proceed to checkout")
    public void proceedToCheckout() {
        logger.info("Proceeding to checkout");
        click(PLACE_ORDER_BUTTON);
        isVisible(ORDER_MODAL_TITLE);
        isVisible(ORDER_TOTAL);
        logger.info("Checkout form opened");
    }

    @Step("Fill order details")
    public void fillOrderDetails(String name, String country, String city,
                                 String card, String month, String year) {
        logger.info("Filling order details: name={}, country={}, city={}", name, country, city);
        fill(NAME_FIELD, name);
        fill(COUNTRY_FIELD, country);
        fill(CITY_FIELD, city);
        fill(CARD_FIELD, card);
        fill(MONTH_FIELD, month);
        fill(YEAR_FIELD, year);
        isVisible(PURCHASE_BUTTON);
        isVisible(CLOSE_BUTTON);
        logger.info("Order details filled");
    }

    @Step("Complete purchase")
    public void completePurchase() {
        logger.info("Completing purchase");
        click(PURCHASE_BUTTON);
        logger.info("Purchase submitted");
    }

    @Step("Verify purchase confirmation")
    public void verifyPurchaseConfirmation() {
        logger.info("Verifying purchase confirmation");
        isVisible(CONFIRMATION_ICON);
        isVisible(CONFIRMATION_MESSAGE);
        isVisible(CONFIRMATION_ID);
        isVisible(OK_BUTTON);
        click(OK_BUTTON);
        logger.info("Purchase confirmation verified and closed");
    }

    @Step("Verify user still logged in: {0}")
    public void verifyUserStillLoggedIn(String username) {
        logger.info("Verifying user still logged in: {}", username);
        isVisible(WELCOME_MESSAGE + ":has-text('Welcome " + username + "')");
        isVisible(LOGOUT_LINK);
        logger.info("User still logged in confirmation");
    }

    @Step("Log out")
    public void logout() {
        logger.info("Logging out");
        click(LOGOUT_LINK);
        logger.info("Logout clicked");
    }

    @Step("Verify logout success")
    public void verifyLogoutSuccess() {
        logger.info("Verifying logout success");
        isVisible(SIGNIN_LINK);
        isVisible(LOGIN_LINK);
        logger.info("Logout verified successfully");
    }
}
