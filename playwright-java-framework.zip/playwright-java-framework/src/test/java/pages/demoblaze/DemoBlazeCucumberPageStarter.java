package pages.demoblaze;

import framework.core.BasePage;
import io.qameta.allure.Step;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Simplified single-flow Page Object for DemoBlaze site.
 * Executes a full end-to-end shopping flow (login → browse → add to cart → checkout → confirm → logout)
 * in one method, mainly for quick smoke tests or framework validation.
 */
public class DemoBlazeCucumberPageStarter extends BasePage {

    private static final Logger logger = LoggerFactory.getLogger(DemoBlazeCucumberPageStarter.class);

    public DemoBlazeCucumberPageStarter() {
        super();
    }

    /**
     * Executes a single complete shopping flow on DemoBlaze.
     */
    @Step("Execute single end-to-end purchase flow on DemoBlaze")
    public void singleFlow() {

        // Step 1: Navigate to website
        logger.info("Navigating to DemoBlaze homepage");
        navigate("https://www.demoblaze.com/index.html");
        waitForPageLoad();

        // Step 2: Verify homepage elements
        isVisible("a[href='index.html']:has-text('PRODUCT STORE')");
        isVisible("#login2");

        // Step 3: Login process
        logger.info("Performing login");
        click("#login2");
        isVisible("#logInModalLabel");
        fill("#loginusername", "aaabbbcccddeee");
        fill("#loginpassword", "123456");
        isVisible("button:has-text('Log in')");
        click("button:has-text('Log in')");

        // Step 4: Verify successful login
        isVisible("a#nameofuser:has-text('Welcome aaabbbcccddeee')");
        isVisible("#logout2");

        // Step 5: Browse categories and products
        logger.info("Browsing Laptops category");
        isVisible("a:has-text('CATEGORIES')");
        isVisible("a:has-text('Laptops')");
        click("a:has-text('Laptops')");
        isVisible("a:has-text('Sony vaio i5')");
        isVisible("h4:has-text('$790')");
        isVisible("#tbodyid:has-text('Sony is so confident')");

        // Step 6: View product details
        logger.info("Viewing product details");
        click("a:has-text('Sony vaio i5')");
        isVisible("h2:has-text('Sony vaio i5')");
        isVisible("h3:has-text('$790')");
        isVisible("#tbodyid:has-text('Sony is so confident')");
        isVisible("a.btn-success:has-text('Add to cart')");
        isVisible("#imgp img");

        // Step 7: Add product to cart (handling alert)
        logger.info("Adding product to cart");
        withDialogHandler(BasePage.DialogAction.ACCEPT);
        click("a.btn-success:has-text('Add to cart')");

        // Step 8: View cart
        logger.info("Opening Cart page");
        isVisible("#cartur");
        click("#cartur");

        // Step 9: Verify product in cart
        isVisible("th:has-text('Pic')");
        isVisible("tr:has-text('Sony vaio i5') img");
        isVisible("#tbodyid:has-text('Sony vaio i5')");
        isVisible("#tbodyid:has-text('790')");
        isVisible("a:has-text('Delete')");
        isVisible("button:has-text('Place Order')");
        isVisible("#totalp:has-text('790')");

        // Step 10: Checkout process
        logger.info("Proceeding to checkout");
        click("button:has-text('Place Order')");
        isVisible("h5:has-text('Place order')");
        isVisible("#totalm:has-text('Total: 790')");

        // Step 11: Fill order details
        logger.info("Filling order form");
        fill("#name", "a");
        fill("#country", "b");
        fill("#city", "cd");
        fill("#card", "e");
        fill("#month", "f");
        fill("#year", "g");
        isVisible("button:has-text('Purchase')");
        isVisible(".modal-footer button:has-text('Close')");

        // Step 12: Complete purchase
        logger.info("Completing purchase");
        click("button:has-text('Purchase')");
        isVisible(".sa-placeholder");
        isVisible("div.sweet-alert:has-text('Thank you for your purchase')");
        isVisible("div.sweet-alert:has-text('Id:')");
        isVisible("button:has-text('OK')");
        click("button:has-text('OK')");

        // Step 13: Verify user still logged in
        isVisible("a#nameofuser:has-text('Welcome aaabbbcccddeee')");
        isVisible("#logout2");

        // Step 14: Logout and verify success
        logger.info("Logging out");
        click("#logout2");
        isVisible("#signin2");
        isVisible("#login2");

        logger.info("✅ Single flow execution completed successfully");
    }
}
