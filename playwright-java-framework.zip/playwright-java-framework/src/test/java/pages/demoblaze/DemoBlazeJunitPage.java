package pages.demoblaze;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.TimeoutError;

/**
 * Simple Page Object for DemoBlaze website.
 * Encapsulates selectors and user actions used by tests.
 */
public class DemoBlazeJunitPage {

    private final Page page;

    // ---------- Common / navigation ----------
    private static final String STORE_LINK         = "#nava";
    private static final String LOGIN_LINK         = "#login2";
    private static final String LOGOUT_LINK        = "#logout2";
    private static final String WELCOME_MESSAGE    = "#nameofuser";
    private static final String LAPTOPS_CATEGORY   = "a:has-text('Laptops')";
    private static final String CART_LINK          = "#cartur";

    // ---------- Login modal ----------
    private static final String LOGIN_MODAL_TITLE  = "#logInModalLabel";
    private static final String USERNAME_FIELD     = "#loginusername";
    private static final String PASSWORD_FIELD     = "#loginpassword";
    private static final String LOGIN_BUTTON       = "button:has-text('Log in')";

    // ---------- Products page ----------
    private static final String SONY_VAIO_PRODUCT  = "a:has-text('Sony vaio i5')";
    private static final String PRODUCT_TITLE      = "h2:has-text('Sony vaio i5')";
    private static final String ADD_TO_CART_BUTTON = "a:has-text('Add to cart')";

    // ---------- Cart page ----------
    private static final String PLACE_ORDER_BUTTON = "button:has-text('Place Order')";
    private static final String PRODUCT_IN_CART    = "td:has-text('Sony vaio i5')";
    private static final String CART_ITEMS_TABLE   = "#tbodyid";

    // ---------- Order form ----------
    private static final String NAME_FIELD   = "#name";
    private static final String COUNTRY_FIELD= "#country";
    private static final String CITY_FIELD   = "#city";
    private static final String CARD_FIELD   = "#card";
    private static final String MONTH_FIELD  = "#month";
    private static final String YEAR_FIELD   = "#year";
    private static final String PURCHASE_BUTTON = "button:has-text('Purchase')";

    // ---------- Confirmation ----------
    private static final String CONFIRMATION_MESSAGE = ".sweet-alert";
    private static final String OK_BUTTON            = "button:has-text('OK')";

    public DemoBlazeJunitPage(Page page) {
        this.page = page;
    }

    // -------------------- Actions --------------------

    public void navigateToHomePage() {
        page.navigate("https://www.demoblaze.com/index.html");
        page.waitForLoadState(LoadState.NETWORKIDLE);
    }

    public boolean isHomePageLoaded() {
        return page.locator(STORE_LINK).isVisible();
    }

    public void login(String username, String password) {
        page.locator(LOGIN_LINK).click();
        page.locator(LOGIN_MODAL_TITLE).waitFor();

        page.locator(USERNAME_FIELD).click();
        page.locator(USERNAME_FIELD).fill(username);

        page.locator(PASSWORD_FIELD).click();
        page.locator(PASSWORD_FIELD).fill(password);

        page.locator(LOGIN_BUTTON).click();

        // Wait for login to complete and welcome message to appear
        page.waitForLoadState(LoadState.NETWORKIDLE);
        try {
            page.locator(WELCOME_MESSAGE)
                .waitFor(new Locator.WaitForOptions().setTimeout(10_000));
        } catch (TimeoutError e) {
            throw new RuntimeException("Login failed - welcome message not visible", e);
        }
    }

    public void navigateToLaptopsCategory() {
        page.locator(LAPTOPS_CATEGORY).click();
        page.waitForLoadState(LoadState.NETWORKIDLE);
    }

    public boolean isSonyVaioProductVisible() {
        return page.locator(SONY_VAIO_PRODUCT).isVisible();
    }

    public void clickSonyVaioProduct() {
        page.locator(SONY_VAIO_PRODUCT).click();
        page.waitForLoadState(LoadState.NETWORKIDLE);
        try {
            page.locator(PRODUCT_TITLE)
                .waitFor(new Locator.WaitForOptions().setTimeout(5_000));
        } catch (TimeoutError e) {
            throw new RuntimeException("Product title not visible after clicking", e);
        }
    }

    public void addProductToCart() {
        // Handle alert dialog (Product added)
        page.onceDialog(dialog -> dialog.accept());
        page.locator(ADD_TO_CART_BUTTON).click();
        page.waitForLoadState(LoadState.NETWORKIDLE);
    }

    public void goToCart() {
        page.locator(CART_LINK).click();
        page.waitForLoadState(LoadState.NETWORKIDLE);
    }

    public boolean isProductInCart() {
        return page.locator(PRODUCT_IN_CART).isVisible();
    }

    public String getCartContent() {
        return page.locator(CART_ITEMS_TABLE).textContent();
    }

    public void placeOrder() {
        page.locator(PLACE_ORDER_BUTTON).click();
        page.locator(".modal-content:has(#totalm)").waitFor();
    }

    public void fillOrderForm(String name, String country, String city,
                              String card, String month, String year) {
        page.locator(NAME_FIELD).fill(name);
        page.locator(COUNTRY_FIELD).fill(country);
        page.locator(CITY_FIELD).fill(city);
        page.locator(CARD_FIELD).fill(card);
        page.locator(MONTH_FIELD).fill(month);
        page.locator(YEAR_FIELD).fill(year);
    }

    public void submitOrder() {
        page.locator(PURCHASE_BUTTON).click();
        page.locator(".sweet-alert:has-text('Thank you for your purchase')").waitFor();
    }

    public String getConfirmationText() {
        return page.locator(CONFIRMATION_MESSAGE).textContent();
    }

    public void confirmOrder() {
        page.locator(OK_BUTTON).click();
        page.waitForLoadState(LoadState.NETWORKIDLE);

        // Safely close any visible modal with a Close button
        Locator visibleCloseButton = page.locator(".modal.show button:has-text('Close')").first();
        if (visibleCloseButton.count() > 0 && visibleCloseButton.isVisible()) {
            visibleCloseButton.click();
            page.waitForLoadState(LoadState.NETWORKIDLE);
        }
    }

    public void logout() {
        page.locator(LOGOUT_LINK).click();
        page.waitForLoadState(LoadState.NETWORKIDLE);
        page.locator(LOGIN_LINK).waitFor(new Locator.WaitForOptions().setTimeout(5_000));
    }

    public boolean isLoggedOut() {
        return page.locator(LOGIN_LINK).isVisible();
    }

    public Page getPage() {
        return page;
    }
}
