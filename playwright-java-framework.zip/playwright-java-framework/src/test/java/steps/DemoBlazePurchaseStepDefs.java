package steps;

import io.cucumber.java.en.*;
import io.cucumber.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pages.demoblaze.DemoBlazeCucumberPage;
import framework.core.PlaywrightManager;

import java.util.List;
import java.util.Map;

/**
 * Step Definitions for DemoBlaze E-commerce Purchase Flow.
 * Connects Gherkin steps to Playwright Page Object actions.
 */
public class DemoBlazePurchaseStepDefs {

    private static final Logger logger = LoggerFactory.getLogger(DemoBlazePurchaseStepDefs.class);

    private final DemoBlazeCucumberPage demoBlazePage = new DemoBlazeCucumberPage();
    private final String username = "aaabbbcccddeee";
    private final String password = "123456";

    // ------------------------------------------------------------------
    @Given("user is on the DemoBlaze home page")
    public void userIsOnTheDemoBlazeHomePage() {
        logger.info("STEP: User is on the DemoBlaze home page");
        demoBlazePage.navigateToHomePage();
        demoBlazePage.verifyHomePageElements();
    }

    @When("user logs in with valid credentials")
    public void userLogsInWithValidCredentials() {
        logger.info("STEP: User logs in with valid credentials");
        demoBlazePage.loginWithValidCredentials(username, password);
    }

    @Then("user should see welcome message with their username")
    public void userShouldSeeWelcomeMessageWithTheirUsername() {
        logger.info("STEP: User should see welcome message with their username");
        // Here we could verify using the welcome message element if needed
        demoBlazePage.verifyLoginSuccess(username);
    }

    @When("user navigates to {string} category")
    public void userNavigatesToCategory(String category) {
        logger.info("STEP: User navigates to {} category", category);
        if (category.equalsIgnoreCase("Laptops")) {
            demoBlazePage.browseLaptopsCategory();
        } else {
            logger.warn("Category {} not implemented yet", category);
        }
    }

    @When("user selects {string} product")
    public void userSelectsProduct(String productName) {
        logger.info("STEP: User selects {} product", productName);
        if (productName.equalsIgnoreCase("Sony vaio i5")) {
            demoBlazePage.selectSonyVaioProduct();
        } else {
            logger.warn("Product {} not implemented yet", productName);
        }
    }

    /**
     * Verification step - checks if product details are displayed correctly
     * Uses DataTable from feature file to verify product information
     */
    @Then("user should see product details page with correct information")
    public void userShouldSeeProductDetailsPageWithCorrectInformation(DataTable dataTable) {
        logger.info("STEP: User should see product details page with correct information");

        // Convert DataTable to a List of Maps (each row becomes a Map)
        List<Map<String, String>> productData = dataTable.asMaps();

        // Log expected values
        String expectedProductName = productData.get(0).get("productName");
        String expectedPrice = productData.get(0).get("price");
        String expectedDescription = productData.get(0).get("description");

        logger.info("Expected product: {}, price: {}, description contains: {}",
                expectedProductName, expectedPrice, expectedDescription);

        // Verify product details using Page Object
        demoBlazePage.verifyProductDetails();
    }

    @When("user adds product to cart")
    public void userAddsProductToCart() {
        logger.info("STEP: User adds product to cart");
        demoBlazePage.addProductToCart();
    }

    @When("user navigates to cart page")
    public void userNavigatesToCartPage() {
        logger.info("STEP: User navigates to cart page");
        demoBlazePage.navigateToCart();
    }

    @Then("user should see product in the cart")
    public void userShouldSeeProductInTheCart(DataTable dataTable) {
        logger.info("STEP: User should see product in the cart");

        List<Map<String, String>> cartData = dataTable.asMaps();
        String expectedProductName = cartData.get(0).get("productName");
        String expectedPrice = cartData.get(0).get("price");

        logger.info("Expected product in cart: {}, price: {}", expectedProductName, expectedPrice);

        demoBlazePage.verifyProductInCart();
    }

    @When("user proceeds to checkout")
    public void userProceedsToCheckout() {
        logger.info("STEP: User proceeds to checkout");
        demoBlazePage.proceedToCheckout();
    }

    /**
     * Action step - fills in order details
     * Uses DataTable from feature file for order information
     */
    @When("user fills in order details")
    public void userFillsInOrderDetails(DataTable dataTable) {
        logger.info("STEP: User fills in order details");

        List<Map<String, String>> orderData = dataTable.asMaps();

        String name = orderData.get(0).get("name");
        String country = orderData.get(0).get("country");
        String city = orderData.get(0).get("city");
        String creditCard = orderData.get(0).get("creditCard");
        String month = orderData.get(0).get("month");
        String year = orderData.get(0).get("year");

        logger.info("Order details - name: {}, country: {}, city: {}, card: {}", name, country, city, creditCard);

        demoBlazePage.fillOrderDetails(name, country, city, creditCard, month, year);
    }

    @When("user completes checkout")
    public void userCompletesCheckout() {
        logger.info("STEP: User completes checkout");
        demoBlazePage.completePurchase();
        demoBlazePage.verifyPurchaseConfirmation();
    }

    @Then("user should see purchase confirmation")
    public void userShouldSeePurchaseConfirmation() {
        logger.info("STEP: User should see purchase confirmation");
        // The verification was already done in the completePurchase step
        demoBlazePage.verifyUserStillLoggedIn(username);
    }

    @Then("user logs out")
    public void userLogsOut() {
        logger.info("STEP: User logs out");
        demoBlazePage.logout();
        demoBlazePage.verifyLogoutSuccess();
    }
}