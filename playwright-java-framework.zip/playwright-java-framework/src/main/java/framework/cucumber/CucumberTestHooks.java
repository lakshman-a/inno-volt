package framework.cucumber;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

import io.qameta.allure.Allure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import framework.core.PlaywrightManager;
import utils.ConfigUtil;

import java.io.ByteArrayInputStream;

/**
 * Cucumber hooks to handle setup and teardown actions for BDD tests.
 */
public class CucumberTestHooks {

    private static final Logger logger = LoggerFactory.getLogger(CucumberTestHooks.class);

    @Before
    public void setUp(Scenario scenario) {
        logger.info("Starting scenario: {}", scenario.getName());
        PlaywrightManager.initialize();
    }

    @After
    public void tearDown(Scenario scenario) {
        try {
            if (scenario.isFailed()) {
                logger.info("Scenario failed: {}", scenario.getName());

                // Take screenshot on failure
                byte[] screenshot = PlaywrightManager
                        .takeScreenshot(("failure_" + scenario.getName()).replaceAll("\\s+", ""));

                // Attach to Cucumber report
                scenario.attach(screenshot, "image/png", "Screenshot on Failure");

                // Allure reporting
                Allure.addAttachment("Failure Screenshot", "image/png",
                        new ByteArrayInputStream(screenshot), ".png");
            }
        } catch (Exception e) {
            logger.error("Failed to capture failure screenshot", e);
        } finally {
            PlaywrightManager.close();
            logger.info("Finished scenario: {}", scenario.getName());
        }
    }

    /**
     * Hook to capture screenshot after each step when enabled.
     */
    @AfterStep
    public void afterStep(Scenario scenario) {
        logger.debug("Taking screenshot after step");

        // Check if step screenshots are enabled via framework properties
        // can be overridden at runtime: -Dcucumber.step.screenshots=true
        boolean stepScreenshotsEnabled = ConfigUtil.getBoolean("cucumber.step.screenshots", false);

        String sysProp = System.getProperty("cucumber.step.screenshots");
        if (sysProp != null) {
            stepScreenshotsEnabled = Boolean.parseBoolean(sysProp);
        }

        if (stepScreenshotsEnabled) {
            try {
                String stepName = scenario.getId(); // best available name per step
                byte[] screenshot = PlaywrightManager.takeScreenshot("step_" + System.currentTimeMillis());

                // Attach to Cucumber
                scenario.attach(screenshot, "image/png", "Step: " + stepName);

                // Attach to Allure
                Allure.addAttachment("Step Screenshot: " + stepName, "image/png",
                        new ByteArrayInputStream(screenshot), ".png");
            } catch (Exception e) {
                logger.warn("Failed to capture step screenshot: {}", e.getMessage());
                // do not fail scenario for screenshot issues
            }
        }
    }
}
