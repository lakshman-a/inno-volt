package framework.cucumber;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import com.microsoft.playwright.Page;

import framework.core.PlaywrightManager;
import io.qameta.allure.Step;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Base step definitions that can be shared across features.
 */
public class CommonStepDefinitions {

    private static final Logger logger = LoggerFactory.getLogger(CommonStepDefinitions.class);
    protected Page page;

    public CommonStepDefinitions() {
        this.page = PlaywrightManager.getPage();
    }

    // -------------------- Navigation --------------------

    @Given("I navigate to {string}")
    public void iNavigateTo(String url) {
        logger.info("Navigating to URL: {}", url);
        page.navigate(url);
        page.waitForLoadState();
    }

    // -------------------- Actions --------------------

    @When("I click on element {string}")
    public void iClickOnElement(String selector) {
        logger.info("Clicking on element: {}", selector);
        page.locator(selector).click();
    }

    @When("I fill {string} with {string}")
    public void iFillWith(String selector, String text) {
        logger.info("Filling element '{}' with text: '{}'", selector, text);
        page.locator(selector).fill(text);
    }

    @When("I type {string} into {string}")
    public void iTypeInto(String text, String selector) {
        logger.info("Typing '{}' into element: {}", text, selector);
        page.locator(selector).pressSequentially(text);
    }

    @When("I press the {string} key")
    public void iPressTheKey(String key) {
        logger.info("Pressing key: {}", key);
        page.keyboard().press(key);
    }

    // -------------------- Assertions --------------------

    @Then("I should see element {string}")
    public void iShouldSeeElement(String selector) {
        logger.info("Checking if element is visible: {}", selector);
        assertTrue(page.locator(selector).isVisible(), "Element should be visible: " + selector);
    }

    @Then("I should not see element {string}")
    public void iShouldNotSeeElement(String selector) {
        logger.info("Checking if element is not visible: {}", selector);
        assertFalse(page.locator(selector).isVisible(), "Element should NOT be visible: " + selector);
    }

    @Then("The element {string} should contain text {string}")
    public void theElementShouldContainText(String selector, String text) {
        String actual = page.locator(selector).innerText();
        logger.info("Asserting element '{}' contains text. Expected: '{}', Actual: '{}'", selector, text, actual);
        assertTrue(actual.contains(text), "Expected text not present. Expected contains: " + text);
    }

    @Then("The page title should be {string}")
    public void thePageTitleShouldBe(String title) {
        logger.info("Checking if page title equals: {}", title);
        assertEquals(title, page.title(), "Page title mismatch");
    }

    @Then("The page title should contain {string}")
    public void thePageTitleShouldContain(String title) {
        logger.info("Checking if page title contains: {}", title);
        assertTrue(page.title().contains(title), "Page title should contain: " + title);
    }

    // -------------------- Waits & Screenshots --------------------

    @And("I wait for {int} seconds")
    public void iWaitForSeconds(int seconds) {
        logger.info("Waiting for {} seconds", seconds);
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Wait interrupted", e);
        }
    }

    @And("I wait for element {string} to be visible")
    public void iWaitForElementToBeVisible(String selector) {
        logger.info("Waiting for element to be visible: {}", selector);
        page.locator(selector).waitFor();
    }

    @Step("Take screenshot: {0}")
    @And("I take screenshot {string}")
    public void iTakeScreenshot(String name) {
        PlaywrightManager.takeScreenshot(name);
    }
}
