package framework.core;

import io.qameta.allure.Allure;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.ConfigUtil;

import java.io.ByteArrayInputStream;
import java.util.UUID;

/**
 * BaseTest - common setup/teardown for Playwright tests
 */
public abstract class BaseTest {

    protected static final Logger logger = LoggerFactory.getLogger(BaseTest.class);

    protected String baseUrl;
    protected String testId;
    protected String testName;

    @BeforeEach
    public void setup(TestInfo testInfo) {
        testId = UUID.randomUUID().toString();
        testName = testInfo.getDisplayName();
        baseUrl = ConfigUtil.get("baseUrl");

        logger.info("Starting test [{}] with ID: {}", testName, testId);

        // Initialize Playwright
        PlaywrightManager.initialize();

        // Add test info to Allure
        Allure.parameter("Test ID", testId);
        Allure.parameter("Browser", ConfigUtil.get("browser"));
        Allure.parameter("Headless", ConfigUtil.getBoolean("headless"));
    }

    @AfterEach
    public void tearDown() {
        try {
            logger.info("Finishing test [{}] with ID: {}", testName, testId);
            if (PlaywrightManager.getPage() != null) {
                logger.info("Capturing screenshot at the end of test");
                byte[] screenshot = PlaywrightManager.takeScreenshot("test_end_" + testId);
                Allure.addAttachment("Final Screenshot", "image/png",
                        new ByteArrayInputStream(screenshot), ".png");
            }
        } catch (Exception e) {
            logger.error("Failed to capture final screenshot", e);
        } finally {
            try {
                PlaywrightManager.close();
            } catch (Exception e) {
                logger.error("Error during teardown", e);
            }
        }
    }

    protected void logStep(String step) {
        logger.info("STEP: {}", step);
        Allure.step(step);
    }
}
