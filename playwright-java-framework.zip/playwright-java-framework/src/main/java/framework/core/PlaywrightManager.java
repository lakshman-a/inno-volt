package framework.core;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.Cookie;
import io.qameta.allure.Attachment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.ConfigUtil;

import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import java.util.List;

/**
 * PlaywrightManager - Core class for managing Playwright lifecycle and browser setup.
 */
public class PlaywrightManager {

    // Logger
    private static final Logger logger = LoggerFactory.getLogger(PlaywrightManager.class);

    // Thread-safe Playwright instances
    private static final ThreadLocal<Playwright> playwrightThreadLocal = new ThreadLocal<>();
    private static final ThreadLocal<Browser> browserThreadLocal = new ThreadLocal<>();
    private static final ThreadLocal<BrowserContext> contextThreadLocal = new ThreadLocal<>();
    private static final ThreadLocal<Page> pageThreadLocal = new ThreadLocal<>();

    // Browser mapping and trace directory
    private static final Map<String, String> browserTypeMap = new HashMap<>();
    private static final String TRACE_DIR = "target/playwright-traces";

    static {
        browserTypeMap.put("chromium", "chromium");
        browserTypeMap.put("firefox", "firefox");
        browserTypeMap.put("webkit", "webkit");

        try {
            java.nio.file.Files.createDirectories(Paths.get(TRACE_DIR));
        } catch (Exception e) {
            logger.warn("Could not create trace directory: {}", e.getMessage());
        }
    }

    /** Initialize Playwright and browser */
    public static void initialize() {
        if (playwrightThreadLocal.get() == null) {
            logger.info("Initializing Playwright...");
            Playwright playwright = Playwright.create();
            playwrightThreadLocal.set(playwright);

            String browserName = ConfigUtil.get("browser").toLowerCase();
            boolean headless = ConfigUtil.getBoolean("headless");
            int slowMo = Integer.parseInt(ConfigUtil.get("slowMo"));
            int timeout = Integer.parseInt(ConfigUtil.get("timeout"));
            int viewportWidth = Integer.parseInt(ConfigUtil.get("viewport.width"));
            int viewportHeight = Integer.parseInt(ConfigUtil.get("viewport.height"));
            String videoDir = ConfigUtil.get("video.dir");

            logger.info("Launching browser: {} (headless: {})", browserName, headless);
            BrowserType browserType = getBrowserType(browserName);
            Browser browser = browserType.launch(new BrowserType.LaunchOptions()
                    .setHeadless(headless)
                    .setSlowMo(slowMo));

            browserThreadLocal.set(browser);

            Browser.NewContextOptions contextOptions = new Browser.NewContextOptions()
                    .setViewportSize(viewportWidth, viewportHeight)
                    .setRecordVideoDir(Paths.get(videoDir))
                    .setLocale("en-US")
                    .setIgnoreHTTPSErrors(true);

            BrowserContext context = browser.newContext(contextOptions);

            // Custom headers & user-agent
            context.setExtraHTTPHeaders(Map.of(
                    "Accept-Language", "en-US,en;q=0.9",
                    "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
            ));

            // Example cookie setup
            context.addCookies(List.of(new Cookie("CONSENT", "YES")
                    .setDomain(".google.com")
                    .setPath("/")));

            contextThreadLocal.set(context);

            // Enable tracing if configured
            boolean tracingEnabled = ConfigUtil.getBoolean("tracing.enabled", false);
            if (tracingEnabled) {
                try {
                    logger.info("Starting Playwright tracing...");
                    context.tracing().start(new Tracing.StartOptions()
                            .setScreenshots(true)
                            .setSnapshots(true)
                            .setSources(false));
                } catch (Exception e) {
                    logger.error("Error starting tracing: {}", e.getMessage());
                }
            }

            // Create a new page
            Page page = context.newPage();
            pageThreadLocal.set(page);

            // Event listeners
            page.onConsoleMessage(msg ->
                    logger.debug("Browser console [{}]: {}", msg.type(), msg.text()));

            page.onDialog(dialog -> {
                logger.info("Dialog appeared: {}", dialog.message());
                dialog.accept();
            });

            logger.info("Playwright initialized successfully");
        }
    }

    public static Page getPage() {
        if (pageThreadLocal.get() == null) initialize();
        return pageThreadLocal.get();
    }

    public static BrowserContext getContext() {
        if (contextThreadLocal.get() == null) initialize();
        return contextThreadLocal.get();
    }

    @Attachment(value = "Screenshot", type = "image/png")
    public static byte[] takeScreenshot(String name) {
        logger.info("Taking screenshot: {}", name);
        Page page = getPage();
        if (page == null) {
            logger.error("Cannot take screenshot, page is null");
            return new byte[0];
        }
        return page.screenshot(new Page.ScreenshotOptions()
                .setPath(Paths.get(ConfigUtil.get("screenshot.dir"), name + ".png")));
    }

    public static void navigate(String url) {
        logger.info("Navigating to: {}", url);
        getPage().navigate(url);
    }

    /** Close Playwright resources */
    public static void close() {
        try {
            boolean tracingEnabled = ConfigUtil.getBoolean("tracing.enabled", false);
            if (tracingEnabled && contextThreadLocal.get() != null) {
                String testId = Thread.currentThread().getName();
                String tracePath = TRACE_DIR + "/trace-" + testId + "-" + System.currentTimeMillis() + ".zip";
                logger.info("Exporting trace to: {}", tracePath);
                try {
                    contextThreadLocal.get().tracing().stop(new Tracing.StopOptions()
                            .setPath(Paths.get(tracePath)));
                } catch (Exception e) {
                    logger.error("Error exporting trace: {}", e.getMessage());
                }
            }

            if (pageThreadLocal.get() != null) {
                pageThreadLocal.get().close();
                pageThreadLocal.remove();
            }

            if (contextThreadLocal.get() != null) {
                contextThreadLocal.get().close();
                contextThreadLocal.remove();
            }

            if (browserThreadLocal.get() != null) {
                browserThreadLocal.get().close();
                browserThreadLocal.remove();
            }

            if (playwrightThreadLocal.get() != null) {
                playwrightThreadLocal.get().close();
                playwrightThreadLocal.remove();
            }

            logger.info("Playwright resources closed successfully");
        } catch (Exception e) {
            logger.error("Error closing Playwright resources", e);
        }
    }

    /** Get browser type */
    private static BrowserType getBrowserType(String browser) {
        String key = browserTypeMap.getOrDefault(browser, "chromium");
        Playwright playwright = playwrightThreadLocal.get();
        switch (key) {
            case "firefox":
                return playwright.firefox();
            case "webkit":
                return playwright.webkit();
            default:
                return playwright.chromium();
        }
    }
}
