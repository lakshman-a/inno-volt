package framework.core;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import io.qameta.allure.Step;
import io.qameta.allure.Attachment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.ConfigUtil;

import java.nio.file.Paths;
import java.util.function.Supplier;

/**
 * BasePage – common Playwright page helpers used by all Pages & Steps.
 */
public abstract class BasePage {

    protected static final Logger logger = LoggerFactory.getLogger(BasePage.class);
    protected final Page page;
    protected String pageUrl;

    // ---------- Constructors ----------
    public BasePage(String pageUrl) {
        this.page = PlaywrightManager.getPage();
        this.pageUrl = pageUrl;
    }

    public BasePage() {
        this.page = PlaywrightManager.getPage();
    }

    // ---------- Navigation ----------
    @Step("Navigate to page: {0}")
    public void navigate() {
        if (pageUrl == null || pageUrl.isEmpty()) {
            logger.warn("No URL defined for this page. Use navigate(String url) instead or set URL in ctor.");
            return;
        }
        logger.info("Navigating to: {}", pageUrl);
        navigateTo(pageUrl);
    }

    @Step("Navigate to specific URL: {0}")
    public void navigate(String url) {
        logger.info("Navigating to URL: {}", url);
        navigateTo(url);
    }

    private void navigateTo(String url) {
        page.navigate(url);
        waitForPageLoad();
    }

    @Step("Wait for page to load")
    public void waitForPageLoad() {
        page.waitForLoadState(); // default = LoadState.LOAD
    }

    // ---------- Element getters ----------
    @Step("Get element: {0}")
    protected Locator getElement(String selector, boolean waitVisible, int maxAttempts) {
        logger.debug("Getting element with selector: {}", selector);

        if (maxAttempts <= 0)
            maxAttempts = 1;

        Locator locator = null;
        Exception lastException = null;
        int attempt = 0;

        while (attempt < maxAttempts) {
            try {
                locator = page.locator(selector);

                // Touch the locator to fail fast if selector is invalid
                locator.count();

                if (waitVisible) {
                    logger.debug("Waiting for element to be visible: {}", selector);
                    locator.waitFor(new Locator.WaitForOptions()
                            .setState(WaitForSelectorState.VISIBLE)
                            .setTimeout(30_000));
                    logger.debug("Element is now visible: {}", selector);
                }
                return locator;

            } catch (Exception e) {
                lastException = e;
                logger.warn("Attempt {} to locate element '{}' failed: {}", attempt + 1, selector, e.getMessage());
                attempt++;

                if (attempt < maxAttempts) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }

        // Exhausted retries → throw with rich context
        String errorMessage = String.format("Failed to get element '%s' after %d attempts. Error: %s",
                selector, maxAttempts, (lastException != null ? lastException.getMessage() : "unknown error"));
        logger.error(errorMessage);
        logger.error("Page URL at time of failure: {}", page.url());
        logger.error("Page title at time of failure: {}", page.title());
        throw new RuntimeException(errorMessage, lastException);
    }

    @Step("Get element: {0}")
    protected Locator getElement(String selector) {
        return getElement(selector, false, 1);
    }

    @Step("Get element and wait for visibility: {0}")
    protected Locator getVisibleElement(String selector) {
        return getElement(selector, true, 3);
    }

    // ---------- Basic interactions ----------
    @Step("Click element: {0}")
    protected void click(String selector) {
        logger.info("Clicking element: {}", selector);
        getElement(selector, true, 3).click();
    }

    @Step("Click element: {0} with force option")
    protected void forceClick(String selector) {
        logger.info("Force clicking element: {}", selector);
        getElement(selector, true, 3).click(new Locator.ClickOptions().setForce(true));
    }

    @Step("Type text: {1} into element: {0}")
    protected void type(String selector, String text) {
        getElement(selector, true, 3).fill(text);
    }

    @Step("Type text using keyboard: {1} into element: {0}")
    protected void typeWithKeyboard(String selector, String text) {
        logger.info("Typing with keyboard '{}' into element: {}", text, selector);
        getElement(selector, true, 3).click();
        for (char c : text.toCharArray()) {
            page.keyboard().press(String.valueOf(c));
            page.waitForTimeout(50);
        }
    }

    @Step("Click and type: {1} into element: {0}")
    protected void clickAndType(String selector, String text) {
        getElement(selector, true, 3).click();
        getElement(selector).fill(text);
    }

    @Step("Force click and type: {1} into element: {0}")
    protected void forceClickAndType(String selector, String text) {
        getElement(selector, true, 3).click(new Locator.ClickOptions().setForce(true));
        getElement(selector).fill(text);
    }

    @Step("Clear and type text: {1} into element: {0}")
    protected void clearAndType(String selector, String text) {
        Locator el = getElement(selector, true, 3);
        el.fill(""); // clear
        el.fill(text); // type
    }

    @Step("Get text from element: {0}")
    protected String getText(String selector) {
        return getElement(selector, true, 3).innerText();
    }

    // ---------- Checks & waits ----------
    @Step("Check if element exists: {0}")
    protected boolean exists(String selector) {
        boolean exists = getElement(selector).count() > 0;
        logger.info("Element '{}' {}", selector, exists ? "exists" : "does not exist");
        return exists;
    }

    @Step("Fill element: {0} with value: {1}")
    protected void fill(String selector, String value) {
        logger.info("Filling element '{}' with value '{}'", selector, value);
        getElement(selector, true, 3).fill(value);
    }

    @Step("Wait for element to be visible: {0}")
    protected void waitForVisible(String selector) {
        getElement(selector, true, 3);
    }

    @Step("Wait for element to be hidden: {0}")
    protected void waitForHidden(String selector) {
        page.waitForSelector(selector,
                new Page.WaitForSelectorOptions().setState(WaitForSelectorState.HIDDEN));
    }

    @Step("Hover over element: {0}")
    protected void hover(String selector) {
        getElement(selector, true, 3).hover();
    }

    @Step("Upload file to: {0}")
    protected void uploadFile(String selector, String filePath) {
        getElement(selector, true, 3).setInputFiles(Paths.get(filePath));
    }

    @Attachment(value = "Screenshot", type = "image/png")
    @Step("Take screenshot: {0}")
    protected byte[] takeScreenshot(String name) {
        return page.screenshot(new Page.ScreenshotOptions()
                .setPath(Paths.get(ConfigUtil.get("screenshot.dir"), name + ".png")));
    }

    @Step("Get page title")
    protected String getTitle() {
        return page.title();
    }

    @Step("Check if element is enabled: {0}")
    protected boolean isEnabled(String selector) {
        return getElement(selector, true, 3).isEnabled();
    }

    @Step("Check if element is visible: {0}")
    protected boolean isVisible(String selector) {
        return getElement(selector, true, 3).isVisible();
    }

    // ---------- Retry & assertions ----------
    @Step("Retry action until successful or timeout")
    protected <T> T retry(Supplier<T> action, int maxAttempts) {
        int attempt = 0;
        Exception lastException = null;

        while (attempt < maxAttempts) {
            try {
                return action.get();
            } catch (Exception e) {
                lastException = e;
                logger.warn("Attempt {} failed: {}", attempt + 1, e.getMessage());
                attempt++;
                if (attempt < maxAttempts) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }

        String message = String.format("Action failed after %d attempts. Last error: %s",
                maxAttempts, (lastException != null ? lastException.getMessage() : "unknown error"));
        logger.error(message);
        throw new RuntimeException(message, lastException);
    }

    @Step("Assert with retry: {1}")
    protected void assertWithRetry(Supplier<Boolean> condition, String description, int maxAttempts) {
        try {
            retry(() -> {
                boolean success = condition.get();
                if (!success)
                    throw new RuntimeException("Condition not met: " + description);
                return success;
            }, maxAttempts);
            logger.info("Assertion passed after retries: {}", description);
        } catch (Exception e) {
            String contextMessage = String.format("Assertion failed after %d attempts: %s", maxAttempts, description);
            logger.error(contextMessage);
            throw new AssertionError(contextMessage, e);
        }
    }

    @Step("Assert element visible: {0} ({1})")
    protected void assertElementVisible(String selector, String description) {
        // Will throw with context if not found/visible
        getElement(selector, true, 3);
    }

    // ---------- Dialog utilities ----------
    @Step("Setup dialog handler: {0}")
    protected BasePage withDialogHandler(DialogAction action) {
        logger.info("Setting up dialog handler: {}", action);
        page.onDialog(dialog -> {
            String message = dialog.message();
            logger.info("Dialog appeared with message: {}", message);

            switch (action) {
                case DISMISS:
                    logger.info("Dismissing dialog");
                    dialog.dismiss();
                    break;
                case ACCEPT:
                    logger.info("Accepting dialog");
                    dialog.accept();
                    break;
                case ACCEPT_WITH_TEXT:
                    // Use withDialogText method to set text before calling this
                    String textToEnter = dialogText != null ? dialogText : "";
                    logger.info("Accepting dialog with text: {}", textToEnter);
                    dialog.accept(textToEnter);
                    break;
                default:
                    logger.info("Using default action: dismiss dialog");
                    dialog.dismiss();
            }
        });
        return this;
    }

    // Store dialog text (for prompts)
    private String dialogText = null;

    @Step("Set dialog text: {0}")
    protected BasePage withDialogText(String text) {
        this.dialogText = text;
        logger.info("Dialog text set to: {}", text);
        return this;
    }

    @Step("Setup dialog handler with text: {0}")
    protected BasePage withDialogHandlerAndText(String text) {
        withDialogText(text);
        return withDialogHandler(DialogAction.ACCEPT_WITH_TEXT);
    }

    @Step("Wait for dialog and get message")
    protected String waitForDialogAndGetMessage(int timeoutMs) {
        final String[] dialogMessage = { null };

        page.onDialog(dialog -> {
            dialogMessage[0] = dialog.message();
            // capture only; do not handle here
        });

        long endTime = System.currentTimeMillis() + timeoutMs;
        while (dialogMessage[0] == null && System.currentTimeMillis() < endTime) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return dialogMessage[0];
    }

    // Actions that can be performed on dialogs
    public enum DialogAction {
        DISMISS, // Cancel/dismiss the dialog
        ACCEPT, // Accept/OK the dialog
        ACCEPT_WITH_TEXT // Accept with text input (for prompts)
    }
}
