package utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * ConfigUtil - loads and provides access to framework.properties file.
 */
public class ConfigUtil {

    private static final Properties properties = new Properties();

    static {
        try (InputStream input = ConfigUtil.class.getClassLoader()
                .getResourceAsStream("framework.properties")) {

            if (input != null) {
                properties.load(input);
            } else {
                throw new RuntimeException("framework.properties not found");
            }

        } catch (IOException ex) {
            throw new RuntimeException("Error loading framework.properties", ex);
        }
    }

    // Get string value
    public static String get(String key) {
        return properties.getProperty(key);
    }

    // Get boolean value
    public static boolean getBoolean(String key) {
        return Boolean.parseBoolean(properties.getProperty(key));
    }

    // Get boolean with default
    public static boolean getBoolean(String key, boolean defaultValue) {
        String value = properties.getProperty(key);
        return (value != null) ? Boolean.parseBoolean(value) : defaultValue;
    }
}
