package utils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * CommonUtil – handy utilities for tests (timestamps, randoms, files, waits).
 */
public class CommonUtil {

    private static final Logger logger = LoggerFactory.getLogger(CommonUtil.class);
    private static final Random random = new Random();
    private static final String ALPHANUMERIC =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    // Prevent instantiation
    private CommonUtil() {}

    /** Generates a timestamp string with the given format (e.g. "yyyy-MM-dd_HH-mm-ss"). */
    public static String timestamp(String format) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.format(new Date());
    }

    /** Generates a random alpha-numeric string of the given length. */
    public static String randomString(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(ALPHANUMERIC.charAt(random.nextInt(ALPHANUMERIC.length())));
        }
        return sb.toString();
    }

    /** Generates a random int in [min, max). */
    public static int randomInt(int min, int max) {
        return random.nextInt(max - min) + min;
    }

    /** Generates a UUID string. */
    public static String uuid() {
        return UUID.randomUUID().toString();
    }

    /** Reads a text file and returns its contents as a String, or null on error. */
    public static String readFileAsString(String filePath) {
        try {
            return new String(Files.readAllBytes(Paths.get(filePath)));
        } catch (Exception e) {
            logger.error("Error reading file: {}", filePath, e);
            return null;
        }
    }

    /**
     * Creates directory (and parents) if it doesn't exist.
     * @return true if directory exists or was created successfully; false otherwise.
     */
    public static boolean createDirectoryIfNotExists(String dirPath) {
        File directory = new File(dirPath);
        if (!directory.exists()) {
            boolean created = directory.mkdirs();
            if (created) {
                logger.info("Created directory: {}", dirPath);
                return true;
            } else {
                logger.error("Failed to create directory: {}", dirPath);
                return false;
            }
        }
        return true;
    }

    /** Sleeps for the given milliseconds (logs if interrupted). */
    public static void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.warn("Sleep interrupted", e);
        }
    }

    /** Returns the file extension without the dot (or empty string if none). */
    public static String getFileExtension(String filePath) {
        int lastDotIndex = filePath.lastIndexOf('.');
        if (lastDotIndex > 0) {
            return filePath.substring(lastDotIndex + 1);
        }
        return "";
    }
}
