# Executive Briefing — Talking Points & Speaker Notes
## Plugin vs Custom Agent for TLM | 30 Minutes

---

## SLIDE 1: Title + Context (3 minutes)

**Opening line:** "Today I want to walk you through our TLM modernization journey — what we started with, what we learned, and where we've landed."

**Key points to make:**
- 4 months ago, we adopted the GitHub Copilot App Modernization extension — a Microsoft-built plugin — to solve our Java TLM upgrade challenge
- It uses OpenRewrite recipes (open-source transformation engine) combined with AI to upgrade Java and Spring Boot projects
- We promoted it heavily, teams started using it, and we got consistent feedback about what worked and what didn't
- Based on that feedback, we built a custom TLM agent using Copilot's native agent architecture — not a separate tool, but an enterprise knowledge layer on top of the same Copilot platform

**Transition:** "Let me show you exactly what the plugin does well and where it falls short."

---

## SLIDE 2: The Plugin — What It Does (7 minutes)

**What it is:**
- Microsoft/GitHub-built VS Code extension, GA since September 2025
- Now also available as `@modernize` agent in Copilot Chat and CLI
- Uses OpenRewrite (open-source recipe engine) for known transformation patterns + AI for everything else
- Currently supports: JDK 8→21→25, Spring Boot up to 3.5, Jakarta EE 10, Spring FW 6.2+

**What it does well (walk through the green checkmarks):**
- When a recipe exists for a migration pattern, it works reliably — these are deterministic transforms, not AI guessing
- Jakarta namespace migration (javax→jakarta) is solid
- The build/fix loop is useful — it tries to compile, catches errors, fixes them
- Generates a good summary report

**Where it falls short (walk through the red X's — this is the critical part):**
- **No Spring Boot 4.x:** The plugin maxes out at 3.5. Many teams need to plan for 4.x. When you ask it to go to 4.x, it either refuses or falls back to generic AI — which hallucinates version numbers and APIs
- **No internal Artifactory:** It only checks Maven Central for dependency versions. In our enterprise, dependencies live in internal Artifactory. The plugin can't reach them, so it either uses outdated versions or asks the user to manually provide them
- **No enterprise library awareness:** It doesn't know about internal libraries (like our internal JWT, crypto, or audit clients). When it upgrades Spring Boot, these internal libs break silently at runtime because they were compiled against the old version
- **Generic AI fallback:** When no recipe exists for a migration step, the plugin falls back to the underlying AI model with no specific guidance. This is where users experienced hallucinated versions, wrong API patterns, and multiple rework iterations

**Read the user feedback quote at the bottom.**

**If asked "Isn't Microsoft improving it?":**
- Yes, they are. In Jan 2026 they added JDK 25 support and are working toward Spring Boot 4.x
- But their roadmap is driven by the general market, not our enterprise-specific needs (internal Artifactory, internal libraries, org EOL timelines)
- We can't wait for them to add internal Artifactory support — that may never come as it's enterprise-specific

---

## SLIDE 3: The Custom Agent — What We Built (7 minutes)

**What it is — critical framing:**
- "This is NOT a separate tool or platform. It's the same GitHub Copilot, same AI models, same VS Code experience."
- "What we've done is given Copilot enterprise-specific knowledge — written as structured skill files — so it makes better decisions for our context."
- "Think of it as: the plugin brings the recipe engine, our agent brings the enterprise knowledge. They're complementary."

**Walk through the 6 additions:**
1. **Internal Artifactory:** The agent queries our internal Maven Artifactory using the developer's existing `~/.m2/settings.xml` credentials — no new config needed. It uses Maven CLI as a bridge, not direct HTTP calls.
2. **Spring Boot 4.x:** We've written skill files that contain the Spring Boot 4.x migration knowledge (modularization, Spring FW 7, Jackson 3, Security 7). No recipe exists for this yet — our skills fill that gap.
3. **Enterprise Libraries:** The agent detects internal libraries, checks what Spring Boot version they were compiled against, and shows a compatibility matrix BEFORE making changes. This prevents the "builds fine but crashes at runtime" problem.
4. **Multi-Module:** Understands Maven reactor build order. Upgrades module by module, compiles between each. Doesn't leave you in a half-migrated state.
5. **Stable Version Filtering:** Reads `maven-metadata.xml` from all configured repos, filters out milestones/RCs/snapshots, picks latest stable GA. Eliminates the "agent picked 4.1.0-M2 which doesn't exist" problem.
6. **Org Standards:** Knows internal EOL timelines, buildpack requirements, internal library replacement mappings — things no external plugin could ever know.

**Key messaging for the bottom bar:**
- "Not a replacement — an extension layer. The plugin handles what it handles well. Our agent handles the enterprise gaps."

---

## SLIDE 4: Architecture — How It Works (7 minutes)

**This is the "how does it actually work" slide for technical leaders.**

**Frame it simply:**
- "When a developer types `@tlm` in Copilot Chat, here's what happens behind the scenes..."
- Walk through the 4 layers, emphasizing the loading behavior:
  - **Layer 1 (Always):** Global instructions — shared coding standards, rules that apply to ALL agents
  - **Layer 2 (On @mention):** The agent persona — when someone types `@tlm`, this file loads with the full TLM workflow, menu system, and decision logic
  - **Layer 3 (When needed):** Skills — the agent decides WHICH skill to load based on the task. If upgrading Spring Boot, it loads `spring-boot-upgrade.md`. If handling internal libs, it loads `internal-library-protection.md`. This is token-efficient — you don't pay for skills you're not using.
  - **Layer 4 (/command):** Prompts — lightweight triggers like `/fix-all-tlm` that route to the right agent + workflow

**What gets sent to the API:**
- "All of this — the instructions, agent file, skill files, your code, and conversation history — gets assembled into a context window and sent to the AI model"
- "The model sees your code AND our enterprise knowledge simultaneously. It's not calling external APIs or tools autonomously."

**Critical clarification (if asked):**
- "This is NOT agentic AI in the autonomous sense. The model doesn't have a planning loop or memory across sessions. It's structured knowledge injection — we're giving the model curated expertise so it makes better decisions within a single conversation."
- "The agent CAN run terminal commands (mvn compile, mvn versions:display-dependency-updates) with user approval. This is how it verifies builds and discovers versions."

**Why not just a big prompt?**
- "If you put 1000 lines of instructions in one prompt file, the model loads ALL of it on every interaction — even for a simple question. That wastes tokens and costs money."
- "With the layered approach, a simple scan loads ~5K tokens. A full Spring Boot migration loads ~15K tokens. The difference matters at scale."

---

## SLIDE 5: Comparison + Forward Path (6 minutes)

**Walk through the comparison table quickly — the visual contrast tells the story.**

Highlight the 3 rows that matter most:
1. **Where no recipe exists:** Plugin = generic AI fallback (hallucinations). Agent = curated enterprise skills (reliable).
2. **Version discovery:** Plugin = Maven Central only. Agent = Internal Artifactory via Maven CLI.
3. **Internal library handling:** Plugin = none. Agent = conflict detection + resolution.

**Forward path — the 4 points:**
1. "The plugin IS getting better. Microsoft is actively developing it. We should continue to track it."
2. "But our enterprise gaps exist TODAY. Teams need to do TLM work THIS quarter. The custom agent fills those gaps now."
3. "They're complementary. Our agent's skill files say 'use App Mod recipes where available.' We're not duplicating — we're extending."
4. "The same architecture pattern — agents + skills — already powers our QA testing and Sonar remediation agents. This is a platform, not a one-off."

**Closing statement:**
"The plugin gives us the recipe engine. Our custom agent gives us the enterprise knowledge. Together, they give developers a complete TLM solution that actually works for our specific environment."

---

## ANTICIPATED QUESTIONS

**Q: "Is this just prompt engineering?"**
A: "At its core, yes — but structured and scalable. Think of it as 'institutional knowledge as code.' The same way we codify coding standards in linters, we're codifying migration knowledge in skill files. Any developer can use it without being a migration expert."

**Q: "What happens when Microsoft adds the features we need?"**
A: "Great — we use them. Our agent already says 'use App Mod recipes where available.' If they add Spring Boot 4.x recipes, our agent will use those recipes. Our enterprise-specific skills (internal Artifactory, internal libraries) will likely never be in the plugin — those are inherently org-specific."

**Q: "How much maintenance does the custom agent need?"**
A: "The skill files need updating when new framework versions come out or when internal library replacement mappings change — roughly quarterly. It's the same kind of maintenance as updating a wiki or runbook, but structured so AI can use it."

**Q: "Can the model hallucinate even with skills?"**
A: "Yes, but significantly less. Without skills, the model invents version numbers. With skills, it follows a structured lookup process (Maven CLI → metadata parsing → stable version filtering). The skill tells it HOW to find the answer, not what the answer is."

**Q: "Why not wait for the plugin to improve?"**
A: "Two reasons. First, our teams have TLM deadlines this quarter — they can't wait. Second, some capabilities (internal Artifactory access, internal library mappings) are inherently enterprise-specific. No generic plugin will ever ship with our internal library replacement tables."

**Q: "Is this scalable? Can other teams create agents?"**
A: "Yes. The architecture is a folder of markdown files. Anyone who can write a technical document can create a skill. We've already built 3 agents (TLM, QA, Developer) with 26+ skills. The pattern is proven."
