package com.fmr.fi.analytics.controller;

import com.fmr.fi.analytics.model.Order;
import com.fmr.fi.analytics.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);
    private final OrderService service = new OrderService(); // simple in-memory

    @PostMapping
    public ResponseEntity<Order> create(@RequestParam String customerName,
                                        @RequestParam BigDecimal amount) {
        logger.info("Creating new order - Customer: {}, Amount: {}", customerName, amount);
        try {
            Order order = service.createOrder(customerName, amount);
            logger.info("Order created successfully - ID: {}, Status: {}", order.getId(), order.getStatus());
            return ResponseEntity.ok(order);
        } catch (IllegalArgumentException e) {
            logger.error("Failed to create order - Invalid input: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("Unexpected error while creating order", e);
            throw e;
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getById(@PathVariable Long id) {
        logger.info("Fetching order by ID: {}", id);
        return service.findById(id)
                .map(order -> {
                    logger.info("Order found - ID: {}, Customer: {}, Status: {}", 
                            order.getId(), order.getCustomerName(), order.getStatus());
                    return ResponseEntity.ok(order);
                })
                .orElseGet(() -> {
                    logger.warn("Order not found - ID: {}", id);
                    return ResponseEntity.notFound().build();
                });
    }

    @GetMapping
    public List<Order> listAll() {
        logger.info("Fetching all orders");
        List<Order> orders = service.listAll();
        logger.info("Retrieved {} orders", orders.size());
        return orders;
    }

    @PostMapping("/{id}/pay")
    public ResponseEntity<Order> pay(@PathVariable Long id) {
        logger.info("Processing payment for order ID: {}", id);
        try {
            Order order = service.markPaid(id);
            logger.info("Payment processed successfully - Order ID: {}, Status: {}", order.getId(), order.getStatus());
            return ResponseEntity.ok(order);
        } catch (Exception e) {
            logger.error("Failed to process payment for order ID: {} - Error: {}", id, e.getMessage());
            throw e;
        }
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<Void> cancel(@PathVariable Long id) {
        logger.info("Cancelling order ID: {}", id);
        try {
            service.cancel(id);
            logger.info("Order cancelled successfully - ID: {}", id);
            return ResponseEntity.noContent().build();
        } catch (IllegalStateException e) {
            logger.error("Cannot cancel order ID: {} - {}", id, e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("Failed to cancel order ID: {} - Error: {}", id, e.getMessage());
            throw e;
        }
    }
}
