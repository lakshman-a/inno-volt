package com.fmr.fi.analytics.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import com.fmr.fi.analytics.model.Order;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);
    private final Map<Long, Order> store = new ConcurrentHashMap<>();

    public Order createOrder(String customerName, BigDecimal amount) {
        logger.debug("Validating order creation request - Customer: {}, Amount: {}", customerName, amount);
        
        if (customerName == null || customerName.trim().isEmpty()) {
            logger.warn("Order creation failed - customerName is required");
            throw new IllegalArgumentException("customerName is required");
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            logger.warn("Order creation failed - amount must be > 0, provided: {}", amount);
            throw new IllegalArgumentException("amount must be > 0");
        }

        long id = store.size() + 1;
        Order order = new Order(id, customerName, amount,
                LocalDateTime.now(), "NEW");
        store.put(id, order);
        logger.info("Order created in store - ID: {}, Customer: {}, Amount: {}", id, customerName, amount);
        return order;
    }

    public Optional<Order> findById(Long id) {
        logger.debug("Searching for order in store - ID: {}", id);
        Optional<Order> order = Optional.ofNullable(store.get(id));
        if (order.isPresent()) {
            logger.debug("Order found in store - ID: {}", id);
        } else {
            logger.debug("Order not found in store - ID: {}", id);
        }
        return order;
    }

    public List<Order> listAll() {
        int count = store.size();
        logger.debug("Retrieving all orders from store - Total count: {}", count);
        return new ArrayList<>(store.values());
    }

    public Order markPaid(Long id) {
        logger.debug("Attempting to mark order as paid - ID: {}", id);
        Order order = store.get(id);
        if (order == null) {
            logger.warn("Cannot mark order as paid - Order not found: {}", id);
            throw new NoSuchElementException("Order not found");
        }
        if ("PAID".equals(order.getStatus())) {
            logger.info("Order already paid - ID: {}", id);
            return order;
        }
        String oldStatus = order.getStatus();
        order.setStatus("PAID");
        logger.info("Order status updated - ID: {}, Previous status: {}, New status: PAID", id, oldStatus);
        return order;
    }

    public void cancel(Long id) {
        logger.debug("Attempting to cancel order - ID: {}", id);
        Order order = store.get(id);
        if (order == null) {
            logger.warn("Cannot cancel order - Order not found: {}", id);
            throw new NoSuchElementException("Order not found");
        }
        if ("PAID".equals(order.getStatus())) {
            logger.warn("Cannot cancel order - Order already paid: {}", id);
            throw new IllegalStateException("Cannot cancel a PAID order");
        }
        String oldStatus = order.getStatus();
        order.setStatus("CANCELLED");
        logger.info("Order cancelled - ID: {}, Previous status: {}", id, oldStatus);
    }
}