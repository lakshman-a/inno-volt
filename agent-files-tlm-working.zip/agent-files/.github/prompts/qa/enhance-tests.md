---
description: Enhance existing test suite — find gaps, add missing tests
mode: agent
agent: qa-automation
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---
Read `.github/agents/qa-automation/qa-automation.agent.md`.
Analyze existing suite → understand patterns → gap analysis → generate ONLY missing tests (no duplicates) → execute → report.
