---
description: Run JaCoCo code coverage analysis
mode: agent
agent: qa-automation
tools: ['codebase', 'editFiles', 'runCommands']
---
Read `.github/skills/qa/qa-jacoco-coverage/SKILL.md`.
Build dev project → configure JaCoCo agent → run test suite → generate coverage report → identify gaps.
