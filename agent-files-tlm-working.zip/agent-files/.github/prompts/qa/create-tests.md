---
description: Create a new API test suite
mode: agent
agent: qa-automation
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---
Read `.github/agents/qa-automation/qa-automation.agent.md` and relevant skill from `.github/skills/qa/`.
Auto-detect framework → scaffold test project at workspace root → generate tests → execute → report.
