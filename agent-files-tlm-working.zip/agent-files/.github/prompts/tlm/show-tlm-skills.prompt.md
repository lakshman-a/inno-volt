---
mode: agent
agent: tlm
description: Show all available TLM skills and capabilities
tools: ['codebase', 'search']
---

Start **option 7 — Show Skills & Capabilities** from `tlm.agent.md`. List all available skills from `.github/skills/tlm/`.
