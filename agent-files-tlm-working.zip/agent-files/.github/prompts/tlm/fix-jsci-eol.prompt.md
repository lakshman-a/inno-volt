---
mode: agent
agent: tlm
description: Migrate all JSCI fmr-commons-* libraries — EOL replacement to dp-* and open-source
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---

Start **JSCI EOL migration**. Read `.github/skills/tlm/enterprise/jsci-eol-retirement.md`. Follow the full workflow in `tlm.agent.md`.
