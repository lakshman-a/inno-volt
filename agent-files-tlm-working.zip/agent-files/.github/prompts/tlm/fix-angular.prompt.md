---
mode: agent
agent: tlm
description: Upgrade Angular to target version — step-by-step, one major version at a time
tools: ['codebase', 'editFiles', 'runCommands', 'search']
model: ['Claude Opus 4.5']
---

Start **option 2 — Angular TLM Fixes**. Read `.github/skills/tlm/angular/SKILL.md`. Follow the full workflow in `tlm.agent.md`.
