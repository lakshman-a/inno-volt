---
mode: agent
agent: tlm
description: Fix all TLM items — libraries, frameworks, CVEs, enterprise packages — end to end
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---

Start **option 1 — Fix All TLM Items**. Follow the full workflow in `tlm.agent.md`. Scan, dashboard, plan, approve, execute, validate, report.
