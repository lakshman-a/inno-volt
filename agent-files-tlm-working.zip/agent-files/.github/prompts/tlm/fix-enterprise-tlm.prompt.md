---
mode: agent
agent: tlm
description: Fix enterprise/internal library EOL items — JSCI, AMT FSF, FMR packages
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---

Start **option 5 — Enterprise / Internal Library Upgrades**. Read skills from `.github/skills/tlm/enterprise/`. Follow the full workflow in `tlm.agent.md`.
