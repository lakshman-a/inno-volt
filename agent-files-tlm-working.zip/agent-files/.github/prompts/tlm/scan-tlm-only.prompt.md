---
mode: agent
agent: tlm
description: Scan project and show health dashboard — no changes, report only
tools: ['codebase', 'search']
---

Run **scan only** from `tlm.agent.md`. Show the project health dashboard with all findings. Do NOT make any changes. Report and stop.
