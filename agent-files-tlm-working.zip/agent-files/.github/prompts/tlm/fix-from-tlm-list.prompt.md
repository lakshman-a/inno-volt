---
mode: agent
agent: tlm
description: Fix items from SW EOL list — paste your TLM list or provide a CSV file
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---

Start **option 6 — Fix from TLM List**. Follow the full workflow in `tlm.agent.md`. Match list items against project dependencies, fix matched items only.
