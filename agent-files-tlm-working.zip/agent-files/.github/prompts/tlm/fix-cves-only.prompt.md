---
mode: agent
agent: tlm
description: Fix CVE and security vulnerabilities only — targeted, minimal-risk changes
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---

Start **option 3 — CVE & Vulnerability Fixes**. Follow the full workflow in `tlm.agent.md`. Only fix security vulnerabilities, no major upgrades.
