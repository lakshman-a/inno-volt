---
description: Create a new Spring Boot 3.x enterprise project
mode: agent
agent: sr-developer
tools: ['codebase', 'editFiles', 'runCommands']
---
Read `.github/skills/dev/scaffolding/SKILL.md`.
Scaffold Java Spring Boot 3.x with security, actuator, OpenAPI, JaCoCo, Docker, Jenkinsfile, README.
Build and verify: `mvn clean package`.
