---
description: Plan and implement a new feature from requirements
mode: agent
agent: sr-developer
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---
Read `.github/agents/sr-developer/sr-developer.agent.md` and `.github/skills/dev/design/SKILL.md`.
Execute Workflow [3]: Create New Feature.
Gather requirements → design doc (API, data model, sequence diagram) → WAIT FOR APPROVAL → implement → test → report.
