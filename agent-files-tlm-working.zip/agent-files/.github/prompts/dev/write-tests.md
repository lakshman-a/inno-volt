---
description: Generate unit tests to reach 90%+ coverage
mode: agent
agent: sr-developer
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---
Read `.github/agents/sr-developer/sr-developer.agent.md` and `.github/skills/dev/testing/SKILL.md`.
Execute Workflow [2]: Write Unit Tests.
Detect framework → inject JaCoCo → baseline coverage → identify gaps → generate tests → compile → run → 90%+ target → report delta.
