---
description: Create a new Angular 17+ enterprise project
mode: agent
agent: sr-developer
tools: ['codebase', 'editFiles', 'runCommands']
---
Read `.github/skills/dev/scaffolding/SKILL.md`.
Scaffold Angular 17+ with standalone components, lazy routing, auth, interceptors, Jest, Docker.
Build and verify: `npm run build`.
