---
description: Analyze and refactor code for better quality
mode: agent
agent: sr-developer
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---
Read `.github/skills/dev/refactoring/SKILL.md`.
Analyze complexity/SOLID → plan with before/after → WAIT FOR APPROVAL → refactor → compile → ALL tests pass → report.
