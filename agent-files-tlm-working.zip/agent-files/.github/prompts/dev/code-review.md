---
description: Review code for security, performance, and standards
mode: agent
agent: sr-developer
tools: ['codebase', 'search']
---
Read `.github/skills/dev/refactoring/SKILL.md`.
Review: security, performance, error handling, SOLID, naming, coverage → categorize Critical/Important/Suggestions → score.
