---
description: Scan and fix all Sonar issues in this project
mode: agent
agent: sr-developer
tools: ['codebase', 'editFiles', 'runCommands', 'search']
---
Read `.github/agents/sr-developer/sr-developer.agent.md` and `.github/skills/dev/sonar/SKILL.md`.
Execute Workflow [1]: Fix Sonar Issues.
Check `.github/config/sonar-config.json` → fetch from API or local scan → categorize → plan → approve → fix → compile → test → report.
