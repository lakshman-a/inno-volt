---
name: enterprise-standards
description: Naming, logging, error handling, config conventions for all agents.
---

# Enterprise Standards

## Naming
- **Java:** PascalCase classes, camelCase methods, UPPER_SNAKE constants, lowercase packages
- **Angular:** kebab-case files, PascalCase classes, no `I` prefix on interfaces
- **Python:** snake_case modules/functions, PascalCase classes

## Logging (Java — SLF4J)
```java
private static final Logger logger = LoggerFactory.getLogger(ClassName.class);
logger.error("Payment failed for order {}: {}", orderId, e.getMessage(), e);
logger.info("Order {} created", orderId);
```
NEVER System.out. NEVER printStackTrace. Use `{}` placeholders. Include context IDs.

## Error Handling
- Catch specific exceptions, never generic `Exception`
- @ControllerAdvice + GlobalExceptionHandler
- Always include context in error messages
- Log at boundary (service layer), not everywhere

## Configuration
- application.yml primary, profile-based (application-{env}.yml)
- No hardcoded values — @Value or @ConfigurationProperties
- Secrets via env vars or vault, NEVER in code

## API Design
- REST: `/api/v1/{resource}`, pagination `?page=0&size=20`
- Error: `{"code":"ERROR_CODE","message":"Human-readable"}`
- Always @Valid on request bodies, proper HTTP status codes
