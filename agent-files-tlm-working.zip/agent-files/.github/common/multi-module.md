---
name: multi-module
description: Multi-module project handling across all agents.
---

# Multi-Module Project Handling

## Detection
- Maven: `grep "<modules>" pom.xml` → parse `<module>` elements
- Gradle: `grep "include" settings.gradle`
- npm: `grep "workspaces" package.json`

## Rules (All Agents)
1. Map parent + all submodules + dependency order
2. Process parent/shared modules first
3. Build and verify each module before next
4. Report per-module status

## Display
```
📁 Multi-Module:
  parent-pom (reactor)
  ├── common-lib (no deps)
  ├── data-access (→ common-lib)
  ├── service-api (→ common-lib, data-access)
  └── web-app (→ service-api)
Order: parent → common → data → service → web
```

## Agent-Specific
- **Sr Dev (Sonar):** Group issues by module, fix in dependency order
- **Sr Dev (Tests):** JaCoCo classfiles must point to ALL module target/classes dirs
- **QA:** Identify bootable module, group tests by functionality not module
- **TLM:** Update parent BOM first, upgrade in dependency order
