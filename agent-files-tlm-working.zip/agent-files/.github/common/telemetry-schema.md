---
name: unified-telemetry
description: Shared telemetry schema for all DevAssist agents.
---

# Unified Telemetry Schema

## File Locations
- Sr Developer: `.github/dev-agent-telemetry.json`
- QA Automation: `.github/qa-agent-telemetry.json`
- TLM: `tlm-config/tlm-telemetry-[YYYY-MM-DD-HHmmss].json`

## Rules
- Create if doesn't exist. Append to `sessions`. NEVER ask permission. NEVER block workflow.

## Schema
```json
{
  "$schema": "devassist-telemetry-v1",
  "agent": { "name": "sr-developer|qa-automation|tlm", "version": "1.0.0" },
  "timestamp": "ISO 8601",
  "project": { "name": "", "language": "java|angular|python", "buildSystem": "maven|npm|pip", "runtimeVersion": "" },
  "sessions": [{
    "timestamp": "ISO 8601",
    "action": "sonar_fix|unit_test|feature|scaffold|refactor|review|test_gen|jacoco|tlm_upgrade|cve_fix",
    "model": "Claude Sonnet 4.5|Claude Opus 4.5",
    "summary": "Human-readable summary",
    "metrics": {
      "itemsFound": 0, "itemsFixed": 0, "itemsSkipped": 0, "itemsFailed": 0,
      "filesChanged": 0, "testsGenerated": 0, "testsPassed": 0, "testsFailed": 0,
      "coverageBefore": null, "coverageAfter": null, "buildPassed": true, "buildAttempts": 1
    },
    "effort": { "estimatedManualHours": 0, "actualAgentMinutes": 0, "efficiencyMultiplier": "0x" }
  }],
  "cumulative": { "totalSessions": 0, "totalItemsProcessed": 0, "totalFilesChanged": 0, "totalTestsGenerated": 0, "totalManualHoursSaved": 0, "lastUpdated": "ISO 8601" }
}
```

## Effort Estimates
| Task | Manual Time |
|---|---|
| Single Sonar smell fix | 15 min |
| Vulnerability fix | 30 min |
| Complexity reduction | 1-2 hrs |
| Unit tests for one class | 1-2 hrs |
| New feature (design+impl) | 8-16 hrs |
| Project scaffold | 4-8 hrs |
| Major framework migration | 8-16 hrs |
| Full project TLM (20+ items) | 16-40 hrs |
