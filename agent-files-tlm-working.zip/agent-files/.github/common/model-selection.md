---
name: model-selection
description: When to use Opus vs Sonnet across all agents.
---

# Model Selection Guide

| Task | Model | Reason |
|---|---|---|
| Simple Sonar fixes, naming, unused fields | 🤖 Sonnet | Pattern-based |
| Vulnerability fixes (SQL injection, creds) | 🤖 Sonnet | Well-known |
| Cognitive complexity reduction | 🧠 Opus | Restructuring |
| Large class splitting | 🧠 Opus | Architecture |
| Unit test generation (standard) | 🤖 Sonnet | Template |
| Tests for complex logic | 🧠 Opus | Edge cases |
| Feature design / architecture | 🧠 Opus | Judgment |
| Feature implementation | 🤖 Sonnet | Following design |
| Code review | 🧠 Opus | Deep analysis |
| Build error fixing | 🤖 Sonnet | Pattern-based |
| Spring Boot 2→3 / Angular major | 🧠 Opus | Complex |
| After 2 Sonnet failures | 🧠 Opus | Escalation |

**Rule: When in doubt, use Opus. Developer time > model cost.**
