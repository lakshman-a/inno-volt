# Skill: Python Library & Framework Upgrades

## Skill Metadata

```yaml
name: python-upgrades
language: python
category: framework
type: agent
priority: varies
source_library: multiple
from_version: varies
to_version: latest stable
app_mod_recipe: false
estimated_complexity: simple to moderate
```

---

## Python Runtime Upgrade

### Python 3.8/3.9 → 3.11/3.12

**Steps:**
1. Update `python_requires` in `setup.py`/`pyproject.toml`
2. Update CI/CD pipeline Python version
3. Update Dockerfile base image
4. Check for deprecated stdlib modules

**Removed in 3.12:**
- `distutils` → use `setuptools` instead
- `imp` → use `importlib` instead
- `aifc`, `audioop`, `cgi`, `cgitb`, `chunk`, `crypt`, `imghdr`, `mailcap`, `msilib`, `nis`, `nntplib`, `ossaudiodev`, `pipes`, `sndhdr`, `spwd`, `sunau`, `telnetlib`, `uu`, `xdrlib`

---

## Django Upgrades

### Django 4.x → 5.x

**Key changes:**
- Python 3.10+ required
- `DEFAULT_AUTO_FIELD` must be set explicitly
- `django.conf.urls.url()` removed → use `django.urls.re_path()` or `path()`
- `CSRF_TRUSTED_ORIGINS` must include scheme (`https://`)

```python
# settings.py
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
CSRF_TRUSTED_ORIGINS = ['https://example.com']  # scheme required in 4.x+
```

### Django 3.x → 4.x

**Key changes:**
- `django.conf.urls.url()` deprecated → `django.urls.re_path()`
- `USE_L10N` default changed to `True`
- `SecurityMiddleware` handles HSTS by default

---

## Flask Upgrades

### Flask 2.x → 3.x

**Key changes:**
- Python 3.8+ required
- `flask.json.jsonify` → just return dicts directly
- Async views now stable
- Blueprint nesting improvements

---

## Common Python Libraries

### requests
Usually safe version bumps. Check for deprecated `requests.packages.urllib3` imports.

### SQLAlchemy 1.x → 2.x
**Major migration:**
- Query API changed significantly
- `session.query(Model)` → `select(Model)` with `session.execute()`
- Use the SQLAlchemy 2.0 migration guide

### Pydantic v1 → v2
**Major migration:**
- `BaseModel.dict()` → `BaseModel.model_dump()`
- `BaseModel.json()` → `BaseModel.model_dump_json()`
- `@validator` → `@field_validator`
- `BaseModel.parse_obj()` → `BaseModel.model_validate()`
- Config class → `model_config = ConfigDict(...)`

### pytest
Usually safe version bumps. Watch for deprecated fixture patterns.

---

## Scan Commands

```bash
# List outdated packages
pip list --outdated --format=json

# Security audit
pip-audit --format=json

# Or using safety
safety check --json

# Check compatibility
pip check
```

---

## Build Verification

```bash
# Syntax check
python -m py_compile main.py

# Run tests
python -m pytest

# Type checking (if configured)
mypy src/
```

---

## Reference Documentation

- Python Release Notes: https://docs.python.org/3/whatsnew/
- Django Release Notes: https://docs.djangoproject.com/en/stable/releases/
- Flask Changelog: https://flask.palletsprojects.com/en/latest/changes/
