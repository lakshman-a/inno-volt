# Skill: Java Library Upgrades

## Skill Metadata

```yaml
name: java-library-upgrades
language: java
category: library
type: agent
priority: varies
app_mod_recipe: false
estimated_complexity: simple to complex
last_updated: 2026-02-26
```

---

## How This Skill Works

This skill is NOT hardcoded to specific versions. The agent:
1. Scans project dependencies (`mvn versions:display-dependency-updates` or `gradle dependencyUpdates`)
2. Identifies outdated libraries and their latest stable versions
3. Shows impact analysis — what files, methods, APIs change per library
4. Groups by risk: safe version bumps vs breaking changes
5. Executes upgrades from safest to riskiest

**Rule: Always get latest stable from Maven Central.** Never hardcode a version in this skill — search or run version check.

---

## CRITICAL: Internal Library Protection

**When upgrading any public library, check if internal libraries depend on it.**

Example: You upgrade `jackson-databind` from 2.14 to 2.17. But `dp-commons-jwt` was tested with 2.14 and uses a Jackson API that changed in 2.17. Result: `NoSuchMethodError` at runtime.

**Agent MUST:** For each library being upgraded, run `mvn dependency:tree -Dverbose` and check if any internal library pulls in the old version. If yes → add exclusion and verify internal lib still works. See `.github/skills/tlm/enterprise/internal-library-protection.md`.

---

## Step 0: Scan and Categorize

```bash
# Maven — show all outdated dependencies
mvn versions:display-dependency-updates -q 2>/dev/null

# Gradle
gradle dependencyUpdates 2>/dev/null

# Check for CVEs
mvn org.owasp:dependency-check-maven:check 2>/dev/null || echo "OWASP plugin not configured"
```

**Categorize every library into risk groups:**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 JAVA LIBRARY UPGRADES — RISK ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🟢 SAFE (patch/minor — version bump only, no code changes):
  jackson-databind 2.15.2 → 2.17.0 (managed by Spring Boot BOM)
  guava 32.1.2-jre → 33.4.0-jre
  commons-io 2.11.0 → 2.18.0
  slf4j-api 2.0.7 → 2.0.16

🟡 MODERATE (minor API changes, may need small code fixes):
  lombok 1.18.28 → 1.18.36 (check annotation processor)
  mapstruct 1.5.3 → 1.6.3 (new features, backward compatible)
  flyway 8.5.x → 10.x (config property changes)
  commons-lang3 3.12 → 3.17

🔴 BREAKING (major version — significant code changes):
  log4j 1.x → SLF4J + Logback (complete rewrite)
  JUnit 4 → JUnit 5 (import changes, annotation changes)
  Hibernate 5 → 6 (javax→jakarta, API changes)
  commons-lang 2.x → 3.x (package name change)
  commons-collections 3.x → 4.x (package name change)
  springfox 2.x → springdoc 2.x (complete replacement)
  Swagger 2 → OpenAPI 3 (annotation changes)

🛡️ CVE FIXES (security — prioritize):
  log4j-core 2.17.0 → 2.24.3 (known CVEs)
  jackson-databind < 2.15 → 2.17+ (deserialization CVEs)
  snakeyaml < 2.0 → 2.3+ (code execution CVE)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Library-Specific Upgrade Guides

### Jackson (JSON Processing)

**Impact analysis:**
```bash
# Find all Jackson usage
grep -rn "ObjectMapper\|@JsonProperty\|@JsonIgnore\|@JsonSerialize\|@JsonDeserialize\|@JsonCreator\|@JsonFormat\|@JsonInclude" src/ --include="*.java" | wc -l
# Find version
grep -n "jackson" pom.xml build.gradle 2>/dev/null
```

**Minor upgrade (2.14→2.17):** Usually safe — version bump only.
- If Spring Boot managed: version updates automatically with Boot version
- Check: `JavaTimeModule` registered for date handling
- Check: Custom serializers/deserializers for breaking changes in edge cases

**Breaking: Jackson 2.x → 3.x (Spring Boot 4):**
| Change | Impact | Find with |
|---|---|---|
| Package rename | `com.fasterxml.jackson` → `tools.jackson` | `grep -rn "com.fasterxml.jackson"` |
| Default typing changes | Security implications | `grep "enableDefaultTyping\|activateDefaultTyping"` |
| Streaming API changes | `JsonParser`/`JsonGenerator` updates | `grep "JsonParser\|JsonGenerator"` |

---

### Hibernate (JPA)

**Impact analysis:**
```bash
# Find Hibernate-specific usage
grep -rn "createQuery\|@Type\|@TypeDef\|hibernate\.\|SessionFactory\|org\.hibernate\." src/ --include="*.java" --include="*.properties" --include="*.yml" | wc -l
# List affected files
grep -rl "org\.hibernate\.\|createQuery\|@Type(" src/ --include="*.java" | sort
```

**Hibernate 5 → 6 (comes with Spring Boot 3):**
| Old (H5) | New (H6) | Files Affected | Find with |
|---|---|---|---|
| `javax.persistence.*` | `jakarta.persistence.*` | All entity classes | `grep "import javax.persistence"` |
| `Session.createQuery(hql)` | `Session.createQuery(hql, Type.class)` — type required | Repository/DAO classes | `grep "createQuery("` |
| `@Type(type="...")` | `@Type(SomeType.class)` | Entity classes with custom types | `grep "@Type("` |
| `@TypeDef` | Remove — use `@Type` directly | Entity classes | `grep "@TypeDef"` |
| `hibernate.dialect` | Auto-detected in H6 — can remove | properties/yml files | `grep "hibernate.dialect"` |
| `hibernate.id.new_generator_mappings` | Removed (always true in H6) | properties/yml | `grep "new_generator_mappings"` |

---

### Log4j / Logging

**Impact analysis:**
```bash
# Check which logging framework
grep -rn "log4j\|logback\|slf4j\|java\.util\.logging" pom.xml build.gradle 2>/dev/null
# Find usage
grep -rn "Logger\|LoggerFactory\|getLogger\|log\.info\|log\.debug\|log\.error" src/ --include="*.java" | head -10
```

**Log4j 2.x patch upgrade (e.g., 2.17→2.24):** Safe version bump.

**Log4j 1.x → SLF4J + Logback (COMPLEX — USE OPUS):**
| Change | Every file with logging | Find with |
|---|---|---|
| `org.apache.log4j.Logger` | `org.slf4j.Logger` + `org.slf4j.LoggerFactory` | `grep "org.apache.log4j"` |
| `Logger.getLogger(X.class)` | `LoggerFactory.getLogger(X.class)` | `grep "getLogger("` |
| `log.fatal(msg)` | `log.error(msg)` (SLF4J has no FATAL) | `grep "\.fatal("` |
| `log4j.properties` / `log4j.xml` | `logback.xml` | config files |
| `log4j-core` dependency | `logback-classic` + `slf4j-api` | `pom.xml` |

---

### JUnit 4 → JUnit 5

**Impact analysis:**
```bash
# Count JUnit 4 usage
grep -rl "org\.junit\.Test\|org\.junit\.Before\|org\.junit\.After\|org\.junit\.Assert\|@RunWith" src/test/ --include="*.java" | wc -l
# List all test files using JUnit 4
grep -rl "import org\.junit\.\(Test\|Before\|After\|Assert\|Ignore\|Rule\|RunWith\)" src/test/ --include="*.java" | sort
```

**Import and annotation changes:**
| JUnit 4 | JUnit 5 | Find with |
|---|---|---|
| `org.junit.Test` | `org.junit.jupiter.api.Test` | `grep "import org.junit.Test"` |
| `org.junit.Before` | `org.junit.jupiter.api.BeforeEach` | `grep "import org.junit.Before;"` |
| `org.junit.After` | `org.junit.jupiter.api.AfterEach` | `grep "import org.junit.After;"` |
| `org.junit.BeforeClass` | `org.junit.jupiter.api.BeforeAll` | `grep "BeforeClass"` |
| `org.junit.AfterClass` | `org.junit.jupiter.api.AfterAll` | `grep "AfterClass"` |
| `org.junit.Ignore` | `org.junit.jupiter.api.Disabled` | `grep "@Ignore"` |
| `org.junit.Assert.*` | `org.junit.jupiter.api.Assertions.*` | `grep "org.junit.Assert"` |
| `assertEquals(msg, exp, act)` | `assertEquals(exp, act, msg)` — arg order! | `grep "assertEquals("` |
| `@RunWith(SpringRunner.class)` | `@ExtendWith(SpringExtension.class)` or just `@SpringBootTest` | `grep "@RunWith"` |
| `@Rule ExpectedException` | `assertThrows(Ex.class, () -> ...)` | `grep "ExpectedException\|@Rule"` |
| `@Rule TemporaryFolder` | `@TempDir Path tempDir` | `grep "TemporaryFolder"` |

---

### Apache Commons (Lang, Collections, IO)

**Commons Lang 2.x → 3.x:**
```bash
# Find files affected
grep -rl "org\.apache\.commons\.lang\." src/ --include="*.java" | sort
# NOT lang3 — those are already on 3.x
```
| Change | Find with |
|---|---|
| `org.apache.commons.lang.StringUtils` → `org.apache.commons.lang3.StringUtils` | `grep "commons.lang.StringUtils"` |
| `commons-lang:commons-lang` → `org.apache.commons:commons-lang3` | pom.xml |

**Commons Collections 3.x → 4.x:**
| Change | Find with |
|---|---|
| `org.apache.commons.collections.` → `org.apache.commons.collections4.` | `grep "commons.collections\."` |
| `commons-collections:commons-collections` → `org.apache.commons:commons-collections4` | pom.xml |

---

### Lombok

**Impact analysis:**
```bash
grep -rn "@Data\|@Getter\|@Setter\|@Builder\|@AllArgsConstructor\|@Slf4j\|@Log4j2" src/ --include="*.java" | wc -l
grep -n "lombok.version\|lombok" pom.xml build.gradle 2>/dev/null
```

**Version compatibility:**
| Java Version | Min Lombok |
|---|---|
| Java 17 | 1.18.24+ |
| Java 21 | 1.18.30+ |
| Java 25 | 1.18.34+ |

Usually safe version bump. Check annotation processor config in `maven-compiler-plugin`.

---

### Flyway

**Impact analysis:**
```bash
grep -rn "flyway\|@FlywayTest\|V[0-9]__\|R__" src/ pom.xml build.gradle --include="*.java" --include="*.xml" --include="*.gradle" --include="*.sql" 2>/dev/null | head -20
```

**Flyway 8→9:** Minor changes.
**Flyway 9→10 (BREAKING):**
| Change | Impact |
|---|---|
| Java 17 minimum | Must be on Java 17+ |
| Community DB support reduced | MySQL, MariaDB, PostgreSQL remain free; some moved to paid Teams edition |
| `flyway.url` | Property changes if using Spring Boot |

---

### Springfox → SpringDoc (Swagger/OpenAPI)

**Impact analysis:**
```bash
# Check if using springfox
grep -rn "springfox\|@Api\|@ApiOperation\|@ApiParam\|@ApiResponse\|@ApiModel" src/ --include="*.java" pom.xml | head -20
```

**This is a FULL REPLACEMENT (use Opus):**
| Springfox (Old) | SpringDoc (New) |
|---|---|
| `io.springfox:springfox-boot-starter` | `org.springdoc:springdoc-openapi-starter-webmvc-ui` |
| `@Api(tags = "Users")` | `@Tag(name = "Users")` |
| `@ApiOperation(value = "Get user")` | `@Operation(summary = "Get user")` |
| `@ApiParam(value = "User ID")` | `@Parameter(description = "User ID")` |
| `@ApiResponse(code = 200)` | `@ApiResponse(responseCode = "200")` |
| `@ApiModel` | `@Schema` |
| `@ApiModelProperty` | `@Schema(description = "...")` |
| Docket bean config | GroupedOpenApi or OpenAPI bean |
| `/swagger-ui.html` | `/swagger-ui/index.html` (or `/swagger-ui.html` redirect) |

---

### MapStruct

**Impact analysis:**
```bash
grep -rn "@Mapper\|@Mapping\|@MapperConfig" src/ --include="*.java" | wc -l
```

Usually safe upgrade. Ensure annotation processor version matches in `maven-compiler-plugin`:
```xml
<annotationProcessorPaths>
    <path>
        <groupId>org.mapstruct</groupId>
        <artifactId>mapstruct-processor</artifactId>
        <version>SAME_AS_MAPSTRUCT_VERSION</version>
    </path>
</annotationProcessorPaths>
```

---

### Guava

**Impact analysis:**
```bash
grep -rn "com\.google\.common\.\|com\.google\.guava" src/ --include="*.java" | head -10
```

Usually safe version bump. Watch for:
- `com.google.common.base.Optional` → prefer `java.util.Optional`
- Deprecated `Futures.transform()` overloads
- `ImmutableList.copyOf()` behavior with null elements

---

## Execution Strategy

1. **CVE fixes first** — safest, highest impact
2. **Safe version bumps** — patch/minor, compile and test after each
3. **Moderate changes** — one library at a time, build between each
4. **Breaking changes** — plan each one, get approval, use Opus for complex ones
5. **Build and test after EVERY library** — never batch breaking changes

---

## Common Patterns

**Spring Boot BOM managed dependencies:**
If a library is managed by Spring Boot's BOM (jackson, hibernate, etc.), upgrading Spring Boot automatically upgrades them. Check with:
```bash
mvn dependency:tree | grep "jackson\|hibernate\|slf4j\|snakeyaml"
```

**Version properties in parent POM:**
Many projects define versions as properties. Find them:
```bash
grep -n "\.version>" pom.xml | head -20
```
Update the property, not individual dependencies.

---

## Build Verification

```bash
mvn clean compile -q   # Compile check
mvn test -q             # Test check
mvn dependency:tree     # Verify no conflicts
mvn dependency:analyze  # Find unused/undeclared deps
```
