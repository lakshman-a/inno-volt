# Skill: Jakarta EE Migration (javax → jakarta)

## Skill Metadata

```yaml
name: jakarta-migration
language: java
category: framework
type: recipe
priority: critical
source_library: javax.*
from_version: javax namespace
to_version: jakarta namespace
app_mod_recipe: true
estimated_complexity: moderate
```

---

## Prerequisites

- [ ] Spring Boot 3 or Jakarta EE 9+ upgrade is planned/in progress
- [ ] This is usually part of Spring Boot 3 upgrade — can be done standalone too

---

## App Mod Recipe

**Recipe available.** Try: `@workspace /appmod Apply Jakarta EE namespace migration`

---

## Upgrade Steps

### Step 1: Complete Namespace Mapping

Apply these replacements across ALL Java source files AND test files:

| javax Package | jakarta Package | Notes |
|---|---|---|
| `javax.persistence` | `jakarta.persistence` | JPA entities, repositories |
| `javax.persistence.criteria` | `jakarta.persistence.criteria` | Criteria API |
| `javax.servlet` | `jakarta.servlet` | Servlet API, filters |
| `javax.servlet.http` | `jakarta.servlet.http` | HttpServletRequest/Response |
| `javax.validation` | `jakarta.validation` | Bean validation (@Valid, @NotNull) |
| `javax.validation.constraints` | `jakarta.validation.constraints` | Constraint annotations |
| `javax.annotation` | `jakarta.annotation` | @PostConstruct, @PreDestroy, @Resource |
| `javax.transaction` | `jakarta.transaction` | @Transactional (JTA) |
| `javax.inject` | `jakarta.inject` | @Inject, @Named |
| `javax.websocket` | `jakarta.websocket` | WebSocket API |
| `javax.mail` | `jakarta.mail` | JavaMail API |
| `javax.activation` | `jakarta.activation` | Activation framework |
| `javax.xml.bind` | `jakarta.xml.bind` | JAXB |
| `javax.ws.rs` | `jakarta.ws.rs` | JAX-RS (if used) |
| `javax.enterprise` | `jakarta.enterprise` | CDI |
| `javax.faces` | `jakarta.faces` | JSF (if used) |

### DO NOT CHANGE THESE (core Java, NOT Jakarta):

| Package | Reason |
|---|---|
| `javax.crypto.*` | Part of JDK — not Jakarta |
| `javax.net.*` | Part of JDK — not Jakarta |
| `javax.net.ssl.*` | Part of JDK — not Jakarta |
| `javax.security.auth.*` | Part of JDK — not Jakarta |
| `javax.security.cert.*` | Part of JDK — not Jakarta |
| `javax.sql.*` | Part of JDK — not Jakarta |
| `javax.naming.*` | Part of JDK — not Jakarta |
| `javax.management.*` | Part of JDK — not Jakarta |
| `javax.swing.*` | Part of JDK — not Jakarta |
| `javax.imageio.*` | Part of JDK — not Jakarta |

### Step 2: Find All Affected Files

```bash
# Find all files with javax imports that need changing
grep -rl "import javax\.\(persistence\|servlet\|validation\|annotation\|transaction\|inject\|websocket\|mail\|activation\|xml\.bind\|ws\.rs\|enterprise\|faces\)" src/ --include="*.java"
```

### Step 3: Update Maven Dependencies

```xml
BEFORE:
<dependency>
    <groupId>javax.persistence</groupId>
    <artifactId>javax.persistence-api</artifactId>
    <version>2.2</version>
</dependency>

AFTER:
<dependency>
    <groupId>jakarta.persistence</groupId>
    <artifactId>jakarta.persistence-api</artifactId>
    <version>3.1.0</version>
</dependency>
```

**Common dependency mappings:**

| Old Dependency | New Dependency |
|---|---|
| `javax.persistence:javax.persistence-api` | `jakarta.persistence:jakarta.persistence-api:3.1.0` |
| `javax.servlet:javax.servlet-api` | `jakarta.servlet:jakarta.servlet-api:6.0.0` |
| `javax.validation:validation-api` | `jakarta.validation:jakarta.validation-api:3.0.2` |
| `javax.annotation:javax.annotation-api` | `jakarta.annotation:jakarta.annotation-api:2.1.1` |
| `javax.inject:javax.inject` | `jakarta.inject:jakarta.inject-api:2.0.1` |

### Step 4: Update persistence.xml (if exists)

```xml
BEFORE:
<persistence xmlns="http://xmlns.jcp.org/xml/ns/persistence"
             xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
             xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/persistence
             http://xmlns.jcp.org/xml/ns/persistence/persistence_2_2.xsd"
             version="2.2">

AFTER:
<persistence xmlns="https://jakarta.ee/xml/ns/persistence"
             xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
             xsi:schemaLocation="https://jakarta.ee/xml/ns/persistence
             https://jakarta.ee/xml/ns/persistence/persistence_3_0.xsd"
             version="3.0">
```

### Step 5: Update web.xml (if exists)

```xml
BEFORE:
<web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee" version="4.0">

AFTER:
<web-app xmlns="https://jakarta.ee/xml/ns/jakartaee" version="6.0">
```

---

## Common Errors & Fixes

| Error Message | Cause | Fix |
|---|---|---|
| `package javax.persistence does not exist` | Import not updated | Change to `jakarta.persistence` |
| `cannot find symbol @javax.validation.Valid` | Import not updated | Change to `jakarta.validation.Valid` |
| `javax.servlet.Filter cannot be resolved` | Import not updated | Change to `jakarta.servlet.Filter` |
| Duplicate class errors | Both javax and jakarta on classpath | Remove old javax dependency |

---

## Build Verification

```bash
# Verify no javax references remain (except core Java ones)
grep -rn "import javax\.\(persistence\|servlet\|validation\|annotation\|transaction\)" src/main/java/
# Should return 0 results

mvn clean compile -q
```

---

## Reference Documentation

- Jakarta EE 9→10 Release Notes: https://jakarta.ee/release/10/
- Spring Boot Jakarta Migration: https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-3.0-Migration-Guide#jakarta-ee
