# Skill: Java Runtime Upgrade

## Skill Metadata

```yaml
name: java-runtime-upgrade
language: java
category: runtime
type: recipe + agent
priority: critical
app_mod_recipe: true (for Java 17 upgrade)
estimated_complexity: moderate to complex
last_updated: 2026-02-26
```

---

## How This Skill Works

This skill is NOT hardcoded to one target version. The agent:
1. Detects current Java version from pom.xml / build.gradle
2. Asks user for target version (or recommends based on framework needs)
3. Looks up the correct upgrade path below
4. Shows impacted files and methods BEFORE making changes
5. Executes step by step

---

## Java LTS Versions (Current as of Feb 2026)

| Version | LTS? | Status | EOL (Oracle Premier) |
|---------|------|--------|----------------------|
| Java 8  | LTS  | Extended Support | Dec 2030 |
| Java 11 | LTS  | Extended Support | Sep 2027 |
| Java 17 | LTS  | Active Support | Sep 2026 |
| Java 21 | LTS  | Active Support | Sep 2028 |
| Java 25 | LTS  | Current (Sep 2025) | Sep 2030 |

**Recommendation:** Always target the latest LTS. Currently Java 25.
**Minimum for Spring Boot 3:** Java 17
**Minimum for Spring Boot 4:** Java 17 (Java 25 recommended)

---

## CRITICAL: Internal Library Protection

**Before ANY Java runtime upgrade, read and follow `.github/skills/tlm/enterprise/internal-library-protection.md`.**

Internal/enterprise libraries compiled against the OLD Java version WILL break if:
- They use `sun.misc.*` APIs removed in Java 17
- They use JAXB/JAX-WS removed from JDK in Java 11
- Their class file version doesn't match (e.g., lib compiled for Java 8 may work on 17, but if it uses reflection on JDK internals, it will fail)
- They bundle old versions of common libraries that conflict

**Agent MUST:** Inventory internal libs → check compiled Java version → build compatibility matrix → resolve conflicts BEFORE changing java.version.

---

## Step 0: Impact Analysis (ALWAYS DO FIRST)

**Before any changes, show the developer what will be affected:**

```bash
# 1. Find current Java version
grep -n "java.version\|maven.compiler.source\|sourceCompatibility" pom.xml build.gradle 2>/dev/null

# 2. Find removed/encapsulated API usage
grep -rn "sun\.misc\.\|sun\.reflect\.\|com\.sun\.net\.\|com\.sun\.crypto\." src/ --include="*.java"

# 3. Find javax modules removed from JDK (Java 11+)
grep -rn "javax\.xml\.bind\.\|javax\.annotation\.\|javax\.activation\.\|javax\.xml\.ws\.\|javax\.jws\." src/ --include="*.java"

# 4. Find reflection/illegal access patterns
grep -rn "setAccessible\|getDeclaredField\|Unsafe\." src/ --include="*.java"

# 5. Find JVM flags in scripts/configs
grep -rn "\-\-illegal-access\|\-XX:+UseConcMarkSweepGC\|\-XX:+UseParNewGC\|PermSize\|MaxPermSize" . --include="*.sh" --include="*.bat" --include="*.yml" --include="*.yaml" --include="Dockerfile*" --include="Jenkinsfile*" --include="*.properties"

# 6. Check Lombok version (needs 1.18.30+ for Java 21, 1.18.34+ for Java 25)
grep -n "lombok" pom.xml build.gradle 2>/dev/null
```

**Present impact dashboard:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 JAVA RUNTIME UPGRADE — IMPACT ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Current: Java 11  →  Target: Java 21

📁 FILES THAT WILL CHANGE:
  Build Config:
    pom.xml — java.version property (line 14)
    pom.xml — maven-compiler-plugin (line 87)
    Dockerfile — base image (line 1)
    Jenkinsfile — JDK tool reference (line 12)

  Source Code (removed APIs):
    src/.../util/XmlHelper.java — javax.xml.bind (lines 3,7,45)
    src/.../config/AppConfig.java — javax.annotation (line 2)

  JVM Flags:
    docker-compose.yml — --illegal-access=permit (line 23)
    start.sh — -XX:+UseConcMarkSweepGC (line 5)

  Dependencies to Add:
    jakarta.xml.bind:jakarta.xml.bind-api (for JAXB)
    org.glassfish.jaxb:jaxb-runtime
    jakarta.annotation:jakarta.annotation-api

  Dependencies to Update:
    lombok 1.18.24 → 1.18.34 (required for Java 21)

⚠️ METHODS/APIs THAT WILL CHANGE:
    XmlHelper.java:45 — JAXBContext.newInstance() → needs jakarta.xml.bind
    AppConfig.java:2 — @PostConstruct → needs jakarta.annotation
    start.sh:5 — CMS GC removed → use G1GC (default) or ZGC

🟢 NO IMPACT (safe):
    javax.crypto, javax.net.ssl, javax.sql — these are core JDK, not removed
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Upgrade Paths — Version-Specific Changes

### Java 8 → Java 11

**Removed from JDK (must add as dependencies):**
| Removed Module | Replacement Dependency |
|---|---|
| `java.xml.bind` (JAXB) | `jakarta.xml.bind:jakarta.xml.bind-api` + `org.glassfish.jaxb:jaxb-runtime` |
| `java.xml.ws` (JAX-WS) | `jakarta.xml.ws:jakarta.xml.ws-api` + `com.sun.xml.ws:jaxws-rt` |
| `java.activation` | `jakarta.activation:jakarta.activation-api` |
| `java.xml.ws.annotation` | `jakarta.annotation:jakarta.annotation-api` |
| `java.corba` | Remove or use GlassFish ORB |
| `java.transaction` | `jakarta.transaction:jakarta.transaction-api` |
| `java.se.ee` | Add individual modules above |
| `javafx` | Use OpenJFX |

**Code changes:**
| Old Pattern | New Pattern | Find with |
|---|---|---|
| `sun.misc.BASE64Encoder` | `java.util.Base64.getEncoder()` | `grep -rn "sun.misc.BASE64" src/` |
| `sun.misc.BASE64Decoder` | `java.util.Base64.getDecoder()` | same |
| `new URL("...").openStream()` | `URI.create("...").toURL().openStream()` | `grep -rn "new URL(" src/` |
| `Runtime.getRuntime().exec(String)` | `Runtime.getRuntime().exec(String[])` | `grep -rn "exec(" src/` |

**Build config:**
```xml
<!-- Maven: change from source/target to release -->
<plugin>
    <artifactId>maven-compiler-plugin</artifactId>
    <version>3.13.0</version>
    <configuration>
        <release>11</release>  <!-- replaces source + target -->
    </configuration>
</plugin>
```

### Java 11 → Java 17

**Strong encapsulation enforced (--illegal-access removed):**
| Affected Code | Fix |
|---|---|
| `sun.misc.Unsafe` access | Use `java.lang.invoke.VarHandle` or `java.util.concurrent.atomic` |
| `setAccessible(true)` on JDK internals | Add `--add-opens` or refactor |
| Reflection on `java.base` internals | Use public API alternatives |

**Removed JVM flags:**
| Remove This | Replace With |
|---|---|
| `--illegal-access=permit` | Remove entirely (or use specific `--add-opens`) |
| `-XX:+UseConcMarkSweepGC` | Remove (G1 is default since Java 9) |
| `-XX:+UseParNewGC` | Remove |
| `-XX:PermSize` / `-XX:MaxPermSize` | Remove (Metaspace since Java 8) |

**New language features available (don't auto-refactor, just inform):**
- Text blocks: `"""multi-line"""`
- Records: `record Point(int x, int y) {}`
- Sealed classes: `sealed interface Shape permits Circle, Rectangle`
- Pattern matching: `if (obj instanceof String s)`
- Switch expressions: `var x = switch(y) { case A -> 1; default -> 0; };`

### Java 17 → Java 21

**Key changes:**
| Area | What Changes |
|---|---|
| `Thread.stop()` | Throws `UnsupportedOperationException` — find and remove |
| Finalization | Deprecated for removal — find `finalize()` overrides |
| Security Manager | Deprecated for removal — find `System.setSecurityManager()` |
| `java.lang.ThreadGroup` | Degraded — some methods throw |
| UTF-8 by default | Already default since Java 18 — check file encoding assumptions |

**Find affected code:**
```bash
grep -rn "\.stop()\|finalize()\|setSecurityManager\|ThreadGroup" src/ --include="*.java"
```

**New features available (inform user):**
- Virtual threads: `Thread.ofVirtual().start(() -> ...)`
- Sequenced collections: `SequencedCollection`, `SequencedMap`
- Record patterns: `if (obj instanceof Point(int x, int y))`
- String templates (preview)

### Java 21 → Java 25

**Key changes:**
| Area | What Changes |
|---|---|
| Scoped Values | Finalized — can replace `ThreadLocal` in virtual thread contexts |
| Structured Concurrency | Finalized — replaces manual `ExecutorService` patterns |
| Compact Object Headers | Default — may affect tools that inspect object layout |
| Key Derivation Function API | New crypto API available |
| Module Import Declarations | New syntax: `import module java.base;` |

**Dependency updates needed:**
| Library | Minimum for Java 25 |
|---|---|
| Lombok | 1.18.34+ |
| ByteBuddy | 1.15+ |
| ASM | 9.7+ |
| Mockito | 5.14+ (uses ByteBuddy) |
| Jacoco | 0.8.12+ |
| Maven Surefire | 3.3+ |
| Gradle | 8.10+ |

**Find affected code:**
```bash
# ThreadLocal that could migrate to ScopedValue
grep -rn "ThreadLocal" src/ --include="*.java"
# Object layout tools
grep -rn "Instrumentation\|getObjectSize\|ObjectLayout" src/ --include="*.java"
```

---

## Step 1: Update Build Configuration

**Maven — find and update:**
```bash
grep -n "java.version\|maven.compiler.source\|maven.compiler.target\|<release>" pom.xml
```

Update `java.version` property and `maven-compiler-plugin`:
```xml
<properties>
    <java.version>TARGET_VERSION</java.version>
</properties>
<plugin>
    <artifactId>maven-compiler-plugin</artifactId>
    <version>3.13.0</version>
    <configuration>
        <release>TARGET_VERSION</release>
    </configuration>
</plugin>
```

**Gradle — find and update:**
```bash
grep -n "sourceCompatibility\|targetCompatibility\|jvmTarget\|toolchain" build.gradle build.gradle.kts 2>/dev/null
```

```groovy
java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(TARGET_VERSION)
    }
}
```

## Step 2: Add Missing Dependencies (version-specific — see paths above)

## Step 3: Fix Removed APIs (version-specific — see paths above)

## Step 4: Update JVM Flags in All Locations

**Search ALL locations:**
```bash
grep -rn "JAVA_OPTS\|JVM_OPTS\|JAVA_TOOL_OPTIONS\|_JAVA_OPTIONS" . --include="*.sh" --include="*.bat" --include="*.yml" --include="*.yaml" --include="*.env" --include="Dockerfile*" --include="Jenkinsfile*" --include="*.properties" --include="*.conf"
```

## Step 5: Update CI/CD

**Dockerfile:**
```bash
grep -n "FROM\|java\|jdk\|jre" Dockerfile* 2>/dev/null
```

**Jenkinsfile / pipeline:**
```bash
grep -n "jdk\|java\|tool\|JDK" Jenkinsfile* .github/workflows/*.yml 2>/dev/null
```

## Step 6: Update Test Dependencies

```bash
# Check test framework versions
grep -n "junit\|mockito\|jacoco\|surefire\|failsafe" pom.xml
```

---

## Common Errors & Fixes

| Error | Java Version | Cause | Fix |
|---|---|---|---|
| `module java.xml.bind does not exist` | 11+ | JAXB removed | Add jakarta.xml.bind dependency |
| `cannot access class sun.misc.Unsafe` | 17+ | Strong encapsulation | Use `--add-opens` or VarHandle |
| `--illegal-access=permit` not recognized | 17+ | Flag removed | Remove the flag |
| `UnsupportedClassVersionError: 65.0` | Any | Class compiled for newer JDK | Match runtime to compile target |
| `-XX:+UseConcMarkSweepGC` not recognized | 14+ | CMS removed | Remove flag, G1 is default |
| `Lombok compilation error` | 21+/25+ | Old Lombok version | Upgrade to 1.18.34+ |
| `Mockito/ByteBuddy error` | 21+/25+ | Old ByteBuddy | Upgrade Mockito to 5.14+ |

---

## Build Verification

```bash
java -version  # Confirm target JDK
mvn clean compile -q  # Or: gradle clean build
mvn test -q  # Run tests
```

---

## Reference

- Oracle Migration Guides: https://docs.oracle.com/en/java/javase/
- Spring Boot compatibility: SB 3.x requires Java 17+, SB 4.x requires Java 17+ (25 recommended)
