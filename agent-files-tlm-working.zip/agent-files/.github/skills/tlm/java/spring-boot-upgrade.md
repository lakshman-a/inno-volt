# Skill: Spring Boot Upgrade

## Skill Metadata

```yaml
name: spring-boot-upgrade
language: java
category: framework
type: recipe + agent
priority: critical
app_mod_recipe: true (for 2→3)
estimated_complexity: complex
last_updated: 2026-02-26
```

---

## How This Skill Works

This skill supports ANY Spring Boot upgrade path. The agent:
1. Detects current Spring Boot version from pom.xml / build.gradle
2. Determines target version (user choice or latest stable)
3. Shows full impact analysis — every file, method, config that changes
4. Uses App Mod recipe where available, agent mode where not
5. Handles multi-step upgrades (e.g., 2.7 → 3.2 → 3.5 → 4.0)

**Rule: Never skip major versions.** Always step through: 2.x → latest 2.7 → 3.x → latest 3.5 → 4.x

---

## Spring Boot Versions (Current as of Feb 2026)

| Version | Spring FW | Java Min | Jakarta EE | Status |
|---------|-----------|----------|------------|--------|
| 2.7.x | 5.3.x | 8 | javax | EOL (Nov 2023) |
| 3.0-3.2 | 6.0-6.1 | 17 | Jakarta 9/10 | EOL |
| 3.3.x | 6.1.x | 17 | Jakarta 10 | Maintenance |
| 3.4.x | 6.2.x | 17 | Jakarta 10 | Active (3.4.13) |
| 3.5.x | 6.2.x | 17 | Jakarta 10 | Active (3.5.11) |
| **4.0.x** | **7.0.x** | **17 (25 rec.)** | **Jakarta 11** | **Current (4.0.3)** |

---

## CRITICAL: Internal Library Protection

**Before ANY Spring Boot upgrade, read and follow `.github/skills/tlm/enterprise/internal-library-protection.md`.**

This is the #1 failure in enterprise Spring Boot migrations. Internal libraries compiled against old Spring Boot:
- Still reference `javax.*` when project moves to `jakarta.*` → `ClassNotFoundException`
- Pull in old Spring transitive deps that conflict with new version → `NoSuchMethodError`
- Use deprecated Spring APIs removed in the target version → runtime crash
- Were never tested with the new Hibernate/Jackson/Security version → silent data bugs

**Agent MUST:** Inventory internal libs → check what Spring Boot version they were compiled against → build compatibility matrix → resolve ALL conflicts BEFORE upgrading Spring Boot version in pom.xml.

---

## Step 0: Impact Analysis (ALWAYS DO FIRST)

**Run these scans and show results to developer:**

```bash
# 1. Current Spring Boot version
grep -n "spring-boot-starter-parent\|spring-boot.*version\|org.springframework.boot" pom.xml build.gradle 2>/dev/null

# 2. Spring Security config (major changes in every version)
find src/ -name "*.java" -exec grep -l "WebSecurityConfigurerAdapter\|SecurityFilterChain\|@EnableWebSecurity\|HttpSecurity" {} \;

# 3. javax vs jakarta imports
grep -rl "import javax\.\(persistence\|servlet\|validation\|annotation\|transaction\)" src/ --include="*.java" | wc -l

# 4. Configuration properties that rename
grep -rn "spring\.redis\.\|spring\.elasticsearch\.\|server\.max-http-header-size\|management\.metrics\." src/main/resources/ --include="*.properties" --include="*.yml" --include="*.yaml"

# 5. Deprecated APIs still in use
grep -rn "WebSecurityConfigurerAdapter\|authorizeRequests()\|antMatchers\|mvcMatchers\|@ConstructorBinding" src/ --include="*.java"

# 6. spring.factories (removed in SB 3+)
find src/ -name "spring.factories" -path "*/META-INF/*"

# 7. Template engines
grep -rn "ThymeleafViewResolver\|FreeMarkerConfigurer\|@Controller" src/ --include="*.java"

# 8. Companion dependencies
grep -n "spring-cloud\|flyway\|liquibase\|mapstruct\|lombok\|swagger\|springdoc\|springfox" pom.xml build.gradle 2>/dev/null
```

**Present impact dashboard:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 SPRING BOOT UPGRADE — IMPACT ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Current: Spring Boot 2.7.18  →  Target: Spring Boot 3.5.11
Upgrade Path: 2.7.18 → 3.2.x → 3.5.11

📁 BUILD CONFIG CHANGES:
  pom.xml — parent version (line 6)
  pom.xml — java.version 11 → 17 (line 15)
  pom.xml — maven-compiler-plugin (line 89)
  pom.xml — 3 dependency version bumps

📁 JAKARTA MIGRATION (javax → jakarta):
  23 files need import changes
  Key files:
    src/.../entity/User.java — javax.persistence (4 imports)
    src/.../entity/Order.java — javax.persistence (3 imports)
    src/.../config/WebConfig.java — javax.servlet (2 imports)
    src/.../dto/CreateUserRequest.java — javax.validation (1 import)
    ... and 19 more files

📁 SPRING SECURITY (MAJOR REWRITE):
  src/.../config/SecurityConfig.java
    Line 12: extends WebSecurityConfigurerAdapter → REMOVE
    Line 15: configure(HttpSecurity) → @Bean SecurityFilterChain
    Line 22: authorizeRequests() → authorizeHttpRequests()
    Line 23: antMatchers("/api/**") → requestMatchers("/api/**")
    Line 28: .and().formLogin() → .formLogin(withDefaults())
  src/.../config/CorsConfig.java
    Line 8: CorsFilter → update to SecurityFilterChain cors config

📁 SPRING DATA CHANGES:
  src/.../repository/UserRepository.java — OK (no breaking changes)
  application.yml:
    Line 34: spring.redis.host → spring.data.redis.host
    Line 35: spring.redis.port → spring.data.redis.port

📁 REMOVED APIS:
  src/.../config/AppConfig.java:
    Line 5: @ConstructorBinding on class → move to constructor
  src/main/resources/META-INF/spring.factories:
    → Move to META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports

📁 COMPANION DEPENDENCIES TO UPDATE:
  spring-cloud 2021.x → 2023.0.x (Leyton)
  springfox-swagger2 → REMOVE, use springdoc-openapi 2.x
  flyway 7.x → 9.x+
  lombok 1.18.24 → 1.18.34

⚠️ NO APP MOD RECIPE FOR:
  Spring Security rewrite (agent mode — Opus)
  Springfox → SpringDoc migration (agent mode — Opus)

⏱️ Estimated: 2 hours manual → 15 min with agent
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Upgrade Path: Spring Boot 2.x → 3.x

### Prerequisites
- Java 17+ required (run java-runtime-upgrade skill first if Java < 17)
- Upgrade to latest 2.7.x first (`2.7.18`)

### Phase 1: Update Spring Boot Version

**Files:** `pom.xml` or `build.gradle`

**Maven:**
```xml
<!-- Find: -->
<version>2.7.18</version>  <!-- spring-boot-starter-parent -->
<!-- Replace with: -->
<version>3.5.11</version>  <!-- or target 3.x version -->
```

### Phase 2: Jakarta Migration (javax → jakarta)

**App Mod Recipe available:** `@workspace /appmod Apply Jakarta EE namespace migration`

**If no recipe — manual replacement across ALL files:**

| Find (javax) | Replace (jakarta) | Affected Areas |
|---|---|---|
| `javax.persistence` | `jakarta.persistence` | Entity classes, repositories |
| `javax.persistence.criteria` | `jakarta.persistence.criteria` | Criteria API queries |
| `javax.servlet` | `jakarta.servlet` | Filters, interceptors, controllers |
| `javax.servlet.http` | `jakarta.servlet.http` | Request/Response handling |
| `javax.validation` | `jakarta.validation` | DTOs, request validation |
| `javax.validation.constraints` | `jakarta.validation.constraints` | @NotNull, @Size, etc. |
| `javax.annotation` | `jakarta.annotation` | @PostConstruct, @PreDestroy |
| `javax.transaction` | `jakarta.transaction` | @Transactional (JTA) |
| `javax.inject` | `jakarta.inject` | @Inject, @Named |
| `javax.websocket` | `jakarta.websocket` | WebSocket handlers |
| `javax.mail` | `jakarta.mail` | Email functionality |
| `javax.xml.bind` | `jakarta.xml.bind` | JAXB marshalling |

**DO NOT CHANGE (core Java, not Jakarta):**
`javax.crypto`, `javax.net`, `javax.net.ssl`, `javax.security.auth`, `javax.sql`, `javax.naming`, `javax.management`, `javax.swing`, `javax.imageio`

**Find all affected files:**
```bash
grep -rl "import javax\.\(persistence\|servlet\|validation\|annotation\|transaction\|inject\|websocket\|mail\|xml\.bind\)" src/ --include="*.java" | sort
```

**Maven dependencies:**
| Old | New |
|---|---|
| `javax.persistence:javax.persistence-api` | `jakarta.persistence:jakarta.persistence-api:3.1.0` |
| `javax.servlet:javax.servlet-api` | `jakarta.servlet:jakarta.servlet-api:6.0.0` |
| `javax.validation:validation-api` | `jakarta.validation:jakarta.validation-api:3.0.2` |
| `javax.annotation:javax.annotation-api` | `jakarta.annotation:jakarta.annotation-api:2.1.1` |

### Phase 3: Spring Security 5 → 6 (USE OPUS — NO RECIPE)

**Find affected files:**
```bash
grep -rl "WebSecurityConfigurerAdapter\|authorizeRequests\|antMatchers\|mvcMatchers\|regexMatchers" src/ --include="*.java"
```

**API replacements (per file):**

| Old (Security 5) | New (Security 6) | Impact |
|---|---|---|
| `extends WebSecurityConfigurerAdapter` | Remove — use `@Bean SecurityFilterChain` | Every security config class |
| `configure(HttpSecurity http)` | `@Bean SecurityFilterChain filterChain(HttpSecurity http)` | Method signature |
| `http.authorizeRequests()` | `http.authorizeHttpRequests()` | All request matchers |
| `.antMatchers("/path")` | `.requestMatchers("/path")` | Every URL pattern |
| `.mvcMatchers("/path")` | `.requestMatchers("/path")` | Every MVC pattern |
| `.regexMatchers("regex")` | `.requestMatchers(new RegexRequestMatcher("regex"))` | Regex patterns |
| `.and()` chaining | Lambda DSL | All chained configs |
| `configure(AuthenticationManagerBuilder)` | `@Bean AuthenticationManager` | Auth config |
| `@WithMockUser` | Same but check imports | Test files |

**Before/After example:**
```java
// BEFORE (Security 5):
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
            .antMatchers("/public/**").permitAll()
            .antMatchers("/api/**").authenticated()
            .and()
            .formLogin();
    }
}

// AFTER (Security 6):
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(auth -> auth
                .requestMatchers("/public/**").permitAll()
                .requestMatchers("/api/**").authenticated()
            )
            .formLogin(Customizer.withDefaults());
        return http.build();
    }
}
```

### Phase 4: Property Renames

**Find and replace in application.yml / application.properties:**

| Old Property | New Property | Find with |
|---|---|---|
| `spring.redis.*` | `spring.data.redis.*` | `grep "spring.redis" src/main/resources/` |
| `spring.elasticsearch.*` | `spring.data.elasticsearch.*` | `grep "spring.elasticsearch"` |
| `server.max-http-header-size` | `server.max-http-request-header-size` | `grep "max-http-header"` |
| `spring.security.oauth2.resourceserver.jwt.jws-algorithm` | `...jws-algorithms` (plural) | `grep "jws-algorithm"` |

**Tip:** Add `spring-boot-properties-migrator` temporarily to detect renames:
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-properties-migrator</artifactId>
    <scope>runtime</scope>
</dependency>
<!-- REMOVE after migration — only for detection -->
```

### Phase 5: Remove Deprecated APIs

| Deprecated | Replacement | Find with |
|---|---|---|
| `spring.factories` auto-config | `META-INF/spring/...AutoConfiguration.imports` | `find . -name "spring.factories"` |
| `@ConstructorBinding` on class | Move to constructor or remove | `grep "@ConstructorBinding"` |
| `SpringApplicationBuilder.web()` | `.web(WebApplicationType.SERVLET)` | `grep "\.web()"` |

### Phase 6: Companion Dependency Updates

| Dependency | Min for SB 3.x | Find with |
|---|---|---|
| Spring Cloud | 2023.0.x (Leyton) | `grep "spring-cloud"` |
| Spring Security | 6.x (auto via SB3) | auto-managed |
| Hibernate | 6.x (auto via SB3) | auto-managed |
| Flyway | 9.x+ | `grep "flyway"` |
| Liquibase | 4.20+ | `grep "liquibase"` |
| Lombok | 1.18.30+ | `grep "lombok"` |
| MapStruct | 1.5.5+ | `grep "mapstruct"` |
| **Springfox** | **REMOVE** → use `springdoc-openapi 2.x` | `grep "springfox"` |

---

## Upgrade Path: Spring Boot 3.x → 4.x

### Prerequisites
- Must be on latest 3.5.x first (currently 3.5.11)
- All deprecated calls from 3.x must be removed (they're gone in 4.x)
- Java 17 minimum (Java 25 recommended for full SB4 benefits)

### Phase 1: Pre-flight Check

```bash
# Find deprecated API usage that will break in SB4
grep -rn "@Deprecated\|@SuppressWarnings" src/ --include="*.java" | head -20

# Check for Undertow (dropped in SB4)
grep -rn "undertow\|spring-boot-starter-undertow" pom.xml build.gradle 2>/dev/null

# Check for spring.factories (must be migrated)
find . -name "spring.factories" -path "*/META-INF/*"
```

### Phase 2: Update to Spring Boot 4.x

```xml
<!-- Find: -->
<version>3.5.11</version>  <!-- spring-boot-starter-parent -->
<!-- Replace with: -->
<version>4.0.3</version>
```

### Phase 3: Handle Modularization (Major SB4 Change)

Spring Boot 4 split the monolithic `spring-boot-autoconfigure` into small modules.

**Impact:**
- Package names changed: `org.springframework.boot.autoconfigure.*` → `org.springframework.boot.<module>.*`
- Starters renamed (old ones still work via `spring-boot-starter-classic`)

**Strategy:**
```xml
<!-- Quick migration: add classic starter to keep old imports working -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-classic</artifactId>
</dependency>
<!-- Then gradually migrate to modular starters -->
```

**Find affected imports:**
```bash
grep -rn "org\.springframework\.boot\.autoconfigure\." src/ --include="*.java" | sort | head -30
```

### Phase 4: Spring Framework 7 Changes

| Change | Impact | Find with |
|---|---|---|
| Null-safety via JSpecify | Compilation warnings on null usage | `grep "@Nullable\|@NonNull"` |
| Jackson 3.x default | Serialization behavior may change | `grep "ObjectMapper\|@JsonProperty"` |
| Binder API null behavior | `map.from()` skips null by default | `grep "Binder\|map\.from"` |
| Public field binding removed | Config properties need getters/setters | `grep "@ConfigurationProperties"` |

### Phase 5: Spring Security 7 Changes (if coming from SB 3.x)

Spring Security 7 (bundled with SB4) makes explicit configuration mandatory:
- No more implicit defaults
- Must explicitly configure CSRF, CORS, session management

### Phase 6: Removed Items in SB4

| Removed | Alternative |
|---|---|
| Undertow support | Use Tomcat (default) or Jetty |
| Reactive Pulsar client | Use imperative Pulsar client |
| `spring-boot-starter-jersey` | Migrate to Spring MVC or WebFlux |
| Several `spring.factories` | Must use `.imports` files |
| Deprecated 3.x methods/properties | Already removed — fix before upgrading |

---

## Common Errors & Fixes (All Versions)

| Error | Version | Fix |
|---|---|---|
| `package javax.persistence does not exist` | 3.x | Change to `jakarta.persistence` |
| `WebSecurityConfigurerAdapter not found` | 3.x | Rewrite to SecurityFilterChain |
| `authorizeRequests() not found` | 3.x | Use `authorizeHttpRequests()` |
| `antMatchers() not found` | 3.x | Use `requestMatchers()` |
| `spring.redis.host unknown property` | 3.x | Use `spring.data.redis.host` |
| `ClassNotFoundException autoconfigure` | 4.x | Add `spring-boot-starter-classic` or fix imports |
| `Undertow not compatible` | 4.x | Switch to Tomcat starter |
| `ConfigurationProperties binding failed` | 4.x | Add getters/setters (no public fields) |
| `Jackson serialization changed` | 4.x | Check Jackson 3.x compatibility |

---

## Build Verification

```bash
mvn clean compile -q   # Must pass
mvn test -q             # Must pass
# Check for runtime issues:
mvn spring-boot:run     # Verify startup logs for warnings
```

---

## Reference

- SB 3.0 Migration: https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-3.0-Migration-Guide
- SB 4.0 Migration: https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-4.0-Migration-Guide
- Modularization: https://spring.io/blog/2025/10/28/modularizing-spring-boot/
