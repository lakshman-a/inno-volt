# Skill: Handling Unknown / No-Recipe Upgrades

## Overview

This skill guides the TLM Agent when it encounters a library upgrade that has:
- No App Modernization recipe
- No custom skill file
- No enterprise documentation

This is the **agent mode fallback** — the agent uses its own knowledge to plan and execute the upgrade.

---

## Strategy for Unknown Upgrades

### Step 1: Assess the Upgrade Type

| Upgrade Type | Risk | Approach |
|---|---|---|
| **Patch** (e.g., 2.3.1 → 2.3.5) | Low | Version bump only, compile, test |
| **Minor** (e.g., 2.3.x → 2.4.x) | Low-Medium | Version bump, check deprecation warnings, compile, test |
| **Major** (e.g., 2.x → 3.x) | High | Full research, plan, step-by-step migration |

### Step 2: Research Phase (For Major Upgrades)

Before making any changes, the agent should:

1. **Check if a skill file exists** in `.github/skills/tlm/` — always check first
2. **Review the library's changelog/migration guide** mentally (use training knowledge)
3. **Scan the codebase for usage patterns:**
```bash
# Find all imports of the library
grep -rn "import.*[library.package]" src/ --include="*.java" --include="*.py" --include="*.ts"

# Find direct API usage
grep -rn "[ClassName]\." src/ --include="*.java" | head -30
```
4. **Identify affected files** before making changes
5. **Create a plan** and show it to the user before executing

### Step 3: Safe Upgrade Process

```
1. Update version in dependency file (pom.xml, package.json, requirements.txt)
2. Attempt to compile/build
3. If build succeeds → run tests → if tests pass → DONE
4. If build fails:
   a. Read error messages carefully
   b. Categorize errors: import changes? API changes? removed classes?
   c. Fix one error category at a time
   d. Rebuild after each category
   e. Repeat until green
5. If stuck → escalate to Opus model
6. If still stuck → flag for manual review
```

### Step 4: Common Patterns for Unknown Upgrades

**Pattern 1: Package/Namespace Rename**
```
Symptom: "package X does not exist" across many files
Fix: Find the new package name, bulk rename imports
```

**Pattern 2: API Method Rename**
```
Symptom: "cannot find symbol: method oldName()"
Fix: Find the new method name, update all usages
```

**Pattern 3: Constructor/Factory Change**
```
Symptom: "constructor X(params) not found" or "X() is not public"
Fix: Check if moved to builder pattern, factory method, or new constructor signature
```

**Pattern 4: Return Type Change**
```
Symptom: "incompatible types" errors
Fix: Update variable types, add casts, or update downstream code
```

**Pattern 5: Removed Feature**
```
Symptom: "cannot find symbol" for entire class
Fix: Find replacement class/library, may require significant refactoring
```

---

## When to Escalate

**Escalate to Opus model when:**
- More than 10 files affected by breaking changes
- Multiple interdependent API changes
- The upgrade requires architectural changes (not just find-replace)
- Sonnet fails to resolve build errors after 2 attempts

**Escalate to user (manual review) when:**
- The upgrade requires business logic decisions
- The change affects external integrations or contracts
- No clear migration path exists even with Opus
- After 5 total attempts with no resolution

---

## Agent Mode Output Format

When working in agent mode without a recipe, always show:

```
🤖 Agent Mode: Upgrading [library] [from] → [to]

📋 Research:
   - Library type: [open-source / enterprise / internal]
   - Upgrade type: [patch / minor / major]
   - Files using this library: [count]
   - Breaking changes expected: [yes/no]

📝 Plan:
   1. [First step]
   2. [Second step]
   3. [Third step]
   ...

🔧 Executing:
   Step 1: [description] → ✅ Done
   Step 2: [description] → ✅ Done
   Step 3: [description] → ⚠️ Issue found → fixing...
   ...

🔨 Build: [PASS/FAIL]
🧪 Tests: [PASS/FAIL - X/Y passed]

📊 Result: [SUCCESS / NEEDS ATTENTION]
```

---

## Quality Checks

After ANY upgrade (recipe or agent mode), verify:

1. **No leftover old imports** — grep for old package names
2. **No commented-out code** — agent should not comment out code to "fix" things
3. **No `@SuppressWarnings` added** — agent should fix the actual issue
4. **No version conflicts** — check dependency tree for conflicts
5. **Tests actually run** — not just "no tests found" (which counts as pass)
6. **Code compiles with zero errors** — warnings are acceptable, errors are not
