# Skill: Build Validation & Test Verification

## Overview

This skill defines how the TLM Agent validates that upgrades are successful. Every upgrade MUST pass build validation before being considered complete.

---

## Build Commands by Language

### Java (Maven)
```bash
# Compile only (fast check)
mvn clean compile -q

# Compile + run tests
mvn clean test -q

# Full build with install (complete validation)
mvn clean install -q -DskipITs

# Check for dependency conflicts
mvn dependency:tree -Dverbose | grep "omitted for conflict"
```

### Java (Gradle)
```bash
# Compile
gradle clean compileJava

# Compile + test
gradle clean test

# Full build
gradle clean build

# Dependencies
gradle dependencies --configuration compileClasspath
```

### Angular
```bash
# Build
ng build --configuration=production

# Build with source maps (for debugging)
ng build

# Test
ng test --watch=false --browsers=ChromeHeadless

# Lint
ng lint
```

### Node.js
```bash
# Build (if build script exists)
npm run build

# Test
npm test

# Lint (if configured)
npm run lint
```

### Python
```bash
# Syntax validation
python -m py_compile [file]

# Run tests
python -m pytest -v

# Type check (if configured)
mypy src/

# Lint (if configured)
flake8 src/ || pylint src/
```

---

## Build Failure Handling

### Error Classification

When a build fails, classify each error:

| Error Type | Example | Fix Strategy |
|---|---|---|
| **Missing import** | `package X does not exist` | Find new package, update import |
| **Missing symbol** | `cannot find symbol: method foo()` | Find renamed/replaced method |
| **Type mismatch** | `incompatible types: X cannot be converted to Y` | Update type or add conversion |
| **Removed class** | `cannot find symbol: class OldClass` | Find replacement class |
| **Access error** | `method has private access` | Use public API instead |
| **Dependency conflict** | `ClassNotFoundException at runtime` | Resolve version conflict |
| **Config error** | `unknown property X` | Update property name |

### Iterative Fix Process

```
Attempt 1: Fix all compilation errors
  → Rebuild
  → If new errors appear (cascading), continue to Attempt 2

Attempt 2: Fix cascading errors
  → Rebuild
  → If still failing and errors are similar, escalate model (Sonnet → Opus)

Attempt 3 (Opus): Deep analysis of remaining errors
  → Look at error patterns holistically
  → May need to revert and take different approach
  → Rebuild

Attempt 4-5: Targeted fixes
  → If still failing, likely a fundamental compatibility issue
  → Report to user with detailed error analysis

After 5 attempts: STOP and report
  → List remaining errors
  → Suggest potential root causes
  → Ask user for guidance
```

### What NOT to Do

- ❌ Never suppress errors with `@SuppressWarnings`
- ❌ Never comment out failing code
- ❌ Never downgrade a dependency to make it compile (defeats the purpose)
- ❌ Never skip tests to get a "green build"
- ❌ Never add `try-catch` blocks just to swallow errors
- ❌ Never use `--force` flags in dependency resolution without user approval

---

## Test Verification

### Test Failure Categories

| Category | What It Means | Action |
|---|---|---|
| **Compilation failure in test** | Test uses old API | Fix the test code |
| **Assertion failure** | Behavior changed after upgrade | Analyze: is the test wrong or the code? |
| **Runtime exception in test** | Missing dependency or config | Fix the root cause |
| **Flaky test** | Timing/order dependent | Note but don't block on it |
| **Pre-existing failure** | Failed before upgrade too | IGNORE — not caused by TLM |

### Determining Pre-Existing vs. TLM-Caused Failures

If possible, check if the test was already failing:
```bash
# For git repos, run tests on the previous commit
git stash
mvn test -pl [module] -Dtest=[TestClass]
git stash pop
```

If the test was already failing before the upgrade, note it in the report but don't try to fix it.

---

## Dependency Conflict Resolution

### Java (Maven)
```bash
# Find conflicts
mvn dependency:tree -Dverbose | grep "omitted for conflict"

# Analyze specific dependency
mvn dependency:tree -Dincludes=[groupId]:[artifactId]
```

**Resolution strategies:**
1. **Exclude transitive:** Add `<exclusion>` in pom.xml
2. **Force version:** Add explicit dependency with desired version
3. **Use BOM:** Import a BOM that manages compatible versions
4. **Update parent:** Parent POM may need version alignment

### Angular/Node.js
```bash
# Find why a package is installed
npm explain [package-name]

# Find peer dependency issues
npm ls [package-name]
```

**Resolution strategies:**
1. **Update the conflicting package** to a compatible version
2. **Use `overrides`** in package.json (npm 8.3+) to force a version
3. **Remove and reinstall** — `rm -rf node_modules package-lock.json && npm install`

---

## Final Validation Checklist

Before marking an upgrade as complete, verify ALL of these:

```
✅ Build compiles with 0 errors
✅ All existing tests pass (or only pre-existing failures remain)
✅ No dependency conflicts in dependency tree
✅ No leftover references to old package/class names
✅ Configuration files updated (application.yml, etc.)
✅ No new @SuppressWarnings annotations added
✅ No code commented out as a "fix"
✅ New tests added for critical changes (if applicable)
```
