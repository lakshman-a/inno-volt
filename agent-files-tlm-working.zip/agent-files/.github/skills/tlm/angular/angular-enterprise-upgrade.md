# Skill: Angular Version Upgrade — Enterprise Grade

## Skill Metadata

```yaml
name: angular-enterprise-upgrade
language: angular
category: framework
type: agent
priority: critical
source_library: "@angular/core"
from_version: 8.x, 9.x, 10.x, 11.x, 12.x, 13.x, 14.x, 15.x, 16.x, 17.x
to_version: latest stable (target version)
app_mod_recipe: false
estimated_complexity: complex (ALWAYS use Opus model)
model: opus (mandatory — Angular upgrades are complex and costly to get wrong)
```

---

## Critical Rules for Angular Upgrades

### ALWAYS Use Opus Model
Angular upgrades are inherently complex with cascading breaking changes, peer dependency conflicts, and enterprise-specific complications. ALWAYS use Opus.

### ALWAYS Upgrade One Major Version at a Time
```
CORRECT:  8 → 9 → 10 → 11 → 12 → 13 → 14 → 15 → 16 → 17 → 18
WRONG:    8 → 17 (will break everything)
```
After EACH major version jump, complete ALL steps including build and verify before proceeding.

### Beast Mode — Autonomous Execution
- Keep going until the upgrade is completely resolved before yielding back to the user
- Be thorough — it's fine if it takes time. Avoid unnecessary repetition but be concise
- MUST iterate and keep going until the problem is solved
- Only terminate your turn when you are sure that the problem is solved and all items in the todo list are checked off
- NEVER end your turn without having truly and completely solved the problem
- When you say "Next I will do X" — you MUST actually do X, not just say it
- You are a highly capable and autonomous agent — solve without needing to ask the user for further input unless genuinely stuck

### Workflow Pattern
1. **Understand the problem deeply** — read the issue, think critically, break down into manageable parts: What is the expected behavior? What are the edge cases? What are the potential pitfalls? What are the dependencies?
2. **Investigate the codebase** — explore relevant files, search for key functions, gather context. (DO NOT EXPLORE THE ENTIRE CODEBASE — only look at files relevant to the problem)
3. **Develop a detailed plan** — outline a specific, simple, and verifiable sequence of steps. Create a todo list in markdown format to track progress
4. **Implement incrementally** — make small, testable code changes
5. **Debug as needed** — use debugging techniques to isolate and resolve issues
6. **Iterate** — until the root cause is fixed and all tests pass
7. **Reflect and validate comprehensively**

### Making Code Changes
- Before editing, always read the relevant file contents or section to ensure complete context
- Always read 2000 lines of code at a time to ensure you have enough context
- If a patch is not applied correctly, attempt to reapply it
- Make small, testable, incremental changes that logically follow from your investigation

### Debugging
- Use the `get_errors` tool to identify and report any compilation or linting issues
- For runtime errors, use the browser's developer tools (console, network tab, etc.)
- Use the persistent shell session to run `ng serve` for live development with reloading
- When debugging, try to determine the root cause rather than addressing symptoms
- Use `console.log` statements or set breakpoints to inspect variable values and execution flow
- For change detection issues, use Angular DevTools to visualize the component tree
- Use the persistent shell to run diagnostic commands like `npm list`, `ng version`, or custom scripts
- Revisit your assumptions if unexpected behavior occurs

### Progress Tracking (change.md)
- Check for a progress tracking file (change.md) as specified in the prompt
- Use the progress file as the single source of truth for completed steps
- Mark completed steps using strikethrough (~~Step X~~) in the progress file
- Display the updated progress after completing each major step
- Execute all steps autonomously without waiting for user confirmation unless explicitly critical
- Integrate the structured steps into your todo list format for consistency

### Resume Capability
- If the user request is "resume" or "continue" or "try again", check the conversation history and change.md to find the last incomplete step
- Do not hand back control to the user until the entire todo list is complete
- Inform the user that you are continuing from the incomplete step, and what that step is

### FMR Libraries — DO NOT Replace or Modify
**FMR (Fidelity Mutual Repositories) libraries are enterprise-provided.** These are internal packages for theming, CSS, and enterprise functionality. They must remain unchanged during Angular upgrades.

If FMR libraries block the upgrade (incompatible with newer Angular versions), the solution is:
1. **Source Code Integration:** Extract the FMR library source from the npm package
2. **Store locally:** Place the source in an internal application folder
3. **Path Aliasing:** Update `package.json` or `tsconfig.json` to resolve FMR imports from the local source
4. This gives full control to refactor during upgrade without modifying the enterprise package

**If an upgrade requires a change to an FMR library:**
```
⚠️ FMR LIBRARY INCOMPATIBILITY DETECTED

Library: @fmr/[library-name]
Issue: [what's incompatible with Angular X]

This is an enterprise-provided library. I CANNOT modify it directly.

Options:
  (a) Extract FMR source code and integrate locally (recommended)
  (b) Flag for manual review by enterprise team
  (c) Skip Angular upgrade for now

What would you like to do?
```

### Dependency Updates
- Use `npm outdated` to check for outdated packages
- Use `npm install <package>@<version>` to update non-Angular packages
- Be cautious with remaining issues — pay special attention to RxJS, HttpClient, and Router changes
- Use the `ng update` command and the `ng update` results to determine what needs fixing

### Design Changes Due to Incompatibility
When Angular removes or changes an API, and the current code relies on it:

```
⚠️ DESIGN DECISION NEEDED

Angular [X] removed: [old API/pattern]
Your code uses this in: [file1, file2, ...]

Recommended replacement: [new pattern]
Impact: [what changes, how many files]
Risk: [low/medium/high]

Should I proceed with the recommended approach?
```

NEVER silently change application design. Always explain why and get approval.

### Persistent Shell Session (Critical for Copilot Agent)
All `ng` and `npm` commands MUST run in the same persistent terminal session. Opening new terminals causes:
- Loss of environment variables and working directory context
- High CPU usage
- Loss of installed packages state
- Angular CLI state inconsistency

### Work in the UI Subdirectory
- Angular projects often live in a `ui/` subdirectory
- Never use `cd` commands — use absolute paths or run from root targeting `ui/`
- All `ng` and `npm` commands should reference the correct Angular project directory

### Communication Guidelines
- Always communicate clearly and concisely in a casual, friendly yet professional tone
- After all the version upgrades and code changes are done, inform the user that the upgrade is complete
- Consolidate and summarize all file upgrades and key changes made in the Final Summary

---

## Prerequisites

Before starting:
- [ ] Read README.md for current Angular version, requirements, build commands
- [ ] Check current Angular version: `ng version` in the `ui/` directory
- [ ] Determine target version from TLM list or latest stable
- [ ] Identify FMR/enterprise libraries in package.json that must not be modified
- [ ] Commit or stash all current changes

---

## The Iterative Upgrade Process

**For EACH major version jump, execute Steps 1-15. Then repeat for the next version (Step 16).**

### Step 1: Check Current Angular Version

**Action:** Determine current version and target
```bash
# Run in the ui/ directory
ng version
```
- Document current Angular, Node.js, and TypeScript versions
- Go to https://update.angular.io/ to find the recommended upgrade path
- Create or update `change.md` in project root to track progress

### Step 2: Check for Available Updates

**Action:** See what can be updated
```bash
ng update
```
- This lists all packages that have available updates
- Note which packages can be updated for this version jump

### Step 3: Update Core Angular Packages

**Action:** Update Angular core and CLI
```bash
ng update @angular/core @angular/cli
```
- This updates to the next stable version and runs automated migrations
- Schematics will apply automated code fixes
- Check output for any manual migrations needed

### Step 4: Update Other Angular Dependencies

**Action:** Update remaining Angular ecosystem packages
```bash
# Update any other packages that showed updates in Step 2
ng update @angular/material @angular/cdk    # if used
ng update @ngrx/store                       # if used
npm outdated                                 # check for non-Angular outdated packages
npm install <package>@<version>              # update individual packages
```

### Step 5: Address Compilation Errors

**Action:** Fix any compilation errors from the upgrade
- Use `get_errors` or `ng build` to find compilation errors
- Fix breaking changes in:
  - RxJS patterns (toPromise → firstValueFrom, throwError syntax)
  - HttpClient API changes
  - Router changes (CanActivate → CanActivateFn in v15+)
  - Template syntax changes (@if/@for control flow in v17+)
  - ViewChild/ContentChild changes
- Manually refactor code for breaking API changes
- Pay special attention to RxJS, HttpClient, and Router changes
- **Completion criteria:** The project compiles without errors
- Update change.md with strikethrough for Step 5

### Step 5b: Address Breaking Changes in Dependencies

**Action:** Fix breaking changes in non-Angular dependencies
- Check for peer dependency warnings with `npm ls`
- If `npm install` loops repeatedly, **analyze the error output**:
  - Identify the conflicting packages and their peer dependency requirements
  - Try installing compatible versions explicitly
  - If needed, remove the dependency and find alternatives
  - Do NOT just retry `npm install` in a loop — understand the conflict first
- For FMR/enterprise libraries that conflict:
  - **DO NOT modify the FMR library**
  - Extract source code and integrate locally (see FMR Library Decoupling section)
  - Flag for manual review if extraction isn't feasible
- **Completion criteria:** No critical peer dependency conflicts remain

### Step 6: Address Breaking Changes in Dependencies

**Action:** Fix breaking changes in non-Angular dependencies
- Check for peer dependency warnings
- If `npm install` loops repeatedly, analyze the error output:
  - Identify conflicting packages
  - Try installing compatible versions
  - If needed, remove the dependency and find alternatives
- For FMR/enterprise libraries that conflict:
  - DO NOT modify the FMR library
  - Extract source code and integrate locally (see FMR Library Decoupling)

### Step 7: Clean Workspace

**Action:** Ensure clean state and prevent caching issues
```bash
rm -rf ui/node_modules
rm -f ui/package-lock.json
npm cache clean --force
```

### Step 8: Reinstall Dependencies

**Action:** Fresh install
```bash
npm install
```
- Run in the `ui/` directory
- After install, verify `package-lock.json` is updated correctly

### Step 9: Build and Verify

**Action:** Build the application
```bash
npm run build
# or
ng build
```
- Must compile with zero errors
- Warnings are acceptable (but note them)
- If build fails, go back to Step 5 and fix errors

### Step 10: Run Tests

**Action:** Run unit tests
```bash
ng test --watch=false --browsers=ChromeHeadless
# or
npm test
```
- Fix any test failures caused by the upgrade
- Note pre-existing failures separately

### Step 11: Verify Development Server

**Action:** Test local dev server
```bash
npm start
# or
ng serve
```
- Verify application loads without errors
- Check browser console for any runtime errors
- Verify basic functionality works

### Step 12: List Modified Files

**Action:** Document all files changed
```bash
git diff --name-only
# or
git status
```
- Create a list in `change.md` with:
  - File name: Description of changes made

### Step 13: Update README Documentation

**Action:** Update README.md with new version info
- Update Angular version references
- Update installation/setup instructions if needed
- Update Node.js/TypeScript version requirements

### Step 14: (Reserved for additional checks)

### Step 15: Final Verification Build

**Action:** Complete end-to-end verification from clean state
```bash
rm -rf ui/node_modules
npm install     # in ui/ directory
npm run build
```
- Clean build must succeed
- No errors or critical warnings
- Verify all scripts in package.json work correctly

### Step 16: Repeat for Next Major Version

**Action:** If target version not reached, go back to Step 1
- Re-evaluate current Angular version
- Follow Steps 1-15 for the next major version increment
- Continue until target version is reached

---

## FMR Library Decoupling Process

When an FMR (enterprise) library is incompatible with the target Angular version:

### Problem
FMR libraries for Theming and CSS styles are distributed as npm packages. Newer versions may not exist for recent Angular versions, blocking the upgrade.

### Solution: Source Code Integration

1. **Extract source:** Instead of treating the FMR library as an external npm package, extract its source code and store it in a local folder within the application

2. **Path aliasing:** Update `tsconfig.json` or `package.json` to resolve FMR imports from the local source directory:
```json
// tsconfig.json
{
  "compilerOptions": {
    "paths": {
      "@fmr/theme": ["./src/lib/fmr-theme"],
      "@fmr/styles": ["./src/lib/fmr-styles"]
    }
  }
}
```

3. **Benefits:** Full control over the library code, allowing refactoring to resolve incompatibilities during each stage of the Angular upgrade

4. **Build validation:** After integration, build and verify that the application still compiles and functions correctly

---

## Challenges & Solutions (From Real Experience)

### Challenge: High CPU and Context Loss
**Symptom:** Agent opens new terminal for each command, high CPU, loses context (environment variables, current working directory)
**Solution:** Use single persistent shell session via `angularupgrade.chatmode.md` configuration. All npm and ng commands in same terminal. This was the most significant operational challenge — solved completely by enforcing persistent shell.

### Challenge: Timeout Errors from Models
**Symptom:** Timeout during data model and async operations after certain version upgrades
**Solution:** Manually re-trigger the process by clicking Try again. The resume logic in change.md means no work is lost — agent reads progress file and continues from last incomplete step.

### Challenge: Repetitive npm install Cycles
**Symptom:** Agent stuck in loop running `npm install` repeatedly without resolving
**Solution:** DO NOT just retry. Instead:
1. Analyze the `npm` error output carefully
2. Identify the specific conflicting packages and their peer dependency requirements
3. Try installing compatible versions explicitly: `npm install <package>@<version>`
4. If necessary, apply code changes to remove the conflicting dependency
5. Only use `--legacy-peer-deps` as absolute last resort (not recommended for production)

### Challenge: Agent Halting and Requiring Manual Intervention
**Symptom:** Agent stops mid-process and asks for user input before resolving an error, breaking the autonomous workflow
**Solution:** Instructions refined to make agent more resilient — instructed to "keep going until the problem is solved." Agent attempts to resolve errors independently before yielding control. Only asks user for genuine decisions (design changes, FMR library conflicts).

### Challenge: Server Errors and Dropped Streams
**Symptom:** Process interrupted by "Server error. Stream terminated" (e.g., Request id: `50c36382-a3b2-4e47-a07d-457082cda272`)
**Solution:** These errors are related to the underlying AI model infrastructure. The resume logic is crucial here:
1. Agent reads `change.md` progress file
2. Determines the last incomplete step
3. Resumes from exactly where it left off
4. No work is lost, no steps are repeated

### Challenge: FMR Library Incompatibility
**Symptom:** Angular upgrade blocked because FMR enterprise libraries don't support newer Angular versions
**Solution:** Source Code Integration approach:
1. Extract FMR library source from npm package into local folder
2. Update `tsconfig.json` path aliases to point to local source
3. Refactor local copy as needed for Angular compatibility
4. Build and verify after integration
This was the critical prerequisite that would have stalled the entire upgrade.

---

## Angular/Node.js Compatibility Matrix

| Angular | Min Node.js | Recommended | TypeScript |
|---|---|---|---|
| 8.x | 10.13 | 12.x | 3.5 |
| 9.x | 10.13 | 12.x | 3.7 |
| 10.x | 10.13 | 12.x | 3.9 |
| 11.x | 10.13 | 12.x | 4.0 |
| 12.x | 12.20 | 14.x | 4.2 |
| 13.x | 12.20 | 16.x | 4.4 |
| 14.x | 14.15 | 16.x | 4.7 |
| 15.x | 14.20 | 18.x | 4.8 |
| 16.x | 16.14 | 18.x | 5.0 |
| 17.x | 18.13 | 20.x | 5.2 |
| 18.x | 18.19 | 20.x | 5.4 |

---

## Final Summary (After All Versions Upgraded)

After completing all version jumps, provide:
```
📊 ANGULAR UPGRADE SUMMARY

Old Angular version → New Angular version
Updated configuration files (package.json, angular.json, tsconfig.json)
Updated dependencies (list all)
Updated CI/CD configurations
README.md updates
List of all issues encountered and resolved
Final build and test status
Modified files list

Recommendations:
  □ Team communication about version change
  □ Local environment setup for other developers
  □ Monitoring in production after deployment
  □ Follow-up tasks or considerations
```

---

## Reference Documentation

- Angular Update Guide: https://update.angular.io/
- Angular Releases: https://github.com/angular/angular/releases
- RxJS 7 Migration: https://rxjs.dev/guide/v7/migration
- Enterprise FMR Library documentation (internal Confluence)
