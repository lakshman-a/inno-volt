# Skill: JSCI EOL Retirement — Complete Migration Guide

## Skill Metadata

```yaml
name: jsci-eol-retirement
language: java
category: enterprise
type: enterprise
priority: critical
source_library: com.fmr.jsci:fmr-commons-*, fmr-cookie-processor, fmr-jsci-cucumber
from_version: all versions (EOL March 2026)
to_version: dp-* alternatives, open-source, or native Java/Spring
app_mod_recipe: false
estimated_complexity: complex
eol_deadline: March 2026
infrastructure_deadline: April 1, 2026 (jil.fmr.com and jsci.fmr.com go offline)
```

---

## Context

**JSCI is being fully retired in March 2026.** The sites `jil.fmr.com` and `jsci.fmr.com` go offline April 1, 2026. JSCI patterns have not kept pace with modern web frameworks — much of its functionality is now available natively in Java or Spring.

---

## Complete Component Replacement Mapping

### Drop-in dp-* Replacements (Straightforward)

| Component | Replacement | Notes |
|---|---|---|
| `fmr-commons-jwt` | `dp-commons-jwt` | JWT verification and claims. Also consider `auth0/java-jwt` or `jwtk/jjwt` for 3rd party |
| `fmr-commons-crypto` (basic) | `dp-crypto-utils` | ECS Encryption Standard compliance |
| `fmr-commons-cs203` | `dp-http-request-guard` | Backward compatible. HTTP headers + CSRF guard |

### Open-Source / Native Replacements (Moderate)

| Component | What It Does | Replace With |
|---|---|---|
| `fmr-commons-core` | Logging (Log4j levels), threading, common utils | SLF4J + `java.util.concurrent` + native Java |
| `fmr-commons-logging` | MQ Adaptor audit logging (FieldCollector, FieldSelector, StaticAppender) | SLF4J + Log4j2 (supports Async and JMS appenders natively) |
| `fmr-commons-monitoring` | Timers, counters, metrics collection | Micrometer (Spring Boot) or OpenTelemetry (OTEL) |
| `fmr-cookie-processor` | SameSite cookie stop-gap | Tomcat native SameSite config (containers handle it now) |
| `fmr-jsci-cucumber` | JSCI sample app test dependency | **DELETE entirely** — N/A, sample app no longer relevant |

### Complex Replacements (Significant Effort — May Need User Input)

| Component | What It Does | Replace With | Risk |
|---|---|---|---|
| `fmr-commons-crypto` (advanced) | HSM/KeyStore/KMaaS, GCM encryption, digest/HMAC, signature, chain operations, Luna/HSM | `org.bouncycastle` or `java.security` + `com.thales.LunaProvider` (licensing!) | HIGH — Luna HSM cannot be distributed directly |
| `fmr-commons-security` | FebSec JAAS, B2B Auth, FAC header parsing, StrutsPlus auth, OAuth tokens | Spring Security + native Java JAAS. FebSec FAC → emit as JWT. OAuth → Spring Security OAuth2 | HIGH — authentication infrastructure change |
| `fmr-commons-cs203` (extended validation) | Apache Commons Validator based, core + application validators | Spring Security + Jakarta Bean Validation + OWASP CSRFGuard + Jackson JSON-schema | MODERATE — multiple replacement libs |
| `fmr-commons-util` | JIL/StrutsPlus config processing, Digester XML, JParse tokens → Spring beans | Spring Dependency Injection — convert XML configs to @Configuration or application.yml | MODERATE — legacy config format conversion |

---

## Upgrade Steps

### Step 1: Scan and Categorize
```bash
grep -rn "fmr-commons\|fmr-cookie\|fmr-jsci\|com\.fmr\.jsci\|com\.fmr\.commons\|jsci\.fmr\.com\|jil\.fmr\.com" . \
  --include="*.xml" --include="*.gradle" --include="*.properties" \
  --include="*.yml" --include="*.yaml" --include="*.java" --include="*.xsd"
```
Present findings categorized as: dp-replacement / open-source / complex / remove / infrastructure.

### Step 2: Replace dp-* Drop-ins
For each: remove old dependency → add new → update imports → verify compile.

### Step 3: Replace Open-Source Components
For each: remove dependency → add replacement → update imports and usage patterns → verify.

### Step 4: Handle Complex Components
For fmr-commons-crypto (HSM), fmr-commons-security, fmr-commons-util: show specific files affected, explain the change, ask user for decision before proceeding.

### Step 5: Infrastructure Cleanup
Remove all references to `jil.fmr.com` and `jsci.fmr.com`. Download XSD/config files locally.

### Step 6: Transitive Cleanup
`mvn dependency:tree | grep jsci` must return 0. Add exclusions if needed.

### Step 7: Build + Test + Verify Zero JSCI Remaining

---

## Common Errors & Fixes

| Error | Fix |
|---|---|
| `ClassNotFoundException: FmrLoggerFactory` | → `org.slf4j.LoggerFactory` |
| `cannot resolve jil.fmr.com` | Download XSD locally, update schemaLocation |
| `SameSite cookie not set` | Configure in application.yml or Tomcat |
| `FebSec JAAS LoginModule not found` | Migrate to Spring Security |
| `Digester config parsing failed` | Convert JIL/StrutsPlus XML to Spring @Configuration |
| `MQ Adaptor audit log missing` | Log4j2 with JMS appender |
