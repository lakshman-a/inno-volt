# Skill: JSCI Common Library Migration

## Skill Metadata

```yaml
name: jsci-common-migration
language: java
category: enterprise
type: enterprise
priority: high
source_library: com.enterprise.jsci:jsci-common
from_version: 2.x
to_version: 1.0.0 (com.enterprise.platform:platform-common)
app_mod_recipe: false
estimated_complexity: moderate
```

---

## Context

The enterprise JSCI Common Utilities library has been migrated to the new Platform Common library. This involves a complete package rename, artifact rename, and several API changes.

**Key Change:** The library has moved from the JSCI org to the Platform org:
- Old: `com.enterprise.jsci:jsci-common` (v2.x)
- New: `com.enterprise.platform:platform-common` (v1.0.0+)

---

## Prerequisites

- [ ] Ensure the new `platform-common` artifact is available in enterprise Nexus/Artifactory
- [ ] No other JSCI libraries depend on jsci-common in this project (check dependency tree)

---

## Upgrade Steps

### Step 1: Update Maven Dependency

**pom.xml:**
```xml
BEFORE:
<dependency>
    <groupId>com.enterprise.jsci</groupId>
    <artifactId>jsci-common</artifactId>
    <version>2.3.1</version>
</dependency>

AFTER:
<dependency>
    <groupId>com.enterprise.platform</groupId>
    <artifactId>platform-common</artifactId>
    <version>1.0.0</version>
</dependency>
```

### Step 2: Update All Imports

**Find all affected files:**
```bash
grep -rl "com\.enterprise\.jsci\.common" src/ --include="*.java"
```

### Step 3: Update API Calls

Apply the API changes listed below in every affected file.

### Step 4: Update Configuration

**application.yml / application.properties:**
```yaml
BEFORE:
jsci:
  common:
    cache:
      enabled: true
      ttl: 3600
    retry:
      maxAttempts: 3

AFTER:
platform:
  common:
    cache:
      enabled: true
      ttl: 3600
    retry:
      maxAttempts: 3
```

---

## Import / Package Changes

| Old Import/Package | New Import/Package |
|---|---|
| `com.enterprise.jsci.common.utils.CommonUtils` | `com.enterprise.platform.common.utils.CommonUtils` |
| `com.enterprise.jsci.common.utils.DateHelper` | `com.enterprise.platform.common.utils.DateHelper` |
| `com.enterprise.jsci.common.utils.StringHelper` | `com.enterprise.platform.common.utils.StringHelper` |
| `com.enterprise.jsci.common.model.*` | `com.enterprise.platform.common.model.*` |
| `com.enterprise.jsci.common.exception.*` | `com.enterprise.platform.common.exception.*` |
| `com.enterprise.jsci.common.config.*` | `com.enterprise.platform.common.config.*` |
| `com.enterprise.jsci.common.security.*` | `com.enterprise.platform.common.security.*` |
| `com.enterprise.jsci.common.http.*` | `com.enterprise.platform.common.http.*` |
| `com.enterprise.jsci.common.cache.*` | `com.enterprise.platform.common.cache.*` |

---

## API Changes

| Old API | New API | Notes |
|---|---|---|
| `CommonUtils.parse(String input)` | `CommonUtils.convert(String input)` | Method renamed |
| `CommonUtils.parseJson(String json)` | `CommonUtils.fromJson(String json)` | Method renamed |
| `CommonUtils.toJsonString(Object obj)` | `CommonUtils.toJson(Object obj)` | Method renamed |
| `DateHelper.format(Date date)` | `DateHelper.formatISO(Date date)` | Now returns ISO 8601 format by default |
| `DateHelper.parse(String dateStr)` | `DateHelper.parseISO(String dateStr)` | Expects ISO 8601 format |
| `StringHelper.isEmpty(String s)` | `StringHelper.isBlank(String s)` | Now also checks whitespace-only |
| `SecurityContext.legacy()` | REMOVED | Use `SecurityContext.current()` instead |
| `CacheManager.getInstance()` | `CacheManager.create(config)` | No longer singleton — requires config |
| `HttpClientWrapper(url)` | `HttpClientWrapper.builder().url(url).build()` | Builder pattern now |

---

## Configuration Changes

| Old Property | New Property | Notes |
|---|---|---|
| `jsci.common.cache.enabled` | `platform.common.cache.enabled` | Same behavior |
| `jsci.common.cache.ttl` | `platform.common.cache.ttl` | Same behavior |
| `jsci.common.retry.maxAttempts` | `platform.common.retry.maxAttempts` | Same behavior |
| `jsci.common.retry.backoff` | `platform.common.retry.backoffMs` | Now in milliseconds |
| `jsci.common.security.legacyMode` | REMOVED | Legacy mode no longer supported |
| `jsci.common.logging.level` | `platform.common.logging.level` | Same behavior |

---

## Common Errors & Fixes

| Error Message | Cause | Fix |
|---|---|---|
| `package com.enterprise.jsci.common does not exist` | Import not updated | Replace with `com.enterprise.platform.common` |
| `cannot find symbol: method parse(String)` | API renamed | Use `convert(String)` instead |
| `cannot find symbol: method legacy()` | Removed API | Use `SecurityContext.current()` |
| `CacheManager cannot be applied to ()` | Constructor changed | Use `CacheManager.create(config)` |
| `HttpClientWrapper(String) is not public` | Constructor pattern changed | Use builder: `HttpClientWrapper.builder().url(url).build()` |

---

## Build Verification

```bash
# Ensure no old references remain
grep -rn "com\.enterprise\.jsci\.common" src/ --include="*.java"
# Should return 0 results

grep -rn "jsci\.common\." src/main/resources/ --include="*.yml" --include="*.properties"
# Should return 0 results

mvn clean compile -q
```

---

## Test Considerations

- Update test imports to new package names
- Tests mocking `CommonUtils.parse()` → update to `CommonUtils.convert()`
- Tests using `SecurityContext.legacy()` → update to `SecurityContext.current()`
- Integration tests checking cache behavior → update config property names
- Tests creating `HttpClientWrapper` directly → update to builder pattern

---

## Reference Documentation

- Internal Confluence: https://confluence.enterprise.com/display/PLATFORM/JSCI-to-Platform-Migration
- Platform Common Javadoc: https://nexus.enterprise.com/platform-common/apidocs
- Migration Support: Slack #jsci-migration-support
