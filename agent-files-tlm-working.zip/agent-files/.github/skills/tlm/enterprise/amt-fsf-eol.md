# Skill: AMT FSF Components EOL — Migration Guide

## Skill Metadata

```yaml
name: amt-fsf-eol
language: java
category: enterprise
type: enterprise
priority: high
source_library: AMT FSF * 7.5
from_version: 7.5
to_version: varies (replacement library)
app_mod_recipe: false
estimated_complexity: moderate
eol_deadline: 2026-06-30 (SW EOL) / 2026-Q2 (SWL EOL Timeline)
```

---

## Context

AMT FSF (Fidelity Software Framework) components version 7.5 are reaching End of Life on June 30, 2026 (2026-Q2). Multiple components are affected:

| Component | SW EOL | Timeline | Action Required |
|---|---|---|---|
| AMT FSF Config Utils 7.5 | 2026-06-30 | 2026-Q2 | Replace or upgrade |
| AMT FSF Identity 7.5 | 2026-06-30 | 2026-Q2 | Replace or upgrade |
| AMT FSF Rest 7.5 | 2026-06-30 | 2026-Q2 | Replace or upgrade |
| AMT FSF Secret 7.5 | 2026-06-30 | 2026-Q2 | Replace or upgrade |
| AMT FSF Usage Metrics 7.5 | 2026-06-30 | 2026-Q2 | Replace or upgrade |

---

## Upgrade Steps

### Step 1: Scan for AMT FSF Dependencies

```bash
grep -rn "amt-fsf\|AMT.FSF\|com\.fmr\.amt\.fsf" . \
  --include="*.xml" --include="*.gradle" --include="*.java" \
  --include="*.properties" --include="*.yml"
```

### Step 2: Identify Replacement Versions

**Check with the enterprise team for:**
- Is there an AMT FSF 8.x or newer version available?
- Are there alternative libraries recommended?
- Is this a direct version upgrade or a library replacement?

**⚠️ Agent should ask the user:**
```
🏢 AMT FSF Components 7.5 Detected (EOL: June 2026)

Found the following AMT FSF components in your project:
  • AMT FSF Config Utils 7.5
  • AMT FSF Rest 7.5
  • AMT FSF Secret 7.5

I need guidance on the migration path:
  (a) Is there a newer version (8.x+) available in Nexus?
  (b) Are these being replaced with different libraries?
  (c) Do you have a migration guide or Confluence link?
  (d) Skip for now — I'll fix other TLM items first
```

### Step 3: Apply Upgrade

Based on user input, apply version bump or library replacement following the standard skill pattern.

---

## Reference

- SW EOL List (enterprise spreadsheet)
- Source: FMR
- Contact: Product Manager and Development Lead from EOL spreadsheet
