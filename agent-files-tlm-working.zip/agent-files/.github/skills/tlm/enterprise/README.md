# Skill: Enterprise Internal Library Migrations

## Overview

This folder contains skills for enterprise-specific/internal library upgrades. These are libraries built and maintained internally that don't have public migration guides.

**How this works:**
1. When enterprise announces an internal library change, the platform team creates a skill file here
2. The TLM Agent reads these skills when scanning for enterprise TLM items
3. If no skill exists, the agent asks the user for documentation

---

## Available Enterprise Skills

> **Add your enterprise skills below this section. Each skill should be a separate `.md` file in this folder following the template.**

### How to Add a New Enterprise Skill

1. Copy `SKILL-TEMPLATE.md` from the parent folder
2. Save as `[library-name]-migration.md` in this folder
3. Fill in the metadata, steps, import changes, and API changes
4. Commit to the repo — all team members get the skill automatically

---

## Example: JSCI Common Library Migration

> **File:** `jsci-common-migration.md` (create as separate file)

This is a reference example of what an enterprise skill looks like.

---

## Example: Internal Auth Library v3

> **File:** `auth-lib-v3.md` (create as separate file)

---

## Enterprise TLM List Support

If your enterprise maintains a central TLM list, place it at the project root:

**Supported formats:**
- `tlm-list.csv` — CSV with columns: library, current_version, target_version, priority, category
- `tlm-list.json` — JSON array with same fields
- `tlm-items.txt` — Simple text, one item per line: `library:current_version:target_version`

**Example CSV:**
```csv
library,current_version,target_version,priority,category
com.enterprise.jsci.common,2.3.1,1.0.0,high,enterprise-internal
com.enterprise.auth-lib,2.0.0,3.0.0,critical,enterprise-internal
com.enterprise.theme-core,1.5.0,2.0.0,medium,enterprise-internal
com.enterprise.logging-wrapper,1.2.0,2.0.0,low,enterprise-internal
```

The TLM Agent will automatically detect and use this file when scanning.

---

## When No Skill Exists

If the TLM Agent encounters an enterprise library without a skill file, it will:

1. **Inform the user** that no migration guide is available
2. **Ask for one of these:**
   - A Confluence/wiki link describing the changes
   - Release notes or changelog
   - A brief description of what changed (package renames, API changes, config changes)
3. **Apply the changes** based on user-provided context
4. **Suggest creating a skill file** for future team members

```
Example agent behavior:

🏢 Enterprise Library: com.enterprise.metrics-core 1.0 → 2.0
⚠️  No migration skill found at .github/skills/tlm/enterprise/

To upgrade this library, I need additional context. Please provide:
  (a) A Confluence or wiki link with migration details
  (b) A description of what changed between v1 and v2
  (c) Release notes or changelog

Alternatively, you can create a skill file at:
  .github/skills/tlm/enterprise/metrics-core-v2.md
  using the template at .github/skills/tlm/SKILL-TEMPLATE.md

This will help the entire team upgrade this library in the future.
```
