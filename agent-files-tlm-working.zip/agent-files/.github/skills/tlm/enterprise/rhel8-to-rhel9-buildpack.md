# Skill: UBN22/RHEL8 → UBN24/RHEL9 Build Pack Migration

## Skill Metadata

```yaml
name: rhel8-to-rhel9-buildpack
language: all
category: enterprise
type: enterprise
priority: critical
from_version: UBN22/RHEL8
to_version: UBN24/RHEL9 (Multi-CPU Architecture — AMD64 + ARM64)
app_mod_recipe: true (GHCP App Mod plugin can generate scan plan)
estimated_complexity: moderate
eol_deadline: November 30, 2025 (UBN22/RHEL8 retired)
start_date: July 1, 2025 (UBN24/RHEL9 buildpacks released)
pipeline_warning: "Finished: UNSTABLE" if still using UBN22/RHEL8
```

---

## Context

Enterprise Jenkins Core Buildpacks have moved to **Multi CPU Architecture (AMD64 and ARM64)** on UBN24/RHEL9. UBN22/RHEL8 buildpacks were retired on November 30, 2025. Pipelines still using them get `Finished: UNSTABLE` warnings.

**What's New in RHEL9/UBN24:**
- Full multiarch support for modern CI/CD (amd64 + arm64)
- Introduction of Chromium browser utility
- Microsoft Graph PowerShell SDK for pwsh-dotnet8 buildpacks
- `arm64` support only in UBN24/RHEL9 buildpacks (not available in UBN22/RHEL8)

**Removed/Deprecated:**
- Microsoft Edge and Google Chrome removed (not supported on arm64)
- `jenkins-cli` removed from Java 11 buildpack (incompatible with latest Jenkins server JAR)
- `snowsql` buildpacks deprecated (no arm64 support)
- `pwsh-dotnet6` and `pwsh-dotnet7` removed (.NET 6/7 not supported on Ubuntu 24.04)
- AzureAD module deprecated → use Microsoft Graph PowerShell SDK
- `libgconf-2-4` deprecated → replaced with `dconf-cli` and `gsettings-desktop-schemas`
- `libasound2` updated to `libasound2t64` (64-bit time support)

---

## RHEL9 Available Container Images

| Container Name | Base Image | Utilities | Multi-Arch |
|---|---|---|---|
| `rhel9-mvn3-java11-nodejs14` | pipelineutilis | maven3, nodejs14, java11 | Yes |
| `rhel9-mvn3-java11-nodejs16` | pipelineutilis | maven3, nodejs16, java11 | Yes |
| `rhel9-mvn3-java11-nodejs18` | pipelineutilis | maven3, nodejs18, java11 | Yes |
| `rhel9-mvn3-java17-nodejs14` | pipelineutilis | maven3, nodejs14, java17, jenkins-cli | Yes |
| `rhel9-mvn3-java17-nodejs16` | pipelineutilis | maven3, nodejs16, java17, jenkins-cli | Yes |
| `rhel9-mvn3-java17-nodejs18` | pipelineutilis | maven3, nodejs18, java17, jenkins-cli | Yes |
| `rhel9-mssql` | pipelineutilis | sqlcmd, Kerberos | No (MSSQL not supported for ARM64) |

---

## Image Mapping (UBN22 → UBN24)

| Old Image/Buildpack | New Image/Buildpack | Notes |
|---|---|---|
| `ubn22-aws-utils` | `ubn24-aws-utils` | Direct version upgrade |
| `ubn22-mvn3-java11-nodejs18` | `ubn24-mvn3-java11-nodejs18` | Direct version upgrade |
| `ubn22-mvn3-java17-nodejs18` | `ubn24-mvn3-java17-nodejs18` | Direct version upgrade |

**Mapping source:** Official buildpack documentation at `https://alm-docs.fmr.com/fpps/buildpacks/jc-buildpacks.html`

**For images not in the mapping:** Check the official docs or report as missing upgrade path.

---

## App Mod Plugin Integration

The GHCP App Modernization plugin can generate a **scan plan** that produces 3 output files:

### Plan: Audit and Upgrade UBN22/RHEL8 Image and Buildpack References

**Step 1: Search for Image and Buildpack References**
- Search the entire project for `ubn22` and `rhel8` in ALL files (Dockerfiles, YAML, Groovy, JSON, scripts, CI/CD configs)
- Also search for keywords `buildpack` and `buildpacks`
- Record each match with file path and line number

**Step 2: List and Categorize All References**
- Categorize by image name (e.g., `ubn22-aws-utils`, `ubn22-mvn3-java17-nodejs18`)
- List all locations (file path + line number) for each image

**Step 3: Map to Higher Version Equivalents**
- Consult the official buildpack docs to find the `ubn24` equivalent
- Match tag/variant where possible (e.g., `ubn22-mvn3-java17-nodejs20` → `ubn24-mvn3-java17-nodejs20`)

**Step 4: Report Missing Upgrade Paths**
- Identify any images without a higher version equivalent
- Record in `missing-upgrade-images.txt`

**Step 5: Output Files Generated**
- `ubn22-ubn24-image-mapping.md` — Summary table mapping old → new images
- `ubn22-image-usage-locations.md` — Detailed list of every file and line number
- `missing-upgrade-images.txt` — Images without a mapping

---

## Upgrade Steps (With or Without App Mod)

### Step 1: Scan for All UBN22/RHEL8 References

```bash
grep -rn "ubn22\|rhel8\|UBN22\|RHEL8" . \
  --include="Dockerfile*" --include="Jenkinsfile*" \
  --include="*.yml" --include="*.yaml" --include="*.groovy" \
  --include="*.properties" --include="*.sh" --include="*.json" \
  --include="*.tf"
```

**Show findings grouped by type:**
```
📋 UBN22/RHEL8 REFERENCES FOUND:

  BUILDPACK IMAGES:
    □ ubn22-aws-utils → ubn24-aws-utils
    □ ubn22-mvn3-java11-nodejs18 → ubn24-mvn3-java11-nodejs18
    □ ubn22-mvn3-java17-nodejs18 → ubn24-mvn3-java17-nodejs18

  USAGE LOCATIONS:
    terraform/S3/pipeline/cd/qa-segments.yaml:3 — ubn22-aws-utils
    pipeline/ci/Jenkinsfile:6 — ubn22-mvn3-java11-nodejs18
    pipeline/ci/Jenkinsfile:7 — ubn22-mvn3-java17-nodejs18
    pipeline/ci/ControlMJenkinsfile:5 — ubn22-mvn3-java11-nodejs18

  BUILDPACK SECTION USAGE:
    terraform/S3/pipeline/cd/dev-segments.yaml:1 — buildpack
    pipeline/ci/Jenkinsfile:7 — buildpack
```

### Step 2: Apply Image Mapping
For each reference, replace ubn22 → ubn24 and rhel8 → rhel9 using the mapping table.

### Step 3: Check for Architecture Compatibility
- If using `arm64` specific features → verify image supports it
- Some tools (MSSQL, snowsql) do NOT support arm64
- If using `--platform` flags, verify they match

### Step 4: Handle Removed Utilities
If the project uses any removed utilities:
- `jenkins-cli` in Java 11 → use alternative approach or switch to Java 17 buildpack
- Edge/Chrome → use Chromium (now included)
- AzureAD module → Microsoft Graph PowerShell SDK
- `libgconf-2-4` → `dconf-cli` + `gsettings-desktop-schemas`

### Step 5: Verify Pipeline
```bash
# Run the pipeline and verify:
# - No "Finished: UNSTABLE" warning
# - Build succeeds
# - Tests pass
# - Deployment works
```

---

## Common Errors & Fixes

| Error | Cause | Fix |
|---|---|---|
| `Finished: UNSTABLE` | Still using UBN22/RHEL8 | Update image references to UBN24/RHEL9 |
| `manifest unknown` | New image not yet available | Check alm-docs for exact image name |
| `exec format error` | arm64 image on amd64 or vice versa | Use `--platform linux/amd64` or check image arch support |
| `jenkins-cli not found` | Removed from Java 11 buildpack | Switch to Java 17 buildpack or alternative CLI approach |
| `libgconf-2-4 not found` | Deprecated in Ubuntu 24.04 | Use `dconf-cli` and `gsettings-desktop-schemas` |

---

## Reference

- Official Buildpack Docs: `https://alm-docs.fmr.com/fpps/buildpacks/jc-buildpacks.html`
- ARM Buildpacks: Fidelity Pipeline Library - Multi-Arch buildpacks
- Enterprise ALM: ECCDevLifecycle team
- Event Type: Technology Lifecycle Management
