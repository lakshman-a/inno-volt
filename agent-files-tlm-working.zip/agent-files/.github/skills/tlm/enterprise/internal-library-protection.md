# Skill: Internal Library Protection & Conflict Resolution

## Skill Metadata

```yaml
name: internal-library-protection
language: java
category: enterprise
type: agent
priority: critical
estimated_complexity: complex
last_updated: 2026-02-26
```

---

## Why This Skill Exists

**The #1 failure in enterprise migrations:** Spring Boot or Java version is upgraded, but internal/enterprise libraries are compiled against the OLD version. Result:
- `NoSuchMethodError` at runtime (method signature changed in new Spring)
- `ClassNotFoundException` (javax class removed, internal lib still references it)
- `IncompatibleClassChangeError` (internal lib compiled against old Hibernate)
- Build succeeds but app crashes on startup

**This skill MUST be read and followed during EVERY Java runtime, Spring Boot, or major library upgrade.**

---

## Step 1: Inventory All Internal Libraries (DO FIRST)

Before ANY upgrade, build a complete list of internal/enterprise dependencies:

```bash
# Maven — find all non-public (internal) dependencies
mvn dependency:tree | grep -i "fmr\|internal\|enterprise\|corp\|company\|com\.fidelity\|com\.fmr\|dp-\|amt-\|jsci"

# Also check for private repository references
grep -n "repository\|<url>" pom.xml | grep -v "maven.org\|repo1\|central\|spring.io\|jcenter\|google"

# Check BOM/parent for internal dependency management
grep -A2 "dependencyManagement" pom.xml | head -10

# Angular/Node — find internal packages
grep -n "@fmr/\|@internal/\|@corp/\|@enterprise/" package.json 2>/dev/null

# Gradle
grep -i "fmr\|internal\|enterprise\|corp" build.gradle build.gradle.kts 2>/dev/null
```

**Present internal library inventory:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏢 INTERNAL LIBRARY INVENTORY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Found 6 internal/enterprise dependencies:

  com.fmr.jsci:fmr-commons-jwt:2.3.1
    → Compiled against: Spring Boot 2.7, Java 11
    → Status: EOL — skill available (jsci-eol-retirement)
    → Action: REPLACE with dp-commons-jwt

  com.fmr.jsci:fmr-commons-crypto:1.8.0
    → Compiled against: Spring Boot 2.7, Java 11
    → Status: EOL — skill available
    → Action: REPLACE with dp-crypto-utils

  com.fmr.dp:dp-commons-jwt:3.1.0
    → Compiled against: Spring Boot 3.2, Java 17
    → Status: Active
    → Action: CHECK if version 3.1.0 works with target Spring Boot

  com.fmr.amt:amt-fsf-rest:7.5.2
    → Compiled against: Spring Boot 2.7, Java 11
    → Status: EOL June 2026
    → Action: NEEDS INVESTIGATION — no newer version confirmed

  com.internal:shared-logging:2.0.0
    → Compiled against: Unknown
    → Status: Unknown
    → Action: ASK USER for compatibility info

  com.internal:config-client:1.5.3
    → Compiled against: Unknown
    → Status: Unknown
    → Action: ASK USER for compatibility info

⚠️ RISK ASSESSMENT:
  2 libraries compiled against OLD Spring Boot (will likely break)
  2 libraries status unknown (must verify before upgrading)
  1 library needs version check against target
  1 library is EOL with no confirmed replacement
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 2: Check Internal Library Compatibility BEFORE Upgrading

**For each internal library, determine if it's compatible with the target version:**

```bash
# Check what Spring/Java version an internal JAR was compiled against
# Unpack the JAR and check MANIFEST.MF
unzip -p ~/.m2/repository/com/fmr/dp/dp-commons-jwt/3.1.0/dp-commons-jwt-3.1.0.jar META-INF/MANIFEST.MF

# Check class file version (tells you Java compile target)
javap -v -classpath ~/.m2/repository/com/fmr/dp/dp-commons-jwt/3.1.0/dp-commons-jwt-3.1.0.jar com.fmr.dp.jwt.JwtValidator 2>/dev/null | grep "major version"
# 52 = Java 8, 55 = Java 11, 61 = Java 17, 65 = Java 21, 69 = Java 25

# Check if internal lib uses javax or jakarta
jar tf ~/.m2/repository/com/fmr/dp/dp-commons-jwt/3.1.0/dp-commons-jwt-3.1.0.jar | grep -i "javax\|jakarta"

# Check transitive dependencies of internal lib
mvn dependency:tree -Dincludes=com.fmr -Dverbose
```

**Compatibility matrix to build:**
```
┌─────────────────────┬──────────┬──────────┬──────────┬──────────┐
│ Internal Library     │ Current  │ Target   │ Compat?  │ Action   │
│                      │ Works On │ SB Ver   │          │          │
├─────────────────────┼──────────┼──────────┼──────────┼──────────┤
│ dp-commons-jwt 3.1  │ SB 3.2   │ SB 3.5   │ ✅ Yes   │ Keep     │
│ dp-commons-jwt 3.1  │ SB 3.2   │ SB 4.0   │ ⚠️ Check │ Test     │
│ fmr-commons-jwt 2.3 │ SB 2.7   │ SB 3.5   │ ❌ No    │ Replace  │
│ amt-fsf-rest 7.5    │ SB 2.7   │ SB 3.5   │ ❌ No    │ Invest.  │
│ shared-logging 2.0  │ Unknown  │ SB 3.5   │ ❓       │ Ask user │
│ config-client 1.5   │ Unknown  │ SB 3.5   │ ❓       │ Ask user │
└─────────────────────┴──────────┴──────────┴──────────┴──────────┘
```

---

## Step 3: Handle Each Scenario

### Scenario A: Internal Library Has a Newer Version for Target

**Most common case.** Enterprise team published a newer version compiled against the target Spring Boot.

```bash
# Check Nexus/Artifactory for newer versions
mvn versions:display-dependency-updates -Dincludes="com.fmr.*,com.internal.*" 2>/dev/null

# Or search manually
mvn dependency:resolve -Dartifact=com.fmr.dp:dp-commons-jwt:LATEST 2>/dev/null
```

**Agent action:**
1. Find the latest version compatible with target Spring Boot
2. Update the version in pom.xml
3. Check for API changes between old and new version of the internal lib
4. Build and test

**Show developer:**
```
🏢 dp-commons-jwt: Upgrading 3.1.0 → 4.0.0 (compatible with SB 4.x)

  API Changes in 4.0.0:
    ✅ JwtValidator.validate(token) — same signature, no change
    ⚠️ JwtConfig.builder() — new required field: issuerUrl
    ❌ JwtTokenParser.parse(String) — REMOVED, use JwtValidator.decode(String)

  Files affected:
    src/.../security/TokenService.java (line 34: uses JwtTokenParser.parse)
    src/.../config/SecurityConfig.java (line 12: JwtConfig builder)

  I'll update both files. Approve?
```

### Scenario B: Internal Library Has NO Newer Version (Still on Old Spring)

**This is the #1 blocker.** Internal team hasn't released a version for the target Spring Boot yet.

**Agent action — ask user, then apply one of these strategies:**

```
⚠️ INTERNAL LIBRARY CONFLICT DETECTED

amt-fsf-rest 7.5.2 was compiled against Spring Boot 2.7 / Java 11.
Your target is Spring Boot 3.5 / Java 17.

This WILL cause runtime errors because amt-fsf-rest uses:
  - javax.servlet.http.HttpServletRequest (removed in SB3)
  - org.springframework.web.servlet.config (API changed in SB3)

Options:
  (a) EXCLUDE from upgrade — keep project on SB 2.7 until amt-fsf-rest is updated
  (b) SHIM IT — add javax compatibility bridge to make old library work temporarily
  (c) EXTRACT & INTERNALIZE — copy library source into project, fix javax→jakarta ourselves
  (d) SKIP THIS LIBRARY — upgrade everything else, exclude amt-fsf-rest from classpath
      (app will fail if amt-fsf-rest code is called at runtime)
  (e) CONTACT LIBRARY TEAM — I'll document what's needed and generate a request

Which approach? (I recommend (e) + (b) as interim)
```

**Strategy B-detail: SHIM (javax compatibility bridge):**
```xml
<!-- Add javax-to-jakarta bridge for legacy internal libraries -->
<!-- This lets old javax-compiled JARs work on Jakarta runtime -->
<dependency>
    <groupId>org.eclipse.transformer</groupId>
    <artifactId>org.eclipse.transformer</artifactId>
    <version>0.5.0</version>
    <scope>runtime</scope>
</dependency>

<!-- OR: Add javax API as provided scope alongside jakarta -->
<dependency>
    <groupId>javax.servlet</groupId>
    <artifactId>javax.servlet-api</artifactId>
    <version>4.0.1</version>
    <scope>provided</scope>
</dependency>
<!-- WARNING: This is a TEMPORARY workaround. Both javax and jakarta on classpath
     can cause confusion. Only use as bridge until internal lib is updated. -->
```

**Strategy C-detail: EXTRACT & INTERNALIZE:**
```bash
# 1. Download and extract internal library source (if available)
# 2. Copy relevant classes into project
# 3. Fix javax→jakarta imports in the copied code
# 4. Remove the external dependency
# 5. Update imports in project code to point to local classes

# Find which classes from internal lib are actually used:
grep -rn "import com\.fmr\.amt\.\|import com\.internal\." src/main/java/ --include="*.java" | sort -u
```

**Strategy E-detail: Generate request for library team:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 INTERNAL LIBRARY UPGRADE REQUEST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Library: amt-fsf-rest
Current Version: 7.5.2
Required By: [Project Name] — migrating to Spring Boot 3.5 / Java 17

What We Need:
  A version of amt-fsf-rest compiled against:
    - Spring Boot 3.x (Jakarta EE 10, jakarta.* namespace)
    - Java 17+ class target
    - Spring Security 6.x (if applicable)

Specific Conflicts Found:
  1. javax.servlet.http.HttpServletRequest → needs jakarta.servlet
  2. org.springframework.web.servlet.config.annotation (API changes)
  3. Class file version 55 (Java 11) — we need 61+ (Java 17)

APIs We Use From This Library:
  - FsfRestClient.get(url, headers)
  - FsfConfig.builder().baseUrl().timeout().build()
  - FsfResponseParser.parseJson(response, Type.class)

Timeline: Need by [date] to complete TLM compliance.
Contact: [developer email]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Scenario C: Internal Library Uses Transitive Dependencies That Conflict

**The sneaky one.** Internal lib version is correct, but it pulls in an OLD transitive dependency that conflicts.

```bash
# Find transitive conflicts
mvn dependency:tree -Dverbose 2>&1 | grep "omitted for conflict\|version managed"

# Find specific conflicts from internal libs
mvn dependency:tree -Dincludes=com.fmr -Dverbose 2>&1

# Check for duplicate classes on classpath
mvn dependency:analyze-duplicate 2>/dev/null
```

**Common conflicts and fixes:**

| Internal Lib Pulls In | Conflicts With | Fix |
|---|---|---|
| Old jackson-databind 2.13 | SB 3.x needs 2.15+ | Add `<exclusion>` and let SB BOM manage |
| Old spring-core 5.x | SB 3.x needs 6.x | Add `<exclusion>` — SB BOM provides correct version |
| javax.servlet-api 4.x | SB 3.x needs jakarta.servlet 6.x | Exclude javax, add jakarta |
| Old hibernate-core 5.x | SB 3.x needs 6.x | Exclude and let SB BOM manage |
| Old slf4j-api 1.x | SB 3.x needs 2.x | Exclude old, SB BOM provides 2.x |

**Fix pattern — exclusion + BOM management:**
```xml
<dependency>
    <groupId>com.fmr.dp</groupId>
    <artifactId>dp-commons-jwt</artifactId>
    <version>3.1.0</version>
    <exclusions>
        <!-- Exclude old transitive deps that conflict with Spring Boot 3.x -->
        <exclusion>
            <groupId>com.fasterxml.jackson.core</groupId>
            <artifactId>jackson-databind</artifactId>
        </exclusion>
        <exclusion>
            <groupId>org.springframework</groupId>
            <artifactId>spring-core</artifactId>
        </exclusion>
        <!-- Spring Boot BOM will provide the correct versions -->
    </exclusions>
</dependency>
```

**Show developer:**
```
🔍 TRANSITIVE CONFLICT DETECTED

dp-commons-jwt 3.1.0 pulls in jackson-databind 2.14.2
But Spring Boot 3.5.11 needs jackson-databind 2.17.0

Fix: Exclude jackson-databind from dp-commons-jwt.
Spring Boot BOM will provide 2.17.0 for the whole project.

⚠️ Risk: dp-commons-jwt was tested with 2.14.2.
         If it uses Jackson APIs removed in 2.17, it may fail at runtime.

I'll add the exclusion and run tests. If tests pass → safe.
If tests fail → we'll need dp-commons-jwt team to update.
```

### Scenario D: Internal Library Version is Correct But Has javax/jakarta Mismatch

```bash
# Check if internal JAR uses javax or jakarta
jar tf ~/.m2/repository/com/fmr/dp/dp-commons-jwt/3.1.0/dp-commons-jwt-3.1.0.jar | grep -E "javax/|jakarta/" | head -10

# If it shows javax/ paths but project needs jakarta — CONFLICT
```

**Fix: Use Eclipse Transformer to convert at build time:**
```xml
<!-- Maven plugin to transform javax→jakarta in dependent JARs -->
<plugin>
    <groupId>org.eclipse.transformer</groupId>
    <artifactId>transformer-maven-plugin</artifactId>
    <version>0.5.0</version>
    <executions>
        <execution>
            <goals><goal>jar</goal></goals>
            <configuration>
                <artifact>
                    <groupId>com.fmr.amt</groupId>
                    <artifactId>amt-fsf-rest</artifactId>
                </artifact>
            </configuration>
        </execution>
    </executions>
</plugin>
```

---

## Step 4: Validate After Internal Library Resolution

```bash
# 1. Clean build — no compile errors
mvn clean compile -q

# 2. Check for runtime class conflicts
mvn dependency:tree -Dverbose 2>&1 | grep "omitted for conflict"
# Should be empty or only safe conflicts

# 3. Run tests — catch runtime NoSuchMethodError
mvn test -q

# 4. Start the application — catch startup errors
mvn spring-boot:run &
sleep 30
# Check for errors in console output
# Kill the process after verification

# 5. Verify no javax/jakarta mix on classpath
mvn dependency:tree | grep "javax\.\(servlet\|persistence\|validation\)" 
# Should return NOTHING if fully migrated to jakarta
# If results found → these are from internal libs, need exclusion or shim
```

---

## Step 5: Document Resolution for Team

**After resolving each internal library conflict, update the plan:**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏢 INTERNAL LIBRARY RESOLUTION SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ dp-commons-jwt 3.1.0 → 4.0.0
   Strategy: Upgraded to SB4-compatible version
   Changes: Updated JwtConfig builder, replaced JwtTokenParser.parse
   Risk: Low — new version is official SB4 release

✅ fmr-commons-jwt 2.3.1 → REPLACED with dp-commons-jwt 4.0.0
   Strategy: EOL replacement using jsci-eol-retirement skill
   Changes: All fmr-commons-jwt imports replaced with dp-commons-jwt
   Risk: Low — dp-* is the official replacement

⚠️ amt-fsf-rest 7.5.2 → SHIMMED (temporary)
   Strategy: Added javax bridge + exclusions
   Changes: pom.xml exclusions, no code changes
   Risk: Medium — shim is temporary, needs library team update
   TODO: Library team contacted, request #TLM-2026-0234

❓ shared-logging 2.0.0 → VERIFIED COMPATIBLE
   Strategy: Tested with target Spring Boot — works
   Changes: None needed
   Risk: Low — uses SLF4J API only (no Spring dependency)

❓ config-client 1.5.3 → EXTRACTED SOURCE
   Strategy: Copied 3 classes into project, fixed javax→jakarta
   Changes: New package com.internal.config (local copy)
   Risk: Medium — must maintain local copy until library updated
   Files: src/main/java/com/internal/config/ConfigClient.java (3 files)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Rules for the Agent

1. **NEVER upgrade Spring Boot or Java without checking internal libraries first**
2. **ALWAYS build the compatibility matrix (Step 2) and show it in the plan**
3. **NEVER silently exclude an internal library** — always show the developer what's happening
4. **If an internal library will break → STOP and present options** (don't auto-fix)
5. **After resolving conflicts → run full test suite** — internal libs often fail at runtime, not compile time
6. **Document every resolution** — the team needs to know what was shimmed vs replaced vs extracted
7. **If NO resolution is possible → recommend staying on current version** until internal lib is updated — a partial migration that crashes is worse than no migration
8. **Save unresolved items as a separate TODO list** with library team contact info

---

## Integration with Other Java Skills

**This skill is called BY the other skills, not instead of them.**

Order of operations during any major upgrade:
1. **java-runtime-upgrade.md** → calls this skill at Step 0 (before changing Java version)
2. **spring-boot-upgrade.md** → calls this skill at Step 0 (before changing SB version)
3. **java-library-upgrades.md** → calls this skill for any library that has internal dependents
4. This skill resolves all conflicts → upgrades continue

**In tlm.agent.md workflow, this maps to:**
- Phase B (Plan): Show compatibility matrix
- Phase C (Execute): Resolve conflicts BEFORE upgrading public libraries
- Phase D (Validate): Verify no internal library runtime errors
