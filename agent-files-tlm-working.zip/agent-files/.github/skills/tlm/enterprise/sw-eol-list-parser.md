# Skill: Enterprise SW EOL List Parsing

## Skill Metadata

```yaml
name: sw-eol-list-parser
language: all
category: enterprise
type: enterprise
priority: high
estimated_complexity: simple
```

---

## Context

The enterprise maintains a **Software EOL (End of Life) List** spreadsheet that tracks all software TLM items across the organization. Developers may provide this list (or items from it) to the TLM Agent for automated fixing.

---

## Spreadsheet Format

The SW EOL List has these tabs:
- **SW EOL List** — Master list of all EOL software items
- **SW EOL Summary** — Aggregated view
- **Application Summary (TLM)** — Per-application breakdown
- **Application Summary (TLM) Pivot** — Pivot analysis
- **Charts** — Visual dashboard
- **TLM Item Count based on LT** — Counts by lead time

### SW EOL List Columns

| Column | Field | Description |
|---|---|---|
| A | Application ID | Enterprise application identifier (e.g., AP003033, AP158606) |
| B | Software Model | The software name and version (e.g., "AMT FSF Config Utils 7.5", "Python Software Foundation Python 3.10") |
| C | Campaign | Campaign type: "Non-Campaign", "EOL > 10 years" |
| D | Java Category | "Java", "Non-Java (.NET)", "Non-Java / Python", "Non-Java (JavaScript)" |
| E | SW EOL | Software End of Life date (e.g., 2026-06-30, "Past Due") |
| F | SWL EOL Timeline | Timeline quarter (e.g., "2026-Q2", "2026-Q4", "Past Due") |
| G | Source | Data source: "FMR" or "BDNA" |
| H-K | Product Manager, Development Lead | Owner information |

### Known Software Models in the List

| Software Model | Java Category | EOL | What It Means |
|---|---|---|---|
| AMT FSF Config Utils 7.5 | Java | 2026-06-30 | Enterprise framework component upgrade |
| AMT FSF Identity 7.5 | Java | 2026-06-30 | Enterprise identity library upgrade |
| AMT FSF Rest 7.5 | Java | 2026-06-30 | Enterprise REST framework upgrade |
| AMT FSF Secret 7.5 | Java | 2026-06-30 | Enterprise secrets management upgrade |
| AMT FSF Usage Metrics 7.5 | Java | 2026-06-30 | Enterprise metrics library upgrade |
| Python Software Foundation Python 3.10 | Non-Java / Python | 2026-10-01 | Python runtime upgrade |
| Microsoft ASP.NET 4.0 | Non-Java (.NET) | Past Due | .NET framework upgrade (overdue) |
| Apache Hadoop * | Java | Past Due | Hadoop library upgrades (overdue) |

---

## How the Agent Uses This

### When User Provides EOL List Items

The user can provide items from this list in several ways:

**1. Paste from spreadsheet:**
```
AMT FSF Config Utils 7.5, Java, 2026-06-30
AMT FSF Rest 7.5, Java, 2026-06-30
Python Software Foundation Python 3.10, Non-Java / Python, 2026-10-01
```

**2. Provide the CSV/Excel file:**
The full spreadsheet exported as CSV.

**3. Just list the software names:**
```
Fix these: AMT FSF Config Utils 7.5, AMT FSF Rest 7.5, AMT FSF Secret 7.5
```

### Agent Behavior

1. **Parse the items** — extract software name, version, EOL date
2. **Map to project dependencies** — find matching dependencies in pom.xml/package.json
3. **Check for enterprise skills** — see if we have a skill for this specific component
4. **Determine upgrade path:**
   - Enterprise component (AMT FSF) → check enterprise skills or ask for guidance
   - Open-source library → use agent knowledge to upgrade
   - Runtime (Python, Java) → use runtime upgrade skills
5. **Show plan with EOL context:**
   ```
   📋 EOL Items Matched to Your Project:
   
   ⏰ PAST DUE:
     🔴 Apache Hadoop Common 2.7 — EOL passed, upgrade urgently
   
   ⏰ UPCOMING (2026-Q2):
     🟠 AMT FSF Config Utils 7.5 — EOL June 2026
     🟠 AMT FSF Rest 7.5 — EOL June 2026
   
   ⏰ UPCOMING (2026-Q4):
     🟡 Python 3.10 — EOL October 2026
   ```

6. **Fix in priority order** — Past Due first, then by EOL date

---

## Integration with TLM Agent Menu

When the SW EOL list is detected or provided, show in the dashboard:
```
📋 SW EOL LIST DETECTED
  Items provided: 15
  Matched to project: 8
  Past Due: 2 (urgent)
  Upcoming Q2: 4
  Upcoming Q4: 2
```

And in the menu:
```
[6] 📋 Fix from EOL List
    8 items from your SW EOL list match this project.
    2 are PAST DUE (fix urgently).
    I'll fix them in priority order by EOL date.
```
