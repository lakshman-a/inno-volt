# TLM Skill Template

> **Copy this template to create a new skill.** Save it as a `.md` file in the appropriate folder under `.github/skills/tlm/`.

---

## Skill Metadata

```yaml
name: [skill-name]                    # e.g., spring-boot-3-upgrade
language: [java|angular|python|node]  # target language
category: [framework|library|runtime|enterprise|security]
type: [recipe|agent|enterprise]       # recipe = App Mod recipe exists, agent = use agent mode, enterprise = internal library
priority: [critical|high|medium|low]
source_library: [groupId:artifactId]  # e.g., org.springframework.boot:spring-boot-starter-parent
from_version: [version or range]      # e.g., 2.x or 2.7.x
to_version: [target version]          # e.g., 3.2.5
app_mod_recipe: [true|false]          # Does App Modernization extension have a recipe for this?
estimated_complexity: [simple|moderate|complex]
```

---

## Prerequisites

<!-- List what must be true BEFORE this upgrade can be applied -->

- [ ] Prerequisite 1 (e.g., Java 17+ must be installed)
- [ ] Prerequisite 2 (e.g., Spring Boot must be upgraded first)
- [ ] Prerequisite 3

---

## Upgrade Steps

<!-- Step-by-step instructions the agent should follow -->

### Step 1: [Title]

**What to do:**
<!-- Describe the change -->

**Files affected:**
<!-- List files or patterns -->

**Code change:**
```
BEFORE:
[show the old code/config pattern]

AFTER:
[show the new code/config pattern]
```

### Step 2: [Title]

**What to do:**

**Files affected:**

**Code change:**
```
BEFORE:

AFTER:
```

<!-- Add as many steps as needed -->

---

## Import / Package Changes

<!-- List all import or package renames -->

| Old Import/Package | New Import/Package |
|---|---|
| `old.package.ClassName` | `new.package.ClassName` |

---

## API Changes

<!-- List all API/method signature changes -->

| Old API | New API | Notes |
|---|---|---|
| `OldClass.oldMethod(param)` | `NewClass.newMethod(param)` | Description of change |

---

## Configuration Changes

<!-- List all config property changes (application.yml, application.properties, etc.) -->

| Old Property | New Property | Notes |
|---|---|---|
| `old.config.key` | `new.config.key` | Description |

---

## Common Errors & Fixes

<!-- List errors developers commonly see after this upgrade and how to fix them -->

| Error Message | Cause | Fix |
|---|---|---|
| `Cannot find symbol XYZ` | Removed in new version | Replace with ABC |
| `Incompatible types` | API return type changed | Cast or update type |

---

## Build Verification

<!-- How to verify the upgrade worked -->

```bash
# Command to verify
mvn clean compile
# or
npm run build
```

**Expected result:** Clean compilation with 0 errors.

---

## Test Considerations

<!-- What tests might break and how to fix them -->

- Tests using `OldClass` mock → update to `NewClass`
- Configuration tests → update property names
- Integration tests → may need updated test containers/versions

---

## Reference Documentation

<!-- Links to official migration guides, changelogs, Confluence pages, etc. -->

- Official guide: [URL]
- Changelog: [URL]
- Internal doc: [Confluence URL] (for enterprise skills)

---

## Notes

<!-- Any additional context, warnings, or tips -->
