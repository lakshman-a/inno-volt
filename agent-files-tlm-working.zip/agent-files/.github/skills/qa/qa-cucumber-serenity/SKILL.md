---
name: PLACEHOLDER
description: "ACTION REQUIRED: Copy your existing QA agent skill file content here."
agent: qa-automation
---

# Placeholder — Populate from Existing QA Agent

Copy the corresponding skill content from your existing QA agent into this file.

See `README.md > File Placement Guide` for exact mapping.
