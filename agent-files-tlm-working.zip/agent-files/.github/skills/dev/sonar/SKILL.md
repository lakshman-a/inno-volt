---
name: sonar-fix
description: SonarQube issue resolution — fetch from Sonar API via terminal curl, local pattern scan, fix strategies for bugs/vulnerabilities/code smells/complexity. Java, Angular, Python.
agent: sr-developer
language: all
triggers:
  - "sonar"
  - "code smell"
  - "bug fix"
  - "vulnerability"
  - "cognitive complexity"
---

# Sonar Fix Skill

## WHEN TO USE
- User selects [1] Fix Sonar Issues from menu
- User says "fix sonar", "sonar issues", "code smells", "scan for bugs"

---

## SONAR API INTEGRATION (via Terminal curl)

Copilot cannot call APIs directly. Use `runCommands` tool to execute curl in terminal.

### Authentication
```bash
# Bearer auth (preferred)
curl -s -H "Authorization: Bearer {TOKEN}" "{SONAR_URL}/api/system/status"

# Basic auth fallback (if Bearer returns 401)
TOKEN_BASE64=$(echo -n "{TOKEN}:" | base64)
curl -s -H "Authorization: Basic ${TOKEN_BASE64}" "{SONAR_URL}/api/system/status"
```

### Configuration
Read from `.github/config/sonar-config.json`:
```json
{ "sonarUrl": "https://sonar.fmr.com", "projectKey": "", "branch": "develop", "token": "" }
```
If token empty → ask user once. If file missing → ask for all details.

### API Call 1 — Validate Connection
```bash
curl -s -H "Authorization: Bearer {TOKEN}" "{SONAR_URL}/api/system/status"
# Expected: {"version":"10.8.1","status":"UP"}
```

### API Call 2 — Validate Project
```bash
curl -s -H "Authorization: Bearer {TOKEN}" "{SONAR_URL}/api/components/show?component={PROJECT_KEY}"
```

### API Call 3 — Project Metrics (Dashboard Numbers)
```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "{SONAR_URL}/api/measures/component?component={PROJECT_KEY}&branch={BRANCH}&metricKeys=bugs,vulnerabilities,code_smells,coverage,ncloc,sqale_index,cognitive_complexity,security_hotspots,duplicated_lines_density,reliability_rating,security_rating,sqale_rating"
```
sqale_index = minutes (÷60 for hours). Ratings: 1.0=A, 2.0=B, 3.0=C, 4.0=D, 5.0=E.

### API Call 4 — Fetch All Issues (Paginated, max 500/page)
```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "{SONAR_URL}/api/issues/search?componentKeys={PROJECT_KEY}&branch={BRANCH}&types=BUG,VULNERABILITY,CODE_SMELL&severities=BLOCKER,CRITICAL,MAJOR&statuses=OPEN,CONFIRMED,REOPENED&resolved=false&ps=500&p={PAGE}&additionalFields=_all&facets=types,severities,rules"
```
Loop incrementing `p` until `issues.length < 500`.
Key fields: `rule`, `type`, `severity`, `message`, `line`, `textRange`, `component` (resolve path from `components` array).

### API Call 5 — Source Code (Optional)
```bash
curl -s -H "Authorization: Bearer {TOKEN}" "{SONAR_URL}/api/sources/raw?key={COMPONENT_KEY}&branch={BRANCH}"
```

---

## LOCAL SCAN (No Sonar Connection)

Pattern-match across all source files:

### Java Patterns
| Pattern | Rule | Severity |
|---|---|---|
| `System.out.print` | java:S106 | MAJOR |
| `.printStackTrace()` | java:S1148 | MAJOR |
| `"password"`, `"secret"`, `"api_key"` in literals | java:S2068 | BLOCKER |
| `MessageDigest.getInstance("MD5")` or `"SHA1"` | java:S4790 | CRITICAL |
| `http://` in literals (non-test) | java:S5332 | MAJOR |
| `==` between String variables | java:S1698 | CRITICAL |
| `catch (Exception e) { }` (empty catch) | java:S108 | MAJOR |
| `catch (Exception e)` (generic) | java:S2221 | MAJOR |
| Magic numbers (non 0,1,-1) | java:S109 | MINOR |
| Unused private fields | java:S1068 | MINOR |
| Methods with complexity > 15 | java:S3776 | CRITICAL |
| Files > 300 lines | custom | MAJOR |

### Angular/TypeScript Patterns
| Pattern | Severity |
|---|---|
| `console.log` in non-test files | MAJOR |
| `any` type usage | MAJOR |
| Empty `catch` blocks | MAJOR |
| Hardcoded URLs/tokens | BLOCKER |
| `subscribe()` without unsubscribe | MAJOR |

### Python Patterns
| Pattern | Severity |
|---|---|
| `print()` in non-test files | MAJOR |
| `except:` or `except Exception:` (bare) | MAJOR |
| Hardcoded secrets | BLOCKER |
| `import *` | MAJOR |

---

## FIX STRATEGIES BY RULE

### Vulnerabilities (BLOCKER/CRITICAL — Fix First)

**java:S2068 — Hardcoded Credentials**
```java
// BEFORE: String password = "admin123";
// AFTER:  @Value("${db.password}") private String password;
//   OR:   String password = System.getenv("DB_PASSWORD");
```

**java:S4790 — Weak Crypto** → Replace MD5/SHA1 with SHA-256

**java:S5332 — HTTP** → Change to HTTPS

**java:S2095 — Resource Leak** → try-with-resources

**java:S3649 — SQL Injection** → PreparedStatement with `?` params

### Bugs (CRITICAL — Fix Second)

**java:S2259 — Null Pointer** → null checks, Optional, or early return

**java:S1168 — Return Null for Collection** → `return Collections.emptyList()`

**java:S1698 — == for Strings** → `"ACTIVE".equals(status)`

### Code Smells (MAJOR — Fix Third)

**java:S106 — System.out** → SLF4J Logger:
```java
private static final Logger logger = LoggerFactory.getLogger(ClassName.class);
logger.info("Processing order: {}", orderId);
```

**java:S1148 — printStackTrace** → `logger.error("Failed: {}", fileName, e);`

**java:S109 — Magic Number** → Extract to `private static final` constant

**java:S2221 — Catch Generic Exception** → Catch specific exceptions

### Cognitive Complexity (java:S3776 — HARDEST)

Apply in order:
1. **Guard clauses** — early returns to flatten nesting
2. **Extract booleans** — `boolean isEligible = condition1 && condition2;`
3. **Extract methods** — private helpers in same class
4. **Replace if-else chains** — `Map<String, Runnable>` or switch

**Rules:** NEVER change external behavior. Keep helpers private. Test before AND after.

---

## FIX WORKFLOW

### Execution Order
1. BLOCKER vulnerabilities → 2. CRITICAL bugs → 3. MAJOR code smells → 4. Cognitive complexity

### Per-File Process
1. Read entire source file
2. Identify ALL issues for this file
3. Apply ALL fixes at once
4. `mvn compile -DskipTests` (max 3 retries)
5. If 3 fail → rollback → skip file
6. After all files: `mvn clean compile` then `mvn test`

### Plan File
Generate `sonar-fix-plan.md`:
```markdown
| # | Fix? | Severity | Rule | File | Line | Description |
|---|------|----------|------|------|------|-------------|
| 1 | [Y] | BLOCKER | java:S2068 | DatabaseConfig.java | 45 | Hardcoded password |
| 2 | [Y] | CRITICAL | java:S2259 | OrderService.java | 120 | Null pointer |
```
User edits Y/N, then says "proceed".

---

## REPORTING
```
🔍 SONAR FIX — COMPLETE
Issues Found: X | Fixed: Y | Skipped: Z | Failed: W
Build: ✅ PASSED | Tests: ✅ X passed, 0 new failures
Files Changed: N | Time: ~M min (manual estimate: ~H hours)
```
