---
name: feature-design
description: Feature planning — requirements to design doc, API contracts, data models, sequence diagrams, implementation plans. Design-only or design-then-implement.
agent: sr-developer
language: all
triggers:
  - "new feature"
  - "design"
  - "implement"
  - "plan feature"
---

# Feature Design Skill

## INPUT
Accept: Jira story, requirement doc, verbal description, API spec, user story format.

## DESIGN DOCUMENT (Always Produce First — WAIT FOR APPROVAL)

Template sections:
1. **Overview** — what and why
2. **Scope** — in/out of scope
3. **API Contract** — endpoints, methods, request/response JSON, error codes
4. **Data Model** — entities, DTOs, field types
5. **Sequence Diagram** — Mermaid format
6. **Security** — auth, input validation, data protection
7. **Error Handling** — how errors are caught, logged, returned
8. **Implementation Plan** — ordered file list with complexity estimates

## IMPLEMENTATION (After Approval)
Order: Entity → DTO → Mapper → Repository → Service → Controller → Exception classes → Unit tests (service + controller) → application.yml updates.

Rules: Follow existing conventions. Add Javadoc. Use @Valid. Use ResponseEntity. Add logging. Never hardcode.

After: `mvn clean compile` + `mvn test` — all must pass.

## DESIGN-ONLY MODE
If user picks design-only: produce full doc, no code. Offer "say 'implement' when ready."
