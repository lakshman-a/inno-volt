---
name: code-review-refactoring
description: Code review checklist (security, performance, SOLID) and refactoring patterns (extract method, split class, strategy). Zero logic changes.
agent: sr-developer
language: all
triggers:
  - "refactor"
  - "code review"
  - "complexity"
  - "SOLID"
---

# Code Review & Refactoring Skill

## CODE REVIEW CHECKLIST

### Security
- Input validation on all external inputs
- No hardcoded credentials/secrets
- SQL injection prevention (parameterized queries)
- Auth checks on all endpoints
- HTTPS enforced, no sensitive data in logs

### Performance
- No N+1 queries (use @EntityGraph / JOIN FETCH)
- No object creation in loops, caching for expensive ops
- Pagination for list endpoints, connection pooling

### Error Handling
- Specific exceptions (not generic Exception)
- Meaningful messages with context, proper logging
- No empty catch blocks, no swallowed exceptions

### SOLID Principles
- Single Responsibility: each class/method does one thing
- Open/Closed: extensible without modifying
- Liskov Substitution, Interface Segregation, Dependency Inversion

### Naming & Readability
- Meaningful names, consistent conventions
- Methods < 30 lines, classes < 300 lines, complexity < 15

## REFACTORING PATTERNS

**Extract Method:** Method > 30 lines → split into focused helpers.
**Extract Class:** Class > 300 lines or >5 responsibilities → split by responsibility.
**Replace Conditional with Strategy:** Long if-else → `Map<String, Handler>`.
**Introduce Parameter Object:** >3 params → request object.

## REFACTORING RULES
1. ZERO logic changes — same inputs = same outputs
2. Run tests BEFORE refactoring (baseline)
3. Show plan → WAIT FOR APPROVAL
4. Apply one refactoring at a time → compile → test
5. ALL existing tests must pass after

## OUTPUT FORMAT
```
📊 CODE REVIEW — {ClassName}
🔴 CRITICAL: [must fix items]
🟠 IMPORTANT: [should fix items]
🟡 SUGGESTIONS: [nice to have]
📊 SCORES: Security X/10, Performance Y/10, Readability Z/10
```
