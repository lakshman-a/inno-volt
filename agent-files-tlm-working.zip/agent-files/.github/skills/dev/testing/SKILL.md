---
name: unit-test-generation
description: Unit test generation for Java (JUnit 5 + Mockito + AssertJ), Angular (Jest/Jasmine), Python (pytest). JaCoCo integration, coverage gap analysis, compile validation loop, 90%+ target.
agent: sr-developer
language: all
triggers:
  - "unit test"
  - "write tests"
  - "JUnit"
  - "Mockito"
  - "coverage"
---

# Unit Test Generation Skill

## PIPELINE
```
1. Detect test framework & Java version
2. Set JAVA_HOME to matching JDK
3. Inject JaCoCo plugin if missing
4. Run baseline: mvn clean test jacoco:report
5. Parse jacoco.xml → per-class coverage %
6. Prioritize: lowest coverage first, skip >80%
7. Per class: read → analyze deps → generate → compile → run → validate
8. Final coverage run → report delta
```

---

## STEP 1: DETECT & CONFIGURE

### Java
```bash
grep -A1 "maven.compiler.source" pom.xml    # or java.version
export JAVA_HOME=/usr/lib/jvm/java-{8|11|17|21}-openjdk-amd64
```

Detect from pom.xml: `junit:junit` → JUnit 4, `org.junit.jupiter` → JUnit 5, `org.mockito` → Mockito.
**Default if none found:** Add JUnit 5 + Mockito + AssertJ.

### Angular: `grep -E "jest|jasmine|karma" package.json`
### Python: `grep -E "pytest|unittest" requirements.txt pyproject.toml`

---

## STEP 2: INJECT JACOCO (if missing)

Check: `grep -c "jacoco-maven-plugin" pom.xml`
If 0, inject:
```xml
<plugin>
  <groupId>org.jacoco</groupId><artifactId>jacoco-maven-plugin</artifactId><version>0.8.12</version>
  <executions>
    <execution><goals><goal>prepare-agent</goal></goals></execution>
    <execution><id>report</id><phase>test</phase><goals><goal>report</goal></goals></execution>
  </executions>
</plugin>
```
For multi-module: inject in parent `<pluginManagement>` AND each module's `<plugins>`.

---

## STEP 3: BASELINE

```bash
mvn clean test jacoco:report 2>&1 | tail -20
```
Parse `target/site/jacoco/jacoco.xml`:
`<counter type="LINE" missed="X" covered="Y"/>` → coverage = Y/(X+Y)*100

---

## STEP 4: PRIORITIZE

Sort by coverage ascending. Skip >80%.
Priority: services > controllers > repositories > utilities > DTOs/models.
Skip: getters/setters, auto-generated, framework code.

---

## STEP 5: GENERATE (per class)

### Read Context
1. Full source code of target class
2. Dependency interfaces (from imports) — for mock setup
3. Entity/DTO classes — for test data
4. Existing test file — match style

### Naming: `{ClassName}GenTest.java` — avoids conflict with existing tests.

### Java Pattern (JUnit 5 + Mockito + AssertJ)
```java
@ExtendWith(MockitoExtension.class)
class OrderServiceGenTest {
    @Mock private OrderRepository orderRepository;
    @Mock private PaymentService paymentService;
    @InjectMocks private OrderService orderService;

    @Test
    @DisplayName("createOrder - valid order - returns created order")
    void createOrder_validOrder_returnsCreatedOrder() {
        // Arrange
        Order order = buildValidOrder();
        when(orderRepository.save(any())).thenReturn(order);
        // Act
        Order result = orderService.createOrder(order);
        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(OrderStatus.CREATED);
        verify(orderRepository).save(order);
    }

    @Test
    @DisplayName("createOrder - null order - throws IllegalArgumentException")
    void createOrder_null_throwsException() {
        assertThatThrownBy(() -> orderService.createOrder(null))
            .isInstanceOf(IllegalArgumentException.class);
    }

    private Order buildValidOrder() {
        return Order.builder().id(1L).customerId(100L)
            .items(List.of(new OrderItem("SKU-001", 2, BigDecimal.TEN))).build();
    }
}
```

### What TO Test
Happy path, edge cases (null/empty/boundary), error paths, branch coverage, mock interaction verification.

### What NOT to Test
Getters/setters (unless logic), framework-generated code, third-party internals, private methods directly.

### Mocking Rules
Mock: external deps (DB, HTTP, filesystem). Don't mock: class under test, simple DTOs.
Use ArgumentCaptor for complex argument verification. Use @Spy only for partial mocking.

### Angular (Jest/Jasmine)
```typescript
describe('OrderComponent', () => {
  let component: OrderComponent;
  let fixture: ComponentFixture<OrderComponent>;
  let orderService: jasmine.SpyObj<OrderService>;
  beforeEach(async () => {
    orderService = jasmine.createSpyObj('OrderService', ['getOrders']);
    await TestBed.configureTestingModule({
      declarations: [OrderComponent],
      providers: [{ provide: OrderService, useValue: orderService }]
    }).compileComponents();
    fixture = TestBed.createComponent(OrderComponent);
    component = fixture.componentInstance;
  });
  it('should load orders on init', () => {
    orderService.getOrders.and.returnValue(of([mockOrder]));
    fixture.detectChanges();
    expect(component.orders.length).toBe(1);
  });
});
```

### Python (pytest)
```python
class TestOrderService:
    def setup_method(self):
        self.repo = Mock()
        self.service = OrderService(self.repo)
    def test_create_order_valid(self):
        self.repo.save.return_value = build_order()
        result = self.service.create_order(build_order())
        assert result is not None
        self.repo.save.assert_called_once()
    def test_create_order_none_raises(self):
        with pytest.raises(ValueError):
            self.service.create_order(None)
```

---

## STEP 6: COMPILE & VALIDATE (per class)

```bash
mvn test-compile 2>&1          # If fails → send error to LLM → retry (max 3)
mvn test -Dtest={TestName} 2>&1 # If fails → send failures → retry (max 3)
# If still failing after 3 → remove broken test, log "needs manual"
```

---

## STEP 7: FINAL COVERAGE

```bash
mvn clean test jacoco:report
```
If <90%: analyze gaps → if code issues block testing → fix code first → re-test.

---

## COVERAGE TARGETS
| Metric | Target |
|---|---|
| Line | 90%+ |
| Branch | 80%+ |
| Critical services | 95%+ |

---

## REPORTING
```
🧪 UNIT TEST GENERATION — COMPLETE
Baseline: X% line | Y% branch
Final:    X% line | Y% branch  (delta: +Z%)
Classes: N processed | M green | K manual review
Tests: T new | P passed | F manual fix
Time: ~M min (manual: ~H hours)
```
