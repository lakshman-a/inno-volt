---
name: enterprise-scaffolding
description: Enterprise project scaffolding — Spring Boot 3.x, Angular 17+, Python FastAPI. CI/CD, Docker, Sonar, security, logging, test setup.
agent: sr-developer
language: all
triggers:
  - "scaffold"
  - "new project"
  - "create project"
---

# Enterprise Scaffolding Skill

## INPUT
Ask: Language, framework version, project name, package/group, required modules (security, DB, messaging, caching), Java version (17/21).

---

## JAVA SPRING BOOT 3.x

### Structure
```
{name}/
├── pom.xml                              ← BOM, deps, JaCoCo, build plugins
├── Dockerfile                           ← Multi-stage, non-root
├── docker-compose.yml                   ← Local dev (DB, Redis)
├── Jenkinsfile                          ← CI/CD
├── README.md                            ← Setup, run, test, deploy
├── sonar-project.properties
├── .gitignore
├── src/main/java/{pkg}/
│   ├── Application.java
│   ├── config/ (SecurityConfig, WebConfig, CacheConfig, SwaggerConfig)
│   ├── controller/ (HealthController)
│   ├── service/
│   ├── repository/
│   ├── model/ (entity/, dto/, mapper/)
│   ├── exception/ (GlobalExceptionHandler, BusinessException, ErrorResponse)
│   └── util/
├── src/main/resources/
│   ├── application.yml, application-dev.yml, application-qa.yml, application-prod.yml
│   └── logback-spring.xml
└── src/test/java/{pkg}/ApplicationTest.java
```

### Key Patterns
- **SecurityConfig:** SecurityFilterChain pattern (not deprecated WebSecurityConfigurerAdapter)
- **GlobalExceptionHandler:** @ControllerAdvice with specific exception handlers
- **Logging:** SLF4J with logback-spring.xml, structured JSON in prod
- **Validation:** @Valid on request bodies, MethodArgumentNotValidException handler
- **API docs:** springdoc-openapi-starter-webmvc-ui 2.3+

### POM Dependencies
Core: spring-boot-starter-web, actuator, validation. Security: spring-boot-starter-security. Data: spring-boot-starter-data-jpa + flyway-core. Cache: spring-boot-starter-data-redis. Docs: springdoc-openapi. Utils: lombok, mapstruct. Test: spring-boot-starter-test, mockito, assertj.

---

## ANGULAR 17+

### Structure
```
{name}/
├── angular.json, package.json, tsconfig.json
├── Dockerfile, Jenkinsfile, README.md, .eslintrc.json, .prettierrc
├── src/app/
│   ├── core/ (auth/, interceptors/, services/api.service.ts)
│   ├── shared/ (components/, pipes/, directives/)
│   ├── features/ (lazy-loaded modules)
│   ├── app.component.ts, app.config.ts, app.routes.ts
├── src/environments/ (environment.ts, .dev.ts, .qa.ts, .prod.ts)
```

Features: Standalone components, lazy routes with loadComponent, functional interceptors, signals state, Jest testing, ESLint+Prettier+Husky.

---

## PYTHON FASTAPI

### Structure
```
{name}/
├── pyproject.toml, Dockerfile, README.md
├── src/{pkg}/ (main.py, config.py, api/, models/, services/, core/)
├── tests/ (conftest.py, test_api.py)
└── alembic/ (DB migrations)
```

---

## ALWAYS INCLUDE
1. Dockerfile (multi-stage, non-root)
2. Jenkinsfile or GitHub Actions
3. README.md (prerequisites, setup, run, test)
4. .gitignore
5. Sonar config
6. JaCoCo/coverage config
7. At least one passing test
8. Environment configs (dev/qa/prod)
9. Structured logging
10. Global exception handler

## AFTER SCAFFOLD
Build and verify: `mvn clean package` / `npm run build` / `pytest`. Show structure + next steps.
