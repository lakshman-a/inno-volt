# Agent Architecture Guide for Claude-Based Copilot Agents

## A Practical Blueprint

---

## Part 1: Why Your Agents Drift (Root Cause Analysis)

Before jumping into patterns, let's understand WHY your agents hallucinate, skip steps, and exhaust context windows. Every problem you described maps to a specific architectural mistake:

| Symptom | Root Cause | Fix |
|---------|-----------|-----|
| Agent skips steps | Too many rules competing for attention | Prioritize with hierarchy + phase gates |
| Hallucinated versions | No verification checkpoint enforced | Use BLOCKING gates, not advisory notes |
| Context window exhaustion | Skills/agent files too large (800+ lines) | Decompose; one file per concern |
| Rules ignored late in file | Attention decay after ~300 lines | Front-load critical rules; move details to skills |
| Findings keep expanding files | Append-only knowledge pattern | Use a "known issues" JSON registry instead |
| Copilot writes verbose updates | No update template/constraints | Give Copilot a structured update format |

### The Core Insight

Claude models process instructions with **positional attention bias**:
- **Lines 1–50**: Very high attention (95%+ recall)
- **Lines 50–150**: Good attention (80–90%)
- **Lines 150–300**: Moderate attention (60–75%)
- **Lines 300–500**: Declining attention (40–55%)
- **Lines 500+**: Significant attention drop — rules here get missed frequently

**This is why your 800-line agent files hallucinate.** The rules at line 600+ are essentially invisible during complex multi-step tasks.

---

## Part 2: The Layer Architecture (What Goes Where)

Think of your agent system as 4 layers, each with a specific purpose and size budget:

```
┌─────────────────────────────────────────────────┐
│  Layer 1: AGENT FILE (.agent.md)                │  ← Identity + Routing
│  Target: 80–150 lines MAX                       │     "WHO am I, WHAT do I do, WHERE do I look"
├─────────────────────────────────────────────────┤
│  Layer 2: INSTRUCTIONS (.instructions.md)       │  ← Workflow + Process
│  Target: 100–200 lines per file                 │     "HOW do I execute step by step"
├─────────────────────────────────────────────────┤
│  Layer 3: SKILLS (SKILL.md)                     │  ← Domain Knowledge + Templates
│  Target: 150–300 lines per skill                │     "WHAT exactly do I produce"
├─────────────────────────────────────────────────┤
│  Layer 4: CONFIG (JSON/YAML)                    │  ← Data + Learnings
│  Target: Structured, machine-parseable          │     "WHAT do I know from past runs"
└─────────────────────────────────────────────────┘
```

### Layer 1: Agent File — The Router (80–150 lines)

The agent file should be THIN. It defines identity, critical rules, and routing. It should NEVER contain implementation details, templates, or lengthy examples.

**Template:**

```markdown
---
name: FI-[Agent-Name]
description: [One sentence. What it does, what tech it covers.]
tools: ['codebase', 'editFiles', 'runCommands', 'search', 'fetch', 'problems']
model: ['Claude Sonnet 4.5']
version: '1'
disclaimer: '[Compliance note]'
---

# [Agent Name] — [One-Line Purpose]

## IDENTITY (3–5 lines)
> [Role description. What persona. What expertise level.]

**SHARED RULES:** Follow `.github/copilot-instructions.md` and `.github/common/*` files.

---

## CRITICAL RULES (5–8 max, front-loaded)

1. **[Most important rule]** — [one line explanation]
2. **[Second most important]** — [one line]
3. **[Verification rule]** — [one line]
4. **[Safety/blocking rule]** — [one line]
5. **[Output quality rule]** — [one line]

> Rules are numbered by priority. Rule 1 overrides all others if conflict.

---

## TASK FLOW (Phase list only — details in skills)

| Phase | Name | Skill/Instruction | Blocking? |
|-------|------|-------------------|-----------|
| 0 | Workspace Validation | *inline — 3 steps* | Yes |
| 0.5 | Maven Config Detection | `skills/[path]/SKILL.md` | Yes |
| 1 | Version Detection | `skills/[path]/SKILL.md` | Yes |
| 2 | Plan Generation | `instructions/[path].md` | Yes |
| 3 | Execution | *routes to skills per item type* | No |
| 4 | Validation | `skills/[path]/SKILL.md` | Yes |
| 5 | Report | `instructions/[path].md` | No |

---

## SKILL ROUTING TABLE

| Option | Skill Path | When Used |
|--------|-----------|-----------|
| Spring Boot Upgrade | `skills/[path]/SKILL.md` | Options 2, 4 |
| Java Runtime Upgrade | `skills/[path]/SKILL.md` | Options 2, 3 |
| ... | ... | ... |

---

## GLOBAL COMMANDS (Menu/trigger table only)

| Trigger | Action |
|---------|--------|
| "hi" / "menu" | Auto-scan → show menu |
| "scan" | Phase 0 only |
| "fix all" | Phase 0 → 5 |
| ... | ... |

---

## KNOWN ISSUES REGISTRY
**READ:** `.github/config/known-issues.json`
*Never inline known issues here. Always reference the JSON file.*
```

**What you moved OUT of the agent file:**
- Version detection rules → `skills/tlm/version-detection/SKILL.md`
- Command reference tables → `instructions/commands.md`
- Severity classification → `skills/tlm/severity/SKILL.md`
- All templates (POM, code) → respective skill files
- Known issues / learnings → `config/known-issues.json`

### Layer 2: Instructions — The Process (100–200 lines each)

Instructions define HOW to execute a workflow. They are procedural, step-by-step, and should read like a checklist.

**Template:**

```markdown
---
name: [instruction-name]
description: [When this instruction applies]
---

# [Process Name]

## WHEN TO USE
[1–2 lines: trigger condition]

## PRE-CONDITIONS
- [ ] [What must be true before starting]
- [ ] [What must be true before starting]

## STEPS

### Step 1: [Action Name]
- DO: [specific action]
- VERIFY: [how to check it worked]
- IF FAIL: [what to do]

### Step 2: [Action Name]
- DO: [specific action]
- VERIFY: [how to check it worked]
- IF FAIL: [what to do]

## OUTPUT FORMAT
[What the user should see when done]

## KNOWN EDGE CASES
**READ:** `config/known-issues.json` filtered by `category: "[this-process]"`
```

### Layer 3: Skills — The Knowledge (150–300 lines each)

Skills contain domain-specific knowledge, templates, and exact specifications. This is WHERE you put POM templates, code patterns, and detailed rules.

**Template:**

```markdown
---
name: [skill-name]
description: [Concise trigger description — this is what routes to this skill]
---

# [Skill Name]

## WHEN THIS SKILL IS USED
[1 line: which phase/option triggers this]

## QUICK REFERENCE (Decision Table)
| Situation | Action |
|-----------|--------|
| [condition] | [action] |
| [condition] | [action] |

## PROCEDURE

### Step 1: [Name]
[Detailed instructions with exact commands]

### Step 2: [Name]
[Detailed instructions]

## TEMPLATES
[Exact POM snippets, code templates, etc. — THIS is where they belong]

## ANTI-PATTERNS (Never Do)
1. [mistake] — [why it breaks]
2. [mistake] — [why it breaks]

## VERIFICATION
[How to confirm this skill executed correctly]
```

### Layer 4: Config — The Memory (Structured JSON)

This is the KEY to solving your "files keep growing" problem. Instead of appending findings as prose to skill files, store them as structured data.

**`config/known-issues.json` Template:**

```json
{
  "version": "2.1",
  "last_updated": "2025-03-14",
  "issues": [
    {
      "id": "KI-001",
      "category": "version-detection",
      "trigger": "commons-io detected as 2.11.0 but actual is 2.15.1",
      "root_cause": "Parent POM pins version via dependencyManagement",
      "fix": "Always check effective POM: mvn help:effective-pom | grep commons-io",
      "added": "2025-02-10",
      "severity": "high",
      "verified": true
    },
    {
      "id": "KI-002",
      "category": "build-execution",
      "trigger": "PKIX path building failed",
      "root_cause": "Corporate proxy certificate not in JDK truststore",
      "fix": "Rerun Maven Config Detection skill to regenerate settings.xml",
      "added": "2025-02-15",
      "severity": "critical",
      "verified": true
    }
  ]
}
```

**Why JSON instead of prose:**
1. **Parseable** — the agent can filter by category, severity, trigger pattern
2. **Bounded** — each entry is ~5 fields, not a paragraph
3. **Updatable** — Copilot can add/replace entries without rewriting surrounding text
4. **Reviewable** — you can audit, deduplicate, and prune entries easily
5. **No attention decay** — the agent reads only relevant entries per phase

---

## Part 3: Writing Rules That Claude Actually Follows

### The Rule Effectiveness Hierarchy

Not all instruction formats are equal. Here's what Claude models obey most reliably, ranked:

```
MOST EFFECTIVE (near 100% compliance)
  ▼
  1. BLOCKING GATES with verification commands
     "Run `mvn dependency:resolve`. If exit code ≠ 0, STOP. Do NOT proceed."

  2. IF-THEN rules with specific triggers
     "If the file contains `<packaging>pom</packaging>`, use `-Dpackaging=pom`."

  3. NEVER rules with reason
     "NEVER use RC/beta versions — filter regex: `^[0-9]+\.[0-9]+\.[0-9]+$`"

  4. Numbered checklists (sequential)
     "1. Run X  2. Verify Y  3. If fail, do Z"

  5. Decision tables
     "| Condition | Action |"

  6. Prose paragraphs explaining philosophy
     (Moderate compliance — often summarized/ignored under pressure)

  7. Long examples spanning 50+ lines
     (Low compliance — model "gets the idea" but skips details)
  ▼
LEAST EFFECTIVE (frequently ignored)
```

### Rule Writing Patterns

**Pattern 1: The Blocking Gate (Highest Reliability)**

```markdown
## Phase 0.5 — Maven Config Detection [BLOCKING]
1. READ SKILL: `.github/skills/tlm/maven-config-detection/SKILL.md`
2. Execute the skill completely
3. **GATE CHECK:** Does `$MAVEN_SETTINGS_ARG` have a value?
   - YES → Proceed to Phase 0.7
   - NO → STOP. Tell user: "Maven configuration failed. Cannot proceed."
4. **NEVER skip this phase.** All subsequent `mvn` commands require this variable.
```

**Pattern 2: The Decision Table (High Reliability)**

```markdown
## Framework Selection
| Project Has | Recommend | Reason |
|-------------|-----------|--------|
| `@RestController` only | Karate DSL | Fastest API testing |
| `@RestController` + `templates/` | Cucumber + Serenity | UI + API coverage |
| Existing Cucumber tests | Cucumber + Serenity | Match existing |

**Selection command:** Search for indicators before deciding.
```

**Pattern 3: The Anti-Pattern List (High Reliability)**

```markdown
## NEVER DO (violations cause build failures)
1. ✘ NEVER add `allure` with Serenity — conflicts on `cucumber-messages`
2. ✘ NEVER add standalone `cucumber-java` — Serenity bundles it
3. ✘ NEVER mix `serenity-*` versions — all must use `${serenity.version}`
4. ✘ NEVER use `mvn dependency:purge-local-repository` — takes hours
5. ✘ NEVER write tests before `mvn clean compile` succeeds
```

**Pattern 4: The Verification Loop (Medium-High Reliability)**

```markdown
## After Every Version Change
1. Run: `mvn dependency:resolve -Dartifact=G:A:V -q`
2. Check: Exit code 0?
   - YES → Version confirmed. Proceed.
   - NO → Version does not exist. Try next candidate.
3. NEVER present a version to user without completing this check.
```

### What NOT to Write in Rules

```markdown
# ❌ BAD: Vague, philosophical, no verification
"Always be careful with versions and make sure they're correct."

# ❌ BAD: Too many conditions in one rule
"When upgrading Spring Boot from 2.x to 3.x, check Jakarta migration,
and also Java version, and ensure all dependencies are compatible,
while also checking for deprecated APIs and updating property names
and making sure the build passes and tests run."

# ❌ BAD: Buried in a paragraph
"The agent should note that when performing version detection, it's
important to remember that sometimes Maven Central has versions that
don't match what's in the local repository, so verification is key."

# ✅ GOOD: Atomic, verifiable, one concern
"**Version Verification [MANDATORY]:**
Run `mvn dependency:resolve -Dartifact=G:A:V -q` for every 'To' version.
If exit code ≠ 0, the version does not exist. Do NOT present it to user."
```

---

## Part 4: The Size Budget (Token Economics)

### File Size Targets

| File Type | Max Lines | Max Tokens (~) | Why |
|-----------|-----------|----------------|-----|
| Agent file | 80–150 | 1,500–3,000 | Router only; always loaded |
| Instruction file | 100–200 | 2,000–4,000 | Loaded per phase |
| Skill file | 150–300 | 3,000–6,000 | Loaded on demand |
| Common file | 50–100 | 1,000–2,000 | Shared rules; always loaded |
| Config JSON | Any size | Read selectively | Agent parses, not reads whole |
| Prompt file | 20–50 | 400–1,000 | Minimal; triggers a workflow |

### Total Context Budget Per Task

Claude Sonnet 4.5 has a 200K token context window. Here's how your typical task uses it:

```
Agent file:          ~2,000 tokens (always loaded)
Copilot instructions: ~1,500 tokens (always loaded)
Common files (3):    ~4,500 tokens (always loaded)
                     ─────────────
Base overhead:       ~8,000 tokens

+ Active skill:      ~4,000 tokens (1 skill at a time)
+ Active instruction: ~3,000 tokens (1 instruction at a time)
+ Code context:      ~20,000 tokens (files being edited)
+ Conversation:      ~10,000 tokens (history)
                     ─────────────
Typical task total:  ~45,000 tokens

Budget remaining:    ~155,000 tokens for model reasoning
```

When your agent file alone is 800+ lines (~16,000 tokens), AND it loads 3 skills simultaneously, AND there's code context, you're consuming 60,000+ tokens just on instructions — leaving less room for the model to reason, which causes hallucinations.

### The Decomposition Strategy for Your Current Files

**Your current `tlm.agent.md` (~400+ lines visible):**

```
Current state:
  Lines 1–30:   Identity + config          → KEEP in agent
  Lines 18–28:  Critical rules (8 rules)   → KEEP in agent (compress to 5)
  Lines 31–56:  Task flow phases           → KEEP in agent (table format)
  Lines 78–98:  Skills & references table  → KEEP in agent
  Lines 105–119: Global commands + menu    → KEEP in agent
  Lines 123–141: Phase 0 scan details      → MOVE to instruction file
  Lines 270–284: Version detection rules   → ALREADY in skill (remove from agent)
  Lines 288–301: Commands table            → MOVE to instruction file
  Lines 305–320: Command execution protocol → MOVE to instruction file
  Lines 316–320: Protected properties      → MOVE to common file
  Lines 325+:   Pre-build verification     → MOVE to skill
```

**Target `tlm.agent.md` after refactor: ~120 lines**

**Your current `qa-engineer.agent.md` (~800+ lines visible):**

```
Current state:
  Lines 1–25:   Identity + config          → KEEP in agent
  Lines 27–50:  QA Mindset + identity      → KEEP in agent (compress)
  Lines 41–50:  What to gather             → MOVE to skill: qa-test-design
  Lines 53–63:  Deep code walkthrough      → MOVE to skill: qa-code-walkthrough
  Lines 65–98:  How you write tests        → MOVE to skill: qa-test-writing
  Lines 78–98:  Rules you never break      → KEEP top 5 in agent; rest to skill
  Lines 102+:   Commands table             → MOVE to instruction file
  Lines 218+:   Option 1 scaffold          → MOVE to skill: qa-cucumber-serenity
  Lines 691+:   Lessons learned            → MOVE to config/known-issues.json
  Lines 720+:   Common pitfalls            → MOVE to skill anti-patterns section
```

**Target `qa-engineer.agent.md` after refactor: ~100 lines**

---

## Part 5: Handling Learnings Without File Expansion

### The Problem

Every time you find an issue during testing, you tell Copilot "update the agent with this learning." Copilot appends 5–15 lines of prose. After 20 iterations, you've added 200+ lines of scattered findings. This is the #1 cause of your file bloat.

### The Solution: Structured Issue Registry + Update Protocol

**Step 1:** Create `config/known-issues.json` (see Part 2, Layer 4)

**Step 2:** Create an update instruction that Copilot follows:

```markdown
# File: .github/instructions/update-known-issues.instructions.md

## When to Use
When user reports a new finding, bug, or learning from a test run.

## Update Protocol

1. READ current `config/known-issues.json`
2. Check if this issue already exists (match by `trigger` field)
   - If EXISTS: Update the existing entry's `fix` or `root_cause` if new info
   - If NEW: Add a new entry with next sequential ID
3. Determine `category` from: version-detection | build-execution |
   dependency-resolution | test-execution | environment | framework-selection
4. WRITE the updated JSON back

## Entry Format (strict)
{
  "id": "KI-[NNN]",
  "category": "[from list above]",
  "trigger": "[exact error message or condition — 1 line]",
  "root_cause": "[why it happens — 1 line]",
  "fix": "[exact command or action — 1 line]",
  "added": "[YYYY-MM-DD]",
  "severity": "critical|high|medium|low",
  "verified": true|false
}

## RULES
- NEVER add more than 3 lines per field
- NEVER duplicate an existing issue — UPDATE it instead
- NEVER modify agent.md or SKILL.md files for individual findings
- If a finding reveals a PATTERN (3+ similar issues), THEN create a new
  rule in the relevant SKILL.md — but as a single decision table row, not prose
```

**Step 3:** Reference the registry from skills:

```markdown
# Inside any SKILL.md, at the relevant phase:

## Known Issues
**BEFORE executing this phase**, read `config/known-issues.json`
filtered by `category: "version-detection"`.
Apply any matching fixes preemptively.
```

### When Findings DO Belong in Skill Files

Some findings represent **permanent patterns**, not one-off issues. These graduate from the JSON registry to the skill file — but as a SINGLE LINE in a decision table, not a paragraph:

```markdown
# In SKILL.md — a table that grows by one row, not one paragraph:

## Edge Cases
| Trigger Pattern | Action |
|----------------|--------|
| Parent POM pins version via `dependencyManagement` | Check effective-pom first |
| `PKIX path building failed` | Rerun Maven Config Detection |
| `Could not find artifact` for internal lib | Check Artifactory permissions |
```

Each finding = 1 table row (~15 words) instead of 1 paragraph (~80 words). After 20 findings, that's 300 words vs 1,600 words — and the table format has higher attention retention than prose.

---

## Part 6: Making Skills Route Correctly

### Why Skills Sometimes Don't Trigger

The skill `description` field in the YAML frontmatter is the PRIMARY trigger for routing. If it's vague, the wrong skill gets selected. If it's too narrow, the skill never triggers.

### The Skill Description Formula

```
[Action verb] + [specific artifact/concept] + [context/constraint]
```

**Examples:**

```markdown
# ❌ BAD: Too vague
description: "Handles testing stuff"

# ❌ BAD: Too narrow
description: "Creates Cucumber Serenity RestAssured POM file for Spring Boot API"

# ✅ GOOD: Specific action + artifact + context
description: "QA test design — black-box mindset, API-by-API approach, deep
validation, business-requirement-driven coverage. Quality over quantity.
TODO-driven to prevent attention deviation."

# ✅ GOOD: Clear trigger words
description: "Scaffold new Cucumber+Serenity test suite. Creates pom.xml,
folder structure, and base configuration for API or UI testing."
```

### Making Sure the Right CONTENT Within a Skill Gets Used

Within a skill, use clear H2 headers as "jump targets" that the model can scan:

```markdown
# Skill: QA Test Design

## WHEN: Before Writing Any Test          ← Routing header
[content about pre-test gathering]

## WHEN: Designing Test Scenarios          ← Routing header
[content about scenario design]

## WHEN: Reviewing Test Coverage           ← Routing header
[content about gap analysis]
```

The model scans H2 headers to find the relevant section. If your content is in a wall of text under one header, it's harder to locate.

### Do You Need Full POM Examples in Skills?

**Yes, but with constraints:**

1. **ONE canonical template per skill** — not multiple variations
2. **Mark it clearly:** `## TEMPLATE: [exact purpose]`
3. **Use placeholder comments** for variable parts:

```xml
<!-- TEMPLATE: Cucumber + Serenity + RestAssured POM -->
<!-- Copy EXACTLY. Only modify values marked with [PLACEHOLDER] -->
<project>
  <groupId>[PROJECT_GROUP_ID]</groupId>
  <artifactId>[PROJECT_ARTIFACT_ID]-api-tests</artifactId>
  <properties>
    <serenity.version>4.2.12</serenity.version>  <!-- DO NOT CHANGE -->
    <java.version>17</java.version>               <!-- or 21 -->
  </properties>
  <!-- ... rest of POM ... -->
</project>
```

4. **Never put the same template in two places.** Reference it:

```markdown
# In agent.md:
"For POM template, READ `skills/qa/qa-cucumber-serenity/SKILL.md` → section TEMPLATE"

# NOT:
[paste entire POM here too]
```

---

## Part 7: Telling the Agent What to Do When It Can't Succeed

### The Failure Communication Protocol

Add this to your agent file or a common instruction:

```markdown
## WHEN YOU CANNOT ACHIEVE THE EXPECTED RESULT

If after 3 attempts you cannot complete a phase successfully:

1. **STOP** — do not continue to the next phase
2. **REPORT** to user with this exact format:

   **⚠️ Phase [N] Failed: [Phase Name]**
   - **What I tried:** [list the 3 attempts, 1 line each]
   - **What went wrong:** [exact error message or unexpected behavior]
   - **What I need from you:**
     - [ ] [specific information or action needed]
     - [ ] [specific information or action needed]
   - **Suggested next step:** [your recommendation]

3. **DO NOT:**
   - Guess at a workaround that hasn't been verified
   - Skip the phase and continue
   - Retry more than 3 times without user input

4. **CAPTURE** the failure details for the known issues registry:
   - Error message
   - Context (what version, what dependency, what phase)
   - What was expected vs what happened
```

### Letting the Agent Learn from Failures

Add a "self-improvement" command to your agent:

```markdown
## Command: "learn [description]"

When user says "learn [something]":
1. READ `config/known-issues.json`
2. Follow `.github/instructions/update-known-issues.instructions.md`
3. Add the new finding as a structured entry
4. Confirm to user: "Added KI-[NNN]: [trigger summary]"
5. DO NOT modify any agent.md or SKILL.md files
```

---

## Part 8: The Prompt Layer (Minimal, Trigger-Based)

### When to Use Prompt Files

Prompts are for USER-FACING shortcuts. They should be 20–50 lines and simply trigger a workflow that's defined elsewhere.

```markdown
# File: .github/prompts/scan-and-fix.prompt.md

## Scan and Fix All Dependencies

Trigger the TLM Agent to perform a full scan and upgrade cycle:

1. Execute Phase 0 (Workspace Validation)
2. Execute Phase 0.5 (Maven Config Detection) — BLOCKING
3. Execute Phase 0.7 (Environment Pre-Flight) — BLOCKING
4. Execute Phase 1 (Version Detection)
5. Show scan results with menu (Phase 0 output format)
6. WAIT for user to select options
7. Execute Phase 2 → 5 based on selection

**All phase details are in the agent file's TASK FLOW table.**
**All skill details are in the SKILL ROUTING TABLE.**

Do NOT duplicate any phase logic here.
```

### The Rule: Prompts Call, They Don't Define

```
❌ Prompt contains POM template, version rules, build commands
✅ Prompt says "Execute Phase 3 using skill at [path]"
```

---

## Part 9: Common Files — Shared Rules (50–100 lines each)

### What Belongs in Common Files

Things that EVERY agent must follow, regardless of their specific task:

```markdown
# File: .github/common/enterprise-standards.md

# Enterprise Standards (All Agents)

## Code Quality
- All generated code must compile without warnings
- No TODO comments in delivered code
- Follow existing project code style

## Security
- Never hardcode credentials
- Never commit secrets or tokens
- Use environment variables for sensitive config

## Build Standards
- All builds must pass before presenting to user
- Never modify parent POM unless explicitly asked
- Use `$MAVEN_SETTINGS_ARG` for all Maven commands

## Communication
- Always show progress indicators during long operations
- Max 10 terminal messages per phase
- Capture output to variables — never stream raw output
```

```markdown
# File: .github/common/model-selection.md

# Model Selection Rules

## Default: Claude Sonnet 4.5
- Use for all standard operations
- Sufficient for code generation, analysis, and upgrades

## Escalate to Opus: Only when
- 2 consecutive Sonnet failures on the same step
- Complex multi-file refactoring across 10+ files
- Architecture-level decisions requiring broad context

## NEVER
- Switch models mid-phase without telling the user
- Use Opus for routine scans or simple upgrades
```

---

## Part 10: File Update Protocol (For When Copilot Updates Your Files)

### The Problem: Copilot Writes Verbose Updates

When you say "add this learning to the agent," Copilot writes a paragraph. Over time, this bloats your files.

### The Solution: Constrained Update Instructions

Add this to your `copilot-instructions.md`:

```markdown
## File Update Rules

When asked to update agent files, skills, or instructions:

### For New Findings/Learnings:
- ADD to `config/known-issues.json` using the structured entry format
- NEVER add findings as prose to agent.md or SKILL.md files
- Exception: If 3+ similar findings exist in JSON → create ONE decision table
  row in the relevant SKILL.md

### For Rule Changes:
- REPLACE the existing rule line — do not add a new paragraph explaining the change
- Keep rules to 1–2 lines maximum
- If a rule needs explanation, put the explanation in a skill file, not the agent

### For New Features/Phases:
- Add ONE row to the task flow table in agent.md
- Create a NEW skill or instruction file for details
- NEVER expand an existing file beyond its size budget

### Size Enforcement:
- Agent files: If edit would push beyond 150 lines → STOP and suggest decomposition
- Skill files: If edit would push beyond 300 lines → STOP and suggest splitting
- Instruction files: If edit would push beyond 200 lines → STOP and suggest splitting

### Update Confirmation Format:
After any file update, show:
"Updated [filename]: [1-line summary of change]. File is now [N] lines ([within/over] budget)."
```

---

## Part 11: Complete Refactored Structure

### Directory Layout

```
.github/
├── agents/
│   ├── tlm.agent.md              (120 lines — router + critical rules)
│   ├── qa-engineer.agent.md      (100 lines — router + critical rules)
│   ├── sr-developer.agent.md     (100 lines — router + critical rules)
│   └── devops.agent.md           (100 lines — router + critical rules)
│
├── common/
│   ├── enterprise-standards.md   (60 lines — shared quality rules)
│   ├── model-selection.md        (40 lines — when to use which model)
│   └── multi-module.md           (50 lines — monorepo rules)
│
├── config/
│   ├── known-issues.json         (structured — grows indefinitely, safely)
│   └── agent-config.json         (structured — environment-specific settings)
│
├── instructions/
│   ├── qa-testing.instructions.md          (150 lines)
│   ├── change-summary.instructions.md      (100 lines)
│   ├── update-known-issues.instructions.md (60 lines)
│   └── commands.instructions.md            (100 lines)
│
├── prompts/
│   ├── scan-and-fix.prompt.md    (30 lines — triggers TLM workflow)
│   ├── new-test-suite.prompt.md  (30 lines — triggers QA scaffold)
│   └── fix-sonar.prompt.md       (30 lines — triggers dev agent)
│
├── skills/
│   ├── qa/
│   │   ├── qa-cucumber-serenity/SKILL.md   (250 lines — POM + scaffold)
│   │   ├── qa-karate-dsl/SKILL.md          (200 lines)
│   │   ├── qa-test-design/SKILL.md         (200 lines — methodology)
│   │   ├── qa-test-execution/SKILL.md      (150 lines)
│   │   └── qa-test-pattern-analysis/SKILL.md (150 lines)
│   │
│   ├── tlm/
│   │   ├── version-detection/SKILL.md      (250 lines — 6-phase protocol)
│   │   ├── maven-config-detection/SKILL.md (150 lines)
│   │   ├── environment-preflight/SKILL.md  (150 lines)
│   │   ├── spring-boot-upgrade/SKILL.md    (250 lines)
│   │   ├── build-validation/SKILL.md       (150 lines)
│   │   └── severity/SKILL.md              (80 lines)
│   │
│   └── dev/
│       ├── unit-test-generation/SKILL.md   (200 lines)
│       └── sonar-fix/SKILL.md              (200 lines)
│
├── templates/
│   ├── pom-cucumber-serenity.xml           (exact template — referenced by skill)
│   └── pom-karate-dsl.xml                  (exact template — referenced by skill)
│
└── copilot-instructions.md       (80 lines — global rules + file update protocol)
```

### Key Principle: Templates as Separate Files

Instead of embedding a 60-line POM template inside a skill (which eats into the 300-line budget), store templates as separate files and reference them:

```markdown
# Inside SKILL.md:
## POM Template
**USE EXACTLY:** `.github/templates/pom-cucumber-serenity.xml`
- Copy to workspace root as `pom.xml`
- Replace `[PROJECT_GROUP_ID]` with actual groupId
- Replace `[PROJECT_ARTIFACT_ID]` with actual artifactId
- DO NOT modify any dependency versions
```

This way:
- The skill file stays focused on LOGIC (when to use, how to configure)
- The template is an exact, copyable artifact
- Copilot can fetch the template file only when needed (not loaded into context otherwise)

---

## Part 12: Checklist for Refactoring Your Existing Agents

### Step-by-Step Migration Plan

**Week 1: Create the infrastructure**
- [ ] Create `config/known-issues.json` — migrate all inline findings
- [ ] Create `instructions/update-known-issues.instructions.md`
- [ ] Create `templates/` directory — extract all POM/code templates
- [ ] Update `copilot-instructions.md` with file update protocol

**Week 2: Refactor TLM Agent**
- [ ] Extract version detection rules → already in skill (remove duplicates from agent)
- [ ] Extract command tables → `instructions/commands.instructions.md`
- [ ] Extract execution protocol → instruction file
- [ ] Compress agent to ≤150 lines
- [ ] Test: Run full scan-and-fix cycle → verify all phases work

**Week 3: Refactor QA Agent**
- [ ] Extract test writing methodology → `skills/qa/qa-test-design/SKILL.md`
- [ ] Extract scaffold details → `skills/qa/qa-cucumber-serenity/SKILL.md`
- [ ] Extract lessons learned → `config/known-issues.json`
- [ ] Extract common pitfalls → anti-patterns section in relevant skills
- [ ] Compress agent to ≤100 lines
- [ ] Test: Run new test suite scaffold → verify correct framework selection

**Week 4: Test and tune**
- [ ] Run each agent 5 times on typical tasks
- [ ] Track: Did it skip any phase? → Strengthen the blocking gate
- [ ] Track: Did it hallucinate any version? → Check verification loop
- [ ] Track: Did it pick the wrong skill? → Tune skill descriptions
- [ ] Measure: How many tokens per task? → Compare to pre-refactor

---

## Part 13: Quick Reference Card

### The Golden Rules

1. **Agent file ≤ 150 lines** — it's a router, not an encyclopedia
2. **One concern per file** — if a file does two things, split it
3. **Rules in first 50 lines** — critical rules go at the TOP
4. **Tables over prose** — decision tables have 2x attention retention
5. **BLOCKING gates over advisory notes** — "STOP if X" beats "try to X"
6. **JSON for findings, tables for patterns** — never prose for learnings
7. **Templates in separate files** — referenced, not embedded
8. **Verify every output** — "Run X, check Y, if fail do Z"
9. **5 critical rules max per file** — more than 5 and none get followed
10. **Update protocol in copilot-instructions** — control how Copilot modifies files

### The File Size Cheat Sheet

| If your file is... | Action |
|---------------------|--------|
| Under 100 lines | Perfect. Leave it. |
| 100–200 lines | Acceptable if it's a skill with templates. |
| 200–300 lines | Review: can any section become its own file? |
| 300–500 lines | RED FLAG. Must split. Attention decay is significant. |
| 500+ lines | CRITICAL. Agent will hallucinate. Immediate refactor needed. |

### The Format That Claude Follows Best

```markdown
## [PHASE NAME] [BLOCKING if applicable]

**TRIGGER:** [when this runs]
**PREREQUISITE:** [what must be true — link to gate check]

### Steps
1. **DO:** [specific action with exact command]
2. **VERIFY:** [exact check — command + expected output]
3. **IF FAIL:** [exact recovery action]
4. **IF PASS:** → Proceed to [next phase]

### NEVER
- [specific mistake with reason]
- [specific mistake with reason]

### Known Edge Cases
READ `config/known-issues.json` where `category = "[this-phase]"`
```

---

*This guide was written for team building
Apply these patterns incrementally — refactor
one agent at a time, test thoroughly, and measure token usage before and after.*
