# QA Automation Agent for GitHub Copilot — v3.0

## Quick Start
1. Copy `.github/` folder to your project root
2. Open in VS Code 1.106+ → Copilot Chat → Select **"Senior QA Automation Engineer"**
3. Set model to **Claude Sonnet 4.5** → Type **"hi"**

## What's New in v3.0
- **Separate test project** — never writes tests inside dev project
- **Mandatory test execution** — always runs tests after generation
- **JaCoCo coverage** — functional test code coverage with gap analysis
- **Placeholder assertions** — enforces completion with fail() for missing data
- **DB validation** — API + DB consistency checks
- **Parallel execution** — data isolation, unique IDs, thread-safe
- **Allure reports** — shareable HTML reports
- **Multi-input collection** — upload multiple sources for better coverage

## File Structure
```
.github/
├── copilot-instructions.md                      ← Global rules
├── agents/
│   └── senior-qa-automation.agent.md            ← QA agent persona
├── instructions/
│   └── qa-testing.instructions.md               ← Dynamic test file rules
└── skills/
    ├── qa-cucumber-serenity/SKILL.md            ← Cucumber+Serenity patterns
    ├── qa-karate-dsl/SKILL.md                   ← Karate DSL patterns
    ├── qa-test-design/SKILL.md                  ← Test design methodology
    ├── qa-test-execution/SKILL.md               ← Execution & reporting
    ├── qa-jacoco-coverage/SKILL.md              ← JaCoCo code coverage
    └── qa-test-data-assertions/SKILL.md         ← Data mgmt & assertions
```

## Context Window Optimization
| File Type | Loads When | Size |
|-----------|-----------|------|
| `copilot-instructions.md` | Every chat | Small (global rules) |
| `.agent.md` | When agent selected | Medium (workflow) |
| `SKILL.md` | On-demand (matched to task) | Medium (framework details) |
| `.instructions.md` | When editing test files | Small (rules) |

Skills load only when relevant — not all at once. This keeps context efficient.

## Setup Guide
See **[SETUP-TEST-REVIEW-GUIDE.md](./SETUP-TEST-REVIEW-GUIDE.md)**
