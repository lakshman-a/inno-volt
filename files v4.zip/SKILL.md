---
name: qa-test-data-assertions
description: Test data management, reusable assertions, DB validation, and field-level assertion enforcement. Use when creating test data strategies, writing assertions, adding database validation steps, or enforcing assertion completeness with placeholder failures.
---

# Test Data & Assertions Skill

## 1. Reusable Test Data Strategy

### Data Creation & Cleanup Pattern (Cucumber)
```java
public class TestDataManager {
    private static final Logger LOG = LoggerFactory.getLogger(TestDataManager.class);
    private final List<CleanupAction> cleanupActions = new ArrayList<>();

    /** Create test data and register for cleanup */
    public <T> T createAndTrack(String resourceType, Object requestBody, Class<T> responseType) {
        LOG.info("SETUP: Creating test data for {}", resourceType);
        T created = apiClient.post(resourceType, requestBody, responseType);
        String id = extractId(created);
        cleanupActions.add(new CleanupAction(resourceType, id));
        LOG.info("SETUP: Created {} with ID: {} (registered for cleanup)", resourceType, id);
        return created;
    }

    /** Cleanup all created data — call in @After hook */
    public void cleanupAll() {
        LOG.info("CLEANUP: Removing {} test data items", cleanupActions.size());
        Collections.reverse(cleanupActions); // Delete in reverse order
        for (CleanupAction action : cleanupActions) {
            try {
                apiClient.delete(action.resourceType, action.id);
                LOG.info("CLEANUP: Deleted {} ID: {}", action.resourceType, action.id);
            } catch (Exception e) {
                LOG.warn("CLEANUP: Failed to delete {} ID: {} — {}", action.resourceType, action.id, e.getMessage());
            }
        }
        cleanupActions.clear();
    }
}
```

### Data Creation & Cleanup Pattern (Karate)
```gherkin
# Setup — create data with unique ID
* def uniqueId = java.util.UUID.randomUUID().toString().substring(0, 8)
* def testEmail = 'test_' + uniqueId + '@example.com'
* def customerData = { firstName: 'Test', lastName: 'User', email: '#(testEmail)' }

Given url baseUrl + '/api/v1/customers'
And request customerData
When method post
Then status 201
* def createdId = response.id

# ... test steps ...

# Cleanup — delete created data
Given url baseUrl + '/api/v1/customers/' + createdId
When method delete
```

### Unique Data Generation (Parallel-Safe)
```java
public class TestDataBuilder {
    private static final Faker faker = new Faker();

    /** Generate unique customer data — safe for parallel execution */
    public static Map<String, Object> uniqueCustomer() {
        String uid = UUID.randomUUID().toString().substring(0, 8);
        return Map.of(
            "firstName", faker.name().firstName(),
            "lastName", faker.name().lastName(),
            "email", "test_" + uid + "@example.com",
            "phone", "+1-555-" + faker.number().digits(7)
        );
    }
}
```

### Karate Dynamic Data
```javascript
// testdata/dynamic_customer.js
function() {
    var uid = java.util.UUID.randomUUID().toString().substring(0, 8);
    return {
        firstName: 'Test_' + uid,
        lastName: 'User_' + uid,
        email: 'test_' + uid + '@example.com',
        phone: '+1-555-' + Math.floor(1000000 + Math.random() * 9000000)
    };
}
```

---

## 2. Field-Level Assertion Standards

### EVERY response field MUST be validated. No exceptions.

### Reusable Assertion Helper (Cucumber + AssertJ)
```java
public class ResponseValidator {
    private static final Logger LOG = LoggerFactory.getLogger(ResponseValidator.class);

    /** Validate ALL fields in response against expected values */
    public static void validateAllFields(Response response, Map<String, Object> expected) {
        JsonPath json = response.jsonPath();
        SoftAssertions soft = new SoftAssertions();

        for (Map.Entry<String, Object> entry : expected.entrySet()) {
            String field = entry.getKey();
            Object expectedVal = entry.getValue();
            Object actualVal = json.get(field);

            LOG.info("ASSERT: {} — expected: [{}], actual: [{}]", field, expectedVal, actualVal);
            soft.assertThat(actualVal)
                .as("Field '%s' should equal '%s'", field, expectedVal)
                .isEqualTo(expectedVal);
        }

        // Validate system-generated fields exist
        soft.assertThat(json.getString("id"))
            .as("ID should be a valid UUID")
            .matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
        soft.assertThat(json.getString("createdAt"))
            .as("createdAt should not be null")
            .isNotNull();

        soft.assertAll();
    }

    /** Validate error response structure */
    public static void validateErrorResponse(Response response, int expectedStatus, String expectedField) {
        SoftAssertions soft = new SoftAssertions();
        soft.assertThat(response.getStatusCode()).as("Status code").isEqualTo(expectedStatus);
        soft.assertThat(response.jsonPath().getString("error")).as("Error field").isNotNull();
        soft.assertThat(response.jsonPath().getString("message")).as("Error message").isNotBlank();
        if (expectedField != null) {
            soft.assertThat(response.jsonPath().getString("errors[0].field"))
                .as("Error should reference field: %s", expectedField)
                .containsIgnoringCase(expectedField);
        }
        soft.assertAll();
    }
}
```

### Karate Schema Validation (All Fields)
```json
// schemas/customer/create_success.json — validate EVERY field
{
    "id": "#uuid",
    "firstName": "#string",
    "lastName": "#string",
    "email": "#string",
    "phone": "##string",
    "status": "ACTIVE",
    "createdAt": "#string",
    "updatedAt": "#string",
    "createdBy": "#string",
    "version": "#number"
}
```

```gherkin
# In feature file — validate against schema
And match response == read('classpath:schemas/customer/create_success.json')
# PLUS explicit value checks
And match response.firstName == customerData.firstName
And match response.lastName == customerData.lastName
And match response.email == customerData.email
```

---

## 3. Placeholder Assertions (Enforcement)

When information is missing, create assertions that FAIL with clear TODO messages.
This ensures developers MUST complete them — tests never silently pass incomplete.

### Field-Level Placeholder (Cucumber)
```java
@Then("the response field {string} should match expected value")
public void assertFieldValue(String fieldName) {
    Object actual = SerenityRest.lastResponse().jsonPath().get(fieldName);
    // TODO: Replace with actual expected value
    fail(String.format(
        "ASSERTION PLACEHOLDER — Field '%s' has value '%s' but expected value not defined. " +
        "Update this assertion with the correct expected value.", fieldName, actual));
}
```

### DB Assertion Placeholder (Cucumber)
```java
@Then("the database record should be created in {string} table")
public void assertDbRecord(String tableName) {
    // TODO: Add database connection and validation
    fail(String.format(
        "DB ASSERTION PLACEHOLDER — Verify record exists in table '%s'. " +
        "Provide DB connection details and add JDBC/JPA validation. " +
        "Expected: SELECT * FROM %s WHERE [conditions] returns 1 row.", tableName, tableName));
}

@Then("the database field {string} in table {string} should equal {string}")
public void assertDbField(String field, String table, String expected) {
    // TODO: Add database query and validation
    fail(String.format(
        "DB FIELD ASSERTION PLACEHOLDER — Verify %s.%s = '%s'. " +
        "Add JDBC query: SELECT %s FROM %s WHERE id = [created_id]", table, field, expected, field, table));
}
```

### Karate Placeholders
```gherkin
# Field assertion placeholder
* def actualValue = response.someField
* if (true) karate.fail('ASSERTION PLACEHOLDER: Validate response.someField = [expected]. Actual: ' + actualValue)

# DB assertion placeholder
* if (true) karate.fail('DB ASSERTION PLACEHOLDER: Verify record in [table] where id = ' + response.id)
```

---

## 4. Database Validation (When DB Details Provided)

### Cucumber + JDBC
```java
public class DbValidator {
    private final DataSource dataSource;

    public void assertRecordExists(String table, String idColumn, String idValue) {
        String sql = String.format("SELECT COUNT(*) FROM %s WHERE %s = ?", table, idColumn);
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, idValue);
            ResultSet rs = ps.executeQuery();
            rs.next();
            assertThat(rs.getInt(1))
                .as("Record should exist in %s with %s = %s", table, idColumn, idValue)
                .isEqualTo(1);
        }
    }

    public void assertFieldEquals(String table, String idColumn, String idValue,
                                   String field, Object expected) {
        String sql = String.format("SELECT %s FROM %s WHERE %s = ?", field, table, idColumn);
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, idValue);
            ResultSet rs = ps.executeQuery();
            assertThat(rs.next()).as("Record should exist").isTrue();
            assertThat(rs.getObject(field))
                .as("DB field %s.%s should equal %s", table, field, expected)
                .isEqualTo(expected);
        }
    }
}
```

### Karate + JDBC
```gherkin
# DB validation in Karate
* def dbConfig = { url: 'jdbc:postgresql://localhost:5432/mydb', user: 'test', password: 'test' }
* def DbUtils = Java.type('helpers.DbUtils')
* def db = new DbUtils(dbConfig)
* def dbResult = db.readRow("SELECT * FROM customers WHERE id = '" + response.id + "'")
* match dbResult.first_name == customerData.firstName
* match dbResult.email == customerData.email
* match dbResult.status == 'ACTIVE'
```

---

## 5. Integration Test Assertions (API + DB Consistency)

```gherkin
@integration @api-db
Scenario: Verify API response matches database record after creation
    # Create via API
    Given [create customer via API]
    Then status 201
    * def apiResponse = response

    # Verify in DB
    * def dbRecord = db.readRow("SELECT * FROM customers WHERE id = '" + apiResponse.id + "'")

    # Assert API and DB are consistent
    And match apiResponse.firstName == dbRecord.first_name
    And match apiResponse.lastName == dbRecord.last_name
    And match apiResponse.email == dbRecord.email
    And match apiResponse.status == dbRecord.status
    And match apiResponse.createdAt contains dbRecord.created_at
```

---

## 6. Assertion Completeness Rules

The agent enforces:
1. **Every response field validated** — if field exists in response, assert it
2. **Error response structure validated** — status + error code + message
3. **DB state validated** — if DB available, check record after create/update/delete
4. **Headers validated** — Content-Type, Location, custom headers
5. **Missing data = fail()** — never skip assertions, use placeholders that fail
6. **Soft assertions** — use SoftAssertions to check ALL fields, not just first failure
