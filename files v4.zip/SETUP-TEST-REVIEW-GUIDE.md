# Setup, Test & Review Guide — v3.0

## Prerequisites
- VS Code 1.106+ | GitHub Copilot + Chat extensions | Claude model access
- Java/Maven project (dev project, test project, or both)

## Step 1: Install Files
```bash
cd /path/to/your-project
mkdir -p .github/{agents,instructions,skills/{qa-cucumber-serenity,qa-karate-dsl,qa-test-design,qa-test-execution,qa-jacoco-coverage,qa-test-data-assertions}}
# Copy all files from the package into these directories
```

## Step 2: VS Code Settings
```json
{ "github.copilot.chat.useCustomInstructions": true, "chat.agent.enabled": true }
```

## Step 3: Verify
1. `Ctrl+Shift+P` → `Developer: Reload Window`
2. Open Copilot Chat → agent dropdown → should see **"Senior QA Automation Engineer"**
3. `Ctrl+Shift+P` → `Chat: Diagnostics` → verify all files loaded

## Step 4: Test Scenarios

### Test 1: Empty workspace detection
```
Open empty folder → select agent → type "hi"
✅ Pass: Agent says workspace is empty, asks to load project
```

### Test 2: Multi-project detection
```
Open workspace with dev + test projects → type "hi"
✅ Pass: Agent lists all projects found, asks which to focus on
```

### Test 3: Separate project creation
```
Select option 1, provide swagger → approve plan
✅ Pass: Agent creates NEW directory {name}-api-tests/ with its own pom.xml
❌ Fail: Agent writes tests inside dev project's src/test/
```

### Test 4: Multi-input collection
```
Select option 1 → agent shows input options A-G with quality tip
✅ Pass: Agent accepts multiple inputs (e.g., "A, B, E"), shows quality improvement note
```

### Test 5: Test execution after generation
```
After test generation completes
✅ Pass: Agent runs mvn test, shows pass/fail results, shows report path
❌ Fail: Agent just generates files without executing
```

### Test 6: Placeholder assertions
```
Generate tests WITHOUT providing DB schema
✅ Pass: Tests have fail("DB ASSERTION PLACEHOLDER: ...") steps
❌ Fail: Tests skip DB validation silently
```

### Test 7: JaCoCo coverage (if dev project available)
```
Select option 8 or ask for coverage → dev project runnable
✅ Pass: Agent downloads JaCoCo, instruments API, runs tests, generates coverage report
```

### Test 8: Allure report
```
After test execution
✅ Pass: Agent generates Allure report, provides serve command
```

## Step 5: Quality Checklist

### Generated Test Project
- [ ] Separate directory with own pom.xml (not inside dev project)
- [ ] Java version matches system `java -version`
- [ ] Allure reporting plugin configured
- [ ] README.md with execution instructions

### Test Scenarios
- [ ] Business-readable names (not "POST /api returns 200")
- [ ] Positive + negative + edge + business for each endpoint
- [ ] Every response field validated (or placeholder fail())
- [ ] DB assertions present (real or placeholder)
- [ ] Test data setup + cleanup in every scenario
- [ ] Unique data generation (UUID suffix) for parallel safety
- [ ] Proper tags on every scenario

### Execution
- [ ] Tests actually executed after generation
- [ ] Report generated (Allure/Serenity/Karate)
- [ ] Pass/fail results shown to user
- [ ] README updated with results summary

### Red Flags
- ❌ Tests inside dev project src/test/
- ❌ No execution after generation
- ❌ Status-code-only assertions
- ❌ Hardcoded URLs or data
- ❌ No cleanup steps
- ❌ Missing assertions silently passing (instead of fail() placeholder)

## Step 6: Team Rollout
```bash
git add .github/
git commit -m "feat: add QA automation agent v3.0 with JaCoCo, assertions, execution"
git push
```

Share: "Open repo → Copilot Chat → select 'Senior QA Automation Engineer' → type 'hi'"

## Context Window FAQ

**Q: Will large skill files exhaust tokens?**
A: No. VS Code loads skills ON-DEMAND based on task matching. The agent file (~240 lines) loads when selected. Skills (~80-120 lines each) load only when the task matches their description. Instructions load only when editing matching file patterns. You won't hit all 6 skills at once.

**Q: How to check what's loaded?**
A: `Ctrl+Shift+P` → `Chat: Diagnostics` shows all active instructions and skills.

**Q: Can I reduce context usage?**
A: Yes — remove skills you don't need. If you only use Karate, delete the Cucumber skill folder. If you don't need JaCoCo, delete that skill folder.
