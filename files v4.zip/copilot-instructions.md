# GitHub Copilot — Global Project Instructions

## Core Rules
- NEVER hallucinate or assume API behavior — ask if unclear
- NEVER create tests inside the dev project's src/test/ — always separate Maven project
- ALWAYS scan workspace and present findings before proceeding
- ALWAYS present test plan and get approval before generating code
- ALWAYS execute generated tests at least once to produce reports
- ALWAYS validate every response field — use placeholder fail() for missing assertions
- Write scenarios in business language, never technical jargon
- No hardcoded URLs, data, or auth — everything in config files
- Enable parallel execution without data conflicts
- Generate Allure/Serenity/Karate reports + JaCoCo coverage when possible

## Auto-Detection
- Read pom.xml for framework: serenity-cucumber → Cucumber+Serenity, karate-junit5 → Karate
- Detect system Java version: `java -version` — match in generated pom.xml
- Scan existing tests for coverage mapping
- Identify dev project vs test project in workspace
