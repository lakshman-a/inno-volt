---
applyTo: '**/*.feature,**/test/**,**/tests/**,**/*Test*.java,**/*Runner*.java'
---

# QA Test File Instructions

When working with test files:
1. Validate EVERY response field — use fail() placeholder if expected value unknown
2. Create reusable assertion helpers for common validation patterns
3. Create test data setup AND cleanup for every scenario
4. Use unique IDs (UUID/timestamp) for parallel-safe data
5. Add DB assertion steps when schema is available — fail() placeholder when not
6. Log at every step: setup, action, validation, cleanup
7. Tag every scenario: feature, type (positive/negative/edge), suite, severity
8. Never hardcode URLs, tokens, or test data inline
9. After generating tests, always execute them to produce reports
10. Generate/update README.md with execution instructions
