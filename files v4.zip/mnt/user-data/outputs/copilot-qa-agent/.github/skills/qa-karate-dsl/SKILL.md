---
name: qa-karate-dsl
description: Karate DSL framework patterns for API functional testing. Project structure, POM dependencies, karate-config.js, feature file standards, match expressions, reusable features, and runner templates.
---

# Karate DSL Standards

## Standalone Test Project POM (Template)
```xml
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.{org}</groupId>
    <artifactId>{project}-api-tests</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <properties>
        <java.version>[DETECT FROM SYSTEM]</java.version>
        <karate.version>1.4.1</karate.version>
    </properties>
    <dependencies>
        <dependency><groupId>com.intuit.karate</groupId><artifactId>karate-junit5</artifactId><version>${karate.version}</version><scope>test</scope></dependency>
        <dependency><groupId>io.qameta.allure</groupId><artifactId>allure-karate</artifactId><version>2.25.0</version><scope>test</scope></dependency>
    </dependencies>
    <build>
        <testResources>
            <testResource><directory>src/test/resources</directory></testResource>
            <testResource><directory>src/test/java</directory><excludes><exclude>**/*.java</exclude></excludes></testResource>
        </testResources>
        <plugins>
            <plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-surefire-plugin</artifactId><version>3.2.3</version>
                <configuration><argLine>-Dfile.encoding=UTF-8</argLine>
                    <systemPropertyVariables><karate.env>${karate.env}</karate.env></systemPropertyVariables>
                </configuration>
            </plugin>
            <plugin><groupId>io.qameta.allure</groupId><artifactId>allure-maven</artifactId><version>2.12.0</version></plugin>
        </plugins>
    </build>
</project>
```

## Project Structure
```
{project}-api-tests/
├── pom.xml
├── README.md
└── src/test/
    ├── java/com/{org}/{project}/
    │   ├── KarateTestRunner.java (parallel runner)
    │   ├── SmokeTestRunner.java
    │   └── helpers/ (DataGenerator.java, DbUtils.java, CustomUtils.java)
    └── resources/
        ├── karate-config.js
        ├── logback-test.xml
        ├── features/{feature}/ (_positive, _negative, _edge_cases .feature)
        ├── features/common/ (auth.feature, health-check.feature, cleanup.feature — all @ignore)
        ├── testdata/{feature}/ (JSON, CSV, JS dynamic data)
        └── schemas/{feature}/ (JSON match schemas)
```

## karate-config.js (env switching + auth + logging)
```javascript
function fn() {
    var env = karate.env || 'dev';
    var config = { baseUrl: '', authToken: '' };
    var urls = { dev: 'https://dev-api.example.com', qa: 'https://qa-api.example.com', local: 'http://localhost:8080' };
    config.baseUrl = urls[env] || urls['dev'];
    var auth = karate.callSingle('classpath:features/common/auth.feature', config);
    config.authToken = auth.authToken;
    karate.configure('headers', { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + config.authToken });
    karate.configure('logPrettyRequest', true);
    karate.configure('logPrettyResponse', true);
    return config;
}
```

## Feature File Rules
- Same tags as Cucumber: `@{feature} @api @{type} @{suite} @{severity}`
- Section comments: `# ── SETUP ──`, `# ── ACTION ──`, `# ── VERIFY ──`, `# ── CLEANUP ──`
- `karate.log()` at every key step
- Load data: `* def data = read('classpath:testdata/...')`
- Load schemas: `* def schema = read('classpath:schemas/...')`
- Remove fields: `* remove data.fieldName`
- Set invalid values: `* set data.field = 'invalid'`
- Unique data: UUID suffix for parallel safety
- Cleanup at end: call cleanup feature or inline delete

## Match Expressions
`#null #notnull #present #notpresent #ignore #uuid #string #number #boolean #array #object`
`#regex <pattern>`, `#? <js>`, `##string` (optional), `#[5]` (array size)

## Parallel Runner
```java
Results results = Runner.path("classpath:features").tags("~@ignore").parallel(5);
assertEquals(0, results.getFailCount(), results.getErrorMessages());
```

## Execution
```bash
mvn test -Dkarate.env=dev                     # Full suite
mvn test -Dkarate.options="--tags @smoke"      # Smoke
mvn test -Dkarate.options="--threads 10"       # Parallel
mvn allure:serve                               # Allure report
# Karate report: target/karate-reports/karate-summary.html
```
