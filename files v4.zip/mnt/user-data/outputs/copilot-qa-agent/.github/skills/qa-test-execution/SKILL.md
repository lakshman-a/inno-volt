---
name: qa-test-execution
description: Test execution, reporting, and parallel execution patterns. Use when running tests, generating Allure/Serenity/Karate reports, configuring parallel execution, or troubleshooting test failures.
---

# Test Execution & Reporting Skill

## Mandatory Post-Generation Execution

After generating ANY test code, ALWAYS execute:

### Cucumber + Serenity
```bash
cd {test-project}/
mvn clean verify -Denvironment=dev 2>&1 | tee test-execution.log
mvn serenity:aggregate
echo "Report: target/site/serenity/index.html"
```

### Karate
```bash
cd {test-project}/
mvn clean test -Dkarate.env=dev 2>&1 | tee test-execution.log
echo "Report: target/karate-reports/karate-summary.html"
```

### Allure Report (Both frameworks)
Add to pom.xml:
```xml
<plugin>
    <groupId>io.qameta.allure</groupId>
    <artifactId>allure-maven</artifactId>
    <version>2.12.0</version>
</plugin>
```
Generate: `mvn allure:report` → Open `target/site/allure-maven-plugin/index.html`
Serve: `mvn allure:serve` (opens browser automatically)

## Present Results
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 TEST EXECUTION RESULTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Executed: [timestamp]
Duration: Xs

Total: X scenarios
  ✅ Passed: X
  ❌ Failed: X
  ⏭️ Skipped: X

Failures:
  1. [scenario name] — [reason: API not running / placeholder assertion / actual bug]
  2. ...

📊 Reports:
  Allure: target/site/allure-maven-plugin/index.html
  Serenity: target/site/serenity/index.html  (OR)
  Karate: target/karate-reports/karate-summary.html

📋 Execution log: test-execution.log
```

## Parallel Execution

### When to suggest: Suite has 20+ scenarios

### Cucumber + Serenity Parallel
```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-failsafe-plugin</artifactId>
    <configuration>
        <parallel>methods</parallel>
        <threadCount>4</threadCount>
        <perCoreThreadCount>true</perCoreThreadCount>
    </configuration>
</plugin>
```

### Karate Parallel
```java
Results results = Runner.path("classpath:features")
    .tags("~@ignore")
    .parallel(5); // 5 threads
```

### Data Isolation for Parallel
- Every scenario uses unique test data (UUID suffix or timestamp)
- No shared mutable state between scenarios
- Each scenario creates and cleans up its own data
- Use ThreadLocal for thread-specific context (Cucumber)
- Karate handles isolation natively per feature

## README Generation

Always create/update `README.md` in test project:
```markdown
# {Project Name} — API Functional Tests

## Prerequisites
- Java [version] (matches dev project)
- Maven 3.8+
- Dev API running on [URL] (for execution)

## Run Tests
mvn clean test -Dkarate.env=dev       # Karate
mvn clean verify -Denvironment=dev    # Cucumber+Serenity

## Run with Tags
mvn test -Dkarate.options="--tags @smoke"
mvn verify -Dcucumber.filter.tags="@smoke"

## Run Parallel
mvn test -Dkarate.options="--threads 5"

## Reports
- Allure: mvn allure:serve
- Serenity: open target/site/serenity/index.html
- Karate: open target/karate-reports/karate-summary.html

## JaCoCo Coverage
See [JaCoCo section] for code coverage instructions.

## Test Suite Summary
| Feature | Positive | Negative | Edge | Business | Total |
|---------|----------|----------|------|----------|-------|
| ...     | ...      | ...      | ...  | ...      | ...   |
```
