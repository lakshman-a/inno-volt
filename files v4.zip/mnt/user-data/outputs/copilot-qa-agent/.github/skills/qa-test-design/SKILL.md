---
name: qa-test-design
description: QA test design methodology for API functional testing. Systematic CRUD coverage matrices, scenario design patterns, input analysis, gap analysis algorithm, and anti-patterns to avoid.
---

# QA Test Design Methodology

## Coverage Matrix (Build BEFORE writing tests)
```
| Endpoint            | Positive | Negative | Edge | Business | Total |
|---------------------|----------|----------|------|----------|-------|
| POST /resource      |    3+    |    5+    |  3+  |   2+     |  13+  |
| GET /resource/{id}  |    2+    |    3+    |  2+  |   1+     |   8+  |
| GET /resource       |    3+    |    2+    |  3+  |   1+     |   9+  |
| PUT /resource/{id}  |    3+    |    4+    |  2+  |   2+     |  11+  |
| DELETE /resource/{id}|   2+    |    3+    |  2+  |   2+     |   9+  |
```

## Minimum Scenarios Per CRUD Operation

**CREATE:** Valid all-fields, valid required-only, data-driven combos | Missing each required field, invalid types/formats, exceeds max, duplicate unique, no auth(401), wrong role(403), malformed body | Boundary values, special chars, empty vs null vs missing | Cross-field validation, computed fields

**READ Single:** Retrieve existing, verify all fields | Non-existent ID(404), invalid ID format(400), no auth(401), wrong owner(403) | Read after create, read after update

**READ List:** Default pagination, custom page/size, filter each field, sort asc/desc | Invalid params, invalid filters | Empty results, single result, beyond-data page

**UPDATE:** Full update, partial(PATCH), multiple fields | Update read-only field, invalid values, non-existent(404), no auth, conflict(409) | Idempotent update, boundary values | State-dependent, cascading effects

**DELETE:** Delete existing(204), verify gone(GET→404) | Non-existent(404), no auth, has dependencies(409) | Double delete | Soft delete, cascade effects

## Auth Matrix
Valid creds→200, valid token→authorized, no token→401, expired→401, malformed→401, wrong role→403

## Input Analysis
- **Swagger:** Extract all endpoints, schemas, constraints (required, min, max, pattern, enum)
- **Java Code:** Read @RestController, DTO validations (@NotNull, @Size, @Pattern, @Email), service logic, exception handlers
- **Requirements:** Map each acceptance criterion to 1+ scenarios, extract business rules
- **DB Schema:** Map entity fields to API fields, identify constraints, plan DB assertions

## Gap Analysis
1. Catalog existing: endpoint + type + what it validates
2. Compare to matrix minimums
3. Gap = Expected - Actual (> 0 means missing)
4. Priority: Critical(missing happy path/auth) > High(missing field validation) > Medium(edge cases)

## Anti-Patterns (NEVER)
1. Status-code-only tests (validate body+headers too)
2. Assumption-based tests (ask if unclear)
3. Sequential dependencies (each scenario independent)
4. Hardcoded values (use config/data files)
5. Missing negatives (every positive needs 2+ negatives)
6. Technical jargon in scenario names (use business language)
7. Empty assertions (every Then asserts something real, or fail() placeholder)
8. Flaky patterns (no sleep, no time-dependent, no order-dependent)
