---
name: qa-cucumber-serenity
description: Cucumber + Serenity BDD framework patterns for API functional testing. Project structure, POM dependencies, feature file standards, step definitions, configuration, and runner templates.
---

# Cucumber + Serenity BDD Standards

## Standalone Test Project POM (Template)
Detect system Java version with `java -version` and match.
```xml
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.{org}</groupId>
    <artifactId>{project}-api-tests</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <properties>
        <java.version>[DETECT FROM SYSTEM]</java.version>
        <serenity.version>4.1.4</serenity.version>
        <cucumber.version>7.15.0</cucumber.version>
        <assertj.version>3.25.1</assertj.version>
    </properties>
    <dependencies>
        <!-- Serenity + Cucumber + REST -->
        <dependency><groupId>net.serenity-bdd</groupId><artifactId>serenity-core</artifactId><version>${serenity.version}</version><scope>test</scope></dependency>
        <dependency><groupId>net.serenity-bdd</groupId><artifactId>serenity-cucumber</artifactId><version>${serenity.version}</version><scope>test</scope></dependency>
        <dependency><groupId>net.serenity-bdd</groupId><artifactId>serenity-rest-assured</artifactId><version>${serenity.version}</version><scope>test</scope></dependency>
        <dependency><groupId>io.cucumber</groupId><artifactId>cucumber-java</artifactId><version>${cucumber.version}</version><scope>test</scope></dependency>
        <!-- Reporting -->
        <dependency><groupId>io.qameta.allure</groupId><artifactId>allure-cucumber7-jvm</artifactId><version>2.25.0</version><scope>test</scope></dependency>
        <!-- Assertions & Utils -->
        <dependency><groupId>org.assertj</groupId><artifactId>assertj-core</artifactId><version>${assertj.version}</version><scope>test</scope></dependency>
        <dependency><groupId>com.fasterxml.jackson.core</groupId><artifactId>jackson-databind</artifactId><version>2.16.1</version><scope>test</scope></dependency>
        <dependency><groupId>com.github.javafaker</groupId><artifactId>javafaker</artifactId><version>1.0.2</version><scope>test</scope></dependency>
        <dependency><groupId>org.slf4j</groupId><artifactId>slf4j-simple</artifactId><version>2.0.11</version><scope>test</scope></dependency>
    </dependencies>
    <build><plugins>
        <plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-surefire-plugin</artifactId><version>3.2.3</version><configuration><skip>true</skip></configuration></plugin>
        <plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-failsafe-plugin</artifactId><version>3.2.3</version>
            <configuration><includes><include>**/*Runner.java</include></includes>
                <systemPropertyVariables><environment>${env}</environment></systemPropertyVariables>
            </configuration>
            <executions><execution><goals><goal>integration-test</goal><goal>verify</goal></goals></execution></executions>
        </plugin>
        <plugin><groupId>net.serenity-bdd.maven.plugins</groupId><artifactId>serenity-maven-plugin</artifactId><version>${serenity.version}</version>
            <executions><execution><id>reports</id><phase>post-integration-test</phase><goals><goal>aggregate</goal></goals></execution></executions>
        </plugin>
        <plugin><groupId>io.qameta.allure</groupId><artifactId>allure-maven</artifactId><version>2.12.0</version></plugin>
    </plugins></build>
</project>
```

## Project Structure
```
{project}-api-tests/
├── pom.xml
├── README.md
└── src/test/
    ├── java/com/{org}/{project}/
    │   ├── runners/ (TestSuiteRunner, SmokeRunner, {Feature}Runner)
    │   ├── stepdefinitions/common/ (CommonApiSteps, AuthSteps, ValidationSteps)
    │   ├── stepdefinitions/{feature}/ ({Feature}Steps)
    │   ├── stepdefinitions/Hooks.java (@Before/@After with cleanup)
    │   ├── models/request/ & response/ (POJOs with Builder)
    │   ├── utils/ (ApiClient, TestDataBuilder, TestContext, ResponseValidator, DbValidator)
    │   └── constants/ (Endpoints, ErrorMessages)
    └── resources/
        ├── features/{feature}/ (_positive, _negative, _edge_cases .feature)
        ├── testdata/{feature}/ (JSON/CSV)
        ├── schemas/{feature}/ (JSON schema)
        ├── environments/ (dev.properties, qa.properties)
        ├── serenity.conf
        └── logback-test.xml
```

## Feature File Rules
- Tags: `@{feature} @api @{positive|negative|edge-case} @{smoke|regression} @{severity-*}`
- Business language scenario names (not HTTP verbs)
- Comment blocks: `# CONTEXT`, `# DATA`, `# ACTION`, `# VERIFICATION`
- Data tables for readable request data
- Scenario Outline for parameterized tests
- `@Step("description")` on every step def method
- `LOG.info()` at start and end of every step
- AssertJ with `.as("description")` for every assertion
- SoftAssertions for multi-field validation
- TestContext via PicoContainer DI for shared state

## Execution
```bash
mvn clean verify -Denvironment=dev            # Full suite
mvn clean verify -Dcucumber.filter.tags="@smoke"  # Smoke
mvn serenity:aggregate                        # Serenity report
mvn allure:serve                              # Allure report
```
