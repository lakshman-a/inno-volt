---
name: qa-jacoco-coverage
description: JaCoCo code coverage for functional API tests. Use when measuring test coverage, generating coverage reports, identifying uncovered code, or suggesting additional test cases based on coverage gaps. Covers TCP server mode, file mode, and offline instrumentation.
---

# JaCoCo Coverage for Functional API Tests

## Overview
JaCoCo measures which lines/branches/methods of the DEV code are exercised when functional tests hit the API. This requires:
1. Dev API running WITH JaCoCo agent attached
2. Functional tests executing against the instrumented API
3. Coverage dump and report generation

## Prerequisites Check
Before starting, verify:
```bash
# Check Java version
java -version

# Check if dev project builds
cd {dev-project}/
mvn clean package -DskipTests

# Find the built JAR/WAR
ls target/*.jar target/*.war 2>/dev/null
```

## Method 1: TCP Server Mode (Recommended)

### Step 1: Download JaCoCo
```bash
# Download JaCoCo agent
JACOCO_VERSION=0.8.12
curl -L -o jacoco-agent.jar \
  "https://repo1.maven.org/maven2/org/jacoco/org.jacoco.agent/${JACOCO_VERSION}/org.jacoco.agent-${JACOCO_VERSION}-runtime.jar"

# Download JaCoCo CLI (for report generation)
curl -L -o jacoco-cli.jar \
  "https://repo1.maven.org/maven2/org/jacoco/org.jacoco.cli/${JACOCO_VERSION}/org.jacoco.cli-${JACOCO_VERSION}-nodeps.jar"
```

### Step 2: Start Dev API with JaCoCo Agent
```bash
# Start the dev API with JaCoCo in tcpserver mode
java -javaagent:jacoco-agent.jar=output=tcpserver,address=localhost,port=6300,includes=com.your.package.* \
  -jar {dev-project}/target/{app-name}.jar \
  --spring.profiles.active=dev &

# Wait for API to be ready
echo "Waiting for API to start..."
until curl -sf http://localhost:8080/health > /dev/null 2>&1; do sleep 2; done
echo "API is ready!"
```

### Step 3: Run Functional Tests
```bash
cd {test-project}/
mvn clean test -Dkarate.env=local 2>&1 | tee test-execution.log
# OR for Cucumber:
mvn clean verify -Denvironment=local 2>&1 | tee test-execution.log
```

### Step 4: Dump Coverage Data
```bash
# Dump coverage from running JaCoCo agent
java -jar jacoco-cli.jar dump \
  --address localhost --port 6300 \
  --destfile jacoco-functional.exec

echo "Coverage data dumped to jacoco-functional.exec"
```

### Step 5: Generate Coverage Report
```bash
# Generate HTML report
java -jar jacoco-cli.jar report jacoco-functional.exec \
  --classfiles {dev-project}/target/classes \
  --sourcefiles {dev-project}/src/main/java \
  --html coverage-report \
  --csv coverage-report/coverage.csv \
  --name "Functional Test Coverage"

echo "HTML Report: coverage-report/index.html"
echo "CSV Data: coverage-report/coverage.csv"
```

### Step 6: Parse and Display Results
```bash
# Quick summary from CSV
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 JACOCO COVERAGE SUMMARY"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
# Parse CSV for coverage percentages
head -1 coverage-report/coverage.csv
tail -n +2 coverage-report/coverage.csv | while IFS=',' read -r group package class instr_m instr_c branch_m branch_c line_m line_c complex_m complex_c method_m method_c; do
  if [ "$instr_c" != "0" ] || [ "$instr_m" != "0" ]; then
    total=$((instr_m + instr_c))
    if [ "$total" -gt 0 ]; then
      pct=$((instr_c * 100 / total))
      echo "  $package.$class: ${pct}% instruction coverage"
    fi
  fi
done
```

## Method 2: File Mode (Simpler, no TCP)
```bash
# Start API — JaCoCo writes to file on JVM shutdown
java -javaagent:jacoco-agent.jar=destfile=jacoco-functional.exec,includes=com.your.package.* \
  -jar {dev-project}/target/{app-name}.jar &

# Run tests
cd {test-project}/ && mvn clean test

# Stop the API (triggers JaCoCo dump)
kill $(jps | grep {app-name} | awk '{print $1}')

# Generate report (same as Step 5 above)
```

## Method 3: Maven Plugin (For Spring Boot with Maven)
Add to DEV project pom.xml (temporary, for coverage):
```xml
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <version>0.8.12</version>
    <executions>
        <execution>
            <id>prepare-agent</id>
            <goals><goal>prepare-agent</goal></goals>
            <configuration>
                <output>tcpserver</output>
                <address>localhost</address>
                <port>6300</port>
                <includes>
                    <include>com/your/package/**</include>
                </includes>
            </configuration>
        </execution>
    </executions>
</plugin>
```

## When Dev Project NOT Available
If the dev project cannot be run locally:
1. Analyze source code (if readable) to map test coverage manually
2. Map each test scenario to controller methods/endpoints
3. Estimate coverage based on endpoint coverage:
```
Endpoint Coverage Estimate:
  POST /customers — 3 tests → ~60% estimated (missing error handlers)
  GET /customers/{id} — 2 tests → ~40% estimated (missing edge cases)
  ...
  Overall estimate: ~50% functional coverage
```
4. Identify GAPS: uncovered endpoints, untested code paths, missing error handlers
5. Note: "For exact coverage, run the dev API locally with JaCoCo agent"

## Using Coverage to Find Gaps
After generating the coverage report:
1. Identify classes/methods with < 50% coverage
2. Map uncovered lines to specific code paths (error handling, edge cases, branches)
3. Suggest specific additional test cases targeting uncovered code
4. Identify dead code (methods never called by any endpoint)
5. Present gap analysis with recommended new scenarios

## Integration with Agent Workflow
The agent should:
1. Ask: "Is the dev project runnable locally? Do you want JaCoCo coverage?"
2. If yes: Run full JaCoCo flow (download → instrument → test → report)
3. If no: Provide estimate and note limitation
4. After coverage: Analyze gaps → suggest new tests → generate → re-run
