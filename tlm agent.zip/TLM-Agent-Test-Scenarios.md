# TLM Agent — Test Scenarios & Validation Plan

## Test Projects & Scenarios to Validate Every Workflow

---

## Test Project 1: Java / Spring Boot (Full TLM)

### Setup
Create or use a project with:
```
- Java 11
- Spring Boot 2.7.x
- Spring Security 5.x (with WebSecurityConfigurerAdapter)
- Hibernate 5.x (with javax.persistence)
- Jackson 2.14.x
- Log4j 2.17.x
- Lombok 1.18.24
- Guava 31.x
- Commons Lang 3.12
- JUnit 5
- At least 10-15 unit tests
- application.yml with spring.redis.* properties
- Maven (pom.xml)
```

### Scenarios to Test

| # | Scenario | What to validate | Expected behavior |
|---|---|---|---|
| 1.1 | Type "hi" | Auto-scan runs, dashboard shown, smart menu appears | Shows Java project, all outdated deps, CVEs, App Mod recipes available |
| 1.2 | Option 1: Fix All | Full workflow end to end | All items upgraded, build green, tests pass |
| 1.3 | Option 2: Java TLM Fixes | Same as 1.2 but language-scoped | Java items only |
| 1.4 | Option 3: CVE Fixes only | Just security items | Only CVE items fixed, rest untouched |
| 1.5 | Option 4: Java Runtime (11→17) | Runtime only | Java version updated, removed APIs handled, JAXB dependency added |
| 1.6 | Approve with "Skip 5,8" | Selective execution | Items 5 and 8 skipped, rest upgraded |
| 1.7 | App Mod recipe usage | App Mod triggers for Spring Boot | Plan shows 📦 for Spring Boot, Jakarta, Java 17 |
| 1.8 | Agent mode for no-recipe items | Opus handles Spring Security | Plan shows 🧠 Opus for Security, Hibernate |
| 1.9 | Build failure recovery | Agent fixes compilation errors | Build fails → agent fixes → rebuilds → green |
| 1.10 | Test failure recovery | Agent fixes TLM-caused test failures | Tests fail → agent fixes only TLM-caused → re-run → pass |
| 1.11 | Jakarta migration completeness | All javax imports converted | `grep -r "javax.persistence" src/` returns 0 (but javax.crypto untouched) |
| 1.12 | Transitive dependency check | No conflicts in dependency tree | `mvn dependency:tree -Dverbose` shows no conflicts |
| 1.13 | Post-upgrade CVE check | No new vulnerabilities introduced | Agent reports clean or flags new CVEs |
| 1.14 | Suggested test cases | Agent provides test recommendations | List of suggested tests for changed code areas |
| 1.15 | Telemetry generation | Report saved automatically | tlm-config/tlm-telemetry-*.json exists with correct data |

### Key Validation: App Mod + Agent Completeness

**This is the critical test** (addresses the user feedback about App Mod fixing Spring but breaking others):

1. Run option 1 (Fix All)
2. After App Mod recipe runs for Spring Boot:
   - Verify agent continues to fix Spring Security (no recipe)
   - Verify agent fixes Hibernate API changes
   - Verify agent fixes all remaining libraries
   - Verify agent resolves transitive dependency conflicts
   - Verify final build is GREEN
   - Verify all tests pass

The whole point is that App Mod recipe is one STEP in the workflow, not the end.

---

## Test Project 2: Angular (Frontend TLM)

### Setup
Create or use a project with:
```
- Angular 15.x
- Angular Material 15.x
- RxJS 7.5.x
- TypeScript 4.9.x
- Zone.js (matching Angular 15)
- At least 2-3 enterprise/internal Angular packages
- Unit tests with Karma/Jasmine or Jest
- package.json + angular.json
- At least 5 components using *ngIf, *ngFor
```

### Scenarios to Test

| # | Scenario | What to validate | Expected behavior |
|---|---|---|---|
| 2.1 | Type "hi" | Detects Angular project | Dashboard shows Angular 15, outdated packages, menu shows Angular options |
| 2.2 | Angular TLM Fixes | Full Angular upgrade 15→17 | Step-by-step: 15→16, build, 16→17, build, all passing |
| 2.3 | Opus model used | Complex migration uses Opus | Plan shows 🧠 Opus for Angular (always) |
| 2.4 | Step-by-step upgrade | Never skips major versions | 15→16 first, verify, then 16→17 |
| 2.5 | RxJS migration | toPromise → firstValueFrom | All RxJS deprecations handled |
| 2.6 | TypeScript upgrade | TS version compatible with target Angular | TypeScript updated to match Angular version requirements |
| 2.7 | Control flow migration | *ngIf → @if (Angular 17) | Schematic applied or manual migration done |
| 2.8 | Transitive deps | No peer dependency warnings | `npm ls` shows clean tree, no ERESOLVE errors |
| 2.9 | ng build succeeds | Production build passes | `ng build --configuration=production` succeeds |
| 2.10 | Tests pass | Unit tests pass after upgrade | `ng test --watch=false` all green |
| 2.11 | Internal packages | Enterprise Angular packages handled | Internal packages upgraded with skills or user input |
| 2.12 | package-lock.json | Lock file regenerated cleanly | No stale entries, `npm ci` works |

### Key Validation: Angular Upgrade Completeness

- Must upgrade ONE major version at a time (15→16→17)
- Must rebuild after each major version
- Must handle peer dependency conflicts
- Must not leave broken `node_modules`
- Must use Opus (Angular is always complex)

---

## Test Project 3: Enterprise / Internal Libraries

### Setup
Create a Java project with real enterprise dependencies:
```xml
<!-- Simulate JSCI libraries (EOL March 2026) -->
<dependency>
    <groupId>com.fmr.jsci</groupId>
    <artifactId>fmr-commons-jwt</artifactId>
    <version>3.1.0</version>
</dependency>
<dependency>
    <groupId>com.fmr.jsci</groupId>
    <artifactId>fmr-commons-crypto</artifactId>
    <version>2.5.0</version>
</dependency>
<dependency>
    <groupId>com.fmr.jsci</groupId>
    <artifactId>fmr-commons-cs203</artifactId>
    <version>1.8.0</version>
</dependency>
<dependency>
    <groupId>com.fmr.jsci</groupId>
    <artifactId>fmr-commons-core</artifactId>
    <version>4.0.0</version>
</dependency>
<!-- AMT FSF (EOL June 2026) -->
<dependency>
    <groupId>com.fmr.amt</groupId>
    <artifactId>amt-fsf-rest</artifactId>
    <version>7.5.0</version>
</dependency>
<!-- Unknown enterprise lib (no skill) -->
<dependency>
    <groupId>com.enterprise.payments</groupId>
    <artifactId>payments-lib</artifactId>
    <version>1.5.0</version>
</dependency>
```

Add Java source files with:
- `import com.fmr.jsci.commons.jwt.*` statements
- `import com.fmr.jsci.commons.crypto.*` statements
- `import com.fmr.jsci.commons.logging.FmrLoggerFactory` usage
- Configuration references to `jil.fmr.com` or `jsci.fmr.com`

Also add a Dockerfile with:
```dockerfile
FROM registry.enterprise.com/ubn22/java-17-rhel8:latest
```

Enterprise skills (jsci-eol-retirement.md, amt-fsf-eol.md, rhel8-to-rhel9-buildpack.md) should be present. Do NOT create a skill for payments-lib.

### Scenarios to Test

| # | Scenario | What to validate | Expected behavior |
|---|---|---|---|
| 3.1 | Auto-detect enterprise libs | Scan detects JSCI, AMT FSF, RHEL | Dashboard: "🏢 Enterprise: 6 items (4 have skills, 1 needs guidance, 1 unknown)" |
| 3.2 | JSCI EOL full migration | All fmr-commons-* replaced | fmr-commons-jwt → dp-commons-jwt, fmr-commons-crypto → dp-crypto-utils, fmr-commons-cs203 → dp-http-request-guard, fmr-commons-core → SLF4J + java.util.concurrent |
| 3.3 | JSCI import updates | All com.fmr.jsci imports replaced | `grep -rn "com.fmr.jsci" src/` returns 0 results |
| 3.4 | JSCI infrastructure cleanup | jil.fmr.com / jsci.fmr.com references removed | No references to retired hosts remain |
| 3.5 | AMT FSF handling | Agent asks for guidance (no target version known) | Agent shows AMT FSF detected, explains EOL June 2026, asks user for target version or "skip" |
| 3.6 | RHEL8→9 buildpack | Dockerfile image updated | ubn22/rhel8 → ubn24/rhel9 in Dockerfile |
| 3.7 | No-skill item | payments-lib | Agent stops, asks for docs, provides options |
| 3.8 | User provides info | User gives description for payments-lib | Agent applies changes based on info |
| 3.9 | Skill auto-creation | User says "yes" to save payments-lib as skill | Skill file created in enterprise/ folder with correct metadata |
| 3.10 | Transitive JSCI cleanup | Transitive deps still pulling JSCI | `mvn dependency:tree | grep jsci` returns 0 — all transitive cleaned |

---

## Test Project 4: TLM List / SW EOL List Import

### Setup
Any Java or Angular project. Test with both formats:

**Format A: Enterprise SW EOL Spreadsheet paste (tab-separated):**
```
AP126148	AMT FSF Config Utils 7.5	Non-Campaign	Java	2026-06-30	2026-Q2	FMR
AP131679	AMT FSF Rest 7.5	Non-Campaign	Java	2026-06-30	2026-Q2	FMR
AP131679	AMT FSF Secret 7.5	Non-Campaign	Java	2026-06-30	2026-Q2	FMR
AP158606	Python Software Foundation Python 3.10	Non-Campaign	Non-Java / Python	2026-10-01	2026-Q4	BDNA
AP131679	Apache Software Foundation Hadoop Common 2.7	Non-Campaign	Java	Past Due	Past Due	FMR
AP003033	Microsoft ASP.NET 4.0	EOL > 10 years	Non-Java (.NET)	Past Due	Past Due	BDNA
```

**Format B: Simple text paste:**
```
Fix these from my TLM list:
AMT FSF Config Utils 7.5
AMT FSF Rest 7.5
Python 3.10
```

**Format C: CSV file (tlm-list.csv):**
```csv
library,current_version,target_version,priority,category
spring-boot-starter-parent,2.7.18,3.2.5,critical,framework
jackson-databind,2.14.0,2.17.0,high,library
log4j-core,2.17.1,2.23.1,critical,security
fmr-commons-jwt,3.1.0,,high,enterprise-internal
angular-core,15.2.0,17.3.0,critical,framework
some-lib-not-in-project,1.0,2.0,low,library
```

### Scenarios to Test

| # | Scenario | What to validate | Expected behavior |
|---|---|---|---|
| 4.1 | SW EOL spreadsheet paste | Agent parses enterprise format | Extracts: Software Model, EOL date, Timeline. Shows priority grouping |
| 4.2 | Simple text paste | Agent parses plain names | Matches against project deps, shows plan |
| 4.3 | CSV file detection | Agent finds tlm-list.csv | Dashboard shows: "Found: tlm-list.csv (6 items, 4 match)" |
| 4.4 | Priority ordering | Past Due items first | Past Due (Hadoop) → 2026-Q2 (AMT FSF) → 2026-Q4 (Python) |
| 4.5 | Mixed methods | Different upgrade methods | Recipe for spring-boot, agent for jackson, skill for JSCI, ask for AMT FSF |
| 4.6 | Unmatched items | Items not in project | "Microsoft ASP.NET 4.0 → not found in project (skipping)" |

---

## Test Project 5: Dependency Resolution Edge Cases

### Setup
Project with known dependency conflicts:

```xml
<!-- Jackson version managed by Spring Boot -->
<!-- But explicit version override causing conflict -->
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <version>2.14.0</version> <!-- conflicts with spring-boot managed version -->
</dependency>
```

### Scenarios to Test

| # | Scenario | What to validate | Expected behavior |
|---|---|---|---|
| 5.1 | Version conflict detection | Agent detects conflict | Warns about jackson version conflict with Spring Boot managed version |
| 5.2 | Resolution strategy | Agent resolves conflict | Removes explicit version (uses Spring Boot managed) or aligns versions |
| 5.3 | Artifact not found | Version not in Nexus | Agent pauses, offers alternatives: try nearby version, skip, ask user |
| 5.4 | Retry with alternate version | User approves alternate | Agent tries next closest available version |
| 5.5 | Transitive conflict | Library A needs X 2.0, Library B needs X 3.0 | Agent detects, resolves via exclusion or BOM |

---

## Test Project 6: Multi-Language Project

### Setup
Project with both Java backend and Angular frontend:

```
my-fullstack-app/
├── backend/
│   ├── pom.xml (Java 11, Spring Boot 2.7)
│   └── src/
├── frontend/
│   ├── package.json (Angular 15)
│   ├── angular.json
│   └── src/
└── docker-compose.yml
```

### Scenarios to Test

| # | Scenario | What to validate | Expected behavior |
|---|---|---|---|
| 6.1 | Multi-lang detection | Both detected | Dashboard shows: "Backend: Java 11/Maven/Spring Boot 2.7, Frontend: Angular 15/npm" |
| 6.2 | Combined menu | Shows options for both | Menu has Java AND Angular options plus "Fix All" |
| 6.3 | Fix All (both) | Entire project upgraded | Backend and frontend both upgraded and building |
| 6.4 | Fix Java only | Backend only | Frontend untouched |
| 6.5 | Fix Angular only | Frontend only | Backend untouched |

---

## Test Project 7: Custom Prompts & Memory

### Scenarios to Test

| # | Scenario | What to validate | Expected behavior |
|---|---|---|---|
| 7.1 | Custom prompt alongside workflow | User types own instruction after menu | Agent incorporates user's custom prompt |
| 7.2 | "Upgrade only jackson to 2.17" | Direct specific command, no menu | Agent upgrades jackson only, builds, tests |
| 7.3 | "Fix all but skip enterprise" | Custom scope | All items except enterprise upgraded |
| 7.4 | Skill auto-creation from manual fix | Fix enterprise lib → save as skill | Skill file created, formatted correctly |
| 7.5 | Skill reuse verification | New project uses auto-generated skill | Skill loaded and applied correctly |

---

## Test Project 8: Pre-Upgrade Baseline Check

### Scenarios to Test

| # | Scenario | What to validate | Expected behavior |
|---|---|---|---|
| 8.1 | Initial compile check | Agent compiles before changes | Shows: "Current project compiles ✅" or "Current project has issues ⚠️" |
| 8.2 | Baseline test count | Agent runs tests before changes | Shows: "140 tests pass, 2 pre-existing failures" |
| 8.3 | Post-upgrade comparison | No new failures introduced | Post-upgrade test count >= baseline (new tests OK, no regressions) |

---

## Validation Checklist (Run After Every Agent Change)

```
□ Greeting triggers auto-scan
□ Dashboard shows accurate project info
□ Menu is context-aware (only relevant options)
□ Each menu option has clear subtitle/description
□ Plan shows all items with methods (recipe/agent/skill)
□ Plan shows App Mod recipe usage clearly (📦)
□ Plan shows no-recipe items clearly (❌ → 🧠)
□ Approval is required before execution
□ "Skip" and "Only" work in approval step
□ Execution shows real-time progress
□ App Mod recipe is used where available
□ Agent continues AFTER recipe (doesn't stop)
□ Opus used for complex items (Angular, Spring Boot, Security)
□ Sonnet used for simple items
□ Enterprise skills are loaded and followed
□ No-skill enterprise items prompt for user input
□ Build runs after each phase
□ Build errors are fixed iteratively
□ Dependency conflicts are detected and resolved
□ Artifact not found → pause and offer options
□ Tests run after all upgrades
□ Only TLM-caused test failures are fixed
□ Pre-existing failures are noted but untouched
□ Safety tests suggested for major changes
□ CVE check runs post-upgrade
□ Final clean build is GREEN
□ Report shows complete summary
□ Telemetry JSON is generated
□ Suggested test cases provided
□ User can return to menu at any point
□ Custom prompts work alongside workflow
□ Skill auto-creation works from manual fixes
```

---

## Recommended Open-Source Projects for Testing

These are real projects you can fork to test the TLM Agent:

### Java / Spring Boot
1. **Spring PetClinic** — https://github.com/spring-projects/spring-petclinic
   - Classic Spring Boot app, well-structured, has tests
   - Good for testing Spring Boot 2→3 migration

2. **Spring Boot Realworld Example** — https://github.com/gothinkster/spring-boot-realworld-example-app
   - REST API with Security, JPA, tests
   - Good for testing Security migration

3. **Java Design Patterns** — https://github.com/iluwatar/java-design-patterns
   - Large multi-module Maven project
   - Good for testing multi-module handling

### Angular
4. **Angular RealWorld Example** — https://github.com/gothinkster/angular-realworld-example-app
   - Full Angular app with routing, services, components
   - Good for testing Angular version migration

5. **Angular Spotify Clone** — https://github.com/nicolestandifer3/angular-spotify-clone
   - Complex Angular app with many dependencies
   - Good for testing transitive dependency resolution

### Python
6. **Django REST Framework Tutorial** — https://github.com/encode/rest-framework-tutorial
   - Django project with DRF
   - Good for testing Django upgrades

### Multi-Language
7. **Full-stack Spring Boot + Angular** — search GitHub for spring-boot-angular projects
   - Good for testing multi-language detection and combined upgrades
