# Complete Setup, Test & Review Guide

## Table of Contents
- [Prerequisites](#prerequisites)
- [Step 1: VS Code Setup](#step-1-vs-code-setup)
- [Step 2: Install Files to Your Repository](#step-2-install-files-to-your-repository)
- [Step 3: Verify Installation](#step-3-verify-installation)
- [Step 4: Activate the Agent](#step-4-activate-the-agent)
- [Step 5: Test with Sample Scenarios](#step-5-test-with-sample-scenarios)
- [Step 6: Review & Validate Output Quality](#step-6-review--validate-output-quality)
- [Step 7: Troubleshoot Common Issues](#step-7-troubleshoot-common-issues)
- [Step 8: Roll Out to Team](#step-8-roll-out-to-team)

---

## Prerequisites

### Required
- [ ] **VS Code** — Version 1.106 or later (check: `Help → About`)
- [ ] **GitHub Copilot extension** — Installed and active (check: Copilot icon in status bar)
- [ ] **GitHub Copilot Chat extension** — Installed and active
- [ ] **Copilot subscription** — Business or Enterprise (with Claude model access)
- [ ] **A Java/Maven project** — With API code to test (or a sample project to try with)

### Verify VS Code Version
```
Help → About → Check version is 1.106+
```
If older, update VS Code: `Help → Check for Updates`

### Verify Copilot Extensions
1. Open Extensions panel (`Ctrl+Shift+X`)
2. Search "GitHub Copilot" — should show **installed**
3. Search "GitHub Copilot Chat" — should show **installed**
4. Both should show the green "enabled" indicator

---

## Step 1: VS Code Setup

### 1.1 Enable Custom Agents & Instructions
Open VS Code Settings (`Ctrl+,` or `Cmd+,`), search for each setting:

```
github.copilot.chat.useCustomInstructions → ✅ Enabled (checked)
chat.agent.enabled → ✅ Enabled (checked)
```

You can also set these in `settings.json`:
```json
{
    "github.copilot.chat.useCustomInstructions": true,
    "chat.agent.enabled": true
}
```

### 1.2 Select Claude Model
1. Open Copilot Chat panel (`Ctrl+Shift+I` or `Cmd+Shift+I`)
2. Look at the bottom of the chat input — there's a **model selector**
3. Click it and select:
   - **Claude Sonnet 4.5** — for daily use (fast + good quality)
   - **Claude Opus 4.5** — for complex full-suite generation

> **Note:** If you don't see Claude models, your org admin may need to enable them in GitHub Copilot organization settings. Check with your admin under:
> `github.com → Organization Settings → Copilot → Policies → Model selection`

### 1.3 Verify Agent Mode is Available
In the Copilot Chat panel, look for a **dropdown at the top** that shows different agents/modes:
- `Ask` — Q&A mode
- `Agent` — Autonomous agent mode
- Custom agents will appear here after setup

If you see this dropdown, you're ready. If not, ensure your VS Code is updated to 1.106+.

---

## Step 2: Install Files to Your Repository

### 2.1 File Structure to Copy
Copy the entire `.github/` directory contents to your project root:

```
your-project/
├── .github/
│   ├── copilot-instructions.md              ← Global instructions (auto-loaded)
│   ├── agents/
│   │   └── senior-qa-automation.agent.md    ← The QA agent definition
│   ├── instructions/
│   │   └── qa-testing.instructions.md       ← Dynamic test instructions
│   └── skills/
│       ├── qa-cucumber-serenity/
│       │   └── SKILL.md                     ← Cucumber+Serenity patterns
│       ├── qa-karate-dsl/
│       │   └── SKILL.md                     ← Karate patterns
│       └── qa-test-design/
│           └── SKILL.md                     ← Test design methodology
├── pom.xml                                  ← Your project's pom.xml
├── src/
│   ├── main/                                ← Your API source code
│   └── test/                                ← Your existing tests (if any)
└── ...
```

### 2.2 Copy Commands

**Option A: If you downloaded the files from this package:**
```bash
# Navigate to your project
cd /path/to/your-project

# Create directories if they don't exist
mkdir -p .github/agents
mkdir -p .github/instructions
mkdir -p .github/skills/qa-cucumber-serenity
mkdir -p .github/skills/qa-karate-dsl
mkdir -p .github/skills/qa-test-design

# Copy each file (adjust source path to where you downloaded them)
cp <download-path>/copilot-instructions.md .github/
cp <download-path>/agents/senior-qa-automation.agent.md .github/agents/
cp <download-path>/instructions/qa-testing.instructions.md .github/instructions/
cp <download-path>/skills/qa-cucumber-serenity/SKILL.md .github/skills/qa-cucumber-serenity/
cp <download-path>/skills/qa-karate-dsl/SKILL.md .github/skills/qa-karate-dsl/
cp <download-path>/skills/qa-test-design/SKILL.md .github/skills/qa-test-design/
```

**Option B: Manual creation in VS Code:**
1. Right-click project root → New Folder → `.github`
2. Inside `.github`, create `agents`, `instructions`, `skills` folders
3. Create each file and paste contents from the provided files

### 2.3 Important: Don't Overwrite Existing `.github` Files
If your project already has `.github/workflows/` or other files, DON'T overwrite them. The new folders (`agents/`, `instructions/`, `skills/`) won't conflict with existing CI/CD workflows.

---

## Step 3: Verify Installation

### 3.1 Check Files Are Detected
1. Open your project in VS Code
2. Open Command Palette (`Ctrl+Shift+P` or `Cmd+Shift+P`)
3. Type: `Chat: Diagnostics`  (or right-click in the Chat panel → `Diagnostics`)
4. This will show all loaded instruction files, agents, and any errors

You should see:
```
✅ copilot-instructions.md — loaded
✅ qa-testing.instructions.md — loaded
✅ senior-qa-automation.agent.md — loaded
✅ qa-cucumber-serenity/SKILL.md — loaded
✅ qa-karate-dsl/SKILL.md — loaded
✅ qa-test-design/SKILL.md — loaded
```

### 3.2 Check Agent Appears in Dropdown
1. Open Copilot Chat panel
2. Click the agent/mode dropdown at the top (or bottom)
3. Look for **"Senior QA Automation Engineer"**
4. If it appears → you're good!

If it doesn't appear:
- Click "Configure Custom Agents" in the dropdown
- Your `.agent.md` file should be listed
- If not, check the file is in `.github/agents/` and has the `.agent.md` extension
- Try reloading VS Code: `Ctrl+Shift+P` → `Developer: Reload Window`

### 3.3 Quick Smoke Test
1. Select the "Senior QA Automation Engineer" agent
2. Type: `hi`
3. Expected: The agent should:
   - Scan your workspace
   - Report detected framework (or say none found)
   - Report existing test coverage
   - Present the 7-option menu

If you get a generic response instead of the structured menu, the agent file might not be loaded. Check Step 3.1 diagnostics.

---

## Step 4: Activate the Agent

### 4.1 Select the Agent
1. Open Copilot Chat panel (`Ctrl+Shift+I`)
2. Click the agent dropdown
3. Select **"Senior QA Automation Engineer"**
4. The chat input placeholder should change to show the agent's description

### 4.2 First Interaction
Type one of these to start:
- `hi` or `hello` — Agent initializes and shows menu
- `I need to create API tests` — Agent asks for input type
- `analyze my test coverage` — Agent scans existing tests
- `help me test POST /api/v1/orders` — Agent enters quick mode

The agent will guide you from here. You don't need to memorize any commands.

---

## Step 5: Test with Sample Scenarios

### Test Scenario 1: Basic Initialization
```
You: hi
Expected: Agent scans workspace, shows framework detection, presents 7-option menu
Pass if: You see the structured menu with numbered options
```

### Test Scenario 2: Create Tests from Code
```
You: 1
You: B — look at the [YourController] class
Expected: Agent reads the controller, extracts endpoints, presents test plan
Pass if: Test plan lists positive, negative, edge cases with counts
```

### Test Scenario 3: Quick Single Endpoint
```
You: Generate comprehensive tests for POST /api/v1/customers
Expected: Agent asks for swagger/code reference, then generates focused test suite
Pass if: Tests include positive, negative, edge cases with proper assertions
```

### Test Scenario 4: Gap Analysis
```
You: 5 — analyze my test coverage
Expected: Agent scans existing features, builds gap report
Pass if: Gap report shows categorized missing scenarios with priorities
```

### Test Scenario 5: Framework Scaffolding (for new projects)
```
You: 7 — scaffold Karate test framework
Expected: Agent asks for project details, generates complete structure
Pass if: Generates pom.xml, karate-config.js, runners, sample features
```

### Test Scenario 6: Verify No Hallucination
```
You: Generate tests for the payment refund API
(without providing any swagger, code, or requirements)
Expected: Agent asks for input — does NOT generate tests from assumptions
Pass if: Agent says "I need more information" and asks structured questions
```

---

## Step 6: Review & Validate Output Quality

### Quality Checklist for Generated Tests

After the agent generates test cases, review against this checklist:

#### Structure & Organization
- [ ] Feature files are organized by type (positive/negative/edge)
- [ ] File naming follows convention: `{feature}_{type}.feature`
- [ ] Directory structure matches existing project patterns
- [ ] Tags are present on every scenario (feature, type, suite, severity)

#### Scenario Quality
- [ ] Scenario names describe BUSINESS behavior, not HTTP verbs
- [ ] Given-When-Then structure is clear and logical
- [ ] Each scenario tests ONE specific thing
- [ ] No two scenarios are testing the same thing

#### Coverage
- [ ] Positive cases cover all valid paths
- [ ] Negative cases cover missing fields, invalid values, auth failures
- [ ] Edge cases cover boundaries, special chars, nulls
- [ ] Business rules are tested if provided

#### Assertions
- [ ] Every scenario validates status code AND response body
- [ ] Response structure is validated (schema match or field-by-field)
- [ ] Error responses validate error message/structure
- [ ] System-generated fields checked (UUID format, timestamps)

#### Data Management
- [ ] Test data is in external files (not hardcoded inline)
- [ ] Data is realistic (not "test", "test", "test@test.com")
- [ ] Scenario Outline used for multiple data combinations

#### Configuration
- [ ] URLs are from config (not hardcoded)
- [ ] Auth tokens are from config or auth setup
- [ ] Environment switching is supported

#### Executability
- [ ] Maven execution commands are provided
- [ ] Tests can be run independently (no sequence dependency)
- [ ] Report generation commands are included

### Red Flags (Reject if you see these)
- ❌ Hardcoded URLs in feature files
- ❌ Scenarios named like "POST /api/v1/users returns 200"
- ❌ Status code-only assertions (no body validation)
- ❌ Test data like "test", "abc", "123" everywhere
- ❌ No tags on scenarios
- ❌ No logging statements
- ❌ Tests assume data from other tests

---

## Step 7: Troubleshoot Common Issues

### Agent doesn't appear in dropdown
**Fix:**
1. Verify file is at `.github/agents/senior-qa-automation.agent.md`
2. Verify file extension is `.agent.md` (not `.md` alone)
3. Reload VS Code: `Ctrl+Shift+P` → `Developer: Reload Window`
4. Check diagnostics: `Ctrl+Shift+P` → `Chat: Diagnostics`

### Agent gives generic responses (not using the QA persona)
**Fix:**
1. Make sure you've SELECTED the agent from the dropdown (not just "Agent" mode)
2. Check that `github.copilot.chat.useCustomInstructions` is `true`
3. Try starting a **new chat session** (old sessions may not pick up new agents)

### Claude model not available
**Fix:**
1. Check org settings: `github.com → Org Settings → Copilot → Policies`
2. Claude models may need to be explicitly enabled by org admin
3. If only GPT models are available, the agent will still work but Claude is recommended

### Skills not being loaded
**Fix:**
1. Verify SKILL.md files are in `.github/skills/{skill-name}/SKILL.md`
2. Each skill must have its own subdirectory
3. The SKILL.md must have valid YAML frontmatter with `name` and `description`
4. Check diagnostics view for errors

### Framework not auto-detected
**Fix:**
1. Ensure `pom.xml` is in the workspace root (or opened folder root)
2. If pom.xml is in a subdirectory, tell the agent: "check pom.xml in [path]"
3. If multi-module, specify which module to target

### Tests won't compile/run after generation
**Fix:**
1. Share the error with the agent: paste the compilation/runtime error
2. Say: "fix these compilation errors in the generated tests"
3. The agent will diagnose and fix the issues

### Agent hallucinates or assumes behavior
**Fix:**
1. This shouldn't happen with the instructions, but if it does:
2. Say: "Stop. Don't assume anything. What information do you need from me?"
3. Provide more specific input (actual swagger, actual code)
4. File feedback to refine the agent instructions

---

## Step 8: Roll Out to Team

### 8.1 Commit to Repo
```bash
cd your-project
git add .github/
git commit -m "feat: add QA automation agent for Copilot"
git push
```

Once merged, every developer who opens this repo in VS Code will automatically have the agent available.

### 8.2 Share with Team
Send this to your team:

```
📣 NEW: QA Test Generation Agent in Copilot

We've added a custom AI agent that generates comprehensive API test cases.

Setup (one-time):
1. Update VS Code to 1.106+
2. Open our repo in VS Code
3. Open Copilot Chat (Ctrl+Shift+I)
4. Select "Senior QA Automation Engineer" from agent dropdown
5. Set model to Claude Sonnet 4.5 (in model dropdown)
6. Type "hi" — the agent will guide you from there

What it does:
- Auto-detects Cucumber/Karate framework
- Scans existing tests before generating new ones
- Creates positive, negative, edge, and business test cases
- Writes in business language, not technical jargon
- Never assumes — asks when unclear

Try it and share feedback!
```

### 8.3 Collect Feedback
Track these metrics from your team:
- Did generated tests compile on first try?
- Did generated tests pass on first run?
- Were coverage gaps identified correctly?
- Were scenarios business-readable?
- How much time was saved vs manual test writing?
- What needs improvement?

### 8.4 Iterate
Based on feedback, update the `.agent.md` and `SKILL.md` files. Since they're in the repo, every `git pull` will update the agent for all team members automatically.

---

## Quick Reference Card

```
┌─────────────────────────────────────────────────────┐
│             QA AGENT QUICK REFERENCE                │
├─────────────────────────────────────────────────────┤
│                                                     │
│  Activate: Copilot Chat → Agent dropdown            │
│            → "Senior QA Automation Engineer"        │
│                                                     │
│  Model:    Claude Sonnet 4.5 (daily use)            │
│            Claude Opus 4.5 (complex tasks)          │
│                                                     │
│  Start:    Type "hi" → follow the menu              │
│                                                     │
│  Files:    .github/agents/senior-qa-automation      │
│            .github/skills/qa-*/SKILL.md             │
│            .github/copilot-instructions.md          │
│                                                     │
│  Diagnose: Ctrl+Shift+P → Chat: Diagnostics        │
│  Reload:   Ctrl+Shift+P → Developer: Reload Window │
│                                                     │
│  Feedback: Share with QA Platform team              │
│                                                     │
└─────────────────────────────────────────────────────┘
```
