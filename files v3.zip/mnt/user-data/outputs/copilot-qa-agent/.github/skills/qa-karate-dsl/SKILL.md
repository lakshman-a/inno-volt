---
name: qa-karate-dsl
description: Karate DSL framework patterns for API functional testing. Auto-loaded when Karate dependencies are detected in pom.xml. Covers project structure, POM template, karate-config.js, feature file standards, match expressions, and execution commands.
---

# Karate DSL — Framework Standards

## Project Structure
```
src/test/
├── java/com/{org}/{project}/
│   ├── KarateTestRunner.java
│   ├── SmokeTestRunner.java
│   └── helpers/
│       ├── DataGenerator.java
│       └── CustomUtils.java
└── resources/
    ├── karate-config.js
    ├── logback-test.xml
    ├── features/{feature}/
    │   ├── {feature}_positive.feature
    │   ├── {feature}_negative.feature
    │   └── {feature}_edge_cases.feature
    ├── features/common/
    │   ├── auth.feature (@ignore, callSingle)
    │   ├── health-check.feature (@ignore)
    │   └── cleanup.feature (@ignore)
    ├── testdata/{feature}/ (JSON/CSV/JS files)
    └── schemas/{feature}/ (JSON match schemas)
```

## Key Dependencies (pom.xml)
- `com.intuit.karate:karate-junit5:1.4.1`
- `io.qameta.allure:allure-karate:2.25.0` (optional)
- Use `maven-surefire-plugin` with `-Dkarate.env=${karate.env}` system property
- Add testResources for both `src/test/resources` and `src/test/java` (excluding *.java)

## karate-config.js Template
```javascript
function fn() {
    var env = karate.env || 'dev';
    var config = { baseUrl: '', authUrl: '', authToken: '' };
    var envConfig = {
        dev:     { baseUrl: 'https://dev-api.example.com' },
        qa:      { baseUrl: 'https://qa-api.example.com' },
        staging: { baseUrl: 'https://staging-api.example.com' }
    };
    var selected = envConfig[env] || envConfig['dev'];
    config.baseUrl = selected.baseUrl;
    var auth = karate.callSingle('classpath:features/common/auth.feature', config);
    config.authToken = auth.authToken;
    karate.configure('headers', { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + config.authToken });
    karate.configure('logPrettyRequest', true);
    karate.configure('logPrettyResponse', true);
    return config;
}
```

## Feature File Standards
- Same tagging as Cucumber: `@{feature} @api @{type} @{suite} @{severity}`
- Use section comments: `# ── SETUP ──`, `# ── ACTION ──`, `# ── VERIFY ──`, `# ── CLEANUP ──`
- Use `karate.log()` at every key step
- Load test data from files: `* def data = read('classpath:testdata/...')`
- Load schemas for validation: `* def schema = read('classpath:schemas/...')`
- Use `remove` keyword to test missing fields: `* remove baseData.fieldName`
- Use `set` keyword to test invalid values: `* set data.field = 'invalid'`

## Match Expressions Reference
```
#null, #notnull, #present, #notpresent, #ignore
#uuid, #string, #number, #boolean, #array, #object
#regex <pattern>, #? <js expression>
##string (optional string: null or string)
#[5] (array of exactly 5), #[_ > 0] (array where each > 0)
```

## Reusable Features
- `auth.feature` (@ignore): Called via `karate.callSingle()` — cached across suite
- `health-check.feature` (@ignore): Use `retry until responseStatus == 200`
- `cleanup.feature` (@ignore): Generic delete by resource type + ID

## Runners
```java
class KarateTestRunner {
    @Test void testAll() {
        Results results = Runner.path("classpath:features").tags("~@ignore", "~@wip").parallel(5);
        assertEquals(0, results.getFailCount(), results.getErrorMessages());
    }
}
```

## Execution Commands
```bash
mvn test                                          # All tests (default dev)
mvn test -Dkarate.env=qa                          # Specific environment
mvn test -Dkarate.options="--tags @smoke"          # Specific tags
mvn test -Dkarate.options="--threads 10"           # Parallel execution
# Report: target/karate-reports/karate-summary.html
```
