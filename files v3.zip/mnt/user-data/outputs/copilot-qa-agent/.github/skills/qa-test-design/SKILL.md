---
name: qa-test-design
description: QA test design methodology and patterns for API functional testing. Always loaded for any test generation request. Covers systematic CRUD test matrices, coverage patterns, test data design, validation checklists, and anti-patterns.
---

# QA Test Design Methodology

## Coverage Matrix (Build BEFORE writing any tests)

For every feature, create this matrix:
```
| Endpoint / Function | Positive | Negative | Edge Case | Business | Total |
|---------------------|----------|----------|-----------|----------|-------|
| POST /resource      |    3     |    6     |    4      |    2     |  15   |
| GET /resource/{id}  |    2     |    3     |    2      |    1     |   8   |
| ...                 |   ...    |   ...    |   ...     |   ...    |  ...  |
```

## CRUD Test Design Matrix

### CREATE (POST) — Minimum scenarios:
**Positive (3+):** All required fields valid, all fields valid, multiple data combos (Scenario Outline)
**Negative (5+):** Missing each required field, invalid data types, invalid formats, exceeds max length, duplicate unique field, no auth (401), wrong role (403), malformed body (400)
**Edge (3+):** Boundary values (min/max), special chars (O'Brien, unicode), empty vs null vs missing, large payload
**Business:** Cross-field validation, computed fields, state-dependent creation

### READ Single (GET /{id}):
**Positive:** Retrieve existing, verify all fields match created
**Negative:** Non-existent ID (404), invalid ID format (400), no auth (401), wrong owner (403)
**Edge:** Read after create, read after update

### READ List (GET with params):
**Positive:** Default pagination, custom page/size, filter by each field, sort asc/desc
**Negative:** Invalid pagination params, invalid filter values
**Edge:** Empty results, exactly one result, page beyond data

### UPDATE (PUT/PATCH):
**Positive:** Full update, partial update, multiple fields
**Negative:** Update read-only field, invalid values, non-existent resource (404), no auth
**Edge:** Idempotent update (same values), boundary values
**Business:** State-dependent updates, cascading effects

### DELETE:
**Positive:** Delete existing (204), verify gone (GET → 404)
**Negative:** Delete non-existent (404), no auth, has dependencies (409)
**Edge:** Double delete, delete then recreate
**Business:** Soft delete verification, cascade effects

## Auth & Authorization Matrix
Valid credentials → 200, valid token → authorized, no token → 401, expired → 401, malformed → 401, wrong role → 403

## Test Data Rules
1. NEVER hardcode — use JSON/CSV files or data factories
2. Make data realistic (real names, valid formats)
3. Each scenario creates own data (independent)
4. Include cleanup mechanisms
5. Boundary data: min, min+1, max-1, max for every constrained field

## Response Validation Checklist (EVERY response)
- [ ] Status code correct
- [ ] Content-Type header correct
- [ ] All expected body fields present with correct types
- [ ] Values match input where expected
- [ ] System fields valid (UUID, timestamp format)
- [ ] Error responses: correct structure, meaningful message, no stack traces
- [ ] Collections: correct count, order, pagination metadata

## Anti-Patterns (NEVER do these)
1. Shallow tests (status code only)
2. Copy-paste scenarios (each must test something distinct)
3. Assumption-based tests (ask if unclear)
4. Sequential dependencies between scenarios
5. Magic numbers (use constants/config)
6. Missing negative cases (every positive needs 2+ negatives)
7. Technical jargon in scenario names
8. Empty assertions (every Then must assert something)
9. Swallowed errors (clear diagnostics on failure)
10. Flaky patterns (no Thread.sleep, no time-dependent, no order-dependent)

## Gap Analysis Algorithm
1. Catalog every existing scenario: endpoint + type + what it validates
2. Map against CRUD matrix: count actual vs minimum expected per category
3. Gap = Expected - Actual (if > 0, it's missing coverage)
4. Prioritize: Critical (missing happy path/auth) > High (missing field validation) > Medium (missing edge) > Low (advanced edge)
