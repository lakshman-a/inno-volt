# GitHub Copilot — Global Project Instructions

## Project Context
This workspace uses GitHub Copilot with a custom QA Agent for API functional test automation.

## Auto-Detection Rules

### Framework Detection (Automatic)
On any test-related request, auto-detect from pom.xml:
- `serenity-cucumber` or `serenity-rest-assured` → Cucumber + Serenity BDD
- `karate-junit5` or `karate-core` → Karate DSL
- Both → ask user which to target
- Neither → ask user which to set up

### Existing Test Suite Detection (Automatic)
Before ANY test generation:
1. Scan `src/test/` for existing `.feature` files
2. Scan for step definitions and runners
3. Scan for test data and schemas
4. Build internal coverage map

### Quality Rules
- NEVER hallucinate or assume API behavior
- NEVER generate tests based on assumptions
- ALWAYS ask for clarification when input is ambiguous
- ALWAYS present test plan before generating code
- ALWAYS write scenarios in business language
- NEVER hardcode URLs, data, or auth tokens
