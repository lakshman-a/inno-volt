---
applyTo: '**/*.feature,**/test/**,**/tests/**'
---

# QA Test Generation Instructions

When working with test files or feature files:

1. Always check existing test patterns in the workspace before generating new tests
2. Match existing naming conventions, tag patterns, and directory structure
3. Write all scenario descriptions in business language, not technical terms
4. Never hardcode URLs, test data, or authentication tokens
5. Include comprehensive logging at every step
6. Tag every scenario with: feature group, test type, suite level, and severity
7. Generate test data in external JSON/CSV files, not inline
8. Use JSON schema files for response validation
9. Ensure every scenario is independently executable
10. Provide execution commands after generating tests
