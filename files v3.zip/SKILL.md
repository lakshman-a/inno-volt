---
name: qa-cucumber-serenity
description: Cucumber + Serenity BDD framework patterns for API functional testing. Auto-loaded when Cucumber+Serenity dependencies are detected in pom.xml. Covers project structure, POM template, feature file standards, step definition patterns, configuration, and execution commands.
---

# Cucumber + Serenity BDD — Framework Standards

## Project Structure
```
src/test/
├── java/com/{org}/{project}/
│   ├── runners/
│   │   ├── TestSuiteRunner.java
│   │   ├── SmokeTestRunner.java
│   │   └── {Feature}Runner.java
│   ├── stepdefinitions/
│   │   ├── common/
│   │   │   ├── CommonApiSteps.java
│   │   │   ├── AuthenticationSteps.java
│   │   │   └── ValidationSteps.java
│   │   ├── {feature}/
│   │   │   └── {Feature}Steps.java
│   │   └── Hooks.java
│   ├── models/
│   │   ├── request/{Entity}Request.java
│   │   └── response/{Entity}Response.java
│   ├── utils/
│   │   ├── ApiClient.java
│   │   ├── TestDataBuilder.java
│   │   ├── ConfigManager.java
│   │   └── TestContext.java
│   └── constants/
│       ├── Endpoints.java
│       └── ErrorMessages.java
└── resources/
    ├── features/{feature}/
    │   ├── {feature}_positive.feature
    │   ├── {feature}_negative.feature
    │   └── {feature}_edge_cases.feature
    ├── testdata/{feature}/ (JSON/CSV files)
    ├── schemas/{feature}/ (JSON schemas)
    ├── environments/ (dev.properties, qa.properties, staging.properties)
    ├── serenity.conf
    └── logback-test.xml
```

**Adaptation Rule:** If existing tests use a different structure, MATCH the existing structure.

## Key Dependencies (pom.xml)
- `net.serenity-bdd:serenity-core:4.1.4`
- `net.serenity-bdd:serenity-cucumber:4.1.4`
- `net.serenity-bdd:serenity-rest-assured:4.1.4`
- `io.cucumber:cucumber-java:7.15.0`
- `io.qameta.allure:allure-cucumber7-jvm:2.25.0` (optional)
- `org.assertj:assertj-core:3.25.1`
- `com.fasterxml.jackson.core:jackson-databind:2.16.1`
- `com.github.javafaker:javafaker:1.0.2`
- Use `maven-failsafe-plugin` (not surefire) with `**/*Runner.java` includes
- Use `serenity-maven-plugin` for report aggregation

## Feature File Standards
- File naming: `{feature}_positive.feature`, `{feature}_negative.feature`, `{feature}_edge_cases.feature`
- Mandatory tags: `@{feature} @api @{positive|negative|edge-case} @{smoke|regression} @{severity-*}`
- Use Background for shared setup (auth, health check)
- Use Scenario Outline + Examples for data-driven tests
- Use data tables for request payload in business-readable format
- Comment sections: `# CONTEXT`, `# DATA`, `# ACTION`, `# VERIFICATION`

## Step Definition Standards
- Use `@Step("description")` annotation on every method for Serenity reporting
- Use `LOG.info()` at start and end of every step
- Use AssertJ with `.as("descriptive message")` for every assertion
- Share state via TestContext (PicoContainer DI)
- Never use JUnit assertions directly

## Configuration (serenity.conf)
```hocon
environments {
  default { base.url = "http://localhost:8080" }
  dev { base.url = "https://dev-api.example.com" }
  qa { base.url = "https://qa-api.example.com" }
  staging { base.url = "https://staging-api.example.com" }
}
```

## Runner Template
```java
@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("features")
@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME, value = "io.cucumber.core.plugin.SerenityReporterParallelPlugin")
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "com.org.project.stepdefinitions")
@ConfigurationParameter(key = FILTER_TAGS_PROPERTY_NAME, value = "@regression and not @wip")
public class RegressionTestRunner {}
```

## Execution Commands
```bash
mvn clean verify -Denvironment=qa                                    # Full regression
mvn clean verify -Dcucumber.filter.tags="@smoke" -Denvironment=qa    # Smoke only
mvn clean verify -Dcucumber.filter.tags="@customer-management"       # Specific feature
mvn serenity:aggregate                                               # Generate report
# Report: target/site/serenity/index.html
```
