# QA Automation Agent for GitHub Copilot

## What This Is

A custom GitHub Copilot Agent that generates comprehensive API functional test cases.
Supports **Cucumber+Serenity BDD** and **Karate DSL** (Java, Maven).

## File Structure

```
.github/
├── copilot-instructions.md                          ← Global rules (auto-loaded every chat)
├── agents/
│   └── senior-qa-automation.agent.md                ← The QA agent persona & workflow
├── instructions/
│   └── qa-testing.instructions.md                   ← Dynamic rules for test files
└── skills/
    ├── qa-cucumber-serenity/SKILL.md                ← Cucumber+Serenity patterns
    ├── qa-karate-dsl/SKILL.md                       ← Karate DSL patterns
    └── qa-test-design/SKILL.md                      ← Test design methodology
```

## Quick Start

1. Copy `.github/` folder to your project root
2. Open project in VS Code (1.106+)
3. Open Copilot Chat → Select **"Senior QA Automation Engineer"** from agents dropdown
4. Set model to **Claude Sonnet 4.5**
5. Type **"hi"** — the agent guides you from there

## Full Setup Guide

See **[SETUP-TEST-REVIEW-GUIDE.md](./SETUP-TEST-REVIEW-GUIDE.md)** for:
- Detailed prerequisites and VS Code configuration
- Step-by-step installation and verification
- 6 test scenarios to validate the agent works
- Quality checklist for reviewing generated tests
- Troubleshooting common issues
- Team rollout instructions

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| `.agent.md` format (not `.chatmode.md`) | Chat modes were renamed to Custom Agents in VS Code 1.106+. `.agent.md` is the current format. |
| `SKILL.md` in subdirectories | VS Code Agent Skills standard — auto-discovered and loaded on-demand based on task context |
| `.instructions.md` with `applyTo` | Dynamically applied when working with test/feature files |
| `tools: ['codebase', 'editFiles', 'runCommands']` | Agent needs to read code, generate files, and execute Maven commands |
| `model: ['Claude Sonnet 4.5', 'Claude Opus 4.5']` | Tries models in order — prefers Sonnet for speed, falls back to Opus |
