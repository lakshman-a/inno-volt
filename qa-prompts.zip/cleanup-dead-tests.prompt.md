---
mode: agent
agent: qa-automation
description: Find and clean up dead, weak, duplicate, or stale test cases in the existing suite
---

Scan my existing test suite for quality issues: empty scenarios with no steps, missing glue code, scenarios with no assertions, duplicate test logic, and stale @ignore tests. Show me a cleanup report with recommendations, then remove or fix the identified issues after my approval.
