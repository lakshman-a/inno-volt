---
mode: agent
agent: qa-automation
description: Analyze existing test suite, find gaps, and add missing test cases without duplicating
---

Scan my workspace and analyze the **existing test suite**. Start **option 2 — Enhance Existing Suite**. Understand the current framework, folder structure, naming conventions, tags, auth patterns, and config before making any changes. Show me a gap analysis with what's missing, then add only the delta.
