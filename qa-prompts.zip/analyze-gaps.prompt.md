---
mode: agent
agent: qa-automation
description: Analyze test coverage gaps without generating code — report what's missing
---

Start **option 5 — Analyze Coverage & Report Gaps**. Scan my existing test suite and dev code, build a coverage matrix (positive/negative/edge/business per endpoint), compare to what exists, and show me exactly what's missing. No code generation — analysis only.
