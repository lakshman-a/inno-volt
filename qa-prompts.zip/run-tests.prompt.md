---
mode: agent
agent: qa-automation
description: Execute the test suite and generate Allure/Serenity report with pass/fail summary
---

Run my existing test suite. Execute all tests, show pass/fail/skip counts, generate the report (Allure or Serenity or Karate — whichever is configured), and provide the report path. Suggest parallel execution if the suite is large.
