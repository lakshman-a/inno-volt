---
mode: agent
agent: qa-automation
description: Run JaCoCo code coverage — instrument dev API, execute tests, generate HTML coverage report with gap analysis
---

Start **option 8 — JaCoCo Code Coverage**. Check prerequisites, build the dev project fresh, add Maven JaCoCo plugins, start the API with the JaCoCo agent (java -jar, not spring-boot:run), run the test suite, dump coverage, generate the HTML report, open it, and show me a summary with gap analysis and recommendations.
