---
mode: agent
agent: qa-automation
description: Quickly generate tests for a single API endpoint
---

Start **option 4 — Single Endpoint Tests**. I want to quickly generate positive, negative, and edge case tests for one specific endpoint. Ask me which endpoint, then generate and execute.
