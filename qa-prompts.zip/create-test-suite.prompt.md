---
mode: agent
agent: qa-automation
description: Create a new API functional test suite from Swagger, code, or requirements
---

Scan my workspace, detect the framework and dev project, then start **option 1 — Create New Test Suite**. Show me the multi-input selection (A through G) so I can tell you what inputs I have. Create the test project as a separate Maven project at the workspace root.
