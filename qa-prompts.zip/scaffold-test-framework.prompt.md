---
mode: agent
agent: qa-automation
description: Scaffold a new test framework project with config, auth, health check — verify it runs before adding tests
---

Start **option 7 — Scaffold Test Framework**. Create a standalone Maven test project at the workspace root with: pom.xml (matching my Java version), environment configs (common/dev/qa/uat), auth helper, health check test, and one smoke test. Execute it to verify the skeleton works before adding real tests.
