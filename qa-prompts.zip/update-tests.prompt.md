---
mode: agent
agent: qa-automation
description: Update existing tests after API, schema, or requirement changes
---

Start **option 3 — Update Tests for Changes**. I've had changes in my API (new fields, changed endpoints, updated schemas, or new requirements). Analyze what changed, find affected test cases, update them to match, and verify everything still runs.
