---
mode: agent
agent: qa-automation
description: Debug and fix failing test cases — analyze errors, fix root cause, re-run to verify
---

Start **option 6 — Fix Failing Tests**. Run the existing test suite, identify failures, analyze root causes (compilation errors, assertion mismatches, missing config, API changes), fix them, and re-run to verify all tests pass.
