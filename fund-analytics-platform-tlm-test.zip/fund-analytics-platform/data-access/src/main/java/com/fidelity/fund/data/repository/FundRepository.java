package com.fidelity.fund.data.repository;

import com.fidelity.fund.data.entity.Fund;
import com.fidelity.fund.data.entity.FundStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface FundRepository extends JpaRepository<Fund, Long> {

    Optional<Fund> findByTicker(String ticker);

    List<Fund> findByFundCategory(String category);

    List<Fund> findByStatus(FundStatus status);

    Page<Fund> findByFundCategoryAndStatus(String category, FundStatus status, Pageable pageable);

    @Query("SELECT f FROM Fund f WHERE f.nav > :minNav AND f.status = :status")
    List<Fund> findHighValueFunds(@Param("minNav") BigDecimal minNav, @Param("status") FundStatus status);

    @Query("SELECT f FROM Fund f WHERE f.ytdReturn > :minReturn ORDER BY f.ytdReturn DESC")
    List<Fund> findTopPerformers(@Param("minReturn") BigDecimal minReturn);

    @Query("SELECT COUNT(f) FROM Fund f WHERE f.status = :status")
    long countByStatus(@Param("status") FundStatus status);

    @Query("SELECT f.fundCategory, COUNT(f), AVG(f.nav) FROM Fund f GROUP BY f.fundCategory")
    List<Object[]> getFundStatsByCategory();

    boolean existsByTicker(String ticker);
}
