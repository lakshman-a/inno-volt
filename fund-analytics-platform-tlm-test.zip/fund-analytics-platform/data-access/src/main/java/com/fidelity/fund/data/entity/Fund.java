package com.fidelity.fund.data.entity;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "funds", indexes = {
    @Index(name = "idx_fund_ticker", columnList = "ticker", unique = true),
    @Index(name = "idx_fund_category", columnList = "fund_category")
})
public class Fund {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false, unique = true, length = 10)
    private String ticker;

    @NotBlank
    @Column(nullable = false, length = 200)
    private String name;

    @NotNull
    @Positive
    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal nav;

    @Column(name = "fund_category", length = 50)
    private String fundCategory;

    @Column(name = "manager_id", length = 20)
    private String managerId;

    @Column(name = "inception_date")
    private LocalDate inceptionDate;

    @Column(name = "assets_under_management", precision = 19, scale = 2)
    private BigDecimal assetsUnderManagement;

    @Column(name = "expense_ratio", precision = 5, scale = 4)
    private BigDecimal expenseRatio;

    @Column(name = "ytd_return", precision = 10, scale = 4)
    private BigDecimal ytdReturn;

    @Column(name = "one_year_return", precision = 10, scale = 4)
    private BigDecimal oneYearReturn;

    @Column(name = "three_year_return", precision = 10, scale = 4)
    private BigDecimal threeYearReturn;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private FundStatus status;

    @Column(name = "risk_rating", length = 20)
    private String riskRating;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        lastUpdated = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        lastUpdated = LocalDateTime.now();
    }
}
