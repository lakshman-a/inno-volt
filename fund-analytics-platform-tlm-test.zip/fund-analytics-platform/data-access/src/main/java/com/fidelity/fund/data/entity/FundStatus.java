package com.fidelity.fund.data.entity;

public enum FundStatus {
    ACTIVE,
    SUSPENDED,
    CLOSED,
    PENDING_REVIEW
}
