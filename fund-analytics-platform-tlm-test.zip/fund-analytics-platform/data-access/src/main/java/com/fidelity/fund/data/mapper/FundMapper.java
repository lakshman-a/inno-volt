package com.fidelity.fund.data.mapper;

import com.fidelity.fund.common.dto.FundDto;
import com.fidelity.fund.data.entity.Fund;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.List;

@Mapper(componentModel = "spring")
public interface FundMapper {

    @Mapping(target = "status", expression = "java(fund.getStatus() != null ? fund.getStatus().name() : null)")
    FundDto toDto(Fund fund);

    @Mapping(target = "status", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    Fund toEntity(FundDto dto);

    List<FundDto> toDtoList(List<Fund> funds);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    void updateEntity(FundDto dto, @MappingTarget Fund fund);
}
