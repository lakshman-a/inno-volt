package com.fidelity.fund.batch.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Spring Batch configuration using deprecated JobBuilderFactory/StepBuilderFactory.
 * In Spring Boot 3.x/Spring Batch 5.x, these are replaced with JobBuilder/StepBuilder.
 * @EnableBatchProcessing behavior also changed in SB3.
 */
@Configuration
@EnableBatchProcessing
public class BatchConfig {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Bean
    public Job fundDataImportJob(Step importStep, Step processStep, Step reportStep) {
        return jobBuilderFactory.get("fundDataImportJob")
                .incrementer(new RunIdIncrementer())
                .start(importStep)
                .next(processStep)
                .next(reportStep)
                .build();
    }

    @Bean
    public Job navCalculationJob(Step navCalcStep) {
        return jobBuilderFactory.get("navCalculationJob")
                .incrementer(new RunIdIncrementer())
                .start(navCalcStep)
                .build();
    }
}
