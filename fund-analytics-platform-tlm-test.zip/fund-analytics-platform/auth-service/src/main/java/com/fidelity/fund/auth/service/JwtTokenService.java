package com.fidelity.fund.auth.service;

import com.fmr.jsci.commons.jwt.JwtTokenValidator;
import com.fmr.jsci.commons.jwt.JwtClaims;
import com.fmr.jsci.commons.jwt.JwtConfig;
import com.fmr.jsci.commons.jwt.TokenExpiredException;
import com.fmr.jsci.commons.jwt.InvalidTokenException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Date;
import java.util.Set;

/**
 * JWT Token service using JSCI fmr-commons-jwt.
 * WARNING: fmr-commons-jwt is EOL March 2026.
 * Replacement: dp-commons-jwt
 *
 * This class uses javax.annotation.PostConstruct (needs jakarta migration).
 */
@Service
public class JwtTokenService {

    private static final Logger log = LoggerFactory.getLogger(JwtTokenService.class);

    @Value("${jwt.secret}")
    private String jwtSecret;

    @Value("${jwt.expiration:3600000}")
    private long jwtExpiration;

    @Value("${jwt.issuer:fund-analytics}")
    private String issuer;

    private JwtTokenValidator validator;

    @PostConstruct
    public void init() {
        JwtConfig config = JwtConfig.builder()
                .secret(jwtSecret)
                .issuer(issuer)
                .expirationMs(jwtExpiration)
                .build();
        this.validator = new JwtTokenValidator(config);
        log.info("JWT Token Service initialized with issuer: {}", issuer);
    }

    public String generateToken(String username, Set<String> roles) {
        return validator.generateToken(username, roles);
    }

    public JwtClaims validateToken(String token) {
        try {
            return validator.validate(token);
        } catch (TokenExpiredException e) {
            log.warn("Token expired for request");
            throw e;
        } catch (InvalidTokenException e) {
            log.error("Invalid token received");
            throw e;
        }
    }

    public String getUsernameFromToken(String token) {
        JwtClaims claims = validateToken(token);
        return claims.getSubject();
    }

    public Set<String> getRolesFromToken(String token) {
        JwtClaims claims = validateToken(token);
        return claims.getRoles();
    }

    public boolean isTokenExpired(String token) {
        try {
            JwtClaims claims = validateToken(token);
            return claims.getExpiration().before(new Date());
        } catch (TokenExpiredException e) {
            return true;
        }
    }
}
