package com.fidelity.fund.service.service;

import com.fidelity.fund.common.dto.FundDto;
import com.fidelity.fund.data.entity.Fund;
import com.fidelity.fund.data.entity.FundStatus;
import com.fidelity.fund.data.mapper.FundMapper;
import com.fidelity.fund.data.repository.FundRepository;
import com.fidelity.fund.service.client.ExternalFundDataClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;
import java.math.BigDecimal;
import java.util.List;

@Service
@Transactional
public class FundAnalyticsService {

    private static final Logger log = LoggerFactory.getLogger(FundAnalyticsService.class);

    @Autowired
    private FundRepository fundRepository;

    @Autowired
    private FundMapper fundMapper;

    @Autowired
    private ExternalFundDataClient externalDataClient;

    @Cacheable(value = "funds", key = "#pageable.pageNumber")
    @Transactional(readOnly = true)
    public Page<FundDto> getAllFunds(Pageable pageable) {
        return fundRepository.findAll(pageable).map(fundMapper::toDto);
    }

    @Transactional(readOnly = true)
    public FundDto getFundById(Long id) {
        Fund fund = fundRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Fund not found with id: " + id));
        return fundMapper.toDto(fund);
    }

    @Transactional(readOnly = true)
    public FundDto getFundByTicker(String ticker) {
        Fund fund = fundRepository.findByTicker(ticker)
                .orElseThrow(() -> new EntityNotFoundException("Fund not found with ticker: " + ticker));

        // Enrich with external data via AMT FSF
        try {
            FundDto enriched = externalDataClient.enrichFundData(fundMapper.toDto(fund));
            return enriched;
        } catch (Exception e) {
            log.warn("Failed to enrich fund data from external source: {}", e.getMessage());
            return fundMapper.toDto(fund);
        }
    }

    @CacheEvict(value = "funds", allEntries = true)
    public FundDto createFund(FundDto fundDto) {
        if (fundRepository.existsByTicker(fundDto.getTicker())) {
            throw new IllegalArgumentException("Fund with ticker already exists: " + fundDto.getTicker());
        }
        Fund fund = fundMapper.toEntity(fundDto);
        fund.setStatus(FundStatus.ACTIVE);
        Fund saved = fundRepository.save(fund);
        log.info("Created fund: {} ({})", saved.getName(), saved.getTicker());
        return fundMapper.toDto(saved);
    }

    @CacheEvict(value = "funds", allEntries = true)
    public FundDto updateFund(Long id, FundDto fundDto) {
        Fund existing = fundRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Fund not found with id: " + id));
        fundMapper.updateEntity(fundDto, existing);
        Fund saved = fundRepository.save(existing);
        log.info("Updated fund: {} ({})", saved.getName(), saved.getTicker());
        return fundMapper.toDto(saved);
    }

    @CacheEvict(value = "funds", allEntries = true)
    public void deleteFund(Long id) {
        Fund fund = fundRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Fund not found with id: " + id));
        fund.setStatus(FundStatus.CLOSED);
        fundRepository.save(fund);
        log.info("Soft-deleted fund: {} ({})", fund.getName(), fund.getTicker());
    }

    @Transactional(readOnly = true)
    public List<FundDto> getTopPerformers(double minReturn) {
        List<Fund> funds = fundRepository.findTopPerformers(BigDecimal.valueOf(minReturn));
        return fundMapper.toDtoList(funds);
    }

    @Transactional(readOnly = true)
    public List<FundDto> getFundsByCategory(String category) {
        List<Fund> funds = fundRepository.findByFundCategory(category);
        return fundMapper.toDtoList(funds);
    }
}
