package com.fidelity.fund.service.client;

import com.fidelity.fund.common.dto.FundDto;
import com.fmr.amt.fsf.rest.FsfRestClient;
import com.fmr.amt.fsf.rest.FsfConfig;
import com.fmr.amt.fsf.rest.FsfResponse;
import com.fmr.amt.fsf.rest.FsfResponseParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.Map;

/**
 * External fund data client using AMT FSF Rest.
 * WARNING: amt-fsf-rest 7.5 is EOL June 2026.
 * This library is compiled against Spring Boot 2.7 / Java 11.
 * It uses javax.servlet internally — will conflict with Spring Boot 3+.
 */
@Component
public class ExternalFundDataClient {

    private static final Logger log = LoggerFactory.getLogger(ExternalFundDataClient.class);

    @Value("${external.fund-data.base-url:https://funddata.fmr.com/api/v2}")
    private String baseUrl;

    @Value("${external.fund-data.timeout:5000}")
    private int timeout;

    private FsfRestClient restClient;
    private final ObjectMapper objectMapper;

    public ExternalFundDataClient(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void init() {
        FsfConfig config = FsfConfig.builder()
                .baseUrl(baseUrl)
                .connectionTimeout(timeout)
                .readTimeout(timeout)
                .retryCount(3)
                .build();
        this.restClient = new FsfRestClient(config);
        log.info("External fund data client initialized: {}", baseUrl);
    }

    public FundDto enrichFundData(FundDto fund) {
        try {
            String endpoint = "/funds/" + fund.getTicker() + "/analytics";
            FsfResponse response = restClient.get(endpoint, Map.of(
                    "Accept", "application/json",
                    "X-Api-Version", "2.0"
            ));

            if (response.isSuccess()) {
                Map<String, Object> data = FsfResponseParser.parseJson(
                        response, objectMapper);

                if (data.containsKey("ytdReturn")) {
                    fund.setYtdReturn(new BigDecimal(data.get("ytdReturn").toString()));
                }
                if (data.containsKey("oneYearReturn")) {
                    fund.setOneYearReturn(new BigDecimal(data.get("oneYearReturn").toString()));
                }
                if (data.containsKey("threeYearReturn")) {
                    fund.setThreeYearReturn(new BigDecimal(data.get("threeYearReturn").toString()));
                }
                if (data.containsKey("riskRating")) {
                    fund.setRiskRating(data.get("riskRating").toString());
                }
            }
        } catch (Exception e) {
            log.warn("Failed to enrich fund {} from external source: {}", fund.getTicker(), e.getMessage());
        }
        return fund;
    }
}
