package com.fidelity.fund.service.controller;

import com.fidelity.fund.common.dto.ApiResponse;
import com.fidelity.fund.common.dto.FundDto;
import com.fidelity.fund.service.service.FundAnalyticsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/funds")
@Api(tags = "Fund Management", description = "Operations for fund analytics and management")
public class FundController {

    @Autowired
    private FundAnalyticsService fundService;

    @GetMapping
    @ApiOperation(value = "Get all funds", notes = "Returns a paginated list of all funds")
    public ResponseEntity<ApiResponse<Page<FundDto>>> getAllFunds(Pageable pageable) {
        Page<FundDto> funds = fundService.getAllFunds(pageable);
        return ResponseEntity.ok(ApiResponse.ok(funds));
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "Get fund by ID")
    public ResponseEntity<ApiResponse<FundDto>> getFundById(
            @ApiParam(value = "Fund ID", required = true) @PathVariable Long id) {
        FundDto fund = fundService.getFundById(id);
        return ResponseEntity.ok(ApiResponse.ok(fund));
    }

    @GetMapping("/ticker/{ticker}")
    @ApiOperation(value = "Get fund by ticker symbol")
    public ResponseEntity<ApiResponse<FundDto>> getFundByTicker(
            @ApiParam(value = "Ticker symbol", example = "FXAIX") @PathVariable String ticker) {
        FundDto fund = fundService.getFundByTicker(ticker);
        return ResponseEntity.ok(ApiResponse.ok(fund));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @ApiOperation(value = "Create a new fund")
    public ResponseEntity<ApiResponse<FundDto>> createFund(
            @Valid @RequestBody FundDto fundDto) {
        FundDto created = fundService.createFund(fundDto);
        return ResponseEntity.ok(ApiResponse.ok(created));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @ApiOperation(value = "Update an existing fund")
    public ResponseEntity<ApiResponse<FundDto>> updateFund(
            @PathVariable Long id,
            @Valid @RequestBody FundDto fundDto) {
        FundDto updated = fundService.updateFund(id, fundDto);
        return ResponseEntity.ok(ApiResponse.ok(updated));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @ApiOperation(value = "Delete a fund")
    public ResponseEntity<ApiResponse<Void>> deleteFund(@PathVariable Long id) {
        fundService.deleteFund(id);
        return ResponseEntity.ok(ApiResponse.<Void>builder()
                .success(true).message("Fund deleted").statusCode(200).build());
    }

    @GetMapping("/top-performers")
    @ApiOperation(value = "Get top performing funds by YTD return")
    public ResponseEntity<ApiResponse<List<FundDto>>> getTopPerformers(
            @RequestParam(defaultValue = "5.0") double minReturn) {
        List<FundDto> performers = fundService.getTopPerformers(minReturn);
        return ResponseEntity.ok(ApiResponse.ok(performers));
    }

    @GetMapping("/category/{category}")
    @ApiOperation(value = "Get funds by category")
    public ResponseEntity<ApiResponse<List<FundDto>>> getFundsByCategory(
            @PathVariable String category) {
        List<FundDto> funds = fundService.getFundsByCategory(category);
        return ResponseEntity.ok(ApiResponse.ok(funds));
    }
}
