package com.fidelity.fund.service;

import com.fidelity.fund.common.dto.FundDto;
import com.fidelity.fund.data.entity.Fund;
import com.fidelity.fund.data.entity.FundStatus;
import com.fidelity.fund.data.mapper.FundMapper;
import com.fidelity.fund.data.repository.FundRepository;
import com.fidelity.fund.service.client.ExternalFundDataClient;
import com.fidelity.fund.service.service.FundAnalyticsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import javax.persistence.EntityNotFoundException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FundAnalyticsServiceTest {

    @Mock
    private FundRepository fundRepository;

    @Mock
    private FundMapper fundMapper;

    @Mock
    private ExternalFundDataClient externalDataClient;

    @InjectMocks
    private FundAnalyticsService fundService;

    private Fund testFund;
    private FundDto testFundDto;

    @BeforeEach
    void setUp() {
        testFund = Fund.builder()
                .id(1L)
                .ticker("FXAIX")
                .name("Fidelity 500 Index Fund")
                .nav(new BigDecimal("185.50"))
                .fundCategory("Large Cap")
                .managerId("MGR001")
                .inceptionDate(LocalDate.of(1988, 2, 17))
                .status(FundStatus.ACTIVE)
                .build();

        testFundDto = FundDto.builder()
                .id(1L)
                .ticker("FXAIX")
                .name("Fidelity 500 Index Fund")
                .nav(new BigDecimal("185.50"))
                .fundCategory("Large Cap")
                .managerId("MGR001")
                .build();
    }

    @Test
    void getAllFunds_returnsPagedResults() {
        Page<Fund> fundPage = new PageImpl<>(List.of(testFund));
        when(fundRepository.findAll(any(PageRequest.class))).thenReturn(fundPage);
        when(fundMapper.toDto(any(Fund.class))).thenReturn(testFundDto);

        Page<FundDto> result = fundService.getAllFunds(PageRequest.of(0, 10));

        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        verify(fundRepository).findAll(any(PageRequest.class));
    }

    @Test
    void getFundById_existingFund_returnsFund() {
        when(fundRepository.findById(1L)).thenReturn(Optional.of(testFund));
        when(fundMapper.toDto(testFund)).thenReturn(testFundDto);

        FundDto result = fundService.getFundById(1L);

        assertNotNull(result);
        assertEquals("FXAIX", result.getTicker());
    }

    @Test
    void getFundById_nonExisting_throwsException() {
        when(fundRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> fundService.getFundById(99L));
    }

    @Test
    void createFund_newFund_success() {
        when(fundRepository.existsByTicker("FXAIX")).thenReturn(false);
        when(fundMapper.toEntity(testFundDto)).thenReturn(testFund);
        when(fundRepository.save(any(Fund.class))).thenReturn(testFund);
        when(fundMapper.toDto(testFund)).thenReturn(testFundDto);

        FundDto result = fundService.createFund(testFundDto);

        assertNotNull(result);
        assertEquals("FXAIX", result.getTicker());
        verify(fundRepository).save(any(Fund.class));
    }

    @Test
    void createFund_duplicateTicker_throwsException() {
        when(fundRepository.existsByTicker("FXAIX")).thenReturn(true);

        assertThrows(IllegalArgumentException.class, () -> fundService.createFund(testFundDto));
    }
}
