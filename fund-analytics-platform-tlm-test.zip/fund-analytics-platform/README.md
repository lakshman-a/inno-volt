# Fund Analytics Platform — TLM Test Project

## Purpose

This is a **sample multi-module Spring Boot project** designed to test the TLM Agent's ability to handle real-world enterprise migration scenarios. It contains intentional TLM issues across all 6 modules.

## Module Structure & Build Order

```
fund-analytics-platform (parent POM — reactor)
├── common-lib          (0 deps — shared DTOs, utilities, JSCI crypto)
├── data-access         (depends: common-lib — JPA entities, repos, mappers)
├── auth-service        (depends: common-lib, data-access — security, JSCI JWT)
├── fund-service        (depends: common-lib, data-access, auth-service — business logic, AMT FSF)
├── gateway-api         (depends: fund-service — main app, actuator, exception handling)
└── batch-processor     (depends: common-lib, data-access — Spring Batch jobs)
```

**Build order:** parent → common-lib → data-access → auth-service → fund-service → gateway-api → batch-processor

## TLM Issues Present (For Agent to Find & Fix)

### Framework & Runtime
| Issue | Current | Target | Location |
|---|---|---|---|
| Spring Boot | 2.7.18 | 4.0.3 (or 3.5.11) | parent pom.xml |
| Java | 17 | 21 or 25 | parent pom.xml |

### Jakarta Migration (javax → jakarta)
| File | javax Import | Module |
|---|---|---|
| FundDto.java | javax.validation.constraints | common-lib |
| UserDto.java | javax.validation.constraints | common-lib |
| ApiResponse.java | javax.validation.constraints | common-lib |
| Fund.java | javax.persistence.* | data-access |
| User.java | javax.persistence.* | data-access |
| AuditLog.java | javax.persistence.* | data-access |
| JwtTokenService.java | javax.annotation.PostConstruct | auth-service |
| JwtAuthenticationFilter.java | javax.servlet.* | auth-service |
| ExternalFundDataClient.java | javax.annotation.PostConstruct | fund-service |
| FundAnalyticsService.java | javax.persistence.EntityNotFoundException | fund-service |
| FundController.java | javax.validation.Valid | fund-service |
| GlobalExceptionHandler.java | javax.persistence, javax.servlet, javax.validation | gateway-api |

### Spring Security (Major Rewrite)
| File | Issue | Module |
|---|---|---|
| SecurityConfig.java | extends WebSecurityConfigurerAdapter | auth-service |
| SecurityConfig.java | authorizeRequests(), antMatchers() | auth-service |
| SecurityConfig.java | @EnableGlobalMethodSecurity (→ @EnableMethodSecurity) | auth-service |

### Enterprise/Internal Libraries (The Hard Part)
| Library | Version | Status | Module | Issue |
|---|---|---|---|---|
| fmr-commons-jwt | 2.3.1 | EOL Mar 2026 | auth-service | Replace with dp-commons-jwt |
| fmr-commons-crypto | 1.8.0 | EOL Mar 2026 | common-lib | Replace with dp-crypto-utils |
| fmr-commons-logging | 3.1.0 | EOL Mar 2026 | common-lib | Replace with SLF4J |
| amt-fsf-rest | 7.5.2 | EOL Jun 2026 | fund-service | Compiled against SB 2.7! |
| dp-audit-client | 1.2.0 | Active | auth-service | Check compatibility with SB 3/4 |

### Spring Batch Changes (SB3)
| File | Issue | Module |
|---|---|---|
| BatchConfig.java | JobBuilderFactory/StepBuilderFactory deprecated | batch-processor |
| BatchConfig.java | @EnableBatchProcessing behavior changed | batch-processor |

### Swagger/OpenAPI Migration
| File | Issue | Module |
|---|---|---|
| FundController.java | Springfox @Api, @ApiOperation annotations | fund-service |
| pom.xml | springfox-boot-starter 3.0.0 → springdoc-openapi 2.x | fund-service |
| pom.xml | springdoc-openapi-ui 1.7.0 → springdoc-openapi-starter-webmvc-ui 2.x | gateway-api |

### Outdated Dependencies
| Dependency | Current | Latest | CVE? |
|---|---|---|---|
| jackson-databind | 2.14.2 | 2.17+ | Yes |
| lombok | 1.18.26 | 1.18.36 | No (but required for Java 21+) |
| mapstruct | 1.5.3 | 1.6.3 | No |
| commons-lang3 | 3.12.0 | 3.17 | No |
| commons-io | 2.11.0 | 2.18 | No |
| guava | 31.1 | 33.4 | No |
| flyway | 8.5.13 | 10.x | No |
| snakeyaml | 1.33 | 2.3 | **Yes — CVE-2022-1471** |
| log4j2 | 2.17.1 | 2.24 | Yes (patched) |
| maven-compiler-plugin | 3.10.1 | 3.13 | No |

### CI/CD & Infrastructure
| File | Issue |
|---|---|
| Dockerfile | Uses `ubn22-*` base image (EOL Nov 2025) |
| Dockerfile | `--illegal-access=permit` JVM flag (removed in Java 17+) |
| Dockerfile | `-XX:+UseConcMarkSweepGC` (removed in Java 14) |
| Jenkinsfile | Uses `rhel8-*` buildpack (EOL) |

### Configuration Property Renames (SB3)
| File | Old Property | New Property |
|---|---|---|
| application.yml | spring.redis.host | spring.data.redis.host |
| application.yml | spring.redis.port | spring.data.redis.port |
| application.yml | server.max-http-header-size | server.max-http-request-header-size |

## What the TLM Agent Should Do

1. **Scan** → detect all of the above automatically
2. **Plan** → show module dependency order, recipe vs agent items, internal library conflicts
3. **Internal library check** → identify amt-fsf-rest as incompatible with SB3/4, present options
4. **Execute in order** → parent POM → common-lib → data-access → auth-service → fund-service → gateway-api → batch-processor
5. **Build each module** → verify compilation after each
6. **Validate** → all modules compile, tests pass, no javax references remain
7. **Report** → summary with files changed, effort saved, areas for review

## How to Test

1. Copy this project to your workspace
2. Place TLM Agent files in `.github/` folder
3. Open in VS Code with Copilot
4. Type "hi" or use `/fix-all-tlm`
5. Agent should scan, plan, and execute the full migration
