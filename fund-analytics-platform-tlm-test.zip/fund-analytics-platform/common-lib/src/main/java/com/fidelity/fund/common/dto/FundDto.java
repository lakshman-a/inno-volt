package com.fidelity.fund.common.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FundDto {

    private Long id;

    @NotBlank(message = "Fund ticker is required")
    @Size(min = 1, max = 10, message = "Ticker must be 1-10 characters")
    private String ticker;

    @NotBlank(message = "Fund name is required")
    @Size(max = 200)
    private String name;

    @NotNull(message = "NAV is required")
    @Positive(message = "NAV must be positive")
    private BigDecimal nav;

    @NotNull
    private String fundCategory;

    @NotBlank
    private String managerId;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate inceptionDate;

    @JsonProperty("aum")
    private BigDecimal assetsUnderManagement;

    private BigDecimal expenseRatio;
    private BigDecimal ytdReturn;
    private BigDecimal oneYearReturn;
    private BigDecimal threeYearReturn;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime lastUpdated;

    private String status;
    private String riskRating;
}
