package com.fidelity.fund.common.crypto;

import com.fmr.jsci.commons.crypto.EcsEncryptor;
import com.fmr.jsci.commons.crypto.CryptoConfig;
import com.fmr.jsci.commons.crypto.EncryptionMode;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Encryption utility wrapping JSCI fmr-commons-crypto.
 * This is an enterprise library that is being retired — EOL March 2026.
 * Replacement: dp-crypto-utils
 */
public class EncryptionUtil {

    private static final Logger log = LoggerFactory.getLogger(EncryptionUtil.class);

    private final EcsEncryptor encryptor;

    public EncryptionUtil(String keyAlias) {
        CryptoConfig config = CryptoConfig.builder()
                .keyAlias(keyAlias)
                .mode(EncryptionMode.AES_256_GCM)
                .build();
        this.encryptor = new EcsEncryptor(config);
        log.info("Initialized ECS encryption with alias: {}", keyAlias);
    }

    public String encrypt(String plainText) {
        if (StringUtils.isBlank(plainText)) {
            return null;
        }
        byte[] encrypted = encryptor.encrypt(plainText.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encrypted);
    }

    public String decrypt(String cipherText) {
        if (StringUtils.isBlank(cipherText)) {
            return null;
        }
        byte[] decoded = Base64.getDecoder().decode(cipherText);
        byte[] decrypted = encryptor.decrypt(decoded);
        return new String(decrypted, StandardCharsets.UTF_8);
    }

    public String hash(String input) {
        return encryptor.hash(input.getBytes(StandardCharsets.UTF_8));
    }
}
