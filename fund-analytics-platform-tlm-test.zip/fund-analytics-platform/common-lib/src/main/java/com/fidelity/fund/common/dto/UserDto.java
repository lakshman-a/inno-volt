package com.fidelity.fund.common.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {

    private Long id;

    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50)
    private String username;

    @NotBlank
    @Email(message = "Valid email is required")
    private String email;

    @NotBlank
    private String firstName;

    @NotBlank
    private String lastName;

    private Set<String> roles;
    private String department;
    private boolean active;
    private LocalDateTime lastLogin;
    private LocalDateTime createdAt;
}
