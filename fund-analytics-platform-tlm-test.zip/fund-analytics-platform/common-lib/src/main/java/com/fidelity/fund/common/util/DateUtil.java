package com.fidelity.fund.common.util;

import org.apache.commons.lang3.StringUtils;
import com.google.common.base.Preconditions;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateUtil {

    private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
    private static final String DEFAULT_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";

    private DateUtil() {}

    public static String formatDate(LocalDate date) {
        Preconditions.checkNotNull(date, "Date cannot be null");
        return date.format(DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT));
    }

    public static String formatDateTime(LocalDateTime dateTime) {
        Preconditions.checkNotNull(dateTime, "DateTime cannot be null");
        return dateTime.format(DateTimeFormatter.ofPattern(DEFAULT_DATETIME_FORMAT));
    }

    public static LocalDate parseDate(String dateStr) {
        if (StringUtils.isBlank(dateStr)) {
            return null;
        }
        return LocalDate.parse(dateStr, DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT));
    }

    /**
     * Legacy method — converts old java.util.Date to LocalDate.
     * Used by batch processor for legacy data feeds.
     */
    public static LocalDate fromLegacyDate(Date date) {
        if (date == null) return null;
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    /**
     * Legacy method — formats using SimpleDateFormat (not thread-safe).
     * TODO: Refactor callers to use DateTimeFormatter.
     */
    @Deprecated
    public static String formatLegacy(Date date, String pattern) {
        if (date == null) return null;
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(date);
    }

    public static boolean isBusinessDay(LocalDate date) {
        int dayOfWeek = date.getDayOfWeek().getValue();
        return dayOfWeek >= 1 && dayOfWeek <= 5;
    }
}
