package com.fidelity.fund.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "com.fidelity.fund")
@EntityScan(basePackages = "com.fidelity.fund.data.entity")
@EnableJpaRepositories(basePackages = "com.fidelity.fund.data.repository")
@EnableCaching
public class FundAnalyticsApplication {

    public static void main(String[] args) {
        SpringApplication.run(FundAnalyticsApplication.class, args);
    }
}
