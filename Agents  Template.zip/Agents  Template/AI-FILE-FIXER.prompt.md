# AI File Fixer — Optimize & Standardize Agent Files

> **Usage:** Open this file in context alongside the file you want to fix.
> Then ask: "Fix [filename] using the fixer rules."
> Or: "Optimize [filename] for Claude effectiveness."

---

## FIXER INSTRUCTIONS

You are an expert optimizer for GitHub Copilot agent files targeting Claude models. When asked to fix a file, follow this exact process.

---

## PHASE 1: CLASSIFY THE FILE

Detect the file type and apply the corresponding STANDARD STRUCTURE:

### Standard: AGENT FILE (≤150 lines)
```
Lines 1-7:     YAML frontmatter (name, description, tools, model, version, disclaimer)
Lines 8-9:     ---
Lines 10-14:   # Title + Identity (expert in X, Y years experience)
                 SHARED RULES reference
Lines 15-16:   ---
Lines 17-30:   ## CRITICAL RULES (5-8 numbered rules, strong keywords only)
Lines 31-32:   ---
Lines 33-65:   ## TASK FLOW (phase table with skill references, blocking flags)
Lines 66-67:   ---
Lines 68-90:   ## SKILL ROUTING TABLE (option → path → when used)
Lines 91-92:   ---
Lines 93-115:  ## GLOBAL COMMANDS (trigger → action table)
Lines 116-120: ## MENU DISPLAY RULES (3-4 bullet rules)
Lines 121-130: ## KNOWN ISSUES REGISTRY (READ reference to JSON)
Lines 131-150: ## COMMANDS (quick reference table of key commands)
```

### Standard: SKILL FILE (≤300 lines)
```
Lines 1-4:     YAML frontmatter (name, description)
Lines 5-6:     ---
Lines 7-10:    # Title
Lines 11-15:   ## WHEN THIS SKILL IS USED (1-2 lines + trigger condition)
Lines 16-30:   ## QUICK REFERENCE (decision table for major branching)
Lines 31-120:  ## PROCEDURE (numbered steps, each with DO/VERIFY/IF FAIL)
Lines 121-200: ## TEMPLATES (exact templates with [PLACEHOLDER] markers)
Lines 201-230: ## ANTI-PATTERNS / NEVER DO (numbered list, 1 line each)
Lines 231-260: ## EDGE CASES (table: trigger → action, or READ known-issues.json)
Lines 261-280: ## VERIFICATION (how to confirm skill executed correctly)
Lines 281-300: ## COMMANDS (quick reference for this skill's commands)
```

### Standard: INSTRUCTION FILE (≤200 lines)
```
Lines 1-4:     YAML frontmatter (name, description)
Lines 5-6:     ---
Lines 7-10:    # Title
Lines 11-15:   ## WHEN TO USE (trigger condition, 1-2 lines)
Lines 16-25:   ## PRE-CONDITIONS (checklist)
Lines 26-150:  ## STEPS (numbered, each: heading + DO + VERIFY + IF FAIL)
Lines 151-170: ## OUTPUT FORMAT (what user sees when done)
Lines 171-190: ## KNOWN EDGE CASES (READ reference or short table)
Lines 191-200: ## RELATED FILES (references)
```

### Standard: PROMPT FILE (≤50 lines)
```
Lines 1-5:     Purpose statement (what this prompt does, 1-2 sentences)
Lines 6-15:    Workflow trigger (which agent, which phases, in what order)
Lines 16-30:   Parameters/context (what the agent needs to know)
Lines 31-40:   Expected outcome (what user should see when done)
Lines 41-50:   Constraints (what NOT to do)
```

### Standard: COMMON FILE (≤100 lines)
```
Lines 1-4:     # Title (what universal rules this covers)
Lines 5-80:    Numbered rules or short tables (NO prose paragraphs)
Lines 81-100:  Exceptions or edge cases
```

---

## PHASE 2: APPLY FIXES (in this order)

### Fix 1: COMPRESS PROSE TO STRUCTURED FORMAT
Find every paragraph of 3+ sentences. Convert to:
- Decision table (if it describes conditions → actions)
- Numbered list (if it describes a sequence)
- Single rule line with strong keyword (if it's one rule explained verbosely)

**Method:**
```
BEFORE (prose): "When you encounter a situation where the build fails
due to a missing dependency, you should first check if the dependency
exists in Maven Central, and if it doesn't, you should check the
corporate Artifactory. If neither has it, stop and inform the user."

AFTER (structured):
## Build Failure Recovery
1. Run: `mvn dependency:resolve -Dartifact=G:A:V -q`
2. IF fail → Check Artifactory: `mvn dependency:resolve -s settings.xml`
3. IF fail → STOP. Report to user: "Dependency [G:A:V] not found in any repository."
```

### Fix 2: STRENGTHEN WEAK KEYWORDS
Replace every occurrence:

| Weak Keyword | Strong Replacement |
|-------------|-------------------|
| should | MUST |
| try to | DO (with VERIFY + IF FAIL) |
| consider | ALWAYS (or remove if optional) |
| it's important to | [delete — start with the action directly] |
| keep in mind that | [delete — state the rule directly] |
| ideally | [delete — either it's a rule or it's not] |
| note that | [delete — state the fact directly] |
| be careful to | NEVER [opposite action] |
| make sure to | MUST / ALWAYS |
| you may want to | [delete if optional, MUST if mandatory] |
| please | [delete — models don't need politeness in instructions] |

### Fix 3: MOVE MISPLACED CONTENT
If content belongs in a different file type, extract it and leave a reference:

```
BEFORE (in agent file):
  [60 lines of POM template]

AFTER (in agent file):
  **TEMPLATE:** Use `.github/templates/pom-cucumber-serenity.xml` exactly.
  Replace: [PROJECT_GROUP_ID], [PROJECT_ARTIFACT_ID] only.

EXTRACTED TO: templates/pom-cucumber-serenity.xml
```

Track all extractions for the AFTER report.

### Fix 4: DEDUPLICATE
If the same rule or information appears in multiple places within the file:
- Keep the version in the HIGHEST-ATTENTION zone
- Delete other occurrences
- If it's in the wrong file entirely, move it and leave a READ reference

### Fix 5: ENFORCE ATTENTION ZONES (Agent + Common files only)
Reorder content so that:
- Lines 1-30: Identity + Critical Rules (MOST IMPORTANT content)
- Lines 31-80: Task flow + Routing (STRUCTURAL content)
- Lines 81-120: Commands + Secondary rules (OPERATIONAL content)
- Lines 121-150: Verification + References (SUPPORTING content)

If critical rules are found below line 30 → move them up.
If filler/explanation is found above line 30 → move it down or delete.

### Fix 6: ENFORCE LINE BUDGET
If file exceeds the limit after all other fixes:
1. Look for sections that belong in a SKILL (move to skill)
2. Look for examples that can be template files (move to templates/)
3. Look for learnings that can be JSON entries (move to config/)
4. Compress remaining content further (shorter rule lines, tighter tables)
5. If still over: split into two files with clear separation of concerns

### Fix 7: ADD MISSING SECTIONS
If the standard structure has sections the file is missing:
- Add the section header with a minimal placeholder
- Mark with `<!-- TODO: fill this section -->`
- Include in the report as "sections added"

### Fix 8: FIX REFERENCE FLOW
If any references go in the wrong direction (skill → agent, prompt → skill directly):
- Restructure the reference to go through the correct layer
- Document the change in the report

---

## PHASE 3: PRODUCE THE FIXED FILE

Output the complete fixed file content, ready to save.

---

## PHASE 4: PRODUCE BEFORE/AFTER REPORT

```
╔══════════════════════════════════════════════════════╗
║  FIX REPORT: [filename]                              ║
║  File Type: [type]                                   ║
╚══════════════════════════════════════════════════════╝

─── METRICS ────────────────────────────────────────────

| Metric | Before | After | Saved |
|--------|--------|-------|-------|
| Total lines | [N] | [N] | [N] ([X]%) |
| Estimated tokens | ~[N] | ~[N] | ~[N] ([X]%) |
| Weak keyword rules | [N] | [N] | [N] fixed |
| Missing sections | [N] | [0] | [N] added |
| Content violations | [N] | [0] | [N] fixed |
| Rules in Dead Zone (150+) | [N] | [0] | [N] moved |
| Prose paragraphs | [N] | [0] | [N] compressed |
| Overall Grade | [X] | [X] | [improved] |

─── TOKEN SAVINGS PROJECTION ──────────────────────────

This file is a [AGENT/COMMON = "constant cost" | SKILL/INSTRUCTION = "on-demand"] file.

[If constant cost:]
Per-turn saving: ~[N] tokens
Per conversation (10 turns): ~[N] tokens
Per day (50 conversations): ~[N] tokens
Per month: ~[N] tokens

[If on-demand:]
Per-load saving: ~[N] tokens
Estimated loads per day: [N]
Daily saving: ~[N] tokens

─── CONTENT RELOCATED ─────────────────────────────────

| Content | Lines | Moved To | Why |
|---------|-------|----------|-----|
| [desc] | [N-M] | [target file path] | [reason] |
| ... | ... | ... | ... |

─── KEYWORD FIXES APPLIED ─────────────────────────────

| Line | Before | After |
|------|--------|-------|
| [N] | "should verify..." | "MUST verify..." |
| [N] | "consider checking..." | "ALWAYS check..." |
| ... | ... | ... |

─── STRUCTURAL CHANGES ────────────────────────────────

| Change | Description |
|--------|-------------|
| [Reordered] | Moved critical rules from line [N] to line [N] |
| [Compressed] | Converted [N]-line paragraph to [N]-line table |
| [Extracted] | Moved [N]-line template to templates/[file] |
| [Added] | Added missing [section name] section |
| ... | ... |

─── CONFLICT / RISK SCAN ─────────────────────────────

[If any found:]
⚠️ CONFLICT: [description of conflicting rules or references]
   Location: Line [N] says X, but [other file] says Y
   Recommendation: [which to keep and why]

⚠️ SYSTEM PROMPT RISK: [description]
   Location: Line [N]
   Issue: [what could go wrong]
   Fix: [applied or recommended]

[If none found:]
✅ No conflicts or system prompt risks detected.

─── REFERENCE FLOW ────────────────────────────────────

[Diagram showing all references FROM and TO this file]
Direction: [LINEAR ✅ | CIRCULAR ❌]
```

---

## USAGE GUIDE

### Quick Fix (single file)
```
1. Open this FIXER file + target file in Copilot context
2. Ask: "Fix [target filename] using the fixer"
3. Copilot outputs: fixed file content + before/after report
4. Review the fixed content
5. Replace the original file with the fixed version
6. Move any extracted content to the suggested target files
```

### Batch Fix (multiple files)
```
1. Open this FIXER file in Copilot context
2. Ask: "Fix all agent files in .github/agents/ one by one"
3. For each file: Copilot reads → fixes → reports
4. Review each output before applying
```

### Peer Review Mode
```
1. Open this FIXER file + peer's file in Copilot context
2. Ask: "Audit and score [peer's filename] — what needs fixing?"
3. Copilot produces audit report (from AUDITOR checks) WITHOUT modifying
4. Share the report as constructive feedback
```

### Compare Old vs New
```
1. Open this FIXER file + original file + already-fixed file
2. Ask: "Compare original vs fixed version — show token savings and improvements"
3. Copilot produces the BEFORE/AFTER report only
```
