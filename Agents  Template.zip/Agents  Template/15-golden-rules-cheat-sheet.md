# Agent File Standards — 15 Golden Rules

> Print this. Pin it. Use it to review every file you write.

---

## THE 15 RULES

### 1. AGENT FILE = ROUTER ONLY (≤150 lines)
Contains: Identity (5 lines) + Critical Rules (5-8 rules) + Task Flow Table + Skill Routing Table + Global Commands.
Never contains: Templates, code examples, detailed procedures, learnings, long explanations.

### 2. SKILL FILE = DOMAIN KNOWLEDGE (≤300 lines)
Contains: When Used + Quick Reference Table + Step-by-Step Procedure + Templates + Anti-Patterns + Verification.
Never contains: Workflow routing, identity/persona, other skill's knowledge.

### 3. INSTRUCTION FILE = SHARED PROCESS (≤200 lines)
Contains: When to Use + Pre-Conditions + Numbered Steps (DO/VERIFY/IF FAIL) + Output Format.
Never contains: Templates, agent-specific logic, skill-level detail.

### 4. PROMPT FILE = TRIGGER ONLY (≤50 lines)
Contains: What to execute + Which agent/phase to call + Parameters.
Never contains: Procedures, rules, templates, knowledge. A prompt CALLS — it never DEFINES.

### 5. COMMON FILE = UNIVERSAL RULES (≤100 lines)
Contains: Rules that ALL agents must follow regardless of task.
Never contains: Agent-specific rules, skill-specific knowledge, task-specific procedures.

### 6. CONFIG JSON = STRUCTURED DATA (any size)
Contains: Known issues, environment config, feature flags — all as structured key-value entries.
Never contains: Prose, procedures, rules. Data only.

### 7. CRITICAL RULES IN FIRST 30 LINES
Claude's attention is highest at the start. Put IDENTITY + CRITICAL RULES in lines 1-30 of every agent file. If a rule matters, it goes at the top — not buried at line 400.

### 8. ONE CONCERN PER FILE
If a file does two unrelated things, split it. If editing Section A can break Section B, they should be separate files. Test: can you describe the file's purpose in ONE sentence?

### 9. TABLES OVER PROSE
Decision tables get 90%+ compliance from Claude. Prose paragraphs get ~60%. Convert every "if X then Y" paragraph into a table row. Convert every list of conditions into a decision table.

### 10. BLOCKING GATES OVER ADVICE
"STOP if X fails" gets ~95% compliance. "Try to check X" gets ~50%. Every critical checkpoint must use: DO → VERIFY → IF FAIL → STOP. Never use "should" or "consider" for mandatory steps.

### 11. NEVER INLINE LEARNINGS — USE JSON REGISTRY
When you discover an edge case, add it to `config/known-issues.json` as a structured entry. Never append paragraphs to agent or skill files. One finding = one JSON entry (~5 fields, ~3 lines). Not one paragraph (~10 lines of prose).

### 12. ALL REFERENCES FLOW ONE DIRECTION (DOWN)
Prompt → Agent → Skill → Config. Never upward. Never circular. An agent reads skills. A skill never calls an agent. A prompt triggers a workflow. A skill never triggers a prompt.

### 13. SKILLS LOAD ON DEMAND — AGENT LOADS EVERY TURN
Your agent file costs tokens on EVERY message. Skills cost tokens only when fetched. Keep the agent thin (150 lines = ~3,000 tokens). Push details to skills that load only when that phase runs.

### 14. USE STRONG KEYWORDS FOR RULES
NEVER / ALWAYS / MUST / BLOCKING / STOP / DO NOT = 85-95% compliance.
should / prefer / try to / consider / ideally = 35-70% compliance.
Write rules with strong keywords. Save soft language for suggestions, not rules.

### 15. EVERY FILE MUST PASS THE "REMOVE A LINE" TEST
For each line: "If I delete this line, will the agent fail?" If NO → the line is filler. Remove it. Target: zero filler lines. Every line either defines a rule, a step, a decision, or a reference.

---

## QUICK REFERENCE: FILE SIZE + FORMAT

| File Type | Max Lines | Format | Loaded When |
|-----------|-----------|--------|-------------|
| Agent | 150 | Identity → Rules → Tables → Commands | Every turn (constant cost) |
| Skill | 300 | When Used → Table → Steps → Template → Anti-Patterns | On demand (variable cost) |
| Instruction | 200 | When → Pre-Conditions → Steps (DO/VERIFY/FAIL) → Output | On demand |
| Prompt | 50 | Trigger description → Agent/Phase reference → Parameters | When user selects |
| Common | 100 | Universal rules → Short numbered lists | Every turn (constant cost) |
| Config JSON | Any | Structured entries with id, category, trigger, fix | On demand, parsed selectively |

---

## WHY THIS STRUCTURE (30-second answer for anyone)

"The agent file loads every turn — keeping it at 150 lines saves ~10,000 tokens per conversation vs an 800-line monolith. Skills load only when needed, so 20 skill files cost the same as 1 when only 1 is active. Rules in the first 30 lines get 95% compliance; rules at line 500 get 40%. This structure maximizes Claude's attention where it matters and minimizes wasted tokens."

---

## RED FLAGS DURING REVIEW

- File over line limit → Split immediately
- Rules below line 50 in agent file → Move them up
- Prose paragraph explaining a decision → Convert to table
- "should" / "try to" / "consider" in a mandatory rule → Replace with NEVER / MUST / STOP
- Same content in two files → Remove one, reference the other
- Findings appended as paragraphs → Move to known-issues.json
- Skill references another skill → Route through agent instead
- Prompt contains procedures → Move procedures to skill, prompt just triggers
