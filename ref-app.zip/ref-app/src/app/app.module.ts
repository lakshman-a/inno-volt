import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './pages/home/home.component';
import { TopBarComponent } from './layout/top-bar/top-bar.component';
import { SideBarComponent } from './layout/side-bar/side-bar.component';
import { RequestFormComponent } from './pages/request-form/request-form.component';
import { RequestStatusComponent } from './pages/request-status/request-status.component';
import { ToastComponent } from './shared/toast/toast.component';
import { FullPageLoaderComponent } from './shared/full-page-loader/full-page-loader.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TopBarComponent,
    SideBarComponent,
    RequestFormComponent,
    RequestStatusComponent,
    ToastComponent,
    FullPageLoaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
