import { Component, OnInit, Input } from '@angular/core';
import { TitleService } from 'src/app/services/title.service';

@Component({
  selector: 'app-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.css']
})
export class TopBarComponent implements OnInit {
  pageTitle: string = '';

  constructor(private titleService: TitleService) { }

  ngOnInit(): void {
    this.titleService.pageTitle$.subscribe(title => {
      this.pageTitle = title;
    });
  }

}
