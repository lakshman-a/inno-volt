import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private token: string | null = null;

  constructor(private http: HttpClient) { } // ✅ use HttpClient directly

  getToken(): Observable<string | null> {
    if (this.token) {
      return of(this.token);
    }

    const authUrl = environment.oauthUrl;
    const credentials = {
      username: environment.serviceUsername,
      password: environment.servicePassword,
      grant_type: 'password'
    };

    return this.http.post<any>(authUrl, credentials).pipe(
      map(res => {
        if (!res.access_token) {
          throw new Error('Token not received');
        }
        this.token = res.access_token!;
        return this.token;
      })
    );
  }

  clearToken() {
    this.token = null;
  }

  // pingUser(): Observable<{ username: string; corpId: string }> {
  //   return this.http.get('/user/ping');
  // }

  //  login(credentials: any): Observable<{ token: string }> {
  //   return this.http.post('/auth/token', credentials);
  // }

  // Simulated SSO ping response
  pingUser(): Observable<{ username: string; corpId: string }> {
    // Simulate network latency with setTimeout if needed
    return of({
      username: 'Ayyakkannu, Lakshman',
      corpId: 'F123456',
    });
  }
}
