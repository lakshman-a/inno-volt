import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { TitleService } from 'src/app/services/title.service';

@Component({
  selector: 'app-request-form',
  templateUrl: './request-form.component.html',
  styleUrls: ['./request-form.component.css']
})
export class RequestFormComponent implements OnInit {

  @ViewChild('maskingModal') maskingModal!: TemplateRef<any>;

  constructor(private titleService: TitleService
  ) { }

  ngOnInit(): void {
    this.titleService.setTitle('My Requests');
  }

  currentStep = 3;

  formData = {
    userType: 'new', // 'new' or 'existing'

    // New Request path
    squadInfo: {
      domain: '',
      squadName: '',
      project: '',
      summary: '',
      requestType: '',
      primaryContact: '',
      secondaryContact: '',
      maskingDescription: '',
      priority: '',
      deadline: '',
      type: ''
    },

    // Existing VDB path
    existingVdb: {
      selectedSquad: '',
      vdbName: '',
      overrideSchema: '',
      overrideTables: ''
    },

    // DB Details step
    db: {
      sourceDbType: '',
      sourceEnv: '',
      infra: '',
      host: '',
      port: '',
      service: '',
      sourceSize: '',
      destEnv: '',
      schemaSize: '',
      srcDbType: '',
      connectionString: '',
      srcDeploymentType: '',
      srcEnvironment: '',
      targetEnvironment: '',
      srcDbSize: ''
    },

    // Final value metrics step
    valueStats: {
      valueType: '',
      costSavings: '',
      timeSavings: '',
      expectedBenefits: '',
      valueCommitment: false,
      followUpMode: 'Teams', // default selected
      usePrimaryContact: false, // unchecked by default
      contactPerson: ''
    }
  };

  nextStep(): void {
    if (this.formData.userType === 'existing') {
      const selected = this.onboardedSquads.find(s => s.name === this.formData.existingVdb.selectedSquad);
      this.formData.existingVdb.vdbName = selected?.vdbName || '';
    }
    if (this.currentStep < 3) {
      this.currentStep++;
    }
  }

  prevStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  modalData: any[] = [];
  maskingList: any[] = [];
  isModalOpen: boolean = false;
  totalSize = '';

  addNewRow() {
    const hasEmptyMandatoryField = this.modalData.some(
      (row) => !row.schema || !row.table || !row.column
    );

    if (hasEmptyMandatoryField) {
      alert('Schema, Table, and Column(s) are mandatory for all rows before adding a new one.');
      return;
    }

    const lastRow = this.modalData[this.modalData.length - 1] || {};
    this.modalData.push({
      schema: lastRow.schema || '',
      table: lastRow.table || '',
      column: lastRow.column || '',
      columnType: lastRow.columnType || '',
      description: lastRow.description || ''
    });
  }

  deleteRow(index: number) {
    this.modalData.splice(index, 1);
  }

  closeModal() {
    this.isModalOpen = false;
  }

  openModalForEdit() {
    this.modalData = this.maskingList.map(item => ({
      schema: item.schema,
      table: item.table,
      column: item.columns?.join(', ') || '',
      columnType: item.columnType || '',
      description: item.description || ''
    }));
    this.isModalOpen = true;
  }

  // Flattened list before clubbing, used for edit mode
  get maskingListFlat(): any[] {
    const flatList = [];
    for (const schema in this.groupedMaskingData) {
      for (const table in this.groupedMaskingData[schema]) {
        const columns = this.groupedMaskingData[schema][table];
        flatList.push({
          schema,
          table,
          column: columns.join(', '),
          columnType: '',
          description: ''
        });
      }
    }
    return flatList;
  }


  get groupedMaskingData(): any {
    const grouped: any = {};
    for (const row of this.maskingList) {
      const schema = row.schema;
      const table = row.table;
      const columns = row.columns;

      if (!grouped[schema]) grouped[schema] = {};
      if (!grouped[schema][table]) grouped[schema][table] = [];

      grouped[schema][table].push(...columns);
    }
    return grouped;
  }

  public groupedMaskingSummary: any[] = [];

  saveMaskingData() {
    const hasError = this.modalData.some(
      row => !row.schema?.trim() || !row.table?.trim() || !row.column?.trim()
    );

    if (hasError) {
      alert('Schema, Table, and Column(s) are required in all rows.');
      return;
    }

    // --- Step 1: Duplicate column check with mismatched types ---
    const columnTypeMap = new Map<string, Set<string>>();
    const duplicatesWithDifferentType: string[] = [];

    this.modalData.forEach(row => {
      const schema = row.schema.trim();
      const table = row.table.trim();
      const type = row.columnType?.trim() || '';
      const columns = row.column
        .split(',')
        .map((col: string) => col.trim())
        .filter(Boolean);

      columns.forEach((col: string) => {
        const key = `${schema}__${table}__${col.toLowerCase()}`; // case-insensitive match
        if (!columnTypeMap.has(key)) {
          columnTypeMap.set(key, new Set([type]));
        } else {
          const existingTypes = columnTypeMap.get(key)!;
          if (!existingTypes.has(type)) {
            duplicatesWithDifferentType.push(`${schema}.${table}.${col}`);
          }
          existingTypes.add(type);
        }
      });
    });

    if (duplicatesWithDifferentType.length > 0) {
      alert(
        `Duplicate column(s) found with conflicting types:\n- ${duplicatesWithDifferentType.join(
          '\n- '
        )}\n\nPlease ensure each column has a consistent Type.`
      );
      return;
    }

    // --- Step 2: Grouping (5-field key: Schema, Table, Type, Description, Columns) ---
    const groupedMapFull = new Map<
      string,
      {
        schema: string;
        table: string;
        columns: Set<string>;
        columnType?: string;
        description?: string;
      }
    >();

    // Optional: also 3-field key version
    const groupedMapSimple = new Map<
      string,
      {
        schema: string;
        table: string;
        columns: Set<string>;
      }
    >();

    this.modalData.forEach(row => {
      const schema = row.schema.trim();
      const table = row.table.trim();
      const type = row.columnType?.trim() || '';
      const desc = row.description?.trim() || '';
      const columns = row.column.split(',').map((c: string) => c.trim()).filter(Boolean);
      const columnSet = new Set<string>(columns);

      const fullKey = `${schema}__${table}__${type}__${desc}`;
      if (groupedMapFull.has(fullKey)) {
        const existing = groupedMapFull.get(fullKey)!;
        columns.forEach((col: string) => existing.columns.add(col));
      } else {
        groupedMapFull.set(fullKey, {
          schema,
          table,
          columns: new Set(columns),
          columnType: type,
          description: desc
        });
      }

      const simpleKey = `${schema}__${table}`;
      if (groupedMapSimple.has(simpleKey)) {
        const existing = groupedMapSimple.get(simpleKey)!;
        columns.forEach((col: string) => existing.columns.add(col));
      } else {
        groupedMapSimple.set(simpleKey, {
          schema,
          table,
          columns: new Set(columns)
        });
      }
    });

    this.maskingList = Array.from(groupedMapFull.values()).map(item => ({
      schema: item.schema,
      table: item.table,
      columns: Array.from(item.columns),
      columnType: item.columnType,
      description: item.description
    }));

    this.groupedMaskingSummary = Array.from(groupedMapSimple.values()).map(item => ({
      schema: item.schema,
      table: item.table,
      columns: Array.from(item.columns)
    }));

    this.closeModal();
  }

  get uniqueSchemasCount(): number {
    return new Set(this.maskingList.map(item => item.schema)).size;
  }

  get uniqueTablesCount(): number {
    return new Set(this.maskingList.map(item => `${item.schema}__${item.table}`)).size;
  }

  get uniqueColumnsCount(): number {
    const columnSet = new Set<string>();
    this.maskingList.forEach(item => {
      item.columns.forEach((col: any) => columnSet.add(`${item.schema}__${item.table}__${col}`));
    });
    return columnSet.size;
  }

  schemaSizeMap: { [schema: string]: number } = {};

  get uniqueSchemasForSize(): string[] {
    const uniqueSchemas = Array.from(new Set(this.maskingList.map(item => item.schema)));
    uniqueSchemas.forEach(schema => {
      if (!this.schemaSizeMap.hasOwnProperty(schema)) {
        this.schemaSizeMap[schema] = 0.00;
      }
    });
    return uniqueSchemas;
  }
  onboardedSquads = [
    { name: 'Alpha Squad', vdbName: 'vdb_alpha_001' },
    { name: 'Beta Squad', vdbName: 'vdb_beta_002' }
  ];
  domainOptions = ['Retail', 'Brokerage', 'Wealth'];
  requestTypes = ['Standard', 'Urgent'];
  followUpModes = ['Email', 'Teams', 'Phone'];
  maskingData = [
    { schema: 'Schema1', tables: ['Table1'], columns: ['col1', 'col2', 'col3'] }
  ];

  openMaskingModal() {
    // this.modalService.open(this.maskingModal, { size: 'lg', backdrop: 'static' });
  }
  addColumnRow() {
    const latest = this.getLastFilledRowWithSchemaAndTable();
    if (!latest || !latest.schema || !latest.table || !latest.column) return;

    const columns = latest.column.split(',').map((col: any) => col.trim()).filter(Boolean);

    columns.forEach((col: any, index: any) => {
      this.modalData.push({
        schema: latest.schema,
        table: latest.table,
        column: col,
        columnType: '',
        description: ''
      });
    });
  }

  getLastFilledRowWithSchema() {
    for (let i = this.modalData.length - 1; i >= 0; i--) {
      if (this.modalData[i].schema?.trim()) {
        return this.modalData[i];
      }
    }
    return null;
  }

  getLastFilledRowWithSchemaAndTable() {
    for (let i = this.modalData.length - 1; i >= 0; i--) {
      const row = this.modalData[i];
      if (row.schema?.trim() && row.table?.trim() && row.column?.trim()) {
        return row;
      }
    }
    return null;
  }

  isSubmissionModalOpen = false;
  generatedTrackingId: string = '';

  submitRequest(): void {
    const dbTypePrefix = this.formData.db.sourceDbType === 'Oracle' ? 'O' : 'F';
    const timestamp = Date.now().toString(); // milliseconds
    const trackingId = `TPM${dbTypePrefix}${timestamp.slice(-10)}`; // Last 10 digits for uniqueness

    const finalPayload = {
      ...this.formData,
      maskingDetails: this.maskingList,
      trackingId: trackingId
    };

    console.log("✅ Submitted Payload:", finalPayload);

    // Store and show modal
    this.generatedTrackingId = trackingId;
    this.isSubmissionModalOpen = true;
  }

  copyTrackingIdToClipboard(): void {
    navigator.clipboard.writeText(this.generatedTrackingId).then(() => {
      console.log('Tracking ID copied to clipboard');
    });
  }

  closeSuccessModal(): void {
    this.isSubmissionModalOpen = false;
    this.resetForm();
    this.currentStep = 1; // back to step 1
  }

  resetForm(): void {
    this.formData = {
      userType: 'new', // 'new' or 'existing'

      // New Request path
      squadInfo: {
        domain: '',
        squadName: '',
        project: '',
        summary: '',
        requestType: '',
        primaryContact: '',
        secondaryContact: '',
        maskingDescription: '',
        priority: '',
        deadline: '',
        type: ''
      },

      // Existing VDB path
      existingVdb: {
        selectedSquad: '',
        vdbName: '',
        overrideSchema: '',
        overrideTables: ''
      },

      // DB Details step
      db: {
        sourceDbType: '',
        sourceEnv: '',
        infra: '',
        host: '',
        port: '',
        service: '',
        sourceSize: '',
        destEnv: '',
        schemaSize: '',
        srcDbType: '',
        connectionString: '',
        srcDeploymentType: '',
        srcEnvironment: '',
        targetEnvironment: '',
        srcDbSize: ''
      },

      // Final value metrics step
      valueStats: {
        valueType: '',
        costSavings: '',
        timeSavings: '',
        expectedBenefits: '',
        valueCommitment: false,
        followUpMode: 'Teams', // default selected
        usePrimaryContact: false, // unchecked by default
        contactPerson: ''
      }
    };

    this.maskingList = [];
    this.groupedMaskingSummary = [];
    this.schemaSizeMap = {};
  }

  goToStep(step: number): void {
    this.currentStep = step;
  }

}
