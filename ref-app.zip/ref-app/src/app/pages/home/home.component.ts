import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  stats = [
    { label: 'Items to fix across squads', value: '3,000+' },
    { label: 'Story Compliance Achieved', value: '89%' },
    { label: 'Compliant Sprints this Quarter', value: '150+' },
    { label: 'Change Tickets Reviewed', value: '1,200+' }
  ];

  modules = [
    {
      title: 'Story Compliance',
      icon: '📌',
      stat: '3,000+',
      statDesc: 'Stories can be fixed',
      message: 'Items to fix across squads. Track and resolve gaps in story coverage, test development, and alignment.',
      route: '/story-compliance',
      confluence: 'https://confluence.company.com/assure/story-compliance'
    },
    {
      title: 'Change Ticket Compliance',
      icon: '🛠️',
      stat: '1,200+',
      statDesc: 'CMs can be fixed',
      message: 'Change tickets reviewed. Ensure all changes are validated with test coverage and QA signoff.',
      route: '/change-compliance',
      confluence: 'https://confluence.company.com/assure/cm-compliance'
    },
    {
      title: 'Sprint Summary',
      icon: '📅',
      stat: '150+',
      statDesc: 'Sprint needs action',
      message: 'Compliant sprints this quarter. Get actionable insights on your squad’s sprint performance.',
      route: '/sprint-summary',
      confluence: 'https://confluence.company.com/assure/sprint-summary'
    }
  ];

}
