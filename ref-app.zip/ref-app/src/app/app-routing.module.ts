import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { RequestFormComponent } from './pages/request-form/request-form.component';
import { RequestStatusComponent } from './pages/request-status/request-status.component';

const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'home', component: HomeComponent, data: { title: 'TDM | Home' } },
  { path: 'request', component: RequestFormComponent, data: { title: 'TDM | New Request' } },
  { path: 'status', component: RequestStatusComponent, data: { title: 'TDM | My Request' } },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
