import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { StoryComplianceComponent } from './pages/story-compliance/story-compliance.component';
import { ChangeComplianceComponent } from './pages/change-compliance/change-compliance.component';
import { SprintSummaryComponent } from './pages/sprint-summary/sprint-summary.component';
import { HomeComponent } from './pages/home/home.component';

const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'home', component: HomeComponent, data: { title: 'Assure | Home' } },
  { path: 'dashboard', component: DashboardComponent, data: { title: 'Assure | Dashboard' } },
  { path: 'story-compliance', component: StoryComplianceComponent,data: { title: 'Assure | Story Compliance' } },
  { path: 'change-compliance', component: ChangeComplianceComponent, data: { title: 'Assure | Change Compliance' } },
  { path: 'sprint-summary', component: SprintSummaryComponent, data: { title: 'Assure | Sprint Summary' } },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
