import { Component, ElementRef, HostListener } from '@angular/core';
import { UserContextService } from 'src/app/services/user-context.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent {
   username: string = '';

   menuOpen = false;

  constructor(private userContext: UserContextService, private elementRef: ElementRef) {}

    ngOnInit(): void {
    this.userContext.userInfo$.subscribe(user => {
      this.username = this.formatName(user.username);
    });
  }
  
    formatName(username: string): string {
    if (!username) return '';
    // Convert `lakshman.a` => `Ayyakkannu, Lakshman` (your logic here)
    return username;
  }

  toggleMenu() {
    this.menuOpen = !this.menuOpen;
  }

  closeMenu() {
    this.menuOpen = false;
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: MouseEvent) {
    const clickedInside = this.elementRef.nativeElement.contains(event.target);
    if (!clickedInside) {
      this.closeMenu();
    }
  }

  openLink(type: 'confluence' | 'teams' | 'support') {
    const links: Record<'confluence' | 'teams' | 'support', string> = {
      confluence: 'https://your-confluence-link',
      teams: 'https://teams.microsoft.com/your-channel',
      support: 'mailto:support@example.com'
    };
    window.open(links[type], '_blank');
    this.closeMenu();
  }
}