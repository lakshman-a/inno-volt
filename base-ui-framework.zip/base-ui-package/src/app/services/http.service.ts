import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, switchMap } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class HttpService {
  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken'); // or from a token service
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

    getB<T>(url: string): Observable<T> {
    return this.authService.getToken().pipe(
      switchMap(token => this.http.get<T>(`${environment.apiBaseUrl}${url}`, {
        headers: new HttpHeaders({
          Authorization: `Bearer ${token}`
        })
      }))
    );
  }

  postB<T>(url: string, body: any): Observable<T> {
    return this.authService.getToken().pipe(
      switchMap(token => this.http.post<T>(`${environment.apiBaseUrl}${url}`, body, {
        headers: new HttpHeaders({
          Authorization: `Bearer ${token}`
        })
      }))
    );
  }

  get<T>(url: string): Observable<T> {
    return this.http.get<T>(`${environment.apiBaseUrl}${url}`, {
      headers: this.getHeaders()
    });
  }

  post<T>(url: string, body: any): Observable<T> {
    return this.http.post<T>(`${environment.apiBaseUrl}${url}`, body, {
      headers: this.getHeaders()
    });
  }

  put<T>(url: string, body: any): Observable<T> {
    return this.http.put<T>(`${environment.apiBaseUrl}${url}`, body, {
      headers: this.getHeaders()
    });
  }

  delete<T>(url: string): Observable<T> {
    return this.http.delete<T>(`${environment.apiBaseUrl}${url}`, {
      headers: this.getHeaders()
    });
  }
}