import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class UserContextService {
  private userInfoSubject = new BehaviorSubject<{ username: string; corpId: string }>({
    username: '',
    corpId: ''
  });

  userInfo$ = this.userInfoSubject.asObservable();

  setUserInfo(user: { username: string; corpId: string }) {
    this.userInfoSubject.next(user);
  }

  getCurrentUser() {
    return this.userInfoSubject.value;
  }
}