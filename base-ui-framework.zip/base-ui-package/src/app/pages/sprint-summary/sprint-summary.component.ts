import { Component, OnInit,ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-sprint-summary',
  templateUrl: './sprint-summary.component.html',
  styleUrls: ['./sprint-summary.component.css']
})
export class SprintSummaryComponent implements OnInit {

  @ViewChild('sprintModal') sprintModal!: ElementRef;

  pingUrl = `${environment.apiBaseUrl}${environment.pingEndpoint}`;

  tableData: any[] = [];
  searchText: string = '';
  sortKey: string = '';
  sortAsc: boolean = true;

  squadId: string = '';
  sprintId: string = '';


  loading: boolean = false;
  responseState: 'success' | 'no-data' | 'error' | '' = '';
  apiErrorMessage: string = '';

  highlightTable: boolean = false;

  firstLoadSortApplied: boolean = false;

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.route.queryParams.subscribe(params => {
      const squad = params['squadId'];
      const sprint = params['sprintId'];

      if (squad) {
        this.squadId = squad;
      }

      if (sprint) {
        this.sprintId = sprint;
      }

      if (squad) {
        this.onSubmitForm(); // auto-trigger API fetch
      }
    });

  }

  openConfluence(): void {
    window.open('https://your-confluence-link.com/sprint-summary-details', '_blank');
  }


  isWfcLoading = false;
  wfcToastTimer: any;


  toastList: { type: 'info' | 'warning' | 'error' | 'success'; message: string; id: number }[] = [];
  toastIdCounter = 0;

  detectSquad(): void {
    this.isWfcLoading = true;

    setTimeout(() => {
      const response = this.getMockSquads();
      this.isWfcLoading = false;

      if (!response || response.length === 0) {
        this.showWfcToast('error', 'No Squad found for your ID in WFC. Please enter manually.');
      } else if (response.length === 1) {
        this.squadId = response[0].squadId;
        this.showWfcToast(
          'info',
          `Successfully loaded Squad <strong>${response[0].squadName}</strong> (${response[0].squadId}) for your ID.`
        );
        this.onSubmitForm();
      } else {
        const list = response
          .map(s => `${s.squadName} (${s.squadId})`)
          .join(', ');
        this.showWfcToast('info', `More than one squad found (Copy one):<br/>${list}`);
      }
    }, 100);
  }

  getMockSquads(): any[] {
    return [
      { squadId: 'FB12345', squadName: 'CBPT BTP', squadLead: 'Jane Doe' },
      // { squadId: 'FB67890', squadName: 'PI Agile Squad', squadLead: 'John Smith' }
    ];
  }

  highlightRowId: string | null = null;

  showWfcToast(type: 'info' | 'warning' | 'error' | 'success', message: string): void {
    const id = ++this.toastIdCounter;

    this.toastList.push({ type, message, id });

    // Auto-remove after 8 seconds
    setTimeout(() => {
      this.toastList = this.toastList.filter(t => t.id !== id);
    }, 8000);
  }


  removeToast(id: number): void {
    this.toastList = this.toastList.filter(t => t.id !== id);
  }


  selectedMode: 'Project' | 'Issues' = 'Project';
  currentDate: string = new Date().toISOString().split('T')[0];
  minProjectStartDate: string = new Date(Date.now() - 20 * 24 * 60 * 60 * 1000)
    .toISOString()
    .split('T')[0];

  setMode(mode: 'Project' | 'Issues') {
    this.selectedMode = mode;
  }

  onSubmitForm() {
    this.loading = true;
    this.apiErrorMessage = '';
    this.tableData = [];
    this.responseState = '';
    // this.firstLoadSortApplied = true;
    this.resetSortState();

    const payload = {
      squadId: this.squadId,
      sprintId: this.sprintId,
    };

    console.log('Submitted Payload:', payload);

    // Simulated async API call
    this.callApi(payload)
      .then((response) => {
        this.showWfcToast('success', '✅ Data fetched successfully!',);
        this.loading = false;

        if (response.status === 200) {
          if (response.data.length === 0) {
            this.showWfcToast('warning', '⚠️ No records found for your criteria.');
            this.responseState = 'no-data';
          } else {
            this.tableData = response.data;
            this.responseState = 'success';

            // Trigger green border flash
            this.highlightTable = true;
            setTimeout(() => (this.highlightTable = false), 1000);

            // Focus on table view
            setTimeout(() => {
              const table = document.getElementById('table-section');
              table?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          }
        }
      })
      .catch((error) => {
        this.showWfcToast('error', '❌ API call failed. Please try again.');
        this.loading = false;
        if (error.status === 400) {
          this.apiErrorMessage = error.message || 'Bad Request';
          this.responseState = 'error';
        } else if (error.status === 500) {
          this.apiErrorMessage =
            'Oops! Something went wrong. Please contact the admin team.';
          this.responseState = 'error';
        }
      });
  }

  callApi(payload: any): Promise<any> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (payload.squadId.includes('500')) {
          reject({ status: 500 });
        } else if (payload.squadId.includes('400')) {
          reject({ status: 400, message: 'Invalid Jira Key format' });
        } else if (payload.squadId.includes('empty')) {
          resolve({ status: 200, data: [] });
        } else {
          resolve({
            status: 200,
            data: [
              {
                sprintName: '2025 Q2 S4 05/25',
                sprintStatus: 'active',
                sprintID: '587445662',
                sprintDate: '2025-05-30 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 10,
                testableStories: 8,
                compliantStories: 8,
                compliantStoriesPct: 100,
                testDeveloped: 20,
                autoDevPct: 90,
                testExecution: 30,
                autoExecutionPct: 60,
                nonCompliantCount: 0,
                nigoTestCount: 10,
                automatablePending: 2,
                testHealth: 50
              },
              {
                sprintName: '2025 Q2 S3 05/10',
                sprintID: '587445661',
                sprintDate: '2025-05-15 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 12,
                testableStories: 9,
                compliantStories: 7,
                compliantStoriesPct: 78,
                testDeveloped: 18,
                autoDevPct: 60,
                testExecution: 22,
                autoExecutionPct: 40,
                nonCompliantCount: 2,
                nigoTestCount: 10,
                automatablePending: 5,
                testHealth: 55
              },
              {
                sprintName: '2025 Q2 S2 04/20',
                sprintID: '587445660',
                sprintDate: '2025-04-27 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 11,
                testableStories: 10,
                compliantStories: 9,
                compliantStoriesPct: 90,
                testDeveloped: 24,
                autoDevPct: 75,
                testExecution: 26,
                autoExecutionPct: 65,
                nonCompliantCount: 1,
                nigoTestCount: 5,
                automatablePending: 4,
                testHealth: 70
              },
              {
                sprintName: '2025 Q2 S1 04/05',
                sprintID: '587445659',
                sprintDate: '2025-04-12 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 13,
                testableStories: 11,
                compliantStories: 10,
                compliantStoriesPct: 91,
                testDeveloped: 25,
                autoDevPct: 80,
                testExecution: 29,
                autoExecutionPct: 62,
                nonCompliantCount: 1,
                nigoTestCount: 14,
                automatablePending: 33,
                testHealth: 75
              },
              {
                sprintName: '2025 Q1 S6 03/20',
                sprintID: '587445658',
                sprintDate: '2025-03-28 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 9,
                testableStories: 7,
                compliantStories: 5,
                compliantStoriesPct: 71,
                testDeveloped: 15,
                autoDevPct: 40,
                testExecution: 20,
                autoExecutionPct: 35,
                nonCompliantCount: 1,
                nigoTestCount: 14,
                automatablePending: 33,
                testHealth: 40
              },
              {
                sprintName: '2025 Q1 S5 03/05',
                sprintID: '587445657',
                sprintDate: '2025-03-12 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 15,
                testableStories: 12,
                compliantStories: 10,
                compliantStoriesPct: 83,
                testDeveloped: 22,
                autoDevPct: 70,
                nonCompliantCount: 2,
                nigoTestCount: 1,
                automatablePending: 23,
                testExecution: 25,
                autoExecutionPct: 50,
                testHealth: 68
              },
              {
                sprintName: '2025 Q1 S4 02/20',
                sprintID: '587445656',
                sprintDate: '2025-02-27 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 14,
                testableStories: 11,
                compliantStories: 11,
                compliantStoriesPct: 100,
                testDeveloped: 28,
                autoDevPct: 85,
                testExecution: 28,
                nonCompliantCount: 0,
                nigoTestCount: 11,
                automatablePending: 1,
                autoExecutionPct: 80,
                testHealth: 82
              },
              {
                sprintName: '2025 Q1 S3 02/05',
                sprintID: '587445655',
                sprintDate: '2025-02-12 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 10,
                testableStories: 9,
                compliantStories: 7,
                compliantStoriesPct: 78,
                testDeveloped: 19,
                autoDevPct: 55,
                nonCompliantCount: 2,
                nigoTestCount: 1,
                automatablePending: 0,
                testExecution: 21,
                autoExecutionPct: 45,
                testHealth: 59
              },
              {
                sprintName: '2025 Q1 S2 01/20',
                sprintID: '587445654',
                sprintDate: '2025-01-27 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 8,
                testableStories: 6,
                compliantStories: 5,
                compliantStoriesPct: 83,
                testDeveloped: 14,
                autoDevPct: 50,
                nonCompliantCount: 1,
                nigoTestCount: 11,
                automatablePending: 10,
                testExecution: 17,
                autoExecutionPct: 52,
                testHealth: 48
              },
              {
                sprintName: '2025 Q1 S1 01/05',
                sprintID: '587445653',
                sprintDate: '2025-01-12 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 7,
                testableStories: 5,
                compliantStories: 3,
                compliantStoriesPct: 60,
                nonCompliantCount: 2,
                nigoTestCount: 1,
                automatablePending: 0,
                testDeveloped: 10,
                autoDevPct: 30,
                testExecution: 12,
                autoExecutionPct: 20,
                testHealth: 35
              },
              {
                sprintName: '2024 Q4 S6 12/20',
                sprintID: '587445652',
                sprintDate: '2024-12-27 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 12,
                testableStories: 9,
                compliantStories: 7,
                compliantStoriesPct: 78,
                testDeveloped: 20,
                autoDevPct: 65,
                testExecution: 23,
                autoExecutionPct: 60,
                testHealth: 67
              },
              {
                sprintName: '2024 Q4 S5 12/05',
                sprintID: '587445651',
                sprintDate: '2024-12-12 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 11,
                testableStories: 9,
                compliantStories: 9,
                compliantStoriesPct: 100,
                testDeveloped: 19,
                autoDevPct: 95,
                testExecution: 22,
                autoExecutionPct: 90,
                testHealth: 85
              },
              {
                sprintName: '2024 Q4 S4 11/20',
                sprintID: '587445650',
                sprintDate: '2024-11-27 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 10,
                testableStories: 8,
                compliantStories: 8,
                compliantStoriesPct: 100,
                testDeveloped: 18,
                autoDevPct: 40,
                testExecution: 21,
                autoExecutionPct: 33,
                testHealth: 60
              },
              {
                sprintName: '2024 Q4 S3 11/05',
                sprintID: '587445649',
                sprintDate: '2024-11-12 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 13,
                testableStories: 11,
                compliantStories: 9,
                compliantStoriesPct: 82,
                testDeveloped: 24,
                autoDevPct: 68,
                testExecution: 27,
                autoExecutionPct: 64,
                testHealth: 73
              },
              {
                sprintName: '2024 Q4 S2 10/20',
                sprintID: '587445648',
                sprintDate: '2024-10-27 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 14,
                testableStories: 12,
                compliantStories: 12,
                compliantStoriesPct: 100,
                testDeveloped: 26,
                autoDevPct: 88,
                testExecution: 30,
                autoExecutionPct: 85,
                testHealth: 88
              },
              {
                sprintName: '2024 Q4 S1 10/05',
                sprintID: '587445647',
                sprintDate: '2024-10-12 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 9,
                testableStories: 7,
                compliantStories: 6,
                compliantStoriesPct: 86,
                testDeveloped: 16,
                autoDevPct: 70,
                testExecution: 19,
                autoExecutionPct: 58,
                testHealth: 65
              },
              {
                sprintName: '2024 Q3 S6 09/20',
                sprintID: '587445646',
                sprintDate: '2024-09-27 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 10,
                testableStories: 9,
                compliantStories: 7,
                compliantStoriesPct: 78,
                testDeveloped: 22,
                autoDevPct: 68,
                testExecution: 26,
                autoExecutionPct: 66,
                testHealth: 69
              },
              {
                sprintName: '2024 Q3 S5 09/05',
                sprintID: '587445645',
                sprintDate: '2024-09-12 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 12,
                testableStories: 11,
                compliantStories: 10,
                compliantStoriesPct: 91,
                testDeveloped: 25,
                autoDevPct: 75,
                testExecution: 28,
                autoExecutionPct: 70,
                testHealth: 72
              },
              {
                sprintName: '2024 Q3 S4 08/20',
                sprintID: '587445644',
                sprintDate: '2024-08-27 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 11,
                testableStories: 9,
                compliantStories: 8,
                compliantStoriesPct: 89,
                testDeveloped: 20,
                autoDevPct: 50,
                testExecution: 24,
                autoExecutionPct: 48,
                testHealth: 63
              },
              {
                sprintName: '2024 Q3 S3 08/05',
                sprintID: '587445643',
                sprintDate: '2024-08-12 23:10',
                boardName: 'FIT Unify Scrum Board',
                typeType: 'Scrum',
                totalStories: 10,
                testableStories: 8,
                compliantStories: 6,
                compliantStoriesPct: 75,
                testDeveloped: 18,
                autoDevPct: 55,
                testExecution: 21,
                autoExecutionPct: 50,
                testHealth: 60
              }
            ],
          });
        }
      }, 100);
    });
  }

  getSprintSummaryStatus(row: any): string {
    const compliantPct = row.compliantStoriesPct;
    const isOverdue = new Date(row.sprintDate) < new Date();
    const daysLeft = Math.ceil((new Date(row.sprintDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));

    if (row.sprintStatus === 'active') {
      const eta = isOverdue ? '– Overdue' : `– ${daysLeft} days left`;
      if (compliantPct >= 85 && row.testHealth >= 75) return `🟢 Good ${eta}`;
      if (compliantPct >= 60) return `🟡 Needs Action ${eta}`;
      return `🔴 Critical ${eta}`;
    } else {
      if (compliantPct >= 85 && row.testHealth >= 75) return '✅ Completed OK';
      return '❌ Ended Badly';
    }
  }

  get activeSprintRow() {
    return this.tableData.find(row => row.sprintStatus === 'active');
  }

  filteredTableData() {
    let data = this.tableData;

    // 🔁 Apply compliance filter first
    if (this.complianceFilter) {
      data = data.filter(row =>
        row.compliance?.toLowerCase() === this.complianceFilter.toLowerCase()
      );
    }

    // 🔍 Then apply search text
    data = data.filter(item =>
      Object.values(item as Record<string, any>).some(val =>
        val?.toString().toLowerCase().includes(this.searchText.toLowerCase())
      )
    );

    // ✅ Sort by compliance priority if no sort key is selected
    if (!this.sortKey) {
      const priority = ['non-compliant', 'non compliant', 'compliant', 'excluded', 'manual', 'pending'];
      data.sort((a, b) => {
        const aValue = a.compliance?.toLowerCase() || '';
        const bValue = b.compliance?.toLowerCase() || '';
        const aIndex = priority.indexOf(aValue);
        const bIndex = priority.indexOf(bValue);
        return (aIndex === -1 ? priority.length : aIndex) - (bIndex === -1 ? priority.length : bIndex);
      });
      return data;
    }

    // 🔁 Apply sort by column
    return data.sort((a, b) => {
      const valA = a[this.sortKey] ?? '';
      const valB = b[this.sortKey] ?? '';
      return this.sortAsc
        ? valA.toString().localeCompare(valB.toString())
        : valB.toString().localeCompare(valA.toString());
    });
  }

  sortTable(column: string) {
    if (this.sortKey === column) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortKey = column;
      this.sortAsc = true;
    }
  }

  sortBy(column: string) {
    if (this.sortKey === column) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortKey = column;
      this.sortAsc = true;
    }
  }

  resetSortState() {
    this.sortKey = '';
    this.sortAsc = true;
  }

  downloadTable() {
    const headers = Object.keys(this.tableData[0] || {});
    const rows = this.tableData.map((row) =>
      headers.map((field) => `"${row[field] || ''}"`).join(',')
    );
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', 'jira_compliance_results.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  resetForm() {
    if (this.tableData.length > 0) {
      const confirmReset = confirm(
        'Resetting will clear the table data. Do you want to proceed?'
      );
      if (!confirmReset) return;
    }

    this.squadId = '';
    this.sprintId = '';
    this.searchText = '';
    this.tableData = [];
  }

  copyToClipboard(text: string) {
    navigator.clipboard.writeText(text).then(() => {
      this.toastList.push({ id: Date.now(), message: 'Sprint ID copied!', type: 'success' });
      setTimeout(() => this.toastList.shift(), 2000);
    });
  }

  getBadgeClass(compliance: string): string {
    switch (compliance.toLowerCase()) {
      case 'compliant':
        return 'badge badge-success';
      case 'non compliant':
      case 'non-compliant':
        return 'badge badge-danger';
      case 'excluded':
        return 'badge badge-grey';
      default:
        return 'badge badge-info';
    }
  }

  getJiraLink(issueKey: string): string {
    return `https://your-jira-instance/browse/${issueKey}`;
  }


  complianceFilter: string = '';

  countByStatus(status: string): number {
    return this.filteredTableData().filter(
      row => row.compliance?.toLowerCase() === status.toLowerCase()
    ).length;
  }

  filterByCompliance(status: string) {
    this.complianceFilter = status;
  }

  resetComplianceFilter() {
    this.complianceFilter = '';
  }


  isActionable(compliance: string): boolean {
    return ['non-compliant', 'pending', 'manual'].includes(compliance?.toLowerCase());
  }

  getActionIcon(compliance: string): string {
    const lower = compliance?.toLowerCase();
    // if (lower === 'non-compliant') return '🔥';
    if (lower === 'non-compliant') return '⚠️';
    if (lower === 'pending' || lower === 'manual') return '❗';
    return '';
  }

  getActionMessage(compliance: string, failReasons: string[] = []): string {
    const lower = compliance?.toLowerCase();

    if (lower === 'non-compliant') {
      const reasons = failReasons.length
        ? failReasons.map(reason => `- ${reason}`).join('\n')
        : '- Unknown issue';

      return `Action Required\nFix needed:\n${reasons}`;
    }

    if (lower === 'pending') return 'Pending Review';
    if (lower === 'manual') return 'Manual Verification Needed';

    return '';
  }

  formatFailReasons(reasons: string[] = []): string {
    if (!reasons.length) return 'Click to view compliance details';
    return 'Fixes needed:\n- ' + reasons.join('\n- ');
  }

  showModal = false;
  selectedRow: any = null;

  openModal(row: any) {
    this.selectedRow = row;
    this.showModal = true;
  }

  closeModal() {
    this.showModal = false;
  }

  complianceChecks = [
    {
      title: 'Story/Bug has Valid Fix Version?',
      status: 'COMPLIANT',
      log: '[PASSED] Fix version found: FIAIA 25.05.01',
      showLog: false
    },
    {
      title: 'Story/Bug with Acceptance Criteria?',
      status: 'COMPLIANT',
      log: '[PASSED] Acceptance criteria filled: 484 characters',
      showLog: false
    },
    {
      title: 'Story/Bug with Tests Associated?',
      status: 'NON COMPLIANT',
      log: '[FAILED] No tests associated with the Jira',
      showLog: false
    },
    {
      title: 'Story/Bug Requirement Status is OK',
      status: 'NON COMPLIANT',
      log: '[FAILED] Requirement field shows UNCOVERED status',
      showLog: false
    },
    {
      title: 'Story/Bug has QA Peer Review Done',
      status: 'NON COMPLIANT',
      log: '[FAILED] Peer Review sub-task or test not available in the story',
      showLog: false
    }
  ];

  toggleLog(index: number) {
    this.complianceChecks[index].showLog = !this.complianceChecks[index].showLog;
  }

  isOverdue(dateStr: string): boolean {
    return new Date(dateStr) < new Date();
  }

  getFixEtaDisplay(fixEta: string): string {
    if (!fixEta) return '—';

    const today = new Date();
    const etaDate = new Date(fixEta);
    const diffMs = etaDate.getTime() - today.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    let symbol = '🟢';
    let label = `${diffDays} days left`;

    if (diffDays <= 0) {
      symbol = '🔴';
      label = `Overdue`;
    } else if (diffDays <= 1) {
      symbol = '🔴';
      label = `${diffDays} day left`;
    } else if (diffDays <= 2) {
      symbol = '🟠';
      label = `${diffDays} days left`;
    } else if (diffDays <= 5) {
      symbol = '🟡';
      label = `${diffDays} days left`;
    }

    return `${symbol} <span title="Fix due by ${fixEta}">${label}</span>`;
  }

  getSprintStatusSummary(row: any): string {
    const nonCompliant = row.nonCompliantCount || 0;
    const nigo = row.nigoTestCount || 0;
    const pendingAuto = row.automatablePending || 0;

    const summaryParts = [];

    if (nonCompliant > 0)
      summaryParts.push(`${nonCompliant} Non-Compliant stories`);
    if (nigo > 0)
      summaryParts.push(`${nigo} NIGO tests`);
    if (pendingAuto > 0)
      summaryParts.push(`${pendingAuto} to automate`);

    if (summaryParts.length === 0) {
      return row.sprintStatus === 'active'
        ? 'All metrics in good shape'
        : 'Sprint closed in good shape';
    }

    const prefix = row.sprintStatus === 'active' ? 'Fix' : 'Closed with';
    return `${prefix} ${summaryParts.join(', ')}`;
  }

  itemsPerPage: number = 10;
  currentPage: number = 1;

  get paginatedData(): any[] {
    const filtered = this.filteredTableData();
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return filtered.slice(start, end);
  }

  get totalPages(): number {
    return Math.ceil(this.filteredTableData().length / this.itemsPerPage);
  }

  goToPage(page: number) {
    this.currentPage = page;
  }

  reRunSprint(row: any): void {
    this.isLoadingModal = true;


    setTimeout(() => {
      if (row.sprintID === '587445662') {
        // ✅ Simulated successful re-run response
        const updatedSprint = {
          sprintName: '2025 Q2 S4 05/25',
          sprintStatus: 'active',
          sprintID: '587445662',
          sprintDate: '2025-05-30 23:10',
          boardName: 'FIT Unify Scrum Board',
          typeType: 'Scrum',
          totalStories: 10,
          testableStories: 8,
          compliantStories: 8,
          compliantStoriesPct: 100,
          testDeveloped: 20,
          autoDevPct: 100,
          testExecution: 30,
          autoExecutionPct: 100,
          nonCompliantCount: 0,
          nigoTestCount: 0,
          automatablePending: 0,
          testHealth: 90
        };

        // ✅ Update just that row
        const index = this.tableData.findIndex(item => item.sprintID === row.sprintID);
        if (index !== -1) {
          this.tableData[index] = { ...updatedSprint };
        }
        this.highlightRowId = updatedSprint.sprintID;
        setTimeout(() => {
          this.highlightRowId = null;
        }, 1500); // flash duration: 2 seconds

        this.toastList.push({
          id: Date.now(),
          type: 'success',
          message: `Sprint ${updatedSprint.sprintName} refreshed successfully.`
        });
      } else {
        // ❌ Simulated error
        this.toastList.push({
          id: Date.now(),
          type: 'error',
          message: `Failed to refresh sprint ${row.sprintName}. Please try again.`
        });
      }

      this.isLoadingModal = false;
    }, 1200);
  }

  //modal call:

  selectedSprint: any = null;
  isLoadingModal: boolean = false;
  modalError: string = '';

  isLoadingSprint: boolean = false;

  storyComplianceList: any[] = [];
  testDevelopmentList: any[] = [];
  showAllStories = false;



  viewSprintDetails(sprintID: string): void {
    this.isLoadingSprint = true;
    this.modalError = '';

    setTimeout(() => {
      if (sprintID === '587445662') {
        this.selectedSprint = {

          jiraProjectKey: 'FAIAI',
          boardName: 'FIT Tech Scrum Board',
          boardType: 'Scrum',
          typeType: 'Scrum',
          sprintName: '2025 Q2 S4 05/25',
          sprintID: '587445662',
          sprintDate: '2025-05-30 23:10',
          sprintStart: '2025-05-20',
          sprintEnd: '2025-05-30',
          sprintStatus: 'active',
          totalStories: 10,
          testableStories: 8,
          compliantStories: 8,
          compliantStoriesPct: 100,
          testDeveloped: 6,
          autoDevPct: 50,
          testExecution: 20,
          autoExecutionPct: 100,
          testHealth: 50,
          pipelineStatus: 'TBD',
          storyComplianceList: [
            {
              storyID: 'JIRA-1234',
              testable: 'Yes',
              testLinked: 5,
              status: 'Non-Compliant',
              issue: 'Missing test linkage, No automation tag',
              link: 'https://jira.com/browse/JIRA-1234'
            },
            {
              storyID: 'JIRA-1255',
              testable: 'Yes',
              testLinked: 10,
              status: 'Non-Compliant',
              issue: 'No automation tag',
              link: 'https://jira.com/browse/JIRA-1255'
            },
            {
              storyID: 'JIRA-1300',
              testable: 'Yes',
              testLinked: 1,
              status: 'Compliant',
              issue: 'All OK',
              link: 'https://jira.com/browse/JIRA-1300'
            },
            {
              storyID: 'JIRA-1301',
              testable: 'No',
              testLinked: 0,
              status: 'Compliant',
              issue: 'All OK',
              link: 'https://jira.com/browse/JIRA-1301'
            }
          ],
          testDevelopmentList: [
            {
              testID: 'TC-1001',
              type: 'Automated',
              automationStatus: 'Automation Complete',
              igoStatus: 'IGO',
                completedOn: '2024-04-15',
              issue: ''
            },
            {
              testID: 'TC-1002',
              type: 'Manual',
              automationStatus: 'To Be Automated',
              igoStatus: 'NIGO',
                completedOn: '2024-04-15',
              issue: 'Test not automated, Not in IGO'
            },
            {
              testID: 'TC-1003',
              type: 'Manual',
              automationStatus: 'Cannot Automate',
              igoStatus: 'IGO',
               completedOn: '2024-04-15',
              issue: ''
            },
            {
              testID: 'TC-1004',
              type: 'Automated',
              automationStatus: 'Blank',
              igoStatus: 'NIGO',
              issue: 'Missing automation status, Not in IGO'
            },
            {
              testID: 'TC-1005',
              type: 'Automated',
                completedOn: '2024-04-15',
              automationStatus: 'Automation Complete',
              igoStatus: 'IGO',
              issue: ''
            }
          ]
        };

        // ✅ Assign lists for tables to work
        this.storyComplianceList = this.selectedSprint.storyComplianceList;
        this.testDevelopmentList = this.selectedSprint.testDevelopmentList;

        const hasStoryAlerts = this.storyComplianceList.some(s => s.status === 'Non-Compliant');
        const hasTestAlerts = this.testDevelopmentList.some(t =>
          ['NIGO', 'To Be Automated', 'Blank'].includes(t.igoStatus || t.automationStatus)
        );

        if (hasStoryAlerts) {
          this.isStoryOpen = true;
          this.isTestOpen = false;
        } else if (hasTestAlerts) {
          this.isStoryOpen = false;
          this.isTestOpen = true;
        } else {
          this.isStoryOpen = false;
          this.isTestOpen = false;
        }

        this.isLoadingSprint = false;
        this.showModal = true;
      } else {
        this.isLoadingSprint = false;
        this.toastList.push({
          id: Date.now(),
          type: 'error',
          message: 'Failed to load sprint details. Please try again.'
        });
      }
    }, 100);
  }

  filteredStoryCompliance() {
    const hasActionables = this.storyComplianceList.some(s => s.status === 'Non-Compliant');
    return !hasActionables || this.showAllStories
      ? this.storyComplianceList
      : this.storyComplianceList.filter(s => s.status === 'Non-Compliant');
  }


  copyToClipboardTest(testId: string) {
    navigator.clipboard.writeText(testId).then(() => {
      this.toastList.push({
        id: Date.now(),
        type: 'success',
        message: `Copied Test ID: ${testId}`
      });
    });
  }

  isStoryOpen = true;
  isTestOpen = true;

  get storyAlertCount() {
    return this.storyComplianceList.filter(i => i.status === 'Non-Compliant').length;
  }

  get testAlertCount() {
    return this.testDevelopmentList.filter(i => i.igoStatus === 'NIGO' || i.automationStatus === 'To Be Automated' || i.automationStatus === 'Blank').length;
  }

  get etaDisplay(): string {
    if (!this.selectedSprint?.sprintEnd) return '';

    const today = new Date();
    const endDate = new Date(this.selectedSprint.sprintEnd);
    const diffMs = endDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays >= 0) {
      return `ETA: ${this.selectedSprint.sprintEnd} – ${diffDays} day${diffDays !== 1 ? 's' : ''} remaining`;
    } else {
      return `⚠️ Sprint overdue by ${Math.abs(diffDays)} day${Math.abs(diffDays) !== 1 ? 's' : ''}`;
    }
  }

  copyTestIdsToClipboard() {
    const ids = this.testDevelopmentList.map(t => t.testID).join(', ');
    navigator.clipboard.writeText(ids);
  }

  copyTestSummary() {
    const summary = JSON.stringify(this.testSummary, null, 2);
    navigator.clipboard.writeText(summary);
  }

get testSummary() {
  const total = this.testDevelopmentList.length;

  const automated = this.testDevelopmentList.filter(t => t.type === 'Automated').length;

  const toAutomate = this.testDevelopmentList.filter(t => t.automationStatus === 'To Be Automated').length;
  const cannotAutomate = this.testDevelopmentList.filter(t => t.automationStatus === 'Cannot Automate').length;

  const autoDevPct = total > 0 ? Math.round((automated / total) * 100) : 0;

const manual = this.testDevelopmentList.filter(t => t.type === 'Manual').length;

const execTotal = this.selectedSprint?.testExecution || 0;
const execAuto = execTotal * (this.selectedSprint?.autoExecutionPct || 0) / 100;
const execManual = execTotal - execAuto;
const execAutoPct = execTotal > 0 ? Math.round((execAuto / execTotal) * 100) : 0;

const igoMap = {
  total: this.testDevelopmentList.filter(t => t.igoStatus === 'IGO').length,
  automated: this.testDevelopmentList.filter(t => t.type === 'Automated' && t.igoStatus === 'IGO').length,
  cannotAutomate: this.testDevelopmentList.filter(t => t.automationStatus === 'Cannot Automate' && t.igoStatus === 'IGO').length,
  toAutomate: this.testDevelopmentList.filter(t => t.automationStatus === 'To Be Automated' && t.igoStatus === 'IGO').length,
  manualTotal: this.testDevelopmentList.filter(t => t.type === 'Manual' && t.igoStatus === 'IGO').length,
};

  const igoTotal = igoMap.automated + igoMap.toAutomate + igoMap.cannotAutomate;
  const autoIgoPct = total > 0 ? Math.round((igoTotal / total) * 100) : 0;

  return {
  total,
  manual,
  automated,
  toAutomate,
  cannotAutomate,
  autoDevPct,
  autoIgoPct,
  igoMap,
  execTotal,
  execAuto,
  execManual,
  execAutoPct
};
}

get remainingDays(): number {
  const today = new Date();
  const end = new Date(this.selectedSprint?.sprintEnd);
  const diff = Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff : 0;
}

getIgoClass(igo: number, total: number): string {
  if (igo < total) return 'igo-warning';
  return 'igo-ok';
}

downloadModalAsPDF(): void {
  const modal = this.sprintModal.nativeElement;

  // Temporarily disable scroll and height limit
  const originalOverflow = modal.style.overflow;
  const originalHeight = modal.style.maxHeight;

  modal.style.overflow = 'visible';
  modal.style.maxHeight = 'none';

  html2canvas(modal, { scale: 2 }).then(canvas => {
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgWidth = 210;
    const pageHeight = 297;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    pdf.save('SprintSummary.pdf');

    // Restore original styles
    modal.style.overflow = originalOverflow;
    modal.style.maxHeight = originalHeight;
  });
}

}



