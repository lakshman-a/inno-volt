import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeComplianceComponent } from './change-compliance.component';

describe('ChangeComplianceComponent', () => {
  let component: ChangeComplianceComponent;
  let fixture: ComponentFixture<ChangeComplianceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangeComplianceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChangeComplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
