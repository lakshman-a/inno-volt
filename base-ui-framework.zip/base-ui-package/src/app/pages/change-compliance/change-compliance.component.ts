import { ChangeDetectorRef, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-compliance',
  templateUrl: './change-compliance.component.html',
  styleUrls: ['./change-compliance.component.css']
})
export class ChangeComplianceComponent implements OnInit {

  tableData: any[] = [];
  searchText: string = '';
  sortKey: string = '';
  sortAsc: boolean = true;

  userInput: string = '';
  startDate: string = '';
  endDate: string = '';

  loading: boolean = false;
  responseState: 'success' | 'no-data' | 'error' | '' = '';
  apiErrorMessage: string = '';

  highlightTable: boolean = false;

  firstLoadSortApplied: boolean = false;

  constructor(private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.cdr.detectChanges();
    this.setMode('Ticket'); // 👈 explicitly call your setter to trigger label/render correctly
  }

  selectedMode: 'Ticket' | 'Group' | 'Planned' = 'Ticket';

  currentDate: string = new Date().toISOString().split('T')[0];
  minProjectStartDate: string = new Date(Date.now() - 20 * 24 * 60 * 60 * 1000)
    .toISOString()
    .split('T')[0];

  setMode(mode: 'Ticket' | 'Group' | 'Planned') {
    this.selectedMode = mode;
    this.resetForm();
  }

  onSubmitForm() {

    if (this.selectedMode !== 'Ticket') {
      const start = new Date(this.startDate);
      const end = new Date(this.endDate);

      if (!this.startDate || !this.endDate) {
        this.showToast('Please select both start and end dates.', 'warning');
        return;
      }

      if (start > end) {
        this.showToast('End date cannot be before start date.', 'error');
        return;
      }

      const diffDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 3600 * 24));
      if (diffDays > this.maxWindowDays) {
        this.showToast(`Date range cannot exceed ${this.maxWindowDays} days.`, 'error');
        return;
      }
    }


    this.loading = true;
    this.apiErrorMessage = '';
    this.tableData = [];
    this.responseState = '';
    // this.firstLoadSortApplied = true;
    this.resetSortState();

    const payload = {
      mode: this.selectedMode,
      userInput: this.userInput,
      start: this.startDate,
      end: this.endDate
    };

    console.log('Submitted Payload:', payload);



    // Simulated async API call
    this.callApi(payload)
      .then((response) => {
        this.showToast('✅ Data fetched successfully!', 'success');
        this.loading = false;

        if (response.status === 200) {
          if (response.data.length === 0) {
            this.showToast('⚠️ No records found for your criteria.', 'warning');
            this.responseState = 'no-data';
          } else {
            this.tableData = response.data;
            this.responseState = 'success';

            // Trigger green border flash
            this.highlightTable = true;
            setTimeout(() => (this.highlightTable = false), 1000);

            // Focus on table view
            setTimeout(() => {
              const table = document.getElementById('table-section');
              table?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          }
        }
      })
      .catch((error) => {
        this.showToast('❌ API call failed. Please try again.', 'error');
        this.loading = false;
        if (error.status === 400) {
          this.apiErrorMessage = error.message || 'Bad Request';
          this.responseState = 'error';
        } else if (error.status === 500) {
          this.apiErrorMessage =
            'Oops! Something went wrong. Please contact the admin team.';
          this.responseState = 'error';
        }
      });
  }

  callApi(payload: any): Promise<any> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (payload.userInput.includes('500')) {
          reject({ status: 500 });
        } else if (payload.userInput.includes('400')) {
          reject({ status: 400, message: 'Invalid Jira Key format' });
        } else if (payload.userInput.includes('empty')) {
          resolve({ status: 200, data: [] });
        } else {
          resolve({
            status: 200,
            data: [{
              changeTicket: 'CM124000',
              plannedStartDate: '2025-05-25',
              daysToRelease: 2,
              ticketStatus: 'Active',
              complianceStatus: 'NON COMPLIANT',
              testingCTASK: 'CT1112223',
              ctaskState: 'Assigned',
              qaAssignmentGroup: 'QA-PLATFORM',
              qaAssignedTo: 'Rahul M',
              totalTests: 5,
              totalStories: 1,
              eta: '2 days left',
              isOverdue: false
            },
            {
              changeTicket: 'CM124001',
              plannedStartDate: '2025-05-15',
              daysToRelease: -5,
              ticketStatus: 'Closed',
              complianceStatus: 'COMPLIANT',
              testingCTASK: 'CT1112224',
              ctaskState: 'Closed Complete',
              qaAssignmentGroup: 'QA-OPS',
              qaAssignedTo: 'Meera K',
              totalTests: 10,
              totalStories: 3,
              eta: '5 days overdue',
              isOverdue: true
            },
            {
              changeTicket: 'CM124002',
              plannedStartDate: '2025-05-28',
              daysToRelease: 5,
              ticketStatus: 'Scheduled',
              complianceStatus: 'PENDING',
              testingCTASK: 'CT1112225',
              ctaskState: 'Open',
              qaAssignmentGroup: 'QA-CORE',
              qaAssignedTo: 'Sanjay D',
              totalTests: 8,
              totalStories: 2,
              eta: '5 days left',
              isOverdue: false
            },
            {
              changeTicket: 'CM124003',
              plannedStartDate: '2025-05-10',
              daysToRelease: -10,
              ticketStatus: 'Closed',
              complianceStatus: 'NON COMPLIANT',
              testingCTASK: 'CT1112226',
              ctaskState: 'Assigned',
              qaAssignmentGroup: 'QA-PLATFORM',
              qaAssignedTo: 'Anjali V',
              totalTests: 6,
              totalStories: 2,
              eta: '10 days overdue',
              isOverdue: true
            },
            {
              changeTicket: 'CM124004',
              plannedStartDate: '2025-05-22',
              daysToRelease: -1,
              ticketStatus: 'In Progress',
              complianceStatus: 'EXCLUDED',
              testingCTASK: 'CT1112227',
              ctaskState: 'In Progress',
              qaAssignmentGroup: 'QA-APPS',
              qaAssignedTo: 'Suresh N',
              totalTests: 0,
              totalStories: 0,
              eta: '1 day overdue',
              isOverdue: true
            },
            {
              changeTicket: 'CM124005',
              plannedStartDate: '2025-05-29',
              daysToRelease: 6,
              ticketStatus: 'Scheduled',
              complianceStatus: 'COMPLIANT',
              testingCTASK: 'CT1112228',
              ctaskState: 'Open',
              qaAssignmentGroup: 'QA-OPS',
              qaAssignedTo: 'Priya G',
              totalTests: 12,
              totalStories: 4,
              eta: '6 days left',
              isOverdue: false
            },
            {
              changeTicket: 'CM124006',
              plannedStartDate: '2025-05-26',
              daysToRelease: 3,
              ticketStatus: 'Pending Approval',
              complianceStatus: 'NON COMPLIANT',
              testingCTASK: 'CT1112229',
              ctaskState: 'Assigned',
              qaAssignmentGroup: 'QA-PLATFORM',
              qaAssignedTo: 'Vikram L',
              totalTests: 7,
              totalStories: 3,
              eta: '3 days left',
              isOverdue: false
            },
            {
              changeTicket: 'CM124007',
              plannedStartDate: '2025-05-12',
              daysToRelease: -8,
              ticketStatus: 'Completed',
              complianceStatus: 'COMPLIANT',
              testingCTASK: 'CT1112230',
              ctaskState: 'Closed Complete',
              qaAssignmentGroup: 'QA-CORE',
              qaAssignedTo: 'Neha S',
              totalTests: 6,
              totalStories: 2,
              eta: '8 days overdue',
              isOverdue: true
            },
            {
              changeTicket: 'CM124008',
              plannedStartDate: '2025-05-24',
              daysToRelease: 1,
              ticketStatus: 'Active',
              complianceStatus: 'PENDING',
              testingCTASK: 'CT1112231',
              ctaskState: 'Assigned',
              qaAssignmentGroup: 'QA-PLATFORM',
              qaAssignedTo: 'Arjun R',
              totalTests: 4,
              totalStories: 1,
              eta: '1 day left',
              isOverdue: false
            },
            {
              changeTicket: 'CM124009',
              plannedStartDate: '2025-05-13',
              daysToRelease: -7,
              ticketStatus: 'Cancelled',
              complianceStatus: 'NON COMPLIANT',
              testingCTASK: 'CT1112232',
              ctaskState: 'Rejected',
              qaAssignmentGroup: 'QA-OPS',
              qaAssignedTo: 'Bhavya I',
              totalTests: 2,
              totalStories: 1,
              eta: '7 days overdue',
              isOverdue: true
            },
            {
              changeTicket: 'CM124010',
              plannedStartDate: '2025-05-27',
              daysToRelease: 4,
              ticketStatus: 'Pending',
              complianceStatus: 'EXCLUDED',
              testingCTASK: 'CT1112233',
              ctaskState: 'Pending',
              qaAssignmentGroup: 'QA-PLATFORM',
              qaAssignedTo: 'Lakshman A',
              totalTests: 0,
              totalStories: 0,
              eta: '4 days left',
              isOverdue: false
            },
            {
              changeTicket: 'CM124011',
              plannedStartDate: '2025-05-23',
              daysToRelease: 0,
              ticketStatus: 'In Progress',
              complianceStatus: 'NON COMPLIANT',
              testingCTASK: 'CT1112234',
              ctaskState: 'Assigned',
              qaAssignmentGroup: 'QA-PLATFORM',
              qaAssignedTo: 'Lakshman A',
              totalTests: 3,
              totalStories: 1,
              eta: 'Today',
              isOverdue: false
            }

            ],
          });
        }
      }, 2000);
    });
  }

  filteredTableData() {
    let data = this.tableData;

    // 🔁 Apply compliance filter first
    if (this.complianceFilter) {
      data = data.filter(row =>
        row.compliance?.toLowerCase() === this.complianceFilter.toLowerCase()
      );
    }

    // 🔍 Then apply search text
    data = data.filter(item =>
      Object.values(item as Record<string, any>).some(val =>
        val?.toString().toLowerCase().includes(this.searchText.toLowerCase())
      )
    );

    // ✅ Sort by compliance priority if no sort key is selected
    if (!this.sortKey) {
      const priority = ['non-compliant', 'non compliant', 'compliant', 'excluded', 'manual', 'pending'];
      data.sort((a, b) => {
        const aValue = a.compliance?.toLowerCase() || '';
        const bValue = b.compliance?.toLowerCase() || '';
        const aIndex = priority.indexOf(aValue);
        const bIndex = priority.indexOf(bValue);
        return (aIndex === -1 ? priority.length : aIndex) - (bIndex === -1 ? priority.length : bIndex);
      });
      return data;
    }

    // 🔁 Apply sort by column
    return data.sort((a, b) => {
      const valA = a[this.sortKey] ?? '';
      const valB = b[this.sortKey] ?? '';
      return this.sortAsc
        ? valA.toString().localeCompare(valB.toString())
        : valB.toString().localeCompare(valA.toString());
    });
  }

  sortTable(column: string) {
    if (this.sortKey === column) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortKey = column;
      this.sortAsc = true;
    }
  }

  sortBy(column: string) {
    if (this.sortKey === column) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortKey = column;
      this.sortAsc = true;
    }
  }

  resetSortState() {
    this.sortKey = '';
    this.sortAsc = true;
  }

  downloadTable() {
    const headers = Object.keys(this.tableData[0] || {});
    const rows = this.tableData.map((row) =>
      headers.map((field) => `"${row[field] || ''}"`).join(',')
    );
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', 'jira_compliance_results.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  resetForm() {
    if (this.tableData.length > 0) {
      const confirmReset = confirm(
        'Resetting will clear the table data. Do you want to proceed?'
      );
      if (!confirmReset) return;
    }

    this.userInput = '';
    this.startDate = '';
    this.endDate = '';
    this.searchText = '';
    this.tableData = [];
  }

  getBadgeClass(compliance: string): string {
    switch (compliance.toLowerCase()) {
      case 'compliant':
        return 'badge badge-success';
      case 'non compliant':
      case 'non-compliant':
        return 'badge badge-danger';
      case 'excluded':
        return 'badge badge-grey';
      default:
        return 'badge badge-info';
    }
  }

  getJiraLink(issueKey: string): string {
    return `https://your-jira-instance/browse/${issueKey}`;
  }

  complianceFilter: string = '';

  countByStatus(status: string): number {
    return this.filteredTableData().filter(
      row => row.compliance?.toLowerCase() === status.toLowerCase()
    ).length;
  }

  filterByCompliance(status: string) {
    this.complianceFilter = status;
  }

  resetComplianceFilter() {
    this.complianceFilter = '';
  }


  isActionable(compliance: string): boolean {
    return ['non-compliant', 'pending', 'manual'].includes(compliance?.toLowerCase());
  }

  getActionIcon(compliance: string): string {
    const lower = compliance?.toLowerCase();
    // if (lower === 'non-compliant') return '🔥';
    if (lower === 'non-compliant') return '⚠️';
    if (lower === 'pending' || lower === 'manual') return '❗';
    return '';
  }

  getActionMessage(compliance: string, failReasons: string[] = []): string {
    const lower = compliance?.toLowerCase();

    if (lower === 'non-compliant') {
      const reasons = failReasons.length
        ? failReasons.map(reason => `- ${reason}`).join('\n')
        : '- Unknown issue';

      return `Action Required\nFix needed:\n${reasons}`;
    }

    if (lower === 'pending') return 'Pending Review';
    if (lower === 'manual') return 'Manual Verification Needed';

    return '';
  }

  formatFailReasons(reasons: string[] = []): string {
    if (!reasons.length) return 'Click to view compliance details';
    return 'Fixes needed:\n- ' + reasons.join('\n- ');
  }

  showModal = false;
  selectedRow: any = null;

  openModal(row: any) {
    this.selectedRow = row;
    this.showModal = true;
  }

  closeModal() {
    this.showModal = false;
  }

  complianceChecks = [
    {
      title: 'Story/Bug has Valid Fix Version?',
      status: 'COMPLIANT',
      log: '[PASSED] Fix version found: FIAIA 25.05.01',
      showLog: false
    },
    {
      title: 'Story/Bug with Acceptance Criteria?',
      status: 'COMPLIANT',
      log: '[PASSED] Acceptance criteria filled: 484 characters',
      showLog: false
    },
    {
      title: 'Story/Bug with Tests Associated?',
      status: 'NON COMPLIANT',
      log: '[FAILED] No tests associated with the Jira',
      showLog: false
    },
    {
      title: 'Story/Bug Requirement Status is OK',
      status: 'NON COMPLIANT',
      log: '[FAILED] Requirement field shows UNCOVERED status',
      showLog: false
    },
    {
      title: 'Story/Bug has QA Peer Review Done',
      status: 'NON COMPLIANT',
      log: '[FAILED] Peer Review sub-task or test not available in the story',
      showLog: false
    }
  ];

  toggleLog(index: number) {
    this.complianceChecks[index].showLog = !this.complianceChecks[index].showLog;
  }

  isOverdue(dateStr: string): boolean {
    return new Date(dateStr) < new Date();
  }

  getFixEtaDisplay(fixEta: string): string {
    if (!fixEta) return '—';

    const today = new Date();
    const etaDate = new Date(fixEta);
    const diffMs = etaDate.getTime() - today.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    let symbol = '🟢';
    let label = `${diffDays} days left`;

    if (diffDays <= 0) {
      symbol = '🔴';
      label = `Overdue`;
    } else if (diffDays <= 1) {
      symbol = '🔴';
      label = `${diffDays} day left`;
    } else if (diffDays <= 2) {
      symbol = '🟠';
      label = `${diffDays} days left`;
    } else if (diffDays <= 5) {
      symbol = '🟡';
      label = `${diffDays} days left`;
    }

    return `${symbol} <span title="Fix due by ${fixEta}">${label}</span>`;
  }

  itemsPerPage: number = 10;
  currentPage: number = 1;

  get paginatedData(): any[] {
    const filtered = this.filteredTableData();
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return filtered.slice(start, end);
  }

  get totalPages(): number {
    return Math.ceil(this.filteredTableData().length / this.itemsPerPage);
  }

  goToPage(page: number) {
    this.currentPage = page;
  }

  toastMessage: string = '';
  toastVisible: boolean = false;
  toastType: 'success' | 'error' | 'warning' = 'success';

  showToast(message: string, type: 'success' | 'error' | 'warning' = 'success') {
    this.toastMessage = message;
    this.toastType = type;
    this.toastVisible = true;
    setTimeout(() => {
      this.toastVisible = false;
    }, 3000);
  }

  maxWindowDays = 10; // Max allowed range between start and end
  minDateOffset = 10; // How far back user can go (in days)
  maxDateOffset = 10;  // How far ahead user can go (in days)

  get minSelectableDate(): string {
    const date = new Date();
    date.setDate(date.getDate() - this.minDateOffset);
    return date.toISOString().split('T')[0];
  }

  get maxSelectableDate(): string {
    const date = new Date();
    date.setDate(date.getDate() + this.maxDateOffset);
    return date.toISOString().split('T')[0];
  }

  getActionItemsCount(): number {
    return this.filteredTableData().filter(
      item => item.complianceStatus === 'NON COMPLIANT'
    ).length;
  }

  getComplianceBadgeClass(status: string): string {
    switch (status.toUpperCase()) {
      case 'NON COMPLIANT':
        return 'badge badge-danger';
      case 'EXCLUDED':
        return 'badge badge-grey';
      case 'COMPLIANT':
        return 'badge badge-success';
      default:
        return 'badge badge-grey';
    }
  }

  getCmTicketLink(ticket: string): string {
    return `https://your-link-to-cm-system/${ticket}`;
  }

  getCtaskLink(ctask: string): string {
    return `https://your-link-to-ctask-system/${ctask}`;
  }

  getDateDelta(days: number): string {
  if (days === 0) return 'today';
  return days > 0 ? `in ${days} days` : `past ${Math.abs(days)} days`;
}

showCtaskColumns: boolean = false;

getComplianceClass(status: string): string {
  switch (status.toUpperCase()) {
    case 'NON COMPLIANT': return 'badge-status badge-danger';
    case 'COMPLIANT': return 'badge-status badge-success';
    case 'PENDING': return 'badge-status badge-info';
    default: return 'badge-status';
  }
}

  // Mock API
  fakeApiCall(payload: any): Promise<any[]> {
    return Promise.resolve([
      {
        issueKey: 'FIAIA-123',
        summary: 'Fix login bug',
        status: 'Done',
        fv: 'Yes',
        testable: 'Yes',
        compliance: 'Compliant',
      },
      {
        issueKey: 'FIAIA-124',
        summary: 'Add logout button',
        status: 'In Progress',
        fv: 'No',
        testable: 'Yes',
        compliance: 'Non-Compliant',
      },
    ]);
  }
}
