import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-story-compliance',
  templateUrl: './story-compliance.component.html',
  styleUrls: ['./story-compliance.component.css']
})
export class StoryComplianceComponent implements OnInit {

tableData: any[] = [];
  searchText: string = '';
  sortKey: string = '';
  sortAsc: boolean = true;

  userInput: string = '';
  startDate: string = '';
  endDate: string = '';

  loading: boolean = false;
  responseState: 'success' | 'no-data' | 'error' | '' = '';
  apiErrorMessage: string = '';

  highlightTable: boolean = false;

  firstLoadSortApplied: boolean = false;

  constructor() {}

  ngOnInit(): void {}

  selectedMode: 'Project' | 'Issues' = 'Project';
  currentDate: string = new Date().toISOString().split('T')[0];
  minProjectStartDate: string = new Date(Date.now() - 20 * 24 * 60 * 60 * 1000)
    .toISOString()
    .split('T')[0];

  setMode(mode: 'Project' | 'Issues') {
    this.selectedMode = mode;
  }

  onSubmitForm() {
    this.loading = true;
    this.apiErrorMessage = '';
    this.tableData = [];
    this.responseState = '';
    // this.firstLoadSortApplied = true;
     this.resetSortState();

    const payload = {
      mode: this.selectedMode,
      userInput: this.userInput,
      startDate: this.selectedMode === 'Project' ? this.startDate : null,
      endDate: this.selectedMode === 'Project' ? this.endDate : null,
    };

    console.log('Submitted Payload:', payload);

    // Simulated async API call
    this.callApi(payload)
      .then((response) => {
       this.showToast('✅ Data fetched successfully!', 'success');
        this.loading = false;

        if (response.status === 200) {
          if (response.data.length === 0) {
            this.showToast('⚠️ No records found for your criteria.', 'warning');
            this.responseState = 'no-data';
          } else {
            this.tableData = response.data;
            this.responseState = 'success';

            // Trigger green border flash
            this.highlightTable = true;
            setTimeout(() => (this.highlightTable = false), 1000);

            // Focus on table view
            setTimeout(() => {
              const table = document.getElementById('table-section');
              table?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          }
        }
      })
      .catch((error) => {
     this.showToast('❌ API call failed. Please try again.', 'error');
        this.loading = false;
        if (error.status === 400) {
          this.apiErrorMessage = error.message || 'Bad Request';
          this.responseState = 'error';
        } else if (error.status === 500) {
          this.apiErrorMessage =
            'Oops! Something went wrong. Please contact the admin team.';
          this.responseState = 'error';
        }
      });
  }

  callApi(payload: any): Promise<any> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (payload.userInput.includes('500')) {
          reject({ status: 500 });
        } else if (payload.userInput.includes('400')) {
          reject({ status: 400, message: 'Invalid Jira Key format' });
        } else if (payload.userInput.includes('empty')) {
          resolve({ status: 200, data: [] });
        } else {
          resolve({
            status: 200,
            data: [
              {
                issueKey: 'FIAIA-123',
                summary: 'Fix login bug',
                status: 'Done',
                fv: 'Yes',
                testable: 'Yes',
                compliance: 'Compliant',
              },
              {
                issueKey: 'FIAIA-124',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'Yes',
                  fixEta: '2025-05-25',
                compliance: 'Non-Compliant',
                 failReasons: [
    'Missing Fix Version',
    'No Acceptance Criteria',
    'Tests not linked'
  ]
              },
              {
                issueKey: 'FIAIA-125',
                summary: 'Add logout',
                status: 'Done',
                fv: 'No',
                testable: 'Yes',
                compliance: 'Manual',
              },
              {
                issueKey: 'FIAIA-121',
                summary: 'Add logout',
                status: 'Done',
                fv: 'No',
                testable: 'Yes',
                 fixEta: '2025-05-22',
                compliance: 'Compliant',
              },
              {
                issueKey: 'FIAIA-127',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'Yes',
                compliance: 'Compliant',
              },
              {
                issueKey: 'FIAIA-126',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'Yes',
                fixEta: '2025-05-18',
                compliance: 'Non-Compliant',
                 failReasons: [
    'Missing Fix Version',
    'No Acceptance Criteria',
    'Tests not linked'
  ]
              },
              {
                issueKey: 'FIAIA-120',
                summary: 'Add logout',
                status: 'To-Do',
                fv: 'No',
                testable: 'Yes',
                fixEta: '2025-05-22',
                compliance: 'Non-Compliant',
                 failReasons: [
    'Missing Fix Version',
    'No Acceptance Criteria',
    'Tests not linked'
  ]
              },
              {
                issueKey: 'FIAIA-129',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'Yes',
                 fixEta: '2025-05-25',
                compliance: 'Pending',
              },
              {
                issueKey: 'FIAIA-132',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'No',
                 fixEta: '2025-05-23',
                compliance: 'Excluded',
              },
              {
                issueKey: 'FIAIA-130',
                summary: 'Add logout',
                status: 'Done',
                fv: 'No',
                testable: 'No',
                 fixEta: '2025-05-22',
                compliance: 'Excluded',
              },
              
               {
                issueKey: 'FIAIA-127',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'Yes',
                compliance: 'Compliant',
              },
              {
                issueKey: 'FIAIA-626',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'Yes',
                fixEta: '2025-05-18',
                compliance: 'Non-Compliant',
                 failReasons: [
    'Missing Fix Version',
    'No Acceptance Criteria',
    'Tests not linked'
  ]
              },
              {
                issueKey: 'FIAIA-220',
                summary: 'Add logout',
                status: 'To-Do',
                fv: 'No',
                testable: 'Yes',
                fixEta: '2025-05-22',
                compliance: 'Non-Compliant',
                 failReasons: [
    'Missing Fix Version',
    'No Acceptance Criteria',
    'Tests not linked'
  ]
              },
              {
                issueKey: 'FIAIA-29',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'Yes',
                 fixEta: '2025-05-25',
                compliance: 'Pending',
              },
              {
                issueKey: 'FIAIA-332',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'No',
                 fixEta: '2025-05-23',
                compliance: 'Excluded',
              },
              
              {
                issueKey: 'FIAIA-1132',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'No',
                 fixEta: '2025-05-23',
                compliance: 'Excluded',
              },
              {
                issueKey: 'FIAIA-1230',
                summary: 'Add logout',
                status: 'Done',
                fv: 'No',
                testable: 'No',
                 fixEta: '2025-05-22',
                compliance: 'Excluded',
              },
              
               {
                issueKey: 'FIAIA-1237',
                summary: 'Add logout',
                status: 'In Progress',
                fv: 'No',
                testable: 'Yes',
                compliance: 'Compliant',
              }

            ],
          });
        }
      }, 2000);
    });
  }

filteredTableData() {
  let data = this.tableData;

  // 🔁 Apply compliance filter first
  if (this.complianceFilter) {
    data = data.filter(row =>
      row.compliance?.toLowerCase() === this.complianceFilter.toLowerCase()
    );
  }

  // 🔍 Then apply search text
  data = data.filter(item =>
    Object.values(item as Record<string, any>).some(val =>
      val?.toString().toLowerCase().includes(this.searchText.toLowerCase())
    )
  );

  // ✅ Sort by compliance priority if no sort key is selected
  if (!this.sortKey) {
    const priority = ['non-compliant', 'non compliant', 'compliant', 'excluded', 'manual', 'pending'];
    data.sort((a, b) => {
      const aValue = a.compliance?.toLowerCase() || '';
      const bValue = b.compliance?.toLowerCase() || '';
      const aIndex = priority.indexOf(aValue);
      const bIndex = priority.indexOf(bValue);
      return (aIndex === -1 ? priority.length : aIndex) - (bIndex === -1 ? priority.length : bIndex);
    });
    return data;
  }

  // 🔁 Apply sort by column
  return data.sort((a, b) => {
    const valA = a[this.sortKey] ?? '';
    const valB = b[this.sortKey] ?? '';
    return this.sortAsc
      ? valA.toString().localeCompare(valB.toString())
      : valB.toString().localeCompare(valA.toString());
  });
}

  sortTable(column: string) {
    if (this.sortKey === column) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortKey = column;
      this.sortAsc = true;
    }
  }

  sortBy(column: string) {
  if (this.sortKey === column) {
    this.sortAsc = !this.sortAsc;
  } else {
    this.sortKey = column;
    this.sortAsc = true;
  }
}

resetSortState() {
  this.sortKey = '';
  this.sortAsc = true;
}

  downloadTable() {
    const headers = Object.keys(this.tableData[0] || {});
    const rows = this.tableData.map((row) =>
      headers.map((field) => `"${row[field] || ''}"`).join(',')
    );
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', 'jira_compliance_results.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  resetForm() {
    if (this.tableData.length > 0) {
      const confirmReset = confirm(
        'Resetting will clear the table data. Do you want to proceed?'
      );
      if (!confirmReset) return;
    }

    this.userInput = '';
    this.startDate = '';
    this.endDate = '';
    this.searchText = '';
    this.tableData = [];
  }

  getBadgeClass(compliance: string): string {
    switch (compliance.toLowerCase()) {
      case 'compliant':
        return 'badge badge-success';
      case 'non compliant':
      case 'non-compliant':
        return 'badge badge-danger';
      case 'excluded':
        return 'badge badge-grey';
      default:
        return 'badge badge-info';
    }
  }

  getJiraLink(issueKey: string): string {
    return `https://your-jira-instance/browse/${issueKey}`;
  }


  complianceFilter: string = '';

countByStatus(status: string): number {
  return this.filteredTableData().filter(
    row => row.compliance?.toLowerCase() === status.toLowerCase()
  ).length;
}

filterByCompliance(status: string) {
  this.complianceFilter = status;
}

resetComplianceFilter() {
  this.complianceFilter = '';
}


isActionable(compliance: string): boolean {
  return ['non-compliant', 'pending', 'manual'].includes(compliance?.toLowerCase());
}

getActionIcon(compliance: string): string {
  const lower = compliance?.toLowerCase();
  // if (lower === 'non-compliant') return '🔥';
    if (lower === 'non-compliant') return '⚠️';
  if (lower === 'pending' || lower === 'manual') return '❗';
  return '';
}

getActionMessage(compliance: string, failReasons: string[] = []): string {
  const lower = compliance?.toLowerCase();

  if (lower === 'non-compliant') {
    const reasons = failReasons.length
      ? failReasons.map(reason => `- ${reason}`).join('\n')
      : '- Unknown issue';

    return `Action Required\nFix needed:\n${reasons}`;
  }

  if (lower === 'pending') return 'Pending Review';
  if (lower === 'manual') return 'Manual Verification Needed';

  return '';
}

formatFailReasons(reasons: string[] = []): string {
  if (!reasons.length) return 'Click to view compliance details';
  return 'Fixes needed:\n- ' + reasons.join('\n- ');
}

showModal = false;
selectedRow: any = null;

openModal(row: any) {
  this.selectedRow = row;
  this.showModal = true;
}

closeModal() {
  this.showModal = false;
}

complianceChecks = [
  {
    title: 'Story/Bug has Valid Fix Version?',
    status: 'COMPLIANT',
    log: '[PASSED] Fix version found: FIAIA 25.05.01',
    showLog: false
  },
  {
    title: 'Story/Bug with Acceptance Criteria?',
    status: 'COMPLIANT',
    log: '[PASSED] Acceptance criteria filled: 484 characters',
    showLog: false
  },
  {
    title: 'Story/Bug with Tests Associated?',
    status: 'NON COMPLIANT',
    log: '[FAILED] No tests associated with the Jira',
    showLog: false
  },
  {
    title: 'Story/Bug Requirement Status is OK',
    status: 'NON COMPLIANT',
    log: '[FAILED] Requirement field shows UNCOVERED status',
    showLog: false
  },
  {
    title: 'Story/Bug has QA Peer Review Done',
    status: 'NON COMPLIANT',
    log: '[FAILED] Peer Review sub-task or test not available in the story',
    showLog: false
  }
];

toggleLog(index: number) {
  this.complianceChecks[index].showLog = !this.complianceChecks[index].showLog;
}

isOverdue(dateStr: string): boolean {
  return new Date(dateStr) < new Date();
}

getFixEtaDisplay(fixEta: string): string {
  if (!fixEta) return '—';

  const today = new Date();
  const etaDate = new Date(fixEta);
  const diffMs = etaDate.getTime() - today.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  let symbol = '🟢';
  let label = `${diffDays} days left`;

  if (diffDays <= 0) {
    symbol = '🔴';
    label = `Overdue`;
  } else if (diffDays <= 1) {
    symbol = '🔴';
    label = `${diffDays} day left`;
  } else if (diffDays <= 2) {
    symbol = '🟠';
    label = `${diffDays} days left`;
  } else if (diffDays <= 5) {
    symbol = '🟡';
    label = `${diffDays} days left`;
  }

  return `${symbol} <span title="Fix due by ${fixEta}">${label}</span>`;
}

itemsPerPage: number = 10;
currentPage: number = 1;

get paginatedData(): any[] {
  const filtered = this.filteredTableData();
  const start = (this.currentPage - 1) * this.itemsPerPage;
  const end = start + this.itemsPerPage;
  return filtered.slice(start, end);
}

get totalPages(): number {
  return Math.ceil(this.filteredTableData().length / this.itemsPerPage);
}

goToPage(page: number) {
  this.currentPage = page;
}

toastMessage: string = '';
toastVisible: boolean = false;
toastType: 'success' | 'error' | 'warning' = 'success';

showToast(message: string, type: 'success' | 'error' | 'warning' = 'success') {
  this.toastMessage = message;
  this.toastType = type;
  this.toastVisible = true;
  setTimeout(() => {
    this.toastVisible = false;
  }, 3000);
}

  // Mock API
  fakeApiCall(payload: any): Promise<any[]> {
    return Promise.resolve([
      {
        issueKey: 'FIAIA-123',
        summary: 'Fix login bug',
        status: 'Done',
        fv: 'Yes',
        testable: 'Yes',
        compliance: 'Compliant',
      },
      {
        issueKey: 'FIAIA-124',
        summary: 'Add logout button',
        status: 'In Progress',
        fv: 'No',
        testable: 'Yes',
        compliance: 'Non-Compliant',
      },
    ]);
  }
}
