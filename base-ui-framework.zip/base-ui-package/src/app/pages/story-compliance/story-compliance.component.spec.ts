import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StoryComplianceComponent } from './story-compliance.component';

describe('StoryComplianceComponent', () => {
  let component: StoryComplianceComponent;
  let fixture: ComponentFixture<StoryComplianceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StoryComplianceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StoryComplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
