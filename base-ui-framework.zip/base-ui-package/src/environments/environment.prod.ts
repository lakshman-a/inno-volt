export const environment = {
  production: true,
  apiBaseUrl: 'https://prod.api.company.com',
  pingEndpoint: '/user/ping',
  featureFlag: false
};
