/**
 * ============================================================
 * PANEL UI BUILDER
 * ============================================================
 * Builds and manages the side panel injected into Jira pages.
 * ============================================================
 */

class PanelUI {

  constructor(config) {
    this.config = config;
    this.panel = null;
    this.isOpen = false;
    this.currentTestPlan = null;
  }

  /**
   * Inject the toggle button and panel into the Jira page.
   */
  inject() {
    // Create toggle button
    const toggleBtn = document.createElement("button");
    toggleBtn.id = "qi-toggle-btn";
    toggleBtn.textContent = "QA Intel";
    toggleBtn.addEventListener("click", () => this.toggle());
    document.body.appendChild(toggleBtn);
    this.toggleBtn = toggleBtn;

    // Create panel
    const panel = document.createElement("div");
    panel.id = "qa-intelligence-panel";
    panel.innerHTML = this._getPanelHtml();
    document.body.appendChild(panel);
    this.panel = panel;

    // Bind internal events
    this._bindEvents();
  }

  toggle() {
    this.isOpen = !this.isOpen;
    this.panel.classList.toggle("qi-open", this.isOpen);
  }

  open() {
    this.isOpen = true;
    this.panel.classList.add("qi-open");
  }

  close() {
    this.isOpen = false;
    this.panel.classList.remove("qi-open");
  }

  // ── Display Methods ────────────────────────────────────────

  showLoading(message = "Analyzing story...") {
    this._getEl("qi-content-area").innerHTML = `
      <div class="qi-loading">
        <div class="qi-spinner"></div>
        <span>${message}</span>
      </div>`;
  }

  showError(message) {
    this._getEl("qi-content-area").innerHTML = `
      <div class="qi-error">
        <strong>Error:</strong> ${message}
        <br><br>
        <button class="qi-btn qi-btn-secondary" onclick="document.dispatchEvent(new Event('qi-retry'))">
          Retry
        </button>
      </div>`;
  }

  showScore(scoreResult) {
    const { score, breakdown, missing, suggestions, testability_summary } = scoreResult;
    const level = score >= this.config.SCORE_THRESHOLDS.GOOD ? "good" :
                  score >= this.config.SCORE_THRESHOLDS.MEDIUM ? "medium" : "bad";

    // Update toggle button
    this.toggleBtn.classList.add("qi-has-score");
    this.toggleBtn.setAttribute("data-score", `${score}/10`);

    const breakdownHtml = Object.entries(breakdown).map(([key, val]) => {
      const barLevel = val.score >= 7 ? "good" : val.score >= 4 ? "medium" : "bad";
      const label = key.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase());
      return `
        <div class="qi-breakdown-item" title="${val.feedback}">
          <span class="qi-breakdown-label">${label}</span>
          <div class="qi-breakdown-bar">
            <div class="qi-breakdown-fill qi-${barLevel}" style="width: ${val.score * 10}%"></div>
          </div>
          <span class="qi-breakdown-value">${val.score}</span>
        </div>`;
    }).join("");

    const missingHtml = missing && missing.length > 0 ? `
      <div class="qi-missing">
        <div class="qi-missing-title">Missing from this story:</div>
        <ul class="qi-missing-list">
          ${missing.map(m => `<li>${m}</li>`).join("")}
        </ul>
      </div>` : "";

    this._getEl("qi-score-area").innerHTML = `
      <div class="qi-score-section">
        <div class="qi-score-display">
          <div class="qi-score-circle qi-${level}">${score}</div>
          <div>
            <div class="qi-score-label">Story Clarity Score</div>
            <div class="qi-score-sublabel">${testability_summary || ""}</div>
          </div>
        </div>
        <div class="qi-breakdown">${breakdownHtml}</div>
        ${missingHtml}
      </div>`;
  }

  showTestPlan(testPlan) {
    this.currentTestPlan = testPlan;
    
    let html = `<div class="qi-test-plan">
      <h4 style="margin:0 0 12px 0;color:#1B4F72;">${testPlan.test_plan_title}</h4>
      <p style="font-size:12px;color:#666;margin:0 0 16px 0;">
        ${testPlan.total_test_cases} test cases generated
      </p>`;

    for (const cat of testPlan.categories) {
      html += `<div class="qi-category">
        <div class="qi-category-header">${cat.name} (${cat.test_cases.length})</div>`;
      
      for (const tc of cat.test_cases) {
        const steps = Array.isArray(tc.test_steps)
          ? tc.test_steps.map(s => typeof s === "string" ? s : `${s.step}. ${s.action}`).join("<br>")
          : tc.test_steps;

        html += `
          <div class="qi-test-case">
            <div class="qi-tc-header">
              <span class="qi-tc-id">${tc.id}</span>
              <span class="qi-tc-priority ${tc.priority}">${tc.priority}</span>
            </div>
            <div class="qi-tc-title">${tc.title}</div>
            <div class="qi-tc-detail"><strong>Pre:</strong> ${tc.preconditions}</div>
            <div class="qi-tc-detail"><strong>Steps:</strong> ${steps}</div>
            <div class="qi-tc-detail"><strong>Expected:</strong> ${tc.expected_result}</div>
            <div class="qi-tc-detail"><strong>Rule:</strong> ${tc.business_rule || "N/A"}</div>
          </div>`;
      }
      html += `</div>`;
    }

    html += `
      <div class="qi-export-row">
        <button class="qi-export-btn" data-action="download-md">Download MD</button>
        <button class="qi-export-btn" data-action="download-csv">Download CSV</button>
        <button class="qi-export-btn" data-action="copy">Copy</button>
        <button class="qi-export-btn" data-action="xray">Push XRay</button>
      </div>
      <div style="margin-top:8px;">
        <button class="qi-btn qi-btn-primary" data-action="generate-automation" style="width:100%">
          Generate Automation Code
        </button>
      </div>
    </div>`;

    this._getEl("qi-testplan-area").innerHTML = html;
  }

  showTestPlanLoading() {
    this._getEl("qi-testplan-area").innerHTML = `
      <div class="qi-loading">
        <div class="qi-spinner"></div>
        <span>Generating test plan... This may take 30-60 seconds.</span>
      </div>`;
  }

  // ── Private ────────────────────────────────────────────────

  _getPanelHtml() {
    return `
      <div class="qi-header">
        <h3>QA Intelligence</h3>
        <div class="qi-header-actions">
          <button class="qi-header-btn" data-action="settings" title="Settings">⚙</button>
          <button class="qi-header-btn" data-action="refresh" title="Re-analyze">↻</button>
          <button class="qi-header-btn" data-action="close" title="Close">✕</button>
        </div>
      </div>
      <div class="qi-body">
        <div id="qi-content-area"></div>
        <div id="qi-score-area"></div>
        <div class="qi-actions">
          <button class="qi-btn qi-btn-primary" data-action="generate-testplan">
            Generate Test Plan
          </button>
        </div>
        <div id="qi-testplan-area"></div>
        <div class="qi-settings" id="qi-settings-area">
          <label>Confluence Space Key</label>
          <input type="text" id="qi-conf-space" value="${this.config.CONFLUENCE_DEFAULT_SPACE}" />
          <label>Swagger/OpenAPI URL</label>
          <input type="text" id="qi-swagger-url" placeholder="https://api.example.com/v2/api-docs" value="${this.config.SWAGGER_URL}" />
          <label>Automation Framework</label>
          <select id="qi-framework">
            <option value="cucumber" ${this.config.AUTOMATION_FRAMEWORK === "cucumber" ? "selected" : ""}>Cucumber (Gherkin)</option>
            <option value="playwright" ${this.config.AUTOMATION_FRAMEWORK === "playwright" ? "selected" : ""}>Playwright</option>
            <option value="karate" ${this.config.AUTOMATION_FRAMEWORK === "karate" ? "selected" : ""}>Karate DSL</option>
          </select>
        </div>
      </div>`;
  }

  _bindEvents() {
    this.panel.addEventListener("click", (e) => {
      const action = e.target.closest("[data-action]")?.dataset.action;
      if (!action) return;
      document.dispatchEvent(new CustomEvent("qi-action", { detail: { action, testPlan: this.currentTestPlan } }));
    });
  }

  _getEl(id) {
    return this.panel.querySelector(`#${id}`) || document.createElement("div");
  }
}

window.PanelUI = PanelUI;
