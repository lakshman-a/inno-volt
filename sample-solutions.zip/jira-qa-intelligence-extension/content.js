/**
 * ============================================================
 * QA INTELLIGENCE - MAIN CONTENT SCRIPT
 * ============================================================
 * Entry point injected into Jira pages.
 * Orchestrates all services: JiraReader, GatewayClient,
 * PromptBuilder, PanelUI, ExportHandler.
 * ============================================================
 */

(async function() {
  "use strict";

  const CONFIG = window.QA_INTELLIGENCE_CONFIG;
  if (!CONFIG) {
    console.error("[QA-Intelligence] Config not loaded");
    return;
  }

  // ── Initialize services ────────────────────────────────────
  const jiraReader    = new JiraReader(CONFIG);
  const gatewayClient = new GatewayClient(CONFIG);
  const promptBuilder = new PromptBuilder(CONFIG);
  const exportHandler = new ExportHandler(CONFIG);
  const panelUI       = new PanelUI(CONFIG);

  // Check if we're on a Jira issue page
  const issueKey = jiraReader.getIssueKeyFromUrl();
  if (!issueKey) {
    console.log("[QA-Intelligence] Not on an issue page, skipping.");
    return;
  }

  console.log(`[QA-Intelligence] Detected issue: ${issueKey}`);

  // ── Inject UI ──────────────────────────────────────────────
  panelUI.inject();

  // ── State ──────────────────────────────────────────────────
  let currentStory = null;
  let currentEpic = null;
  let currentScore = null;
  let currentTestPlan = null;

  // ── Auto-score on load ─────────────────────────────────────
  if (CONFIG.AUTO_SCORE) {
    // Small delay to let Jira page fully render
    setTimeout(() => analyzeStory(), 1500);
  }

  // ── Main analysis flow ─────────────────────────────────────
  async function analyzeStory() {
    try {
      panelUI.showLoading("Reading story data...");

      // Step 1: Read story
      currentStory = await jiraReader.readStory();
      console.log("[QA-Intelligence] Story loaded:", currentStory.key);

      // Step 2: Read epic for context
      if (currentStory.epicKey) {
        currentEpic = await jiraReader.readEpic(currentStory.epicKey);
      }

      // Step 3: Check backend health
      const backendOk = await gatewayClient.healthCheck();
      if (!backendOk) {
        panelUI.showError(
          `Cannot reach backend at ${CONFIG.BACKEND_URL}. ` +
          `Make sure the Python backend is running. See README for setup instructions.`
        );
        return;
      }

      // Step 4: Score the story
      panelUI.showLoading("Scoring story clarity...");
      currentScore = await gatewayClient.scoreStory(currentStory, currentEpic);
      panelUI.showScore(currentScore);

    } catch (error) {
      console.error("[QA-Intelligence] Analysis error:", error);
      panelUI.showError(error.message);
    }
  }

  // ── Generate test plan ─────────────────────────────────────
  async function generateTestPlan() {
    try {
      if (!currentStory) {
        await analyzeStory();
      }

      panelUI.showTestPlanLoading();

      // Get settings from UI
      const confluenceSpace = document.getElementById("qi-conf-space")?.value || CONFIG.CONFLUENCE_DEFAULT_SPACE;
      const swaggerUrl = document.getElementById("qi-swagger-url")?.value || CONFIG.SWAGGER_URL;

      currentTestPlan = await gatewayClient.generateTestPlan(currentStory, {
        epicData: currentEpic,
        confluenceSpace,
        swaggerUrl,
      });

      panelUI.showTestPlan(currentTestPlan);

    } catch (error) {
      console.error("[QA-Intelligence] Test plan error:", error);
      panelUI.showError(`Test plan generation failed: ${error.message}`);
    }
  }

  // ── Event handlers ─────────────────────────────────────────
  document.addEventListener("qi-action", async (e) => {
    const { action, testPlan } = e.detail;

    switch (action) {
      case "generate-testplan":
        await generateTestPlan();
        break;

      case "refresh":
        await analyzeStory();
        break;

      case "close":
        panelUI.close();
        break;

      case "settings":
        const settingsEl = document.getElementById("qi-settings-area");
        settingsEl?.classList.toggle("qi-visible");
        break;

      case "download-md":
        if (currentTestPlan) exportHandler.downloadAsMarkdown(currentTestPlan);
        break;

      case "download-csv":
        if (currentTestPlan) exportHandler.downloadAsCsv(currentTestPlan);
        break;

      case "copy":
        if (currentTestPlan) {
          await exportHandler.copyToClipboard(currentTestPlan);
          alert("Test plan copied to clipboard!");
        }
        break;

      case "xray":
        if (currentTestPlan) {
          try {
            const result = await gatewayClient.exportToXray(currentTestPlan);
            alert(`Created ${result.created_tests?.length || 0} test cases in XRay`);
          } catch (err) {
            alert(`XRay export failed: ${err.message}`);
          }
        }
        break;

      case "generate-automation":
        if (currentTestPlan) {
          try {
            panelUI.showTestPlanLoading();
            const framework = document.getElementById("qi-framework")?.value || CONFIG.AUTOMATION_FRAMEWORK;
            const automation = await gatewayClient.generateAutomation(currentTestPlan, framework);
            exportHandler.downloadAutomationFiles(automation);
            panelUI.showTestPlan(currentTestPlan); // Restore test plan view
          } catch (err) {
            panelUI.showError(`Automation generation failed: ${err.message}`);
          }
        }
        break;
    }
  });

  document.addEventListener("qi-retry", () => analyzeStory());

  // ── Watch for Jira SPA navigation ──────────────────────────
  // Jira is an SPA, so we watch for URL changes
  let lastUrl = window.location.href;
  const urlObserver = new MutationObserver(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      const newKey = jiraReader.getIssueKeyFromUrl();
      if (newKey && newKey !== currentStory?.key) {
        console.log(`[QA-Intelligence] Navigation detected: ${newKey}`);
        currentStory = null;
        currentScore = null;
        currentTestPlan = null;
        if (CONFIG.AUTO_SCORE) {
          setTimeout(() => analyzeStory(), 1000);
        }
      }
    }
  });
  urlObserver.observe(document.body, { childList: true, subtree: true });

})();
