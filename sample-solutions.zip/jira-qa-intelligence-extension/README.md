# QA Intelligence for Jira - Chrome Extension

AI-powered story clarity scoring and test plan generation, injected directly into Jira pages. Uses your enterprise GenAI Gateway — all data stays within your network.

## What It Does

1. **Story Clarity Scoring** — Automatically scores Jira stories on testability (1-10) with specific feedback on what's missing
2. **Test Plan Generation** — Generates comprehensive QA-grade test plans with positive, negative, boundary, and security cases  
3. **Context Enrichment** — Pulls in Confluence architecture docs and Swagger API specs for domain-aware test planning
4. **Export** — Download as Markdown/CSV, push to XRay, or generate Cucumber/Playwright/Karate automation code

## Project Structure

```
jira-qa-intelligence-extension/
├── manifest.json              # Chrome extension manifest (v3)
├── config.js                  # ★ ALL configurable settings in one file
├── content.js                 # Main orchestrator (injected into Jira pages)
├── background.js              # Service worker for cross-origin requests
├── services/
│   ├── jira-reader.js         # Reads story data from Jira DOM/API
│   ├── gateway-client.js      # Calls the Python backend
│   ├── prompt-builder.js      # ★ All LLM prompts (edit to customize)
│   └── export-handler.js      # Export to MD/CSV/clipboard/XRay
├── ui/
│   ├── panel.js               # Side panel UI builder
│   └── panel.css              # Panel styles
├── popup/
│   └── popup.html             # Extension popup (settings/health check)
├── icons/                     # Extension icons (add your own 16/48/128px PNGs)
├── backend/
│   ├── app.py                 # ★ FastAPI backend (routes to GenAI Gateway)
│   ├── .env.example           # ★ Environment config template
│   └── requirements.txt       # Python dependencies
└── README.md                  # This file
```

## Setup Guide

### Step 1: Start the Python Backend

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your GenAI Gateway URL and API key
python app.py
# Backend runs at http://localhost:8000
```

Verify: `curl http://localhost:8000/health`

### Step 2: Configure the Extension

Edit `config.js`:
- Set `BACKEND_URL` to your backend (default: `http://localhost:8000`)
- Set `JIRA_BASE_URL` to your Jira instance
- Set `JIRA_CUSTOM_FIELDS` to match your Jira custom field IDs
- Optionally configure Confluence space, Swagger URL, and test framework

### Step 3: Load in Chrome

1. Open `chrome://extensions/`
2. Enable **Developer mode** (toggle top-right)
3. Click **Load unpacked**
4. Select this project folder (the one containing `manifest.json`)
5. Navigate to any Jira story page — the panel toggle appears on the right edge

### Step 4: Add Icons (Optional)

Place PNG files in the `icons/` folder:
- `icon16.png` (16x16)
- `icon48.png` (48x48)  
- `icon128.png` (128x128)

## Configuration Reference

### config.js — Key Settings

| Setting | Description | Default |
|---------|-------------|---------|
| `BACKEND_URL` | Your FastAPI backend URL | `http://localhost:8000` |
| `JIRA_BASE_URL` | Your Jira instance URL | `https://your-org.atlassian.net` |
| `JIRA_CUSTOM_FIELDS.ACCEPTANCE_CRITERIA` | Jira field ID for AC | `customfield_10001` |
| `CONFLUENCE_DEFAULT_SPACE` | Default Confluence space for context | `TEAMSPACE` |
| `SWAGGER_URL` | Default Swagger spec URL | `""` (empty) |
| `AUTO_SCORE` | Auto-score when story loads | `true` |
| `TEST_CASE_FORMAT` | Output format: `gherkin`, `table`, `structured` | `gherkin` |
| `AUTOMATION_FRAMEWORK` | Target framework: `cucumber`, `playwright`, `karate` | `cucumber` |

### backend/.env — Backend Settings

| Variable | Description |
|----------|-------------|
| `GENAI_GATEWAY_URL` | GenAI Gateway endpoint |
| `GENAI_API_KEY` | Your API key for the gateway |
| `MODEL_VENDOR` | LLM vendor: `google`, `openai`, `aws`, `anthropic` |
| `MODEL_NAME` | Model name per gateway docs |
| `CONFLUENCE_BASE_URL` | Confluence URL (optional) |
| `CONFLUENCE_API_TOKEN` | Confluence API token (optional) |

## How to Find Your Jira Custom Field IDs

```
GET https://your-jira.atlassian.net/rest/api/2/issue/PROJ-123
```

Look for fields like `customfield_10001`, `customfield_10002` in the response. Match them to your Acceptance Criteria, Story Points, etc.

## Customizing Prompts

All LLM prompts are in `services/prompt-builder.js`:

- **Scoring prompt**: `buildScoringPrompt()` — Edit scoring criteria and weights
- **Test plan prompt**: `buildTestPlanPrompt()` — Edit test categories and QA instructions
- **QA examples**: `_getDefaultQaExamples()` — **Replace with your team's real test cases** for best results
- **Automation prompt**: `buildAutomationPrompt()` — Edit framework-specific instructions

The same prompts are mirrored in `backend/app.py` for server-side generation.

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Panel doesn't appear | Check `chrome://extensions/` for errors. Verify URL patterns in `manifest.json` match your Jira URL. |
| "Cannot reach backend" | Ensure `python app.py` is running. Check `BACKEND_URL` in `config.js`. |
| Scoring returns error | Check `.env` has correct `GENAI_GATEWAY_URL` and `GENAI_API_KEY`. Check backend logs. |
| Empty description/AC | Verify `JIRA_CUSTOM_FIELDS` in `config.js` match your Jira instance field IDs. |
| CORS errors | The FastAPI backend allows all origins by default. For production, restrict in `app.py`. |

## What to Share with End Users

When piloting with a squad, share this:

1. **They need**: Chrome browser, access to their Jira instance
2. **They install**: Load the unpacked extension in Chrome (you can also distribute as .crx)
3. **They get**: A side panel on every Jira story showing clarity score and test plan generation
4. **You need from them**: Nothing — the extension uses their existing Jira session for auth
5. **Data safety**: All data routes through your internal GenAI Gateway, nothing leaves the network
