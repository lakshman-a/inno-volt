/**
 * ============================================================
 * PROMPT BUILDER SERVICE
 * ============================================================
 * Builds prompts for the GenAI Gateway.
 * 
 * COPILOT/AI INSTRUCTION: This file contains all LLM prompts.
 * When modifying prompts:
 * - Keep the system instruction structure
 * - Update few-shot examples to match your QA team's style
 * - Do not remove the JSON output format instructions
 * ============================================================
 */

class PromptBuilder {

  constructor(config) {
    this.config = config;
  }

  /**
   * Build the story clarity scoring prompt.
   * Returns a lightweight prompt for quick scoring.
   */
  buildScoringPrompt(storyData, epicData = null) {
    return `You are a Senior QA Engineer evaluating a Jira user story for testability and completeness.

SCORING CRITERIA (with weights):
- Acceptance Criteria (25%): Are there explicit, testable acceptance criteria? Are they specific enough to write test cases from?
- Field/Data Validations (20%): Are input fields, formats, ranges, and constraints specified? Are data types and lengths defined?
- Error/Negative Scenarios (20%): Does the story mention what happens on failure, invalid input, timeout, or exception?
- API Contract Details (15%): For API stories - are endpoints, request/response formats, status codes, and headers defined?
- State Transitions (10%): For workflow features - are valid state changes documented? What triggers transitions?
- Dependencies/Preconditions (10%): Are test preconditions, setup requirements, and external dependencies listed?

STORY TO EVALUATE:
Key: ${storyData.key}
Type: ${storyData.issueType || "Story"}
Summary: ${storyData.summary}
Description: ${storyData.description || "EMPTY - No description provided"}
Acceptance Criteria: ${storyData.acceptanceCriteria || "MISSING - No acceptance criteria found"}
Components: ${storyData.components.join(", ") || "None"}
Labels: ${storyData.labels.join(", ") || "None"}
${epicData ? `Epic: ${epicData.key} - ${epicData.summary}\nEpic Description: ${epicData.description}` : ""}

RESPOND WITH ONLY THIS JSON (no markdown, no backticks):
{
  "score": <number 1-10>,
  "breakdown": {
    "acceptance_criteria": { "score": <1-10>, "feedback": "<specific feedback>" },
    "field_validations": { "score": <1-10>, "feedback": "<specific feedback>" },
    "error_scenarios": { "score": <1-10>, "feedback": "<specific feedback>" },
    "api_contract": { "score": <1-10>, "feedback": "<specific feedback>" },
    "state_transitions": { "score": <1-10>, "feedback": "<specific feedback>" },
    "dependencies": { "score": <1-10>, "feedback": "<specific feedback>" }
  },
  "missing": ["<list of specific things missing from the story>"],
  "suggestions": ["<actionable suggestions to improve the story>"],
  "testability_summary": "<2-3 sentence summary of how testable this story is>"
}`;
  }

  /**
   * Build the full test plan generation prompt.
   * Includes context from Confluence, Swagger, and few-shot QA examples.
   */
  buildTestPlanPrompt(storyData, context = {}) {
    const { epicData, confluenceContext, swaggerContext, qaExamples } = context;

    return `You are an expert QA Engineer creating a comprehensive test plan for a Jira user story.

YOUR TESTING PHILOSOPHY:
- Think like a QA, not a developer. Developers test if code works. QA tests if business requirements are met.
- Cover what the developer DIDN'T think of: edge cases, boundary values, race conditions, data integrity.
- Every test case must have a clear business justification, not just technical verification.
- Negative testing is as important as positive testing. Systems fail at boundaries.

${this._buildContextSection(epicData, confluenceContext, swaggerContext)}

${this._buildQaExamplesSection(qaExamples)}

STORY UNDER TEST:
Key: ${storyData.key}
Summary: ${storyData.summary}
Description: ${storyData.description || "No description"}
Acceptance Criteria: ${storyData.acceptanceCriteria || "Not specified"}
Components: ${storyData.components.join(", ") || "None"}
Labels: ${storyData.labels.join(", ") || "None"}
${storyData.linkedIssues.length > 0 ? `Linked Issues: ${storyData.linkedIssues.map(l => `${l.key}: ${l.summary}`).join("; ")}` : ""}
${storyData.subtasks.length > 0 ? `Subtasks: ${storyData.subtasks.map(s => `${s.key}: ${s.summary}`).join("; ")}` : ""}

GENERATE A TEST PLAN WITH THESE CATEGORIES:
${this.config.TEST_CATEGORIES.map((cat, i) => `${i + 1}. ${cat}`).join("\n")}

OUTPUT FORMAT (${this.config.TEST_CASE_FORMAT}):
${this._getOutputFormatInstructions()}

RESPOND WITH ONLY THIS JSON (no markdown, no backticks):
{
  "story_key": "${storyData.key}",
  "test_plan_title": "<descriptive title>",
  "total_test_cases": <number>,
  "categories": [
    {
      "name": "<category name>",
      "test_cases": [
        {
          "id": "TC-001",
          "title": "<descriptive test case title>",
          "priority": "High|Medium|Low",
          "preconditions": "<what must be true before test>",
          "test_steps": ${this._getStepsFormat()},
          "expected_result": "<what should happen>",
          "test_data": "<specific data values to use>",
          "business_rule": "<which business rule this validates>"
        }
      ]
    }
  ],
  "automation_notes": "<notes for automating these test cases>",
  "risks_and_assumptions": ["<list of risks and assumptions>"]
}`;
  }

  /**
   * Build prompt for generating automation code from test plan.
   */
  buildAutomationPrompt(testPlan, framework) {
    const fw = framework || this.config.AUTOMATION_FRAMEWORK;
    
    const frameworkInstructions = {
      cucumber: `Generate Cucumber BDD feature files with Gherkin syntax.
Use Given/When/Then steps. Include Background for common preconditions.
Tag scenarios with @smoke, @regression, @negative as appropriate.
Generate step definition stubs in Java.`,
      
      playwright: `Generate Playwright test files in TypeScript.
Use page object model pattern. Include proper waits and assertions.
Group tests with describe/it blocks matching test categories.`,
      
      karate: `Generate Karate DSL feature files.
Use proper Karate syntax for API testing: Given url, When method, Then status.
Include schema validation and data-driven scenarios where appropriate.`,
    };

    return `You are a test automation engineer. Convert this test plan into ${fw} automation code.

${frameworkInstructions[fw] || frameworkInstructions.cucumber}

TEST PLAN:
${JSON.stringify(testPlan, null, 2)}

Generate complete, runnable test files. Include all imports, setup, and teardown.
Output as JSON:
{
  "files": [
    {
      "filename": "<path/to/file>",
      "content": "<complete file content>",
      "type": "feature|step_definition|page_object|config"
    }
  ]
}`;
  }

  // ── Private helpers ────────────────────────────────────────

  _buildContextSection(epicData, confluenceContext, swaggerContext) {
    let section = "";
    
    if (epicData) {
      section += `\nEPIC CONTEXT:\nEpic: ${epicData.key} - ${epicData.summary}\n${epicData.description}\n`;
    }
    
    if (confluenceContext) {
      section += `\nPRODUCT ARCHITECTURE CONTEXT (from Confluence):\n${confluenceContext}\n`;
    }
    
    if (swaggerContext) {
      section += `\nAPI SPECIFICATION (from Swagger/OpenAPI):\n${swaggerContext}\n`;
    }
    
    return section || "\n(No additional context provided. Generate test plan based on story details only.)\n";
  }

  _buildQaExamplesSection(qaExamples) {
    if (!qaExamples || qaExamples.length === 0) {
      return this._getDefaultQaExamples();
    }
    return `\nQA TEAM TEST CASE EXAMPLES (follow this style):\n${qaExamples}\n`;
  }

  /**
   * DEFAULT QA EXAMPLES
   * ──────────────────────────────────────────────────────────
   * EDIT THESE to match your QA team's actual test case style.
   * Replace with real examples from your XRay/test management.
   * The better these examples, the better the AI output.
   * ──────────────────────────────────────────────────────────
   */
  _getDefaultQaExamples() {
    return `
QA TEAM TEST CASE EXAMPLES (follow this depth and style):

EXAMPLE 1 - Login Feature:
TC-001: Verify login with valid credentials
  Priority: High
  Preconditions: User account exists, is active, not locked
  Steps:
    1. Navigate to login page
    2. Enter valid email "testuser@enterprisef.com"
    3. Enter valid password
    4. Click "Sign In"
  Expected: User redirected to dashboard. Session token created. Last login timestamp updated.
  Business Rule: Authentication must complete within 3 seconds.

TC-002: Verify login with expired password
  Priority: High
  Preconditions: User password was set > 90 days ago (password policy)
  Steps:
    1. Navigate to login page
    2. Enter valid email and expired password
    3. Click "Sign In"
  Expected: User shown "Password expired" message with reset link. NOT allowed to proceed. Event logged.
  Business Rule: Passwords expire after 90 days per security policy.

TC-003: Verify account lockout after failed attempts
  Priority: High
  Preconditions: User account is active, not locked
  Steps:
    1. Attempt login with wrong password 5 times consecutively
    2. Attempt 6th login with correct password
  Expected: After 5th failure, account locked. 6th attempt rejected even with correct password. 
            User receives email notification. Lockout duration: 30 minutes. Audit log entry created.
  Business Rule: 5 consecutive failures triggers lockout. Must be per-account, not per-session.

NOTE TO AI: Notice how QA examples include specific business rules, security implications, audit logging, 
timing requirements, and edge cases. Generate test cases at THIS level of depth.`;
  }

  _getOutputFormatInstructions() {
    switch (this.config.TEST_CASE_FORMAT) {
      case "gherkin":
        return 'For test_steps, use Gherkin format: "Given <precondition> When <action> Then <expected>"';
      case "table":
        return 'For test_steps, use numbered steps: ["Step 1: ...", "Step 2: ...", ...]';
      case "structured":
        return 'For test_steps, use objects: [{"step": 1, "action": "...", "data": "...", "expected": "..."}]';
      default:
        return 'For test_steps, use numbered steps as an array of strings.';
    }
  }

  _getStepsFormat() {
    switch (this.config.TEST_CASE_FORMAT) {
      case "gherkin":
        return '"Given <precondition> When <action> Then <expected>"';
      case "structured":
        return '[{"step": 1, "action": "...", "data": "...", "expected": "..."}]';
      default:
        return '["Step 1: ...", "Step 2: ..."]';
    }
  }
}

window.PromptBuilder = PromptBuilder;
