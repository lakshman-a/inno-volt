/**
 * ============================================================
 * GENAI GATEWAY CLIENT SERVICE
 * ============================================================
 * Makes calls to the Python backend which routes to GenAI Gateway.
 * Handles retries, timeouts, and error parsing.
 * ============================================================
 */

class GatewayClient {

  constructor(config) {
    this.config = config;
    this.backendUrl = config.BACKEND_URL;
  }

  /**
   * Score a story for clarity and testability.
   * Returns: { score, breakdown, missing, suggestions, testability_summary }
   */
  async scoreStory(storyData, epicData = null) {
    return this._callBackend("/api/score-story", {
      story: storyData,
      epic: epicData,
      scoring_weights: this.config.SCORING_WEIGHTS,
    });
  }

  /**
   * Generate a full test plan from story data + context.
   * Returns: { story_key, test_plan_title, categories, ... }
   */
  async generateTestPlan(storyData, context = {}) {
    return this._callBackend("/api/generate-test-plan", {
      story: storyData,
      epic: context.epicData || null,
      confluence_context: context.confluenceContext || "",
      swagger_url: context.swaggerUrl || this.config.SWAGGER_URL,
      confluence_space: context.confluenceSpace || this.config.CONFLUENCE_DEFAULT_SPACE,
      qa_examples: context.qaExamples || "",
      test_categories: this.config.TEST_CATEGORIES,
      test_format: this.config.TEST_CASE_FORMAT,
    });
  }

  /**
   * Generate automation code from a test plan.
   * Returns: { files: [{ filename, content, type }] }
   */
  async generateAutomation(testPlan, framework) {
    return this._callBackend("/api/generate-automation", {
      test_plan: testPlan,
      framework: framework || this.config.AUTOMATION_FRAMEWORK,
    });
  }

  /**
   * Export test cases to XRay.
   * Returns: { created_tests: [...], test_plan_key: "..." }
   */
  async exportToXray(testPlan, projectKey) {
    return this._callBackend("/api/export-xray", {
      test_plan: testPlan,
      project_key: projectKey || this.config.XRAY_PROJECT_KEY,
    });
  }

  /**
   * Check if the backend is healthy and reachable.
   */
  async healthCheck() {
    try {
      const response = await fetch(`${this.backendUrl}/health`, {
        method: "GET",
        signal: AbortSignal.timeout(5000),
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  // ── Private ────────────────────────────────────────────────

  async _callBackend(endpoint, payload, retries = 2) {
    const url = `${this.backendUrl}${endpoint}`;
    
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const response = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
          signal: AbortSignal.timeout(120000),  // 2 min timeout for LLM calls
        });

        if (!response.ok) {
          const errorBody = await response.text();
          throw new Error(`Backend returned ${response.status}: ${errorBody}`);
        }

        const data = await response.json();
        return data;

      } catch (error) {
        if (attempt === retries) {
          throw new Error(`Backend call failed after ${retries + 1} attempts: ${error.message}`);
        }
        // Wait before retry (exponential backoff)
        await new Promise(r => setTimeout(r, 1000 * Math.pow(2, attempt)));
      }
    }
  }
}

window.GatewayClient = GatewayClient;
