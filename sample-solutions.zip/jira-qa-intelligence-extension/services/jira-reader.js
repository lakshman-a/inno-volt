/**
 * ============================================================
 * JIRA READER SERVICE
 * ============================================================
 * Reads story data from Jira pages.
 * Uses two strategies:
 *   1. DOM scraping (fast, no extra API call)
 *   2. REST API (reliable, gets all fields)
 * Falls back from DOM to API if DOM read fails.
 * ============================================================
 */

class JiraReader {

  constructor(config) {
    this.config = config;
  }

  /**
   * Extract the issue key from the current URL.
   * Handles: /browse/PROJ-123, /jira/software/projects/PROJ/issues/PROJ-123
   */
  getIssueKeyFromUrl() {
    const url = window.location.href;
    
    // Pattern 1: /browse/PROJ-123
    const browseMatch = url.match(/\/browse\/([A-Z]+-\d+)/);
    if (browseMatch) return browseMatch[1];

    // Pattern 2: /issues/PROJ-123
    const issueMatch = url.match(/\/issues\/([A-Z]+-\d+)/);
    if (issueMatch) return issueMatch[1];

    // Pattern 3: selectedIssue=PROJ-123 (board view)
    const paramMatch = url.match(/selectedIssue=([A-Z]+-\d+)/);
    if (paramMatch) return paramMatch[1];

    return null;
  }

  /**
   * Read story data - tries DOM first, falls back to REST API.
   * Returns a normalized StoryData object.
   */
  async readStory() {
    const issueKey = this.getIssueKeyFromUrl();
    if (!issueKey) {
      throw new Error("Cannot detect Jira issue key from URL");
    }

    try {
      // Try REST API first (more reliable)
      return await this.readFromApi(issueKey);
    } catch (apiError) {
      console.warn("[QA-Intelligence] API read failed, trying DOM:", apiError.message);
      try {
        return this.readFromDom(issueKey);
      } catch (domError) {
        throw new Error(`Failed to read story data: API(${apiError.message}), DOM(${domError.message})`);
      }
    }
  }

  /**
   * Read story data from Jira REST API.
   * Uses the user's existing session cookie for auth.
   */
  async readFromApi(issueKey) {
    const apiUrl = `/rest/api/${this.config.JIRA_API_VERSION}/issue/${issueKey}?expand=renderedFields,names`;
    
    const response = await fetch(apiUrl, {
      method: "GET",
      headers: { "Accept": "application/json" },
      credentials: "same-origin",  // Uses existing session cookie
    });

    if (!response.ok) {
      throw new Error(`Jira API returned ${response.status}`);
    }

    const issue = await response.json();
    const fields = issue.fields;
    const rendered = issue.renderedFields || {};

    return {
      key: issue.key,
      summary: fields.summary || "",
      description: this._stripHtml(rendered.description || fields.description || ""),
      descriptionHtml: rendered.description || "",
      acceptanceCriteria: this._getCustomField(fields, "ACCEPTANCE_CRITERIA"),
      storyPoints: this._getCustomField(fields, "STORY_POINTS"),
      issueType: fields.issuetype?.name || "",
      status: fields.status?.name || "",
      priority: fields.priority?.name || "",
      labels: fields.labels || [],
      components: (fields.components || []).map(c => c.name),
      epicKey: fields.epic?.key || fields.parent?.key || "",
      epicSummary: fields.epic?.fields?.summary || fields.parent?.fields?.summary || "",
      linkedIssues: (fields.issuelinks || []).map(link => ({
        type: link.type?.name || "",
        key: (link.outwardIssue || link.inwardIssue)?.key || "",
        summary: (link.outwardIssue || link.inwardIssue)?.fields?.summary || "",
      })),
      subtasks: (fields.subtasks || []).map(st => ({
        key: st.key,
        summary: st.fields?.summary || "",
      })),
      reporter: fields.reporter?.displayName || "",
      assignee: fields.assignee?.displayName || "",
      created: fields.created || "",
      updated: fields.updated || "",
      _raw: issue,  // Keep raw response for advanced use
    };
  }

  /**
   * Read story data from DOM elements.
   * Selectors may need updating if Jira UI changes.
   */
  readFromDom(issueKey) {
    // ── Jira Cloud selectors (Next-Gen + Classic) ──
    const selectors = {
      summary: [
        "[data-testid='issue.views.issue-base.foundation.summary.heading']",
        "#summary-val",
        "h1[data-test-id='issue.views.issue-base.foundation.summary.heading']",
      ],
      description: [
        "[data-testid='issue.views.field.rich-text.description']",
        "#description-val",
        "[data-test-id='issue.views.field.rich-text.description']",
      ],
    };

    const summary = this._queryFirst(selectors.summary)?.textContent?.trim() || "";
    const description = this._queryFirst(selectors.description)?.textContent?.trim() || "";

    if (!summary && !description) {
      throw new Error("Could not read story from DOM");
    }

    return {
      key: issueKey,
      summary,
      description,
      descriptionHtml: "",
      acceptanceCriteria: "",  // Hard to reliably get custom fields from DOM
      storyPoints: "",
      issueType: "",
      status: "",
      priority: "",
      labels: [],
      components: [],
      epicKey: "",
      epicSummary: "",
      linkedIssues: [],
      subtasks: [],
      reporter: "",
      assignee: "",
      created: "",
      updated: "",
      _raw: null,
    };
  }

  /**
   * Fetch linked epic details for additional context.
   */
  async readEpic(epicKey) {
    if (!epicKey) return null;
    try {
      const response = await fetch(
        `/rest/api/${this.config.JIRA_API_VERSION}/issue/${epicKey}?expand=renderedFields`,
        { headers: { "Accept": "application/json" }, credentials: "same-origin" }
      );
      if (!response.ok) return null;
      const epic = await response.json();
      return {
        key: epic.key,
        summary: epic.fields.summary || "",
        description: this._stripHtml(epic.renderedFields?.description || epic.fields.description || ""),
      };
    } catch {
      return null;
    }
  }

  // ── Private helpers ────────────────────────────────────────

  _getCustomField(fields, configKey) {
    const fieldId = this.config.JIRA_CUSTOM_FIELDS[configKey];
    if (!fieldId) return "";
    const value = fields[fieldId];
    if (!value) return "";
    if (typeof value === "string") return value;
    if (typeof value === "object" && value.content) {
      // Atlassian Document Format (ADF) - extract text
      return this._extractAdfText(value);
    }
    return String(value);
  }

  _extractAdfText(adf) {
    if (!adf || !adf.content) return "";
    let text = "";
    const walk = (nodes) => {
      for (const node of nodes) {
        if (node.type === "text") text += node.text || "";
        if (node.content) walk(node.content);
      }
    };
    walk(adf.content);
    return text;
  }

  _stripHtml(html) {
    if (!html) return "";
    const div = document.createElement("div");
    div.innerHTML = html;
    return div.textContent || div.innerText || "";
  }

  _queryFirst(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }
}

// Export for use in content script
window.JiraReader = JiraReader;
