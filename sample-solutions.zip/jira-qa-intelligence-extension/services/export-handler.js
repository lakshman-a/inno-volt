/**
 * ============================================================
 * EXPORT HANDLER SERVICE
 * ============================================================
 * Handles exporting test plans in various formats.
 * ============================================================
 */

class ExportHandler {

  constructor(config) {
    this.config = config;
  }

  /**
   * Download test plan as a formatted text/markdown file.
   */
  downloadAsMarkdown(testPlan) {
    let md = `# Test Plan: ${testPlan.test_plan_title}\n`;
    md += `**Story:** ${testPlan.story_key}\n`;
    md += `**Total Test Cases:** ${testPlan.total_test_cases}\n`;
    md += `**Generated:** ${new Date().toISOString().split("T")[0]}\n\n---\n\n`;

    for (const cat of testPlan.categories) {
      md += `## ${cat.name}\n\n`;
      for (const tc of cat.test_cases) {
        md += `### ${tc.id}: ${tc.title}\n`;
        md += `- **Priority:** ${tc.priority}\n`;
        md += `- **Preconditions:** ${tc.preconditions}\n`;
        md += `- **Business Rule:** ${tc.business_rule}\n`;
        md += `- **Steps:**\n`;
        if (Array.isArray(tc.test_steps)) {
          tc.test_steps.forEach(step => { md += `  - ${typeof step === "string" ? step : step.action}\n`; });
        } else {
          md += `  - ${tc.test_steps}\n`;
        }
        md += `- **Expected Result:** ${tc.expected_result}\n`;
        md += `- **Test Data:** ${tc.test_data}\n\n`;
      }
    }

    if (testPlan.risks_and_assumptions) {
      md += `## Risks & Assumptions\n`;
      testPlan.risks_and_assumptions.forEach(r => { md += `- ${r}\n`; });
    }

    this._download(md, `test-plan-${testPlan.story_key}.md`, "text/markdown");
  }

  /**
   * Download test plan as CSV (importable to Excel/XRay).
   */
  downloadAsCsv(testPlan) {
    const headers = ["ID", "Category", "Title", "Priority", "Preconditions", "Steps", "Expected Result", "Test Data", "Business Rule"];
    const rows = [headers.join(",")];

    for (const cat of testPlan.categories) {
      for (const tc of cat.test_cases) {
        const steps = Array.isArray(tc.test_steps)
          ? tc.test_steps.map(s => typeof s === "string" ? s : s.action).join(" | ")
          : tc.test_steps;
        rows.push([
          tc.id, cat.name, this._csvEscape(tc.title), tc.priority,
          this._csvEscape(tc.preconditions), this._csvEscape(steps),
          this._csvEscape(tc.expected_result), this._csvEscape(tc.test_data),
          this._csvEscape(tc.business_rule),
        ].join(","));
      }
    }

    this._download(rows.join("\n"), `test-plan-${testPlan.story_key}.csv`, "text/csv");
  }

  /**
   * Download automation code files as individual files.
   */
  downloadAutomationFiles(automationResult) {
    for (const file of automationResult.files) {
      const ext = file.filename.split(".").pop();
      const mimeTypes = { feature: "text/plain", java: "text/x-java", ts: "text/typescript", js: "text/javascript" };
      this._download(file.content, file.filename, mimeTypes[ext] || "text/plain");
    }
  }

  /**
   * Copy test plan to clipboard as formatted text.
   */
  async copyToClipboard(testPlan) {
    const text = this._formatAsText(testPlan);
    await navigator.clipboard.writeText(text);
    return true;
  }

  // ── Private ────────────────────────────────────────────────

  _formatAsText(testPlan) {
    let text = `Test Plan: ${testPlan.test_plan_title}\nStory: ${testPlan.story_key}\n\n`;
    for (const cat of testPlan.categories) {
      text += `\n=== ${cat.name} ===\n`;
      for (const tc of cat.test_cases) {
        text += `\n[${tc.id}] ${tc.title} (${tc.priority})\n`;
        text += `Preconditions: ${tc.preconditions}\n`;
        text += `Steps: ${Array.isArray(tc.test_steps) ? tc.test_steps.join("; ") : tc.test_steps}\n`;
        text += `Expected: ${tc.expected_result}\n`;
      }
    }
    return text;
  }

  _csvEscape(str) {
    if (!str) return '""';
    return `"${String(str).replace(/"/g, '""')}"`;
  }

  _download(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

window.ExportHandler = ExportHandler;
