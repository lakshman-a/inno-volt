/**
 * ============================================================
 * QA INTELLIGENCE CONFIGURATION
 * ============================================================
 * 
 * EDIT THIS FILE to configure the extension for your environment.
 * All configurable items are in this single file.
 * 
 * COPILOT/AI INSTRUCTION: When updating this config, only modify
 * the values - do not change the CONFIG object structure.
 * ============================================================
 */

const CONFIG = {

  // ── BACKEND API ──────────────────────────────────────────
  // Your FastAPI backend URL that calls GenAI Gateway
  // For local development: http://localhost:8000
  // For deployed: https://your-backend.enterprisef.com
  BACKEND_URL: "http://localhost:8000",

  // ── GENAI GATEWAY (used by backend, shown here for reference) ──
  // The actual gateway calls happen in the Python backend
  // These are stored here for the popup settings UI
  GATEWAY_URL: "https://genai.enterprisef.com/v2/generation/text",
  GATEWAY_MODEL_VENDOR: "google",          // google, openai, aws, anthropic
  GATEWAY_MODEL_NAME: "gemini-1.5-pro",    // Model name per gateway docs

  // ── JIRA CONFIGURATION ───────────────────────────────────
  // Your Jira base URL (without trailing slash)
  JIRA_BASE_URL: "https://your-org.atlassian.net",
  
  // Jira REST API version
  JIRA_API_VERSION: "2",
  
  // Custom field IDs - find these in your Jira admin or by inspecting
  // a story's REST API response: GET /rest/api/2/issue/PROJ-123
  JIRA_CUSTOM_FIELDS: {
    ACCEPTANCE_CRITERIA: "customfield_10001",  // Change to your field ID
    STORY_POINTS: "customfield_10002",         // Change to your field ID
    SPRINT: "customfield_10003",               // Change to your field ID
  },

  // ── CONFLUENCE CONFIGURATION ─────────────────────────────
  // Base URL for Confluence REST API
  CONFLUENCE_BASE_URL: "https://your-org.atlassian.net/wiki",
  
  // Default space key to search for architecture docs
  CONFLUENCE_DEFAULT_SPACE: "TEAMSPACE",
  
  // Maximum number of Confluence pages to fetch for context
  CONFLUENCE_MAX_PAGES: 3,

  // ── SWAGGER / OPENAPI CONFIGURATION ──────────────────────
  // Default Swagger/OpenAPI spec URL (can be overridden per-story)
  SWAGGER_URL: "",

  // ── XRAY CONFIGURATION ───────────────────────────────────
  // XRay REST API base URL
  XRAY_BASE_URL: "https://your-org.atlassian.net/rest/raven/1.0",
  
  // Default test plan project key
  XRAY_PROJECT_KEY: "PROJ",

  // ── SCORING CONFIGURATION ────────────────────────────────
  // Weights for story clarity scoring (must sum to 1.0)
  SCORING_WEIGHTS: {
    ACCEPTANCE_CRITERIA: 0.25,
    FIELD_VALIDATIONS: 0.20,
    ERROR_SCENARIOS: 0.20,
    API_CONTRACT: 0.15,
    STATE_TRANSITIONS: 0.10,
    DEPENDENCIES: 0.10,
  },

  // Score thresholds for color coding
  SCORE_THRESHOLDS: {
    GOOD: 7,      // >= 7 = green
    MEDIUM: 4,    // >= 4 = orange
    // < 4 = red
  },

  // ── UI CONFIGURATION ─────────────────────────────────────
  // Panel position: "right" or "bottom"
  PANEL_POSITION: "right",
  
  // Panel width in pixels (when position is "right")
  PANEL_WIDTH: 420,
  
  // Auto-score when story loads (true) or wait for user click (false)
  AUTO_SCORE: true,

  // ── TEST PLAN CONFIGURATION ──────────────────────────────
  // Categories to include in generated test plans
  TEST_CATEGORIES: [
    "Positive Scenarios",
    "Negative Scenarios",
    "Boundary Value Cases",
    "Security Cases",
    "Performance Considerations",
    "Data Integrity Cases",
  ],

  // Output format for test cases
  TEST_CASE_FORMAT: "gherkin",  // "gherkin", "table", "structured"
  
  // Framework for automation export
  AUTOMATION_FRAMEWORK: "cucumber",  // "cucumber", "playwright", "karate"
};

// Do not modify below this line
if (typeof window !== "undefined") {
  window.QA_INTELLIGENCE_CONFIG = CONFIG;
}
if (typeof module !== "undefined") {
  module.exports = CONFIG;
}
