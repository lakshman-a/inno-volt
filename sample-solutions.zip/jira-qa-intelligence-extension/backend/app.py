"""
============================================================
QA INTELLIGENCE - PYTHON BACKEND (FastAPI)
============================================================
Backend API that the Chrome extension calls.
Routes requests to GenAI Gateway for scoring and test plan generation.

SETUP:
  pip install fastapi uvicorn httpx python-dotenv
  cp .env.example .env    # Edit with your values
  uvicorn backend.app:app --reload --port 8000

COPILOT/AI INSTRUCTION: This is the backend for the QA Intelligence
Chrome extension. It receives story data, enriches it with context,
builds prompts, and calls the GenAI Gateway.
============================================================
"""

import json
import os
import httpx
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="QA Intelligence Backend", version="1.0.0")

# CORS - allow Chrome extension to call this backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to your Jira domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Configuration from environment ────────────────────────────
GENAI_GATEWAY_URL = os.getenv("GENAI_GATEWAY_URL", "https://genai.enterprisef.com/v2/generation/text")
GENAI_API_KEY     = os.getenv("GENAI_API_KEY", "")
MODEL_VENDOR      = os.getenv("MODEL_VENDOR", "google")
MODEL_NAME        = os.getenv("MODEL_NAME", "gemini-1.5-pro")
CONFLUENCE_URL    = os.getenv("CONFLUENCE_BASE_URL", "")
CONFLUENCE_TOKEN  = os.getenv("CONFLUENCE_API_TOKEN", "")
CONFLUENCE_EMAIL  = os.getenv("CONFLUENCE_EMAIL", "")


# ── Request models ────────────────────────────────────────────
class StoryData(BaseModel):
    key: str = ""
    summary: str = ""
    description: str = ""
    acceptanceCriteria: str = ""
    issueType: str = ""
    labels: list = []
    components: list = []
    epicKey: str = ""
    linkedIssues: list = []
    subtasks: list = []

class ScoreRequest(BaseModel):
    story: StoryData
    epic: Optional[dict] = None
    scoring_weights: Optional[dict] = None

class TestPlanRequest(BaseModel):
    story: StoryData
    epic: Optional[dict] = None
    confluence_context: str = ""
    confluence_space: str = ""
    swagger_url: str = ""
    qa_examples: str = ""
    test_categories: list = []
    test_format: str = "gherkin"

class AutomationRequest(BaseModel):
    test_plan: dict
    framework: str = "cucumber"

class XrayExportRequest(BaseModel):
    test_plan: dict
    project_key: str = "PROJ"


# ── Health check ──────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "gateway_url": GENAI_GATEWAY_URL}


# ── Score Story ───────────────────────────────────────────────
@app.post("/api/score-story")
async def score_story(request: ScoreRequest):
    """Score a story for clarity and testability."""
    prompt = _build_scoring_prompt(request.story, request.epic)
    result = await _call_gateway(prompt)
    try:
        return json.loads(result)
    except json.JSONDecodeError:
        # Try to extract JSON from response
        import re
        match = re.search(r'\{.*\}', result, re.DOTALL)
        if match:
            return json.loads(match.group())
        raise HTTPException(status_code=500, detail=f"Invalid JSON response from LLM: {result[:500]}")


# ── Generate Test Plan ────────────────────────────────────────
@app.post("/api/generate-test-plan")
async def generate_test_plan(request: TestPlanRequest):
    """Generate a comprehensive test plan from story data."""
    
    # Enrich with Confluence context if configured
    confluence_ctx = request.confluence_context
    if not confluence_ctx and request.confluence_space and CONFLUENCE_URL:
        confluence_ctx = await _fetch_confluence_context(
            request.confluence_space, request.story.summary
        )
    
    # Fetch Swagger spec if URL provided
    swagger_ctx = ""
    if request.swagger_url:
        swagger_ctx = await _fetch_swagger(request.swagger_url)
    
    prompt = _build_test_plan_prompt(
        request.story, request.epic,
        confluence_ctx, swagger_ctx,
        request.qa_examples, request.test_categories, request.test_format
    )
    
    result = await _call_gateway(prompt)
    try:
        return json.loads(result)
    except json.JSONDecodeError:
        import re
        match = re.search(r'\{.*\}', result, re.DOTALL)
        if match:
            return json.loads(match.group())
        raise HTTPException(status_code=500, detail=f"Invalid JSON from LLM: {result[:500]}")


# ── Generate Automation Code ──────────────────────────────────
@app.post("/api/generate-automation")
async def generate_automation(request: AutomationRequest):
    """Generate automation test code from a test plan."""
    prompt = _build_automation_prompt(request.test_plan, request.framework)
    result = await _call_gateway(prompt)
    try:
        return json.loads(result)
    except json.JSONDecodeError:
        import re
        match = re.search(r'\{.*\}', result, re.DOTALL)
        if match:
            return json.loads(match.group())
        raise HTTPException(status_code=500, detail="Failed to generate automation code")


# ── Export to XRay ────────────────────────────────────────────
@app.post("/api/export-xray")
async def export_to_xray(request: XrayExportRequest):
    """Export test plan to XRay test management."""
    # TODO: Implement XRay REST API integration
    # This is a placeholder - implement based on your XRay setup
    return {
        "status": "not_implemented",
        "message": "XRay export requires configuration. See README.",
        "created_tests": []
    }


# ── GenAI Gateway Call ────────────────────────────────────────
async def _call_gateway(prompt: str, max_retries: int = 2) -> str:
    """
    Call the GenAI Gateway v2/generation/text endpoint.
    
    IMPORTANT: Adjust the payload structure to match your
    GenAI Gateway's exact API contract. The structure below
    follows the documentation shown in the enterprisef GenAI
    Gateway docs (promptSpec with messages).
    """
    payload = {
        "promptSpec": {
            "messages": [
                {"role": "user", "content": prompt}
            ]
        },
        "model": {
            "vendor": MODEL_VENDOR,
            "name": MODEL_NAME,
        },
        # Optional: Add gateway params as needed
        # "gatewayParams": {},
        # "preModeration": {},
        # "postModeration": {},
    }
    
    headers = {
        "Content-Type": "application/json",
    }
    if GENAI_API_KEY:
        headers["Authorization"] = f"Bearer {GENAI_API_KEY}"
    
    for attempt in range(max_retries + 1):
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.post(
                    GENAI_GATEWAY_URL,
                    json=payload,
                    headers=headers,
                )
                response.raise_for_status()
                data = response.json()
                
                # ── Extract text from response ──────────────
                # Adjust based on your gateway's response format
                # Common patterns:
                if "choices" in data:
                    return data["choices"][0]["message"]["content"]
                elif "content" in data:
                    return data["content"]
                elif "response" in data:
                    return data["response"]
                else:
                    return json.dumps(data)
                    
        except httpx.HTTPStatusError as e:
            if attempt == max_retries:
                raise HTTPException(
                    status_code=502,
                    detail=f"GenAI Gateway error: {e.response.status_code} - {e.response.text[:500]}"
                )
        except Exception as e:
            if attempt == max_retries:
                raise HTTPException(status_code=502, detail=f"Gateway call failed: {str(e)}")
        
        # Wait before retry
        import asyncio
        await asyncio.sleep(2 ** attempt)


# ── Confluence Context Fetcher ────────────────────────────────
async def _fetch_confluence_context(space_key: str, search_query: str) -> str:
    """Fetch relevant Confluence pages for context enrichment."""
    if not CONFLUENCE_URL or not CONFLUENCE_TOKEN:
        return ""
    
    try:
        search_url = f"{CONFLUENCE_URL}/rest/api/content/search"
        params = {
            "cql": f'space="{space_key}" AND type="page" AND text~"{search_query}"',
            "limit": 3,
            "expand": "body.storage",
        }
        
        auth = (CONFLUENCE_EMAIL, CONFLUENCE_TOKEN) if CONFLUENCE_EMAIL else None
        headers = {"Authorization": f"Bearer {CONFLUENCE_TOKEN}"} if not CONFLUENCE_EMAIL else {}
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(search_url, params=params, auth=auth, headers=headers)
            if not response.is_success:
                return ""
            data = response.json()
            
            context_parts = []
            for result in data.get("results", [])[:3]:
                title = result.get("title", "")
                # Strip HTML from Confluence storage format
                body = result.get("body", {}).get("storage", {}).get("value", "")
                import re
                text = re.sub(r'<[^>]+>', ' ', body)
                text = re.sub(r'\s+', ' ', text).strip()
                context_parts.append(f"Page: {title}\n{text[:2000]}")
            
            return "\n\n---\n\n".join(context_parts)
    except Exception as e:
        print(f"Confluence fetch error: {e}")
        return ""


# ── Swagger Fetcher ───────────────────────────────────────────
async def _fetch_swagger(swagger_url: str) -> str:
    """Fetch and summarize a Swagger/OpenAPI specification."""
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.get(swagger_url)
            if not response.is_success:
                return ""
            spec = response.json()
            
            # Extract key parts: paths, schemas
            summary_parts = []
            if "info" in spec:
                summary_parts.append(f"API: {spec['info'].get('title', '')} v{spec['info'].get('version', '')}")
            
            if "paths" in spec:
                for path, methods in list(spec["paths"].items())[:20]:  # Limit paths
                    for method, details in methods.items():
                        if method in ("get", "post", "put", "delete", "patch"):
                            summary_parts.append(
                                f"{method.upper()} {path}: {details.get('summary', details.get('description', ''))[:100]}"
                            )
            
            return "\n".join(summary_parts[:30])  # Limit total context
    except Exception as e:
        print(f"Swagger fetch error: {e}")
        return ""


# ── Prompt Builders ───────────────────────────────────────────
# These mirror the JavaScript PromptBuilder but run server-side

def _build_scoring_prompt(story: StoryData, epic: Optional[dict]) -> str:
    epic_section = ""
    if epic:
        epic_section = f"\nEpic: {epic.get('key', '')} - {epic.get('summary', '')}\n{epic.get('description', '')}"

    return f"""You are a Senior QA Engineer evaluating a Jira user story for testability and completeness.

SCORING CRITERIA (with weights):
- Acceptance Criteria (25%): Are there explicit, testable acceptance criteria?
- Field/Data Validations (20%): Are input fields, formats, ranges specified?
- Error/Negative Scenarios (20%): Does it mention failure/invalid scenarios?
- API Contract Details (15%): Are endpoints, formats, status codes defined?
- State Transitions (10%): Are valid state changes documented?
- Dependencies/Preconditions (10%): Are prerequisites and dependencies listed?

STORY TO EVALUATE:
Key: {story.key}
Type: {story.issueType or "Story"}
Summary: {story.summary}
Description: {story.description or "EMPTY"}
Acceptance Criteria: {story.acceptanceCriteria or "MISSING"}
Components: {", ".join(story.components) or "None"}
Labels: {", ".join(story.labels) or "None"}
{epic_section}

RESPOND WITH ONLY THIS JSON (no markdown, no backticks):
{{"score": <1-10>, "breakdown": {{"acceptance_criteria": {{"score": <1-10>, "feedback": "..."}}, "field_validations": {{"score": <1-10>, "feedback": "..."}}, "error_scenarios": {{"score": <1-10>, "feedback": "..."}}, "api_contract": {{"score": <1-10>, "feedback": "..."}}, "state_transitions": {{"score": <1-10>, "feedback": "..."}}, "dependencies": {{"score": <1-10>, "feedback": "..."}}}}, "missing": ["..."], "suggestions": ["..."], "testability_summary": "..."}}"""


def _build_test_plan_prompt(story, epic, confluence_ctx, swagger_ctx, qa_examples, categories, fmt):
    context = ""
    if epic:
        context += f"\nEPIC: {epic.get('key', '')} - {epic.get('summary', '')}\n{epic.get('description', '')}\n"
    if confluence_ctx:
        context += f"\nPRODUCT CONTEXT (Confluence):\n{confluence_ctx}\n"
    if swagger_ctx:
        context += f"\nAPI SPEC (Swagger):\n{swagger_ctx}\n"

    cats = "\n".join(f"{i+1}. {c}" for i, c in enumerate(categories)) if categories else "1. Positive\n2. Negative\n3. Boundary\n4. Security"
    
    return f"""You are an expert QA Engineer. Generate a comprehensive test plan.

Think like a QA: cover boundary values, business rule violations, negative scenarios, data integrity, and edge cases.
{context}
{f"QA EXAMPLES (match this style):{chr(10)}{qa_examples}" if qa_examples else ""}

STORY:
Key: {story.key}
Summary: {story.summary}
Description: {story.description or "Not specified"}
Acceptance Criteria: {story.acceptanceCriteria or "Not specified"}
Components: {", ".join(story.components) or "None"}

CATEGORIES:
{cats}

RESPOND WITH ONLY JSON (no markdown):
{{"story_key": "{story.key}", "test_plan_title": "...", "total_test_cases": <n>, "categories": [{{"name": "...", "test_cases": [{{"id": "TC-001", "title": "...", "priority": "High|Medium|Low", "preconditions": "...", "test_steps": ["Step 1: ...", "Step 2: ..."], "expected_result": "...", "test_data": "...", "business_rule": "..."}}]}}], "automation_notes": "...", "risks_and_assumptions": ["..."]}}"""


def _build_automation_prompt(test_plan, framework):
    fw_instructions = {
        "cucumber": "Generate Cucumber BDD .feature files with Gherkin syntax. Include step definition stubs in Java.",
        "playwright": "Generate Playwright test files in TypeScript with page object model.",
        "karate": "Generate Karate DSL feature files for API testing.",
    }
    return f"""Convert this test plan into {framework} automation code.

{fw_instructions.get(framework, fw_instructions["cucumber"])}

TEST PLAN:
{json.dumps(test_plan, indent=2)}

Respond with JSON only:
{{"files": [{{"filename": "path/to/file.feature", "content": "file content", "type": "feature|step_definition|config"}}]}}"""


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
