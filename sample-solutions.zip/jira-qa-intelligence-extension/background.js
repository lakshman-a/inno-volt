/**
 * Background service worker for QA Intelligence extension.
 * Handles cross-origin requests and storage.
 */
chrome.runtime.onInstalled.addListener(() => {
  console.log("[QA-Intelligence] Extension installed");
});

// Listen for messages from content script (if needed for CORS)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "FETCH_API") {
    fetch(request.url, request.options)
      .then(r => r.json())
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true; // async response
  }
});
