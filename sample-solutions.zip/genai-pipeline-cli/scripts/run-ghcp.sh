#!/bin/bash
# ============================================================
# GENAI PIPELINE - GITHUB COPILOT CLI RUNNER
# ============================================================
# Uses GitHub Copilot CLI (ghcp) to process code improvements.
# GHCP can understand project context and make intelligent changes.
#
# Prerequisites:
#   - gh CLI installed and authenticated
#   - GitHub Copilot CLI extension: gh extension install github/gh-copilot
#   - Copilot access enabled for your account
#
# Usage:
#   ./scripts/run-ghcp.sh --repo org/repo --branch develop --use-case unit-test-gen
#   ./scripts/run-ghcp.sh --repo org/repo --branch develop --use-case sonar-fix --dry-run
# ============================================================

set -euo pipefail

# ── Parse arguments ───────────────────────────────────────────
REPO=""
BRANCH="develop"
USE_CASE="unit-test-gen"
DRY_RUN=false
WORK_DIR="/tmp/genai-pipeline-cli"

while [[ $# -gt 0 ]]; do
    case $1 in
        --repo)     REPO="$2"; shift 2 ;;
        --branch)   BRANCH="$2"; shift 2 ;;
        --use-case) USE_CASE="$2"; shift 2 ;;
        --dry-run)  DRY_RUN=true; shift ;;
        --work-dir) WORK_DIR="$2"; shift 2 ;;
        *)          echo "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$REPO" ]]; then
    echo "Usage: ./scripts/run-ghcp.sh --repo org/repo --branch develop --use-case unit-test-gen"
    exit 1
fi

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BRANCH_NAME="genai/${USE_CASE}-${TIMESTAMP}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
RESULT_FILE="${PROJECT_DIR}/results/${TIMESTAMP}_${REPO//\//_}_${USE_CASE}.json"

echo "============================================================"
echo "GenAI Pipeline - GitHub Copilot CLI"
echo "============================================================"
echo "Repo:     ${REPO}"
echo "Branch:   ${BRANCH}"
echo "Use Case: ${USE_CASE}"
echo "Dry Run:  ${DRY_RUN}"
echo "============================================================"

# ── Step 1: Clone repo ────────────────────────────────────────
echo ""
echo "[1/5] Cloning ${REPO}..."
REPO_DIR="${WORK_DIR}/${REPO//\//_}"
rm -rf "${REPO_DIR}"
mkdir -p "${WORK_DIR}"
gh repo clone "${REPO}" "${REPO_DIR}" -- --branch "${BRANCH}" --depth 1
echo "  Cloned to: ${REPO_DIR}"

cd "${REPO_DIR}"

# ── Step 2: Load the prompt/skill for this use case ───────────
echo ""
echo "[2/5] Loading prompt for ${USE_CASE}..."
PROMPT_FILE="${PROJECT_DIR}/prompts/${USE_CASE}.prompt"
SKILL_FILE="${PROJECT_DIR}/skills/${USE_CASE}.md"

if [[ -f "$SKILL_FILE" ]]; then
    PROMPT_CONTENT=$(cat "$SKILL_FILE")
    echo "  Loaded skill: ${SKILL_FILE}"
elif [[ -f "$PROMPT_FILE" ]]; then
    PROMPT_CONTENT=$(cat "$PROMPT_FILE")
    echo "  Loaded prompt: ${PROMPT_FILE}"
else
    echo "  ERROR: No prompt file found for ${USE_CASE}"
    exit 1
fi

# ── Step 3: Run GitHub Copilot CLI ────────────────────────────
echo ""
echo "[3/5] Running GitHub Copilot CLI..."
echo "  This may take 1-5 minutes depending on project size..."

# Method 1: Using gh copilot suggest for code changes
# Note: ghcp capabilities evolve - check latest docs
# The --shell-out approach pipes the prompt to copilot

# For now, we use the suggest command with workspace context
gh copilot suggest "${PROMPT_CONTENT}" 2>&1 | tee /tmp/ghcp-output.txt || {
    echo "  NOTE: gh copilot suggest may not support this mode yet."
    echo "  Falling back to explain + manual approach..."
    
    # Alternative: Use copilot explain to get recommendations,
    # then apply via the GenAI Gateway pipeline
    echo "  Consider using the gateway pipeline (genai-pipeline-gateway/) instead."
}

# ── Step 4: Validate changes ─────────────────────────────────
echo ""
echo "[4/5] Validating changes..."

COMPILATION_OK=false
TESTS_OK=false

if command -v mvn &> /dev/null && [[ -f "pom.xml" ]]; then
    echo "  Running: mvn compile..."
    if mvn compile -q 2>/dev/null; then
        COMPILATION_OK=true
        echo "  Compilation: PASS"
        
        echo "  Running: mvn test..."
        if mvn test -q 2>/dev/null; then
            TESTS_OK=true
            echo "  Tests: PASS"
        else
            echo "  Tests: FAIL (non-blocking)"
        fi
    else
        echo "  Compilation: FAIL"
    fi
elif command -v gradle &> /dev/null && [[ -f "build.gradle" ]]; then
    echo "  Running: gradle build..."
    if gradle build -q 2>/dev/null; then
        COMPILATION_OK=true
        TESTS_OK=true
        echo "  Build: PASS"
    fi
else
    echo "  No build tool detected, skipping validation"
fi

# ── Step 5: Commit and PR ────────────────────────────────────
echo ""
if [[ "$DRY_RUN" == "true" ]]; then
    echo "[5/5] DRY RUN - Skipping commit and PR"
    echo "  Changed files:"
    git diff --name-only 2>/dev/null || echo "  (no changes detected)"
else
    echo "[5/5] Creating branch and PR..."
    
    # Check if there are changes
    if git diff --quiet && git diff --cached --quiet; then
        echo "  No changes to commit."
    else
        git config user.email "genai-pipeline@enterprisef.com"
        git config user.name "GenAI Pipeline (GHCP)"
        git checkout -b "${BRANCH_NAME}"
        git add -A
        
        CHANGED_FILES=$(git diff --cached --name-only | head -20)
        FILE_COUNT=$(git diff --cached --name-only | wc -l)
        
        git commit -m "[GenAI-GHCP] ${USE_CASE}: auto-generated improvements

Files changed: ${FILE_COUNT}
Generated by: GitHub Copilot CLI Pipeline
Timestamp: ${TIMESTAMP}"
        
        git push origin "${BRANCH_NAME}"
        
        PR_URL=$(gh pr create \
            --title "[GenAI-GHCP] ${USE_CASE}: auto-generated improvements" \
            --body "## Auto-Generated by GenAI Pipeline (GitHub Copilot CLI)

**Use Case:** ${USE_CASE}
**Source Branch:** ${BRANCH}
**Files Changed:** ${FILE_COUNT}

### Changed Files
\`\`\`
${CHANGED_FILES}
\`\`\`

### Validation
- Compilation: $(if $COMPILATION_OK; then echo '✅ PASS'; else echo '❌ FAIL'; fi)
- Tests: $(if $TESTS_OK; then echo '✅ PASS'; else echo '⚠️ FAIL/SKIPPED'; fi)

> Auto-generated. Human review required before merge." \
            --base "${BRANCH}" \
            --head "${BRANCH_NAME}" \
            --label "genai-generated" 2>&1) || PR_URL="PR creation failed"
        
        echo "  PR: ${PR_URL}"
    fi
fi

# ── Save result ───────────────────────────────────────────────
mkdir -p "$(dirname "$RESULT_FILE")"
cat > "$RESULT_FILE" << RESULT_JSON
{
  "repo": "${REPO}",
  "branch": "${BRANCH}",
  "use_case": "${USE_CASE}",
  "engine": "ghcp",
  "timestamp": "${TIMESTAMP}",
  "compilation_ok": ${COMPILATION_OK},
  "tests_ok": ${TESTS_OK},
  "dry_run": ${DRY_RUN},
  "branch_name": "${BRANCH_NAME}",
  "pr_url": "${PR_URL:-none}"
}
RESULT_JSON

echo ""
echo "============================================================"
echo "COMPLETE. Result saved: ${RESULT_FILE}"
echo "============================================================"
