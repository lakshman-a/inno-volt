#!/bin/bash
# ============================================================
# GENAI PIPELINE - CLAUDE CLI RUNNER
# ============================================================
# Uses Claude Code CLI to process entire projects with full context.
# Claude CLI can read all project files and make coordinated changes.
#
# Prerequisites:
#   - Claude CLI installed: npm install -g @anthropic-ai/claude-code
#   - ANTHROPIC_API_KEY environment variable set
#   - gh CLI for PR creation
#
# Usage:
#   ./scripts/run-claude.sh --repo org/repo --branch develop --use-case unit-test-gen
#   ./scripts/run-claude.sh --repo org/repo --use-case sonar-fix --dry-run
#
# NOTE: Claude Code is currently in Evaluation at enterprisef.
# Check approval status before using in production pipelines.
# ============================================================

set -euo pipefail

# ── Parse arguments ───────────────────────────────────────────
REPO=""
BRANCH="develop"
USE_CASE="unit-test-gen"
DRY_RUN=false
WORK_DIR="/tmp/genai-pipeline-claude"

while [[ $# -gt 0 ]]; do
    case $1 in
        --repo)     REPO="$2"; shift 2 ;;
        --branch)   BRANCH="$2"; shift 2 ;;
        --use-case) USE_CASE="$2"; shift 2 ;;
        --dry-run)  DRY_RUN=true; shift ;;
        --work-dir) WORK_DIR="$2"; shift 2 ;;
        *)          echo "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$REPO" ]]; then
    echo "Usage: ./scripts/run-claude.sh --repo org/repo --branch develop --use-case unit-test-gen"
    exit 1
fi

# ── Verify prerequisites ─────────────────────────────────────
if ! command -v claude &> /dev/null; then
    echo "ERROR: Claude CLI not found."
    echo "Install: npm install -g @anthropic-ai/claude-code"
    echo "Docs: https://docs.anthropic.com/en/docs/claude-code"
    exit 1
fi

if [[ -z "${ANTHROPIC_API_KEY:-}" ]]; then
    echo "ERROR: ANTHROPIC_API_KEY environment variable not set."
    exit 1
fi

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BRANCH_NAME="genai/claude-${USE_CASE}-${TIMESTAMP}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
RESULT_FILE="${PROJECT_DIR}/results/${TIMESTAMP}_${REPO//\//_}_claude_${USE_CASE}.json"

echo "============================================================"
echo "GenAI Pipeline - Claude Code CLI"
echo "============================================================"
echo "Repo:     ${REPO}"
echo "Branch:   ${BRANCH}"
echo "Use Case: ${USE_CASE}"
echo "============================================================"

# ── Step 1: Clone repo ────────────────────────────────────────
echo ""
echo "[1/5] Cloning ${REPO}..."
REPO_DIR="${WORK_DIR}/${REPO//\//_}"
rm -rf "${REPO_DIR}"
mkdir -p "${WORK_DIR}"
gh repo clone "${REPO}" "${REPO_DIR}" -- --branch "${BRANCH}" --depth 1
cd "${REPO_DIR}"

# ── Step 2: Load Claude prompt ────────────────────────────────
echo ""
echo "[2/5] Loading prompt for ${USE_CASE}..."
PROMPT_FILE="${PROJECT_DIR}/prompts/claude-${USE_CASE}.md"

if [[ ! -f "$PROMPT_FILE" ]]; then
    echo "  ERROR: Prompt file not found: ${PROMPT_FILE}"
    exit 1
fi

PROMPT=$(cat "$PROMPT_FILE")
echo "  Loaded: ${PROMPT_FILE}"

# ── Step 3: Run Claude CLI ────────────────────────────────────
echo ""
echo "[3/5] Running Claude Code CLI..."
echo "  Claude will analyze the entire project and make changes."
echo "  This may take 2-10 minutes..."

# Claude CLI in non-interactive mode with full project context
# --print: output to stdout instead of interactive mode
# --dangerously-skip-permissions: allow file modifications (pipeline use)
claude --print --dangerously-skip-permissions \
    "${PROMPT}" \
    2>&1 | tee /tmp/claude-output.txt

echo "  Claude processing complete."

# ── Step 4: Validate ─────────────────────────────────────────
echo ""
echo "[4/5] Validating changes..."

COMPILATION_OK=false
TESTS_OK=false

if [[ -f "pom.xml" ]]; then
    if mvn compile -q 2>/dev/null; then
        COMPILATION_OK=true
        echo "  Compilation: PASS"
        if mvn test -q 2>/dev/null; then
            TESTS_OK=true
            echo "  Tests: PASS"
        else
            echo "  Tests: FAIL"
            
            # Let Claude try to fix test failures
            echo "  Asking Claude to fix test failures..."
            TEST_ERRORS=$(mvn test 2>&1 | tail -50)
            claude --print --dangerously-skip-permissions \
                "The tests failed with these errors. Fix them:\n${TEST_ERRORS}" \
                2>&1 | tee -a /tmp/claude-output.txt
            
            # Retry tests
            if mvn test -q 2>/dev/null; then
                TESTS_OK=true
                echo "  Tests (retry): PASS"
            fi
        fi
    else
        echo "  Compilation: FAIL"
        
        # Let Claude fix compilation errors
        echo "  Asking Claude to fix compilation errors..."
        COMP_ERRORS=$(mvn compile 2>&1 | tail -30)
        claude --print --dangerously-skip-permissions \
            "Compilation failed with these errors. Fix them:\n${COMP_ERRORS}" \
            2>&1 | tee -a /tmp/claude-output.txt
        
        if mvn compile -q 2>/dev/null; then
            COMPILATION_OK=true
            echo "  Compilation (retry): PASS"
        fi
    fi
fi

# ── Step 5: Commit and PR ────────────────────────────────────
echo ""
CHANGED_FILES=$(git diff --name-only 2>/dev/null || echo "")
FILE_COUNT=$(echo "$CHANGED_FILES" | grep -c . || echo "0")

if [[ "$FILE_COUNT" -eq 0 ]]; then
    echo "[5/5] No changes detected."
elif [[ "$DRY_RUN" == "true" ]]; then
    echo "[5/5] DRY RUN - Changes detected but not committed:"
    echo "$CHANGED_FILES"
else
    echo "[5/5] Creating branch and PR..."
    git config user.email "genai-pipeline@enterprisef.com"
    git config user.name "GenAI Pipeline (Claude)"
    git checkout -b "${BRANCH_NAME}"
    git add -A
    git commit -m "[GenAI-Claude] ${USE_CASE}: AI-powered improvements

Files changed: ${FILE_COUNT}
Engine: Claude Code CLI
Timestamp: ${TIMESTAMP}
Compilation: $(if $COMPILATION_OK; then echo 'PASS'; else echo 'FAIL'; fi)
Tests: $(if $TESTS_OK; then echo 'PASS'; else echo 'FAIL'; fi)"
    
    git push origin "${BRANCH_NAME}"
    
    PR_URL=$(gh pr create \
        --title "[GenAI-Claude] ${USE_CASE}: AI-powered improvements" \
        --body "## Auto-Generated by GenAI Pipeline (Claude Code CLI)

**Use Case:** ${USE_CASE}
**Source Branch:** ${BRANCH}
**Engine:** Claude Code CLI (whole-project context)
**Files Changed:** ${FILE_COUNT}

### Changed Files
\`\`\`
${CHANGED_FILES}
\`\`\`

### Validation
- Compilation: $(if $COMPILATION_OK; then echo '✅ PASS'; else echo '❌ FAIL'; fi)
- Tests: $(if $TESTS_OK; then echo '✅ PASS'; else echo '⚠️ FAIL/SKIPPED'; fi)

### Why Claude CLI?
Claude analyzes the entire project with full context awareness, understanding imports, 
dependencies, and architecture patterns. This produces higher quality changes than 
file-by-file processing.

> Auto-generated. Human review required before merge." \
        --base "${BRANCH}" \
        --head "${BRANCH_NAME}" \
        --label "genai-generated" 2>&1) || PR_URL="PR creation failed"
    
    echo "  PR: ${PR_URL}"
fi

# ── Save result ───────────────────────────────────────────────
mkdir -p "$(dirname "$RESULT_FILE")"
cat > "$RESULT_FILE" << RESULT_JSON
{
  "repo": "${REPO}",
  "branch": "${BRANCH}",
  "use_case": "${USE_CASE}",
  "engine": "claude-cli",
  "timestamp": "${TIMESTAMP}",
  "files_changed": ${FILE_COUNT},
  "compilation_ok": ${COMPILATION_OK},
  "tests_ok": ${TESTS_OK},
  "dry_run": ${DRY_RUN},
  "branch_name": "${BRANCH_NAME}",
  "pr_url": "${PR_URL:-none}"
}
RESULT_JSON

echo ""
echo "============================================================"
echo "COMPLETE. Result: ${RESULT_FILE}"
echo "============================================================"
