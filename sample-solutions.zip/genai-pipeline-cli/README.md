# GenAI Pipeline - CLI Engines (GitHub Copilot + Claude)

Automated code improvement pipeline using GitHub Copilot CLI and Claude CLI as processing engines. Clones a repo, runs AI-powered code generation/fix, validates, and raises a PR.

## Project Structure

```
genai-pipeline-cli/
├── Jenkinsfile                         # Jenkins declarative pipeline
├── config.yaml.example                 # ★ Configuration template
├── scripts/
│   ├── run-ghcp.sh                     # ★ GitHub Copilot CLI runner
│   └── run-claude.sh                   # ★ Claude CLI runner
├── skills/                             # Custom instruction files
│   ├── unit-test-gen.md                # ★ QA-grade unit test instructions
│   ├── functional-test-gen.md          # ★ BDD functional test instructions
│   └── sonar-fix.md                    # ★ Sonar issue fix instructions
├── prompts/                            # Prompt templates (for Claude CLI)
│   ├── claude-unit-test-gen.md         # Claude-specific unit test prompt
│   ├── claude-functional-test-gen.md   # Claude-specific FT prompt
│   └── claude-sonar-fix.md             # Claude-specific sonar prompt
├── results/                            # Execution results (auto-generated)
└── README.md                           # This file
```

## Quick Start (POC with your personal account)

### Prerequisites

```bash
# GitHub CLI - must be installed and authenticated
gh --version
gh auth status

# For GHCP: Install Copilot extension
gh extension install github/gh-copilot

# For Claude CLI: Install Claude Code
# See: https://docs.anthropic.com/en/docs/claude-code
claude --version
```

### Step 1: Get your GitHub token

```bash
# This prints your Personal Access Token
gh auth token
# Copy this - you'll need it for Jenkins
```

### Step 2: Configure

```bash
cp config.yaml.example config.yaml
# Edit config.yaml with your settings
```

### Step 3: Run from command line (test locally first)

```bash
# GitHub Copilot CLI
./scripts/run-ghcp.sh --repo your-org/your-repo --branch develop --use-case unit-test-gen --dry-run

# Claude CLI
export ANTHROPIC_API_KEY="your-key"
./scripts/run-claude.sh --repo your-org/your-repo --branch develop --use-case unit-test-gen --dry-run
```

### Step 4: Run from Jenkins

1. **Add credentials in Jenkins:**
   - `gh-cli-token-poc`: Secret text → your GitHub PAT
   - `anthropic-api-key`: Secret text → your Anthropic API key

2. **Create a Jenkins job:**
   - New Item → Pipeline (or Freestyle)
   - For Pipeline: point to this repo's Jenkinsfile
   - For Freestyle: add a build step that runs `./scripts/run-ghcp.sh`

3. **Run with parameters:**
   - REPO: `your-org/your-repo`
   - BRANCH: `develop`
   - USE_CASE: `unit-test-gen`
   - ENGINE: `ghcp` or `claude`
   - DRY_RUN: `true` (for first test)

### Step 5: Run as Freestyle Job

If you prefer Freestyle over Pipeline:

```bash
# In the "Execute shell" build step:
export GH_TOKEN=$(cat /path/to/token)
cd $WORKSPACE
chmod +x scripts/run-ghcp.sh
./scripts/run-ghcp.sh \
    --repo "$REPO_PARAM" \
    --branch "$BRANCH_PARAM" \
    --use-case "$USE_CASE_PARAM"
```

## How Each Engine Works

### GitHub Copilot CLI (ghcp)

1. Clones the repo using `gh repo clone`
2. Loads a skill file from `skills/` directory as the instruction
3. Runs `gh copilot suggest` with the skill as context
4. Validates compilation with `mvn compile`
5. Commits changes and creates PR via `gh pr create`

**Note:** GitHub Copilot CLI capabilities are evolving. The `suggest` command may work differently in your version. Check `gh copilot --help` for current options.

### Claude CLI (claude)

1. Clones the repo using `gh repo clone`
2. Loads a prompt from `prompts/` directory
3. Runs `claude --print` in the project directory (whole-project context)
4. Claude reads all project files, understands dependencies, and makes changes
5. Validates compilation, commits, and creates PR

**Advantage:** Claude CLI can see the entire project and make coordinated multi-file changes. This is especially powerful for functional test generation and complex sonar fixes.

**Status at enterprisef:** Claude Code is in "Evaluation" status. Contact the Security Huddle team to get evaluation access for your pipeline use case.

## Customizing Skills & Prompts

### Skills (for GHCP)

Files in `skills/` are instruction documents that tell Copilot how to generate code. Edit these to match your team's coding standards:

| File | What to Customize |
|------|-------------------|
| `unit-test-gen.md` | Test naming conventions, mocking framework (Mockito/PowerMock), assertion library |
| `functional-test-gen.md` | BDD framework (Cucumber/Karate), API testing patterns, test data approach |
| `sonar-fix.md` | Which Sonar rules to prioritize, coding standards, exception handling patterns |

### Prompts (for Claude CLI)

Files in `prompts/` are full prompts sent to Claude. They can be more detailed than skills because Claude handles larger context:

- Include few-shot examples from your team's real code
- Reference specific frameworks and versions
- Include your team's architectural patterns

## Result Tracking

Every execution saves a JSON result file in `results/`:

```json
{
  "repo": "org/repo-name",
  "branch": "develop",
  "use_case": "unit-test-gen",
  "engine": "ghcp",
  "timestamp": "20260317-143022",
  "compilation_ok": true,
  "tests_ok": true,
  "dry_run": false,
  "branch_name": "genai/unit-test-gen-20260317-143022",
  "pr_url": "https://github.com/org/repo-name/pull/42"
}
```

Use these files to track value delivered: PRs created, files changed, compilation success rate.

## Access Requirements for End Users

When onboarding a squad to use this pipeline on their repo:

| What | Who Does It | How |
|------|------------|-----|
| Grant repo write access | Squad lead | Add service account (or your account for POC) as Collaborator |
| Provide repo URL + branch | Squad lead | Tell you `org/repo-name` and `develop` or `main` |
| Review generated PRs | Squad developers | Normal PR review process — nothing new to learn |
| Approve/merge | Squad developers | Standard approval workflow |

The squad doesn't need to install anything or learn any new tools. They just review PRs.

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `gh: command not found` | Install GitHub CLI: https://cli.github.com/ |
| `gh auth status` fails | Run `gh auth login` to authenticate |
| `gh copilot: command not found` | Run `gh extension install github/gh-copilot` |
| `claude: command not found` | Install Claude CLI: https://docs.anthropic.com/en/docs/claude-code |
| `Permission denied` on scripts | Run `chmod +x scripts/*.sh` |
| Clone fails with 403 | Your token may have expired. Run `gh auth token` for a fresh one |
| PR creation fails | Ensure your account has write access to the target repo |
| Compilation fails | Check that Java/Maven is available on the Jenkins agent |
