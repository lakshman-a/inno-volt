Analyze this project and generate Cucumber BDD functional tests.

INSTRUCTIONS:
1. Read the entire project to understand the API endpoints, service layer, and business logic
2. For each REST controller or service endpoint, generate a .feature file
3. Write tests in Gherkin (Given/When/Then) format
4. Cover: happy path, error handling, validation failures, auth scenarios, edge cases
5. Place feature files in src/test/resources/features/
6. Generate Java step definition stubs in src/test/java/.../steps/
7. Include Scenario Outline with Examples tables for data-driven tests
8. Tag scenarios: @smoke, @regression, @negative, @api, @security

QUALITY BAR:
Write tests that a QA lead would approve. Each scenario should test a specific
business behavior, not a code path. Use realistic test data. Include:
- Field validation tests (required, format, min/max length)
- Authorization tests (wrong role, expired token, no token)
- Boundary tests (empty lists, max records, special characters)
- Integration scenarios (multi-step workflows)

After generating, verify the project compiles with `mvn compile`.
