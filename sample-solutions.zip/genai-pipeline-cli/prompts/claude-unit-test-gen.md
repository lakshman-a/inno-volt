Analyze this Java project and generate comprehensive unit tests.

INSTRUCTIONS:
1. Scan all classes in src/main/java/ that do NOT have corresponding test files in src/test/java/
2. For each untested class, generate a JUnit 5 test class with Mockito
3. Follow these QA standards:
   - Test naming: methodName_scenario_expectedResult
   - Cover: positive, negative, boundary, null inputs, exception paths
   - Mock all external dependencies (repos, services, HTTP clients)
   - Include @DisplayName with human-readable descriptions
   - Add business-meaningful assertions, not just "not null" checks
4. Place generated tests in the correct package under src/test/java/
5. Ensure all tests compile. If you reference a class, verify the import exists.
6. After writing tests, run `mvn compile` to verify. Fix any errors.

QUALITY BAR:
Think like a QA engineer, not a developer. A developer tests "does it work?"
A QA tests "does it break?" Focus on edge cases, invalid inputs, state corruption,
and business rule violations that could cause production issues.

DO NOT:
- Generate tests for POJOs/DTOs (getters/setters only)
- Duplicate existing tests
- Test framework code (Spring Boot annotations, config classes)
