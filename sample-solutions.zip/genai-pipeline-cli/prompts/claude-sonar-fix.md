Analyze this Java project and fix SonarQube code quality issues.

INSTRUCTIONS:
1. Scan all classes in src/main/java/ for common SonarQube issues:
   - Resource leaks (unclosed streams, connections)
   - Null pointer risks (missing null checks)
   - Code smells (long methods, high complexity, deep nesting)
   - Security hotspots (hardcoded credentials, SQL injection risks)
   - Bug patterns (equals/hashCode violations, thread safety)
2. Fix each issue while preserving existing behavior
3. Do NOT change method signatures or public APIs
4. After fixing, run `mvn compile` and `mvn test` to verify nothing broke

PRIORITY ORDER:
1. Security vulnerabilities (fix all)
2. Bugs (fix all)
3. Code smells - Critical/Major only (fix)
4. Minor code smells (skip unless trivial)

DO NOT:
- Change business logic
- Rename classes or methods
- Add new dependencies
- Use @SuppressWarnings unless absolutely necessary (explain why in comment)
