"""
Calls the GenAI Gateway v2/generation/text endpoint.
"""
import json
import time
import requests


class GatewayClient:

    def __init__(self, gateway_config):
        self.url = gateway_config["url"]
        self.api_key = gateway_config.get("api_key", "")
        self.vendor = gateway_config.get("model_vendor", "google")
        self.model = gateway_config.get("model_name", "gemini-1.5-pro")
        self.timeout = gateway_config.get("timeout_seconds", 120)
        self.max_retries = gateway_config.get("max_retries", 3)

    def call(self, prompt, retry_context=""):
        """
        Call GenAI Gateway with a prompt. Returns the LLM response text.
        Adjust the payload structure to match your gateway's API contract.
        """
        full_prompt = prompt
        if retry_context:
            full_prompt += f"\n\nPREVIOUS ATTEMPT FAILED WITH:\n{retry_context}\n\nPlease fix and try again."

        payload = {
            "promptSpec": {
                "messages": [
                    {"role": "user", "content": full_prompt}
                ]
            },
            "model": {
                "vendor": self.vendor,
                "name": self.model,
            },
        }

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        for attempt in range(self.max_retries):
            try:
                response = requests.post(
                    self.url,
                    json=payload,
                    headers=headers,
                    timeout=self.timeout,
                )
                response.raise_for_status()
                data = response.json()

                # Extract text from response - adjust based on your gateway's format
                if "choices" in data:
                    return data["choices"][0]["message"]["content"]
                elif "content" in data:
                    return data["content"]
                elif "response" in data:
                    return data["response"]
                else:
                    return json.dumps(data)

            except requests.exceptions.RequestException as e:
                print(f"    Gateway call attempt {attempt+1} failed: {e}")
                if attempt < self.max_retries - 1:
                    wait = 2 ** attempt
                    print(f"    Retrying in {wait}s...")
                    time.sleep(wait)
                else:
                    print(f"    All {self.max_retries} attempts failed.")
                    return None
        return None
