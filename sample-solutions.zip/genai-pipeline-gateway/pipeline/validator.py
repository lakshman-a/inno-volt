"""
Writes generated code to disk and validates (compile + test).
"""
import json
import re
import subprocess
from pathlib import Path


class CodeValidator:

    def __init__(self, use_case_config, pipeline_config):
        self.build_cmd = use_case_config.get("build_command", "mvn compile -q")
        self.test_cmd = use_case_config.get("test_command", "mvn test -q")
        self.retries = pipeline_config.get("compilation_retries", 3)

    def write_and_validate(self, repo_path, generated_files):
        """
        Write generated files and validate compilation/tests.
        Returns: { compilation_ok, tests_ok, errors, files_written }
        """
        result = {
            "compilation_ok": False,
            "tests_ok": False,
            "errors": [],
            "files_written": [],
        }

        # Write generated files
        for gf in generated_files:
            output_path = self._determine_output_path(repo_path, gf)
            if not output_path:
                continue
            try:
                code = self._extract_code(gf["generated_content"])
                out = Path(output_path)
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_text(code, encoding="utf-8")
                result["files_written"].append(str(out.relative_to(repo_path)))
                print(f"    Wrote: {out.relative_to(repo_path)}")
            except Exception as e:
                result["errors"].append(f"Write failed for {output_path}: {e}")

        if not result["files_written"]:
            result["errors"].append("No files were written")
            return result

        # Validate compilation
        print("    Running compilation check...")
        comp = self._run_command(self.build_cmd, repo_path)
        result["compilation_ok"] = comp["success"]
        if not comp["success"]:
            result["errors"].append(f"Compilation failed: {comp['stderr'][:500]}")
            print(f"    Compilation FAILED")
        else:
            print(f"    Compilation PASSED")

        # Validate tests (only if compilation passed)
        if result["compilation_ok"]:
            print("    Running test validation...")
            test = self._run_command(self.test_cmd, repo_path)
            result["tests_ok"] = test["success"]
            if not test["success"]:
                result["errors"].append(f"Tests failed: {test['stderr'][:500]}")
                print(f"    Tests FAILED (non-blocking)")
            else:
                print(f"    Tests PASSED")

        return result

    def _determine_output_path(self, repo_path, gen_file):
        """Figure out where to write the generated file."""
        if gen_file.get("output_path"):
            return str(Path(repo_path) / gen_file["output_path"])

        source = gen_file["source"]
        # Default: create test file in test directory
        test_path = source.replace("src/main/", "src/test/")
        name = Path(test_path).stem
        if not name.endswith("Test"):
            test_path = test_path.replace(f"{name}.java", f"{name}Test.java")
        return str(Path(repo_path) / test_path)

    def _extract_code(self, llm_response):
        """Extract code from LLM response (strip markdown fences etc)."""
        # Try to extract from ```java ... ``` blocks
        match = re.search(r'```(?:java|kotlin|python|gherkin)?\s*\n(.*?)```', llm_response, re.DOTALL)
        if match:
            return match.group(1).strip()

        # Try JSON response with file content
        try:
            data = json.loads(llm_response)
            if isinstance(data, dict):
                return data.get("content", data.get("code", llm_response))
            if isinstance(data, list) and data:
                return data[0].get("content", llm_response)
        except (json.JSONDecodeError, AttributeError):
            pass

        # Return as-is (might already be clean code)
        return llm_response.strip()

    def _run_command(self, cmd, cwd, timeout=120):
        """Run a shell command and return result."""
        try:
            proc = subprocess.run(
                cmd, shell=True, cwd=cwd,
                capture_output=True, text=True, timeout=timeout,
            )
            return {
                "success": proc.returncode == 0,
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "returncode": proc.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": "Command timed out", "returncode": -1}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "returncode": -1}
