"""
Analyzes a cloned project to identify target files and extract context.
"""
import os
import re
from pathlib import Path
from fnmatch import fnmatch


class ProjectAnalyzer:

    def __init__(self, use_case_config):
        self.file_patterns = use_case_config.get("file_patterns", ["**/*.java"])
        self.exclude_patterns = use_case_config.get("exclude_patterns", [])

    def analyze(self, repo_path):
        """
        Analyze a project directory.
        Returns: { target_files: [...], structure_summary: "..." }
        """
        repo = Path(repo_path)
        all_files = self._find_files(repo)
        target_files = []

        for fpath in all_files:
            rel_path = str(fpath.relative_to(repo))
            if self._should_exclude(rel_path):
                continue

            content = self._read_file(fpath)
            if not content:
                continue

            file_info = {
                "path": rel_path,
                "full_path": str(fpath),
                "content": content,
                "class_name": self._extract_class_name(content),
                "package": self._extract_package(content),
                "imports": self._extract_imports(content),
                "methods": self._extract_methods(content),
                "dependencies": "",
                "existing_tests": "",
            }

            # Try to find existing test file
            test_path = self._find_test_file(repo, rel_path)
            if test_path and test_path.exists():
                file_info["existing_tests"] = self._read_file(test_path) or ""

            target_files.append(file_info)

        # Build structure summary
        structure = self._build_structure_summary(repo)

        return {
            "target_files": target_files,
            "structure_summary": structure,
            "total_files": len(all_files),
            "target_count": len(target_files),
        }

    def _find_files(self, repo):
        """Find all files matching configured patterns."""
        found = []
        for pattern in self.file_patterns:
            found.extend(repo.glob(pattern))
        return sorted(set(found))

    def _should_exclude(self, rel_path):
        for pattern in self.exclude_patterns:
            # Simple glob matching
            if fnmatch(rel_path, pattern):
                return True
            # Also check if pattern is a directory prefix
            if pattern.startswith("**/"):
                subpattern = pattern[3:]
                if subpattern in rel_path:
                    return True
        return False

    def _read_file(self, fpath, max_chars=50000):
        try:
            text = fpath.read_text(encoding="utf-8", errors="ignore")
            return text[:max_chars]
        except Exception:
            return None

    def _extract_class_name(self, content):
        match = re.search(r'(?:public\s+)?class\s+(\w+)', content)
        return match.group(1) if match else ""

    def _extract_package(self, content):
        match = re.search(r'package\s+([\w.]+);', content)
        return match.group(1) if match else ""

    def _extract_imports(self, content):
        imports = re.findall(r'import\s+([\w.*]+);', content)
        return "\n".join(f"import {imp};" for imp in imports[:30])

    def _extract_methods(self, content):
        methods = re.findall(
            r'(?:public|protected|private)\s+(?:static\s+)?[\w<>\[\],\s]+\s+(\w+)\s*\(([^)]*)\)',
            content
        )
        return [{"name": m[0], "params": m[1]} for m in methods]

    def _find_test_file(self, repo, source_path):
        """Given a source file, try to find its test file."""
        # src/main/java/com/example/Foo.java -> src/test/java/com/example/FooTest.java
        test_path = source_path.replace("src/main/", "src/test/")
        name = Path(test_path).stem
        test_path = test_path.replace(f"{name}.java", f"{name}Test.java")
        result = repo / test_path
        if result.exists():
            return result
        return None

    def _build_structure_summary(self, repo, max_depth=3):
        """Build a tree-like structure summary."""
        lines = []
        for root, dirs, files in os.walk(repo):
            depth = str(root).replace(str(repo), "").count(os.sep)
            if depth >= max_depth:
                dirs.clear()
                continue
            dirs[:] = [d for d in sorted(dirs) if d not in (".git", "node_modules", "target", ".gradle", "build")]
            indent = "  " * depth
            dirname = os.path.basename(root)
            lines.append(f"{indent}{dirname}/")
            if depth < max_depth - 1:
                for f in sorted(files)[:10]:
                    lines.append(f"{indent}  {f}")
                if len(files) > 10:
                    lines.append(f"{indent}  ... and {len(files)-10} more files")
        return "\n".join(lines[:100])
