"""
Fetches app coverage stats from Snowflake (or mock data for testing).
"""


def get_low_coverage_apps(snowflake_config, query):
    """
    Query Snowflake for apps with low coverage.
    Falls back to mock data if Snowflake is not configured.
    """
    if not snowflake_config.get("account") or snowflake_config["account"].startswith("$"):
        print("  Snowflake not configured, using mock data")
        return _get_mock_data()

    try:
        import snowflake.connector
        conn = snowflake.connector.connect(
            account=snowflake_config["account"],
            user=snowflake_config["user"],
            password=snowflake_config["password"],
            database=snowflake_config["database"],
            schema=snowflake_config["schema"],
            warehouse=snowflake_config["warehouse"],
        )
        cursor = conn.cursor()
        cursor.execute(query)
        columns = [desc[0].lower() for desc in cursor.description]
        rows = cursor.fetchall()
        conn.close()
        return [dict(zip(columns, row)) for row in rows]
    except ImportError:
        print("  snowflake-connector-python not installed, using mock data")
        return _get_mock_data()
    except Exception as e:
        print(f"  Snowflake query failed: {e}, using mock data")
        return _get_mock_data()


def _get_mock_data():
    """Mock data for testing the pipeline without Snowflake."""
    return [
        {
            "app_name": "sample-service",
            "repo_url": "your-org/sample-service",
            "branch": "develop",
            "ut_coverage_pct": 42.0,
            "ft_coverage_pct": 15.0,
            "sonar_critical_count": 8,
        },
        # Add more mock entries as needed for testing
    ]
