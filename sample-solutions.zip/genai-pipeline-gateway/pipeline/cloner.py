"""
Clones GitHub repos using gh CLI or git with token auth.
"""
import subprocess
import shutil
from pathlib import Path


class RepoCloner:

    def __init__(self, github_config):
        self.token = github_config.get("token", "")
        self.api_url = github_config.get("api_url", "https://api.github.com")

    def clone(self, repo_url, branch, work_dir):
        """Clone a repo. Returns the path to the cloned directory."""
        work_path = Path(work_dir)
        if work_path.exists():
            shutil.rmtree(work_path)
        work_path.mkdir(parents=True, exist_ok=True)

        # Try gh CLI first (uses GH_TOKEN env var automatically)
        if self._has_gh_cli():
            return self._clone_with_gh(repo_url, branch, work_path)
        else:
            return self._clone_with_git(repo_url, branch, work_path)

    def _has_gh_cli(self):
        try:
            subprocess.run(["gh", "--version"], capture_output=True, check=True)
            return True
        except (FileNotFoundError, subprocess.CalledProcessError):
            return False

    def _clone_with_gh(self, repo_url, branch, work_path):
        """Clone using GitHub CLI. GH_TOKEN env var provides auth."""
        repo_dir = work_path / "repo"
        cmd = ["gh", "repo", "clone", repo_url, str(repo_dir), "--", "--branch", branch, "--depth", "1"]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"gh clone failed: {result.stderr}")
        return str(repo_dir)

    def _clone_with_git(self, repo_url, branch, work_path):
        """Clone using git with token-based HTTPS auth."""
        repo_dir = work_path / "repo"
        # Build authenticated URL
        if "github.com" in self.api_url or "github" in repo_url.lower():
            clone_url = f"https://x-access-token:{self.token}@github.com/{repo_url}.git"
        else:
            # GitHub Enterprise
            host = self.api_url.replace("https://", "").replace("/api/v3", "")
            clone_url = f"https://x-access-token:{self.token}@{host}/{repo_url}.git"

        cmd = ["git", "clone", "--branch", branch, "--depth", "1", clone_url, str(repo_dir)]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"git clone failed: {result.stderr}")
        return str(repo_dir)
