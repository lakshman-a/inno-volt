"""
Tracks pipeline execution results for value measurement.
Saves results as JSON files for reporting.
"""
import json
import os
from datetime import datetime
from pathlib import Path


class ResultTracker:

    def __init__(self, tracking_config):
        self.results_dir = Path(tracking_config.get("results_dir", "./results"))
        self.results_dir.mkdir(parents=True, exist_ok=True)
        self.results = []

    def save_result(self, result):
        """Save a single execution result."""
        self.results.append(result)
        
        # Save individual result file
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        repo_name = result.get("repo", "unknown").replace("/", "_")
        filename = f"{ts}_{repo_name}_{result.get('use_case', 'unknown')}.json"
        filepath = self.results_dir / filename
        filepath.write_text(json.dumps(result, indent=2))
        print(f"    Result saved: {filepath}")

    def print_summary(self):
        """Print a summary of all results in this run."""
        print(f"\n{'='*60}")
        print(f"PIPELINE EXECUTION SUMMARY")
        print(f"{'='*60}")
        print(f"Total repos processed: {len(self.results)}")
        
        success = sum(1 for r in self.results if r["status"] == "success")
        errors = sum(1 for r in self.results if r["status"] == "error")
        skipped = sum(1 for r in self.results if r["status"] == "skipped")
        
        print(f"  Success: {success}")
        print(f"  Errors:  {errors}")
        print(f"  Skipped: {skipped}")
        print(f"\nFiles generated:  {sum(r.get('files_generated', 0) for r in self.results)}")
        print(f"PRs created:      {sum(1 for r in self.results if r.get('pr_number'))}")
        
        print(f"\nDetails:")
        for r in self.results:
            status_icon = {"success": "✅", "error": "❌", "skipped": "⏭", "dry_run_complete": "🔍"}.get(r["status"], "?")
            pr = f"PR #{r['pr_number']}" if r.get("pr_number") else "No PR"
            print(f"  {status_icon} {r.get('repo', '?')} | {r.get('use_case', '?')} | {r.get('files_generated', 0)} files | {pr}")
            if r.get("errors"):
                for err in r["errors"][:2]:
                    print(f"      Error: {err[:100]}")
        
        # Save combined summary
        summary_file = self.results_dir / f"summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        summary_file.write_text(json.dumps({
            "run_time": datetime.now().isoformat(),
            "total": len(self.results),
            "success": success,
            "errors": errors,
            "files_generated": sum(r.get("files_generated", 0) for r in self.results),
            "prs_created": [r.get("pr_url") for r in self.results if r.get("pr_url")],
            "results": self.results,
        }, indent=2))
        print(f"\nSummary saved: {summary_file}")

    def load_all_results(self):
        """Load all historical results for reporting."""
        all_results = []
        for f in sorted(self.results_dir.glob("*.json")):
            if f.name.startswith("summary_"):
                continue
            try:
                all_results.append(json.loads(f.read_text()))
            except Exception:
                continue
        return all_results
