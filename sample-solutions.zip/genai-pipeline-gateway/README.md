# GenAI Pipeline - Gateway Edition

Automated code improvement pipeline that clones repos, generates unit tests / functional tests / sonar fixes using GenAI Gateway, validates compilation, and raises PRs.

## What It Does

1. **Clones** a GitHub repo (via `gh` CLI or git with token)
2. **Analyzes** the project to find target files (low coverage, sonar issues)
3. **Calls GenAI Gateway** with enriched prompts per file
4. **Validates** generated code (compile + test)
5. **Creates a PR** with the improvements for human review
6. **Tracks results** (files changed, PR numbers, value metrics) for reporting

## Project Structure

```
genai-pipeline-gateway/
├── main.py                    # ★ Main entry point / orchestrator
├── config.yaml.example        # ★ All configuration in one file
├── Jenkinsfile                # ★ Jenkins pipeline definition
├── requirements.txt           # Python dependencies
├── pipeline/
│   ├── __init__.py
│   ├── cloner.py              # Git clone (gh CLI or git+token)
│   ├── analyzer.py            # Project analysis & file extraction
│   ├── gateway_client.py      # ★ GenAI Gateway API calls
│   ├── validator.py           # Compile & test validation
│   ├── git_ops.py             # Branch, commit, push, PR creation
│   ├── tracker.py             # Result tracking & value metrics
│   └── snowflake_client.py    # Coverage stats from Snowflake
├── prompts/
│   ├── unit-test-gen.md       # ★ Prompt for unit test generation
│   ├── functional-test-gen.md # ★ Prompt for functional test gen
│   └── sonar-fix.md           # ★ Prompt for sonar fixes
├── results/                   # Execution results (auto-created)
└── README.md
```

## Quick Start

### 1. Configure

```bash
cp config.yaml.example config.yaml
# Edit config.yaml with your GenAI Gateway URL, model, etc.
```

### 2. Set Environment Variables

```bash
# Your GitHub token (for POC, use personal: `gh auth token`)
export GH_TOKEN="ghp_your_token_here"

# Your GenAI Gateway API key
export GENAI_API_KEY="your-gateway-key"
```

### 3. Run Locally (Single Repo)

```bash
pip install -r requirements.txt

# Dry run (no PR created)
python main.py --repo your-org/your-repo --branch develop --use-case unit-test-gen --dry-run

# Full run (creates PR)
python main.py --repo your-org/your-repo --branch develop --use-case unit-test-gen

# Sonar fix
python main.py --repo your-org/your-repo --branch develop --use-case sonar-fix
```

### 4. Run from Snowflake Coverage Stats

```bash
# Processes all repos with UT coverage < 60%
python main.py --from-snowflake --use-case unit-test-gen
```

### 5. Run in Jenkins

**Option A: Pipeline Job**
1. Create a new Pipeline job in Jenkins
2. Point SCM to this repo
3. Jenkinsfile is auto-detected
4. Add credentials: `gh-cli-token`, `genai-gateway-api-key`
5. Run with parameters

**Option B: Freestyle Job**
1. Create a Freestyle job
2. Add build step: Execute Shell
3. Copy commands from each Jenkinsfile stage
4. Add string parameters: REPO, BRANCH, USE_CASE

## Configuration Reference

### config.yaml — Key Settings

| Setting | Description |
|---------|-------------|
| `gateway.url` | GenAI Gateway endpoint |
| `gateway.model_vendor` | LLM vendor: google, openai, aws, anthropic |
| `gateway.model_name` | Model name per gateway docs |
| `github.branch_prefix` | Branch naming prefix (default: `genai`) |
| `pipeline.max_files_per_run` | Max files to process (default: 20) |
| `pipeline.create_pr` | Set `false` for dry-run mode |

### Jenkins Credentials

| Credential ID | Type | Source |
|--------------|------|--------|
| `gh-cli-token` | Secret text | `gh auth token` (POC) or service account PAT (prod) |
| `genai-gateway-api-key` | Secret text | From GenAI Gateway team |

## Customizing Prompts

Edit files in `prompts/` directory. Prompts use `{variable}` placeholders:

| Variable | Description |
|----------|-------------|
| `{code}` | Source file content |
| `{class_name}` | Extracted class name |
| `{package}` | Java package |
| `{imports}` | Import statements |
| `{file_path}` | Relative file path |
| `{existing_tests}` | Content of existing test file (if found) |
| `{project_structure}` | Directory tree summary |

## Value Tracking

Every execution saves a JSON result in `results/`:

```json
{
  "repo": "org/repo",
  "use_case": "unit-test-gen",
  "files_processed": 12,
  "files_generated": 10,
  "compilation_success": true,
  "pr_number": "47",
  "pr_url": "https://github.com/org/repo/pull/47",
  "files_changed": ["src/main/java/com/example/Foo.java", ...]
}
```

Use these for your value dashboard and leadership presentations.

## What Access Teams Need to Grant

When onboarding a squad:

| What | Why | How |
|------|-----|-----|
| Repo write access | To push branches and create PRs | Add your GitHub user (POC) or service account (prod) as Collaborator |
| Branch protection exception | Optional: allow pipeline to push to `genai/*` branches | Repo settings → Branch protection rules |
| Nothing else | The pipeline uses existing build tooling (Maven/Gradle) | — |
