"""
============================================================
GENAI PIPELINE - MAIN ORCHESTRATOR
============================================================
Entry point for the GenAI code improvement pipeline.
Can be called from Jenkins, CLI, or scheduled jobs.

Usage:
  python main.py --repo org/repo-name --branch develop --use-case unit-test-gen
  python main.py --from-snowflake                    # Process low-coverage apps
  python main.py --repo org/repo --dry-run            # Test without creating PR

COPILOT/AI INSTRUCTION: This is the main entry point.
It orchestrates: clone → analyze → prompt → call LLM → validate → PR.
Each step is a separate module in the pipeline/ directory.
============================================================
"""

import argparse
import json
import os
import sys
import yaml
from datetime import datetime
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pipeline.cloner import RepoCloner
from pipeline.analyzer import ProjectAnalyzer
from pipeline.gateway_client import GatewayClient
from pipeline.validator import CodeValidator
from pipeline.git_ops import GitOperations
from pipeline.tracker import ResultTracker


def load_config(config_path="config.yaml"):
    """Load and resolve config with environment variables."""
    with open(config_path) as f:
        raw = f.read()
    
    # Resolve ${ENV_VAR} patterns
    import re
    def resolve_env(match):
        var_name = match.group(1)
        return os.environ.get(var_name, match.group(0))
    
    resolved = re.sub(r'\$\{(\w+)\}', resolve_env, raw)
    return yaml.safe_load(resolved)


def run_pipeline(repo_url, branch, use_case, config, dry_run=False):
    """
    Execute the full pipeline for a single repository.
    Returns a result dict with metrics.
    """
    result = {
        "repo": repo_url,
        "branch": branch,
        "use_case": use_case,
        "started_at": datetime.now().isoformat(),
        "status": "started",
        "files_processed": 0,
        "files_generated": 0,
        "compilation_success": False,
        "test_pass": False,
        "pr_number": None,
        "pr_url": None,
        "errors": [],
    }
    
    uc_config = config["use_cases"].get(use_case)
    if not uc_config:
        result["status"] = "error"
        result["errors"].append(f"Unknown use case: {use_case}")
        return result

    work_dir = Path(config["pipeline"]["work_dir"]) / repo_url.replace("/", "_")
    
    try:
        # ── Step 1: Clone ─────────────────────────────────────
        print(f"\n{'='*60}")
        print(f"[1/6] Cloning {repo_url} (branch: {branch})")
        print(f"{'='*60}")
        
        cloner = RepoCloner(config["github"])
        repo_path = cloner.clone(repo_url, branch, str(work_dir))
        print(f"  Cloned to: {repo_path}")

        # ── Step 2: Analyze ───────────────────────────────────
        print(f"\n{'='*60}")
        print(f"[2/6] Analyzing project for {use_case}")
        print(f"{'='*60}")
        
        analyzer = ProjectAnalyzer(uc_config)
        analysis = analyzer.analyze(repo_path)
        result["files_processed"] = len(analysis["target_files"])
        print(f"  Found {len(analysis['target_files'])} files to process")
        
        if not analysis["target_files"]:
            result["status"] = "skipped"
            result["errors"].append("No target files found")
            return result

        # ── Step 3: Call GenAI Gateway ────────────────────────
        print(f"\n{'='*60}")
        print(f"[3/6] Calling GenAI Gateway ({len(analysis['target_files'])} files)")
        print(f"{'='*60}")
        
        gateway = GatewayClient(config["gateway"])
        prompt_template = _load_prompt(uc_config["prompt_file"])
        
        generated_files = []
        for i, target_file in enumerate(analysis["target_files"][:config["pipeline"]["max_files_per_run"]]):
            print(f"  Processing [{i+1}/{len(analysis['target_files'])}]: {target_file['path']}")
            
            prompt = _build_prompt(prompt_template, target_file, analysis)
            response = gateway.call(prompt)
            
            if response:
                generated_files.append({
                    "source": target_file["path"],
                    "generated_content": response,
                    "output_path": target_file.get("output_path", ""),
                })
        
        result["files_generated"] = len(generated_files)
        print(f"  Generated {len(generated_files)} files")

        # ── Step 4: Write & Validate ──────────────────────────
        print(f"\n{'='*60}")
        print(f"[4/6] Validating generated code")
        print(f"{'='*60}")
        
        validator = CodeValidator(uc_config, config["pipeline"])
        validation = validator.write_and_validate(repo_path, generated_files)
        result["compilation_success"] = validation["compilation_ok"]
        result["test_pass"] = validation["tests_ok"]
        print(f"  Compilation: {'PASS' if validation['compilation_ok'] else 'FAIL'}")
        print(f"  Tests: {'PASS' if validation['tests_ok'] else 'FAIL (or skipped)'}")

        # ── Step 5: Commit & Create PR ────────────────────────
        if dry_run:
            print(f"\n{'='*60}")
            print(f"[5/6] DRY RUN - Skipping commit and PR")
            print(f"{'='*60}")
            result["status"] = "dry_run_complete"
        elif config["pipeline"]["create_pr"]:
            print(f"\n{'='*60}")
            print(f"[5/6] Creating branch and PR")
            print(f"{'='*60}")
            
            git_ops = GitOperations(config["github"])
            pr_result = git_ops.commit_and_pr(
                repo_path=repo_path,
                repo_url=repo_url,
                base_branch=branch,
                use_case=use_case,
                generated_files=generated_files,
                validation=validation,
            )
            result["pr_number"] = pr_result.get("pr_number")
            result["pr_url"] = pr_result.get("pr_url")
            result["branch_name"] = pr_result.get("branch_name")
            result["status"] = "success"
            print(f"  PR created: {pr_result.get('pr_url', 'N/A')}")
        
        # ── Step 6: Track results ─────────────────────────────
        print(f"\n{'='*60}")
        print(f"[6/6] Saving results")
        print(f"{'='*60}")
        
        result["completed_at"] = datetime.now().isoformat()
        result["files_changed"] = [f["source"] for f in generated_files]
        
    except Exception as e:
        result["status"] = "error"
        result["errors"].append(str(e))
        print(f"\n  ERROR: {e}")
        import traceback
        traceback.print_exc()
    
    return result


def _load_prompt(prompt_file):
    """Load a prompt template from the prompts/ directory."""
    prompt_path = Path(__file__).parent / prompt_file
    if prompt_path.exists():
        return prompt_path.read_text()
    print(f"  WARNING: Prompt file not found: {prompt_file}, using inline prompt")
    return "Analyze the following code and generate improvements:\n\n{code}"


def _build_prompt(template, target_file, analysis):
    """Build a prompt by filling in the template with file-specific data."""
    return template.format(
        file_path=target_file["path"],
        code=target_file["content"],
        class_name=target_file.get("class_name", ""),
        package=target_file.get("package", ""),
        imports=target_file.get("imports", ""),
        existing_tests=target_file.get("existing_tests", ""),
        dependencies=target_file.get("dependencies", ""),
        project_structure=analysis.get("structure_summary", ""),
    )


def main():
    parser = argparse.ArgumentParser(description="GenAI Code Improvement Pipeline")
    parser.add_argument("--repo", help="GitHub repo (org/name)")
    parser.add_argument("--branch", default="develop", help="Branch to process")
    parser.add_argument("--use-case", choices=["unit-test-gen", "functional-test-gen", "sonar-fix"],
                        default="unit-test-gen", help="Use case to execute")
    parser.add_argument("--config", default="config.yaml", help="Config file path")
    parser.add_argument("--dry-run", action="store_true", help="Run without creating PR")
    parser.add_argument("--from-snowflake", action="store_true", help="Get repos from Snowflake coverage query")
    
    args = parser.parse_args()
    config = load_config(args.config)
    tracker = ResultTracker(config.get("tracking", {}))
    
    if args.from_snowflake:
        # ── Batch mode: process multiple repos from coverage stats ──
        print("Fetching low-coverage apps from Snowflake...")
        from pipeline.snowflake_client import get_low_coverage_apps
        apps = get_low_coverage_apps(config["tracking"]["snowflake"], config["tracking"]["coverage_query"])
        
        for app in apps:
            print(f"\n{'#'*60}")
            print(f"Processing: {app['repo_url']} ({app['app_name']})")
            print(f"  UT Coverage: {app['ut_coverage_pct']}% | Sonar Issues: {app['sonar_critical_count']}")
            print(f"{'#'*60}")
            
            result = run_pipeline(app["repo_url"], app["branch"], args.use_case, config, args.dry_run)
            result["app_name"] = app["app_name"]
            result["coverage_before"] = app["ut_coverage_pct"]
            tracker.save_result(result)
        
        tracker.print_summary()
    
    elif args.repo:
        # ── Single repo mode ──
        result = run_pipeline(args.repo, args.branch, args.use_case, config, args.dry_run)
        tracker.save_result(result)
        tracker.print_summary()
    
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
