---
applyTo: '**/*.feature,**/test/**,**/*Test*.java,**/*Runner*.java'
---
# QA Test File Rules
1. Validate EVERY response field — fail() placeholder when expected value unknown
2. Reusable auth in separate class/feature — never inline
3. Test data setup AND cleanup in every scenario — UUID suffix for parallel safety
4. URLs from config files — NEVER hardcoded in features or steps
5. SSL relaxation configured for all REST calls
6. Health check as first test in every suite
7. Log at every step: setup, action, validation, cleanup
8. Tag every scenario: feature, type, suite, severity
9. Always execute tests after generation to produce reports
10. When enhancing existing suite: match naming, tags, structure — never duplicate
