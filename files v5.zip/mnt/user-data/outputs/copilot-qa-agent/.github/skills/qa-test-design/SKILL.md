---
name: qa-test-design
description: QA test design methodology for API functional testing. Systematic CRUD coverage matrices, scenario design patterns, input analysis, gap analysis, and anti-patterns.
---

# QA Test Design Methodology

## Coverage Matrix (Build BEFORE writing tests)
| Endpoint            | Positive | Negative | Edge | Business | Total |
|---------------------|----------|----------|------|----------|-------|
| POST /resource      |    3+    |    5+    |  3+  |   2+     |  13+  |
| GET /resource/{id}  |    2+    |    3+    |  2+  |   1+     |   8+  |
| GET /resource       |    3+    |    2+    |  3+  |   1+     |   9+  |
| PUT /resource/{id}  |    3+    |    4+    |  2+  |   2+     |  11+  |
| DELETE /resource/{id}|   2+   |    3+    |  2+  |   2+     |   9+  |

## Minimum Scenarios Per Operation

**CREATE:** Valid all-fields, valid required-only, data-driven | Missing each required, invalid types/formats, max exceeded, duplicate unique, no auth(401), wrong role(403), malformed body | Boundary min/max, special chars, empty vs null | Cross-field, computed fields

**READ Single:** Retrieve existing, verify all fields | Non-existent(404), invalid ID(400), no auth(401), wrong owner(403) | After create, after update

**READ List:** Default pagination, custom page/size, filter, sort | Invalid params, invalid filters | Empty results, single result, beyond-data page

**UPDATE:** Full, partial(PATCH), multiple fields | Read-only field, invalid values, non-existent(404), no auth, conflict(409) | Idempotent, boundary | State-dependent, cascade

**DELETE:** Delete(204), verify gone(GET→404) | Non-existent(404), no auth, dependencies(409) | Double delete | Soft delete, cascade

## Auth Matrix
Valid creds→200, valid token→OK, no token→401, expired→401, malformed→401, wrong role→403

## Input Extraction
- **Dev Code:** Extract base URL from properties, endpoints from @Mapping, DTOs with @Valid annotations, request/response body structures, path/query params, auth config
- **Swagger:** All endpoints, schemas, constraints (required, min, max, pattern, enum)
- **Requirements:** Each acceptance criterion → 1+ scenarios

## Gap Analysis
1. Catalog existing scenarios: endpoint + type + what it validates
2. Compare to matrix minimums
3. Gap = Expected - Actual
4. Priority: Critical > High > Medium > Low

## Anti-Patterns (NEVER)
Status-code-only tests | Assumption-based | Sequential dependencies | Hardcoded values | Missing negatives | Technical jargon names | Empty assertions | Flaky patterns (sleep, order-dependent)
