---
name: qa-karate-dsl
description: Karate DSL framework patterns for API functional testing. Project structure, POM, karate-config.js with environment hierarchy, auth feature, health check, SSL relaxation, and execution.
---

# Karate DSL Standards

## Standalone Test Project POM
Detect system Java with `java -version`. NEVER hardcode URLs in pom.xml.
```xml
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.{org}</groupId>
    <artifactId>{project}-api-tests</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <properties>
        <java.version>[DETECT]</java.version>
        <karate.version>1.4.1</karate.version>
    </properties>
    <dependencies>
        <dependency><groupId>com.intuit.karate</groupId><artifactId>karate-junit5</artifactId><version>${karate.version}</version><scope>test</scope></dependency>
        <dependency><groupId>io.qameta.allure</groupId><artifactId>allure-karate</artifactId><version>2.25.0</version><scope>test</scope></dependency>
    </dependencies>
    <build>
        <testResources>
            <testResource><directory>src/test/resources</directory></testResource>
            <testResource><directory>src/test/java</directory><excludes><exclude>**/*.java</exclude></excludes></testResource>
        </testResources>
        <plugins>
            <plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-surefire-plugin</artifactId><version>3.2.3</version>
                <configuration><argLine>-Dfile.encoding=UTF-8</argLine>
                    <systemPropertyVariables><karate.env>${karate.env}</karate.env></systemPropertyVariables>
                </configuration></plugin>
            <plugin><groupId>io.qameta.allure</groupId><artifactId>allure-maven</artifactId><version>2.12.0</version></plugin>
        </plugins>
    </build>
</project>
```

## Project Structure
```
{project}-api-tests/               ← At WORKSPACE ROOT, not inside dev project
├── pom.xml
├── README.md
└── src/test/
    ├── java/com/{org}/{project}/
    │   ├── KarateTestRunner.java
    │   ├── SmokeTestRunner.java
    │   └── helpers/ (DataGenerator.java, DbUtils.java)
    └── resources/
        ├── karate-config.js               ← MUST be generated, NEVER hardcode URLs
        ├── config/
        │   ├── common.json                ← Default config (always loaded)
        │   ├── dev.json                   ← mvn test -Dkarate.env=dev
        │   ├── qa.json                    ← mvn test -Dkarate.env=qa
        │   ├── sit.json
        │   ├── uat.json
        │   └── local.json                 ← For JaCoCo: http://localhost:8080
        ├── features/
        │   ├── common/
        │   │   ├── auth.feature           ← @ignore — reusable auth
        │   │   ├── health-check.feature   ← @ignore — API availability
        │   │   └── cleanup.feature        ← @ignore — data cleanup
        │   ├── {feature}/
        │   │   ├── {feature}_positive.feature
        │   │   ├── {feature}_negative.feature
        │   │   └── {feature}_edge_cases.feature
        │   └── smoke/
        │       └── smoke_health.feature   ← Health check as runnable test
        ├── testdata/{feature}/ (JSON, CSV, JS)
        └── schemas/{feature}/ (JSON match schemas)
```

## karate-config.js — CRITICAL: NEVER Hardcode URLs
```javascript
function fn() {
    var env = karate.env || 'common';
    karate.log('=== Karate Environment:', env, '===');

    // STEP 1: Load COMMON config (always — this is the default)
    var config = karate.read('classpath:config/common.json');

    // STEP 2: Override with environment-specific config
    try {
        var envConfig = karate.read('classpath:config/' + env + '.json');
        // Merge: env values override common values
        for (var key in envConfig) {
            if (envConfig[key] !== null && envConfig[key] !== undefined) {
                config[key] = envConfig[key];
            }
        }
        karate.log('Loaded env-specific config:', env);
    } catch (e) {
        karate.log('No env-specific config for "' + env + '", using common defaults');
    }

    // STEP 3: SSL relaxation (critical for test environments)
    karate.configure('ssl', true);

    // STEP 4: Timeouts
    karate.configure('connectTimeout', config.connectTimeout || 30000);
    karate.configure('readTimeout', config.readTimeout || 30000);

    // STEP 5: Logging
    karate.configure('logPrettyRequest', true);
    karate.configure('logPrettyResponse', true);

    // STEP 6: Auth — call once, cache for suite
    if (config.authUrl && config.clientId) {
        try {
            var auth = karate.callSingle('classpath:features/common/auth.feature', config);
            config.authToken = auth.authToken;
            karate.log('Auth successful. Token obtained.');
        } catch (e) {
            karate.log('Auth failed:', e.message, '— proceeding without token');
            config.authToken = '';
        }
    } else {
        karate.log('No auth config — proceeding without authentication');
        config.authToken = '';
    }

    // STEP 7: Default headers
    var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
    if (config.authToken) {
        headers['Authorization'] = 'Bearer ' + config.authToken;
    }
    karate.configure('headers', headers);

    karate.log('Config loaded. Base URL:', config.baseUrl);
    return config;
}
```

## Config Files
**common.json (defaults):**
```json
{
    "baseUrl": "http://localhost:8080",
    "authUrl": "",
    "clientId": "",
    "clientSecret": "",
    "connectTimeout": 30000,
    "readTimeout": 30000
}
```
**qa.json (overrides):**
```json
{
    "baseUrl": "https://qa-api.example.com",
    "authUrl": "https://qa-auth.example.com",
    "clientId": "qa-client",
    "clientSecret": "qa-secret"
}
```

## Auth Feature
```gherkin
@ignore
Feature: Authentication
    Scenario: Get auth token
        Given url authUrl
        And path '/oauth/token'
        And form field grant_type = 'client_credentials'
        And form field client_id = clientId
        And form field client_secret = clientSecret
        When method post
        Then status 200
        * def authToken = response.access_token
        * karate.log('Auth token obtained')
```

## Health Check (Runnable Test)
```gherkin
@health @smoke @severity-critical
Feature: API Health Check
    Scenario: API should be running and healthy
        Given url baseUrl
        And path '/actuator/health'
        When method get
        Then status 200
        And match response.status == 'UP'
        * karate.log('Health check PASSED')
```

## Execution
```bash
mvn test                                      # Default (common config)
mvn test -Dkarate.env=qa                      # QA environment
mvn test -Dkarate.env=local                   # Local (for JaCoCo)
mvn test -Dkarate.options="--tags @smoke"      # Smoke only
mvn test -Dkarate.options="--threads 5"        # Parallel
mvn allure:serve                               # Allure report
```
