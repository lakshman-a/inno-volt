---
name: qa-cucumber-serenity
description: Cucumber + Serenity BDD framework patterns for API functional testing. Project structure, POM, environment config hierarchy, auth helper, SSL relaxation, health check, and execution.
---

# Cucumber + Serenity BDD Standards

## Standalone Test Project POM
```xml
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.{org}</groupId>
    <artifactId>{project}-api-tests</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <properties>
        <java.version>[DETECT FROM SYSTEM]</java.version>
        <serenity.version>4.1.4</serenity.version>
        <cucumber.version>7.15.0</cucumber.version>
    </properties>
    <dependencies>
        <dependency><groupId>net.serenity-bdd</groupId><artifactId>serenity-core</artifactId><version>${serenity.version}</version><scope>test</scope></dependency>
        <dependency><groupId>net.serenity-bdd</groupId><artifactId>serenity-cucumber</artifactId><version>${serenity.version}</version><scope>test</scope></dependency>
        <dependency><groupId>net.serenity-bdd</groupId><artifactId>serenity-rest-assured</artifactId><version>${serenity.version}</version><scope>test</scope></dependency>
        <dependency><groupId>io.cucumber</groupId><artifactId>cucumber-java</artifactId><version>${cucumber.version}</version><scope>test</scope></dependency>
        <dependency><groupId>io.qameta.allure</groupId><artifactId>allure-cucumber7-jvm</artifactId><version>2.25.0</version><scope>test</scope></dependency>
        <dependency><groupId>org.assertj</groupId><artifactId>assertj-core</artifactId><version>3.25.1</version><scope>test</scope></dependency>
        <dependency><groupId>com.fasterxml.jackson.core</groupId><artifactId>jackson-databind</artifactId><version>2.16.1</version><scope>test</scope></dependency>
        <dependency><groupId>com.github.javafaker</groupId><artifactId>javafaker</artifactId><version>1.0.2</version><scope>test</scope></dependency>
        <dependency><groupId>org.slf4j</groupId><artifactId>slf4j-simple</artifactId><version>2.0.11</version><scope>test</scope></dependency>
    </dependencies>
    <build><plugins>
        <plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-surefire-plugin</artifactId><version>3.2.3</version><configuration><skip>true</skip></configuration></plugin>
        <plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-failsafe-plugin</artifactId><version>3.2.3</version>
            <configuration><includes><include>**/*Runner.java</include></includes>
                <systemPropertyVariables><environment>${env}</environment></systemPropertyVariables></configuration>
            <executions><execution><goals><goal>integration-test</goal><goal>verify</goal></goals></execution></executions></plugin>
        <plugin><groupId>net.serenity-bdd.maven.plugins</groupId><artifactId>serenity-maven-plugin</artifactId><version>${serenity.version}</version>
            <executions><execution><id>reports</id><phase>post-integration-test</phase><goals><goal>aggregate</goal></goals></execution></executions></plugin>
        <plugin><groupId>io.qameta.allure</groupId><artifactId>allure-maven</artifactId><version>2.12.0</version></plugin>
    </plugins></build>
</project>
```

## Project Structure (At WORKSPACE ROOT)
```
{project}-api-tests/
├── pom.xml
├── README.md
└── src/test/
    ├── java/com/{org}/{project}/
    │   ├── runners/ (TestSuiteRunner, SmokeRunner)
    │   ├── stepdefinitions/common/ (CommonApiSteps, AuthSteps, ValidationSteps)
    │   ├── stepdefinitions/{feature}/ ({Feature}Steps)
    │   ├── stepdefinitions/Hooks.java
    │   ├── models/request/ & response/
    │   ├── utils/ (AuthHelper, ConfigManager, TestDataBuilder, ResponseValidator, TestContext)
    │   └── constants/ (Endpoints, ErrorMessages)
    └── resources/
        ├── features/{feature}/ (_positive, _negative, _edge .feature)
        ├── features/smoke/health_check.feature
        ├── testdata/{feature}/ (JSON/CSV)
        ├── schemas/{feature}/ (JSON)
        ├── serenity.conf                    ← Environment config
        └── logback-test.xml
```

## serenity.conf — Environment Hierarchy
```hocon
serenity { project.name = "{Project} API Tests", take.screenshots = FOR_FAILURES, logging = VERBOSE }
environments {
  default { base.url = "http://localhost:8080", auth.url = "", connect.timeout = 30000 }
  dev     { base.url = "https://dev-api.example.com", auth.url = "https://dev-auth.example.com" }
  qa      { base.url = "https://qa-api.example.com",  auth.url = "https://qa-auth.example.com" }
  sit     { base.url = "https://sit-api.example.com",  auth.url = "https://sit-auth.example.com" }
  uat     { base.url = "https://uat-api.example.com",  auth.url = "https://uat-auth.example.com" }
  local   { base.url = "http://localhost:8080", auth.url = "http://localhost:8080/auth" }
}
```

## AuthHelper (Separate Class — Always Reusable)
```java
public class AuthHelper {
    private static String cachedToken;
    public static synchronized String getToken(String authUrl, String clientId, String clientSecret) {
        if (cachedToken != null) return cachedToken;
        RestAssured.useRelaxedHTTPSValidation(); // SSL relaxation
        cachedToken = given().baseUri(authUrl)
            .formParam("grant_type", "client_credentials")
            .formParam("client_id", clientId).formParam("client_secret", clientSecret)
            .when().post("/oauth/token")
            .then().statusCode(200).extract().path("access_token");
        return cachedToken;
    }
}
```

## Hooks (SSL + Auth + Cleanup)
```java
public class Hooks {
    @Before
    public void setup() {
        RestAssured.useRelaxedHTTPSValidation();
        // Auth token loaded from AuthHelper, added to context
    }
    @After
    public void cleanup(Scenario scenario) {
        // Cleanup test data created during scenario
        testDataManager.cleanupAll();
    }
}
```

## Execution
```bash
mvn clean verify                                      # Default env
mvn clean verify -Denvironment=qa                     # QA
mvn clean verify -Denvironment=local                  # Local (JaCoCo)
mvn clean verify -Dcucumber.filter.tags="@smoke"      # Smoke
mvn serenity:aggregate                                # Serenity report
mvn allure:serve                                      # Allure report
```
