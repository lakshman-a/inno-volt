---
name: qa-test-data-assertions
description: Test data management, reusable assertions, DB validation, field-level assertion enforcement with placeholder failures. Use when creating test data, writing assertions, or adding database validation.
---

# Test Data & Assertions

## Reusable Test Data
- Create + cleanup in every scenario (setup → test → teardown)
- UUID suffix for parallel safety: `'test_' + UUID.randomUUID().toString().substring(0,8)`
- External JSON/CSV files for static data, JS/Java generators for dynamic data
- Faker library for realistic names, emails, phones
- TestDataManager class tracks created resources, cleanupAll() in @After hook

## Field-Level Assertions (EVERY field validated)

### Cucumber (AssertJ SoftAssertions)
```java
SoftAssertions soft = new SoftAssertions();
soft.assertThat(json.getString("id")).as("ID format").matches("[0-9a-f-]{36}");
soft.assertThat(json.getString("firstName")).as("firstName").isEqualTo(expected.getFirstName());
// ... every single field ...
soft.assertAll(); // Reports ALL failures, not just first
```

### Karate (Schema + Value Match)
```gherkin
And match response == read('classpath:schemas/success.json')  # Structure
And match response.firstName == customerData.firstName         # Values
And match response.id == '#uuid'                               # Format
```

## Placeholder Assertions (FAIL when data missing)
```java
// Java
fail("ASSERTION PLACEHOLDER: response.fieldName — provide expected value");
fail("DB ASSERTION: Verify record in [table] where id = " + id);
```
```gherkin
# Karate
* if (true) karate.fail('ASSERTION PLACEHOLDER: Validate response.field = [expected]')
* if (true) karate.fail('DB ASSERTION: Verify [table].[column] = [expected]')
```
These FORCE test failures until developer completes them. Never silently pass.

## DB Validation (When Available)
```java
// JDBC pattern
String sql = "SELECT * FROM customers WHERE id = ?";
ResultSet rs = conn.prepareStatement(sql).executeQuery();
assertThat(rs.next()).isTrue();
assertThat(rs.getString("email")).isEqualTo(expectedEmail);
```
```gherkin
# Karate + Java helper
* def db = new DbUtils(dbConfig)
* def row = db.readRow("SELECT * FROM customers WHERE id = '" + response.id + "'")
* match row.email == customerData.email
```

## Integration (API + DB Consistency)
After API create → query DB → assert API response matches DB record.
After API update → query DB → assert updated values match.
After API delete → query DB → assert record gone or soft-deleted.
