---
name: qa-test-execution
description: Test execution, Allure/Serenity/Karate reporting, parallel execution, and README generation. Use when running tests, generating reports, or configuring parallel execution.
---

# Test Execution & Reporting

## Mandatory Execution — ALWAYS After Generation

### Scaffold Execution (First — must pass before adding tests)
```bash
cd {test-project}/
mvn clean test -Dkarate.env=common 2>&1 | tee scaffold-execution.log
# Expected: Health check passes, dummy test passes, framework works
```

### Full Suite Execution
```bash
# Karate
cd {test-project}/
mvn clean test -Dkarate.env=dev 2>&1 | tee test-execution.log

# Cucumber+Serenity
cd {test-project}/
mvn clean verify -Denvironment=dev 2>&1 | tee test-execution.log
```

## Reports

### Allure (Preferred — shareable)
```bash
mvn allure:report                    # Generate
mvn allure:serve                     # Open in browser
# Static: target/site/allure-maven-plugin/index.html
```

### Serenity (Cucumber projects)
```bash
mvn serenity:aggregate
# Report: target/site/serenity/index.html
```

### Karate (Built-in)
```
# Auto-generated: target/karate-reports/karate-summary.html
```

## Present Results
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 TEST EXECUTION RESULTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total: X scenarios | ✅ Passed: X | ❌ Failed: X | ⏭️ Skipped: X
Reports: [paths listed]

Type "menu" for more options.
```

## Parallel Execution (Suggest when 20+ scenarios)

### Karate
```java
Results results = Runner.path("classpath:features").tags("~@ignore").parallel(5);
```

### Cucumber+Serenity
```xml
<configuration>
    <parallel>methods</parallel>
    <threadCount>4</threadCount>
</configuration>
```

### Data Isolation: UUID suffix on all test data, no shared mutable state, each scenario creates and cleans its own data.

## README.md — Always Create/Update in Test Project
Include: prerequisites, how to run, how to run per environment, how to run smoke, how to view reports, how to run JaCoCo, test suite summary table.

If README exists → update with new info (don't overwrite). If not → create.
