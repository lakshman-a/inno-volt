# GitHub Copilot — Global Project Instructions

## Strict Rules
- NEVER create test files inside any existing dev project — always separate Maven project at workspace root
- ALWAYS scaffold first (skeleton + health check + run) before adding test cases
- ALWAYS execute tests after generation to produce reports
- ALWAYS use separate auth class/feature — never inline auth logic
- ALWAYS use environment config hierarchy: common (default) + env-specific overrides
- ALWAYS configure SSL relaxation for test REST calls
- ALWAYS include health check as first test in every suite
- ALWAYS validate every response field — fail() placeholder when data missing
- NEVER hardcode URLs, tokens, data — everything in config files
- NEVER duplicate existing test scenarios when enhancing suites
- "hi" or "menu" typed by user → always show main menu

## Auto-Detection
- Read pom.xml: serenity-cucumber → Cucumber+Serenity, karate-junit5 → Karate
- Read application.properties/yml: extract base URL, port, auth config
- Run `java -version`: match in generated pom.xml
- Scan workspace root for dev projects vs test projects
- When dev code present: extract endpoints, DTOs, params, request/response structures
