---
name: qa-jacoco-coverage
description: JaCoCo code coverage for functional API tests. Precise step-by-step commands to download JaCoCo, instrument Spring Boot, run tests, dump coverage, and generate HTML reports. Also covers AI-estimated coverage when dev code unavailable.
---

# JaCoCo Coverage — Precise Execution Steps

## Prerequisites Check (Run BEFORE starting)

```bash
# 1. Check Java
java -version

# 2. Check dev project builds
cd {dev-project}/
mvn clean package -DskipTests -q
echo "Build status: $?"
ls target/*.jar 2>/dev/null && echo "JAR found" || echo "ERROR: No JAR found"

# 3. Check test project builds
cd {test-project}/
mvn clean compile -q
echo "Test project compiles: $?"

# 4. Find the Spring Boot JAR name
DEV_JAR=$(ls {dev-project}/target/*.jar | grep -v original | head -1)
echo "Dev JAR: $DEV_JAR"
```

If ANY check fails → stop and fix before proceeding.

## Step 1: Download JaCoCo Agent and CLI

```bash
JACOCO_VERSION=0.8.12

# Download JaCoCo agent (for instrumenting the dev API)
curl -L -o /tmp/jacoco-agent.jar \
  "https://repo1.maven.org/maven2/org/jacoco/org.jacoco.agent/${JACOCO_VERSION}/org.jacoco.agent-${JACOCO_VERSION}-runtime.jar"

# Download JaCoCo CLI (for dump + report generation)
curl -L -o /tmp/jacoco-cli.jar \
  "https://repo1.maven.org/maven2/org/jacoco/org.jacoco.cli/${JACOCO_VERSION}/org.jacoco.cli-${JACOCO_VERSION}-nodeps.jar"

# Verify downloads
ls -la /tmp/jacoco-agent.jar /tmp/jacoco-cli.jar
```

## Step 2: Stop Any Existing Instance of the Dev API

```bash
# Find and stop any running instance on the dev port
DEV_PORT=8080  # Adjust based on application.properties
lsof -ti:${DEV_PORT} | xargs kill -9 2>/dev/null
sleep 2
echo "Port ${DEV_PORT} is free"
```

## Step 3: Start Dev API with JaCoCo Agent

```bash
# Identify the correct package prefix from dev project
# (read from pom.xml groupId or main application package)
PACKAGE_PREFIX=com.example  # REPLACE with actual package

# Start Spring Boot with JaCoCo agent in tcpserver mode
cd {dev-project}/
java \
  -javaagent:/tmp/jacoco-agent.jar=output=tcpserver,address=127.0.0.1,port=6300,includes=${PACKAGE_PREFIX}.* \
  -jar target/*.jar \
  --server.port=${DEV_PORT} \
  &

# Store PID for later cleanup
DEV_PID=$!
echo "Dev API started with PID: $DEV_PID (JaCoCo on port 6300)"

# Wait for API to be ready
echo "Waiting for API to start..."
for i in $(seq 1 60); do
  if curl -sf http://localhost:${DEV_PORT}/actuator/health > /dev/null 2>&1; then
    echo "✅ API is UP and instrumented with JaCoCo"
    break
  fi
  if [ $i -eq 60 ]; then
    echo "❌ API failed to start within 60 seconds"
    echo "Check logs: tail -50 nohup.out"
    kill $DEV_PID 2>/dev/null
    exit 1
  fi
  sleep 1
done
```

**If dev API uses a different startup method** (e.g., Spring Boot Maven plugin):
```bash
cd {dev-project}/
MAVEN_OPTS="-javaagent:/tmp/jacoco-agent.jar=output=tcpserver,address=127.0.0.1,port=6300,includes=${PACKAGE_PREFIX}.*" \
  mvn spring-boot:run &
```

**If dev API uses docker-compose** → JaCoCo agent must be added to the JAVA_OPTS in docker-compose.yml. Inform user this requires docker config change.

## Step 4: Run Functional Tests Against Instrumented API

```bash
cd {test-project}/

# Point tests at the local instrumented API
# Karate:
mvn clean test -Dkarate.env=local 2>&1 | tee jacoco-test-execution.log

# Cucumber+Serenity:
mvn clean verify -Denvironment=local 2>&1 | tee jacoco-test-execution.log

echo "Test execution complete. Coverage data being collected by JaCoCo agent."
```

## Step 5: Dump Coverage Data

```bash
# Dump coverage from the running JaCoCo agent via TCP
java -jar /tmp/jacoco-cli.jar dump \
  --address 127.0.0.1 \
  --port 6300 \
  --destfile jacoco-functional.exec

echo "Coverage dump: jacoco-functional.exec ($(wc -c < jacoco-functional.exec) bytes)"

# Verify the exec file has data
if [ $(wc -c < jacoco-functional.exec) -lt 100 ]; then
  echo "⚠️ Coverage file seems empty. Possible issues:"
  echo "  - JaCoCo includes filter doesn't match your package"
  echo "  - Tests didn't hit the dev API endpoints"
  echo "  - Dev API wasn't running with JaCoCo agent"
fi
```

## Step 6: Generate HTML Coverage Report

```bash
# Generate comprehensive HTML report
java -jar /tmp/jacoco-cli.jar report jacoco-functional.exec \
  --classfiles {dev-project}/target/classes \
  --sourcefiles {dev-project}/src/main/java \
  --html jacoco-coverage-report \
  --csv jacoco-coverage-report/coverage.csv \
  --xml jacoco-coverage-report/coverage.xml \
  --name "Functional API Test Coverage"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 JACOCO COVERAGE REPORT GENERATED"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "HTML Report: jacoco-coverage-report/index.html"
echo "CSV Data:    jacoco-coverage-report/coverage.csv"
echo "XML Data:    jacoco-coverage-report/coverage.xml"
```

## Step 7: Parse and Display Coverage Summary

```bash
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 COVERAGE BY CLASS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Read CSV and calculate percentages
tail -n +2 jacoco-coverage-report/coverage.csv | while IFS=',' read -r grp pkg cls im ic bm bc lm lc cm cc mm mc; do
  total_i=$((im + ic))
  total_b=$((bm + bc))
  total_l=$((lm + lc))
  if [ "$total_i" -gt 0 ]; then
    pct_i=$((ic * 100 / total_i))
    pct_l=0
    if [ "$total_l" -gt 0 ]; then pct_l=$((lc * 100 / total_l)); fi
    pct_b=0
    if [ "$total_b" -gt 0 ]; then pct_b=$((bc * 100 / total_b)); fi
    echo "  ${pkg}.${cls}: Instructions=${pct_i}% | Lines=${pct_l}% | Branches=${pct_b}%"
  fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📈 OVERALL SUMMARY"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
# Calculate totals
tail -n +2 jacoco-coverage-report/coverage.csv | awk -F',' '
  { tim+=$4; tic+=$5; tbm+=$6; tbc+=$7; tlm+=$8; tlc+=$9 }
  END {
    if (tim+tic > 0) printf "  Instructions: %d%% (%d/%d)\n", tic*100/(tim+tic), tic, tim+tic
    if (tlm+tlc > 0) printf "  Lines:        %d%% (%d/%d)\n", tlc*100/(tlm+tlc), tlc, tlm+tlc
    if (tbm+tbc > 0) printf "  Branches:     %d%% (%d/%d)\n", tbc*100/(tbm+tbc), tbc, tbm+tbc
  }'
```

## Step 8: Cleanup

```bash
# Stop the instrumented dev API
kill $DEV_PID 2>/dev/null
echo "Dev API stopped."
```

## Step 9: Gap Analysis from Coverage

After reading the coverage report, identify:
1. **Classes with < 50% line coverage** → list them
2. **Uncovered controller methods** → suggest specific test scenarios
3. **Uncovered branches** → identify missing negative/edge cases
4. **Dead code** → methods with 0% coverage that no endpoint calls
5. Present:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔍 COVERAGE GAP ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Low Coverage Classes:
  ❌ CustomerService.java — 35% (missing: error handling, validation)
  ⚠️ OrderController.java — 55% (missing: PUT/DELETE endpoints)
  ✅ AuthController.java — 90%

Suggested Additional Tests:
  1. CustomerService error handling — 3 negative scenarios
  2. Order update endpoint — 4 scenarios (positive + negative)
  3. Order delete endpoint — 3 scenarios

Want me to generate these tests? (type "yes" or "menu")
```

---

## When Dev Project is NOT Available (AI Estimation)

```
⚠️ DISCLAIMER: This is an AI-ESTIMATED coverage analysis.
   Without JaCoCo instrumentation, exact numbers cannot be determined.
   This estimate may be inaccurate. Use for directional guidance only.

ESTIMATED COVERAGE ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Method: Mapping test scenarios to known/assumed endpoints

| Endpoint            | Tests Found | Est. Coverage | Gaps |
|---------------------|------------|---------------|------|
| POST /customers     | 8 scenarios | ~70%         | Missing: malformed JSON, rate limit |
| GET /customers/{id} | 3 scenarios | ~50%         | Missing: invalid UUID, not found |
| ...                 | ...         | ...          | ...  |

Overall Estimate: ~55% functional coverage

⚠️ For accurate coverage: add dev project to workspace and run JaCoCo.
```
