# QA Automation Agent for GitHub Copilot — v3.1

## Quick Start
1. Copy `.github/` folder to your project workspace root
2. VS Code 1.106+ → Copilot Chat → Select **"Senior QA Automation Engineer"**
3. Set model to **Claude Sonnet 4.5** → Type **"hi"**

## What's in v3.1 (Fixes from real-world testing)
- **Scaffold-first approach** — creates skeleton, runs it, then adds tests
- **Strict separate project** — test project at WORKSPACE ROOT, never inside dev project
- **Fixed karate-config.js** — proper config hierarchy (common + env override), no hardcoded URLs
- **Smart JaCoCo routing** — precise step-by-step commands, handles missing dev project gracefully
- **Existing suite understanding** — deep analysis before adding (no duplicates, matches patterns)
- **Context splitting** — large suites generated in phases to avoid token exhaustion
- **"menu" command** — type "menu" anytime to return to options
- **Auth/SSL/Health** — always separate auth class, SSL relaxation, health check first test
- **Dev code extraction** — auto-reads endpoints, DTOs, params from dev project

## File Structure (11 files)
```
.github/
├── copilot-instructions.md                      ← Global rules (19 lines)
├── agents/senior-qa-automation.agent.md         ← Agent persona (loads when selected)
├── instructions/qa-testing.instructions.md      ← Dynamic rules (for test files)
└── skills/
    ├── qa-cucumber-serenity/SKILL.md            ← Cucumber patterns (on-demand)
    ├── qa-karate-dsl/SKILL.md                   ← Karate patterns (on-demand)
    ├── qa-test-design/SKILL.md                  ← Coverage matrices (on-demand)
    ├── qa-test-execution/SKILL.md               ← Execution & reports (on-demand)
    ├── qa-jacoco-coverage/SKILL.md              ← JaCoCo coverage (on-demand)
    └── qa-test-data-assertions/SKILL.md         ← Data & assertions (on-demand)
```

## Context Window: Skills load on-demand (not all at once). Safe for token usage.
