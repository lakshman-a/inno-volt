# GenAI Platform - Complete Documentation

## Quick Start

### Prerequisites
- Python 3.12+ with pip
- Node.js 18.20+ with npm
- Java 21 (host) + JDK 8/11/17 for target projects
- Maven 3.8+

### Backend Setup
```bash
cd backend
python -m venv venv
source venv/bin/activate            # Linux/Mac
# venv\Scripts\activate             # Windows
pip install -r requirements.txt
cp .env.example .env
# Edit .env → set OAUTH_CLIENT_ID, OAUTH_CLIENT_SECRET
python -m app.main                  # or: ./run.sh dev
# → http://localhost:8000/docs
```

### Frontend Setup
```bash
cd frontend
npm install
ng serve
# → http://localhost:4200 (proxies /api → localhost:8000)
```

---

## Architecture

```
┌────────────────────── ANGULAR 14 FRONTEND ──────────────────────┐
│  Dashboard │ UnitTestGen │ ApiDocGen │ FuncTestGen │ SonarFix   │
│  Adoption  │ FileUpload  │ JobProgress │ Topbar │ Sidenav      │
│                                                                  │
│  core/services/api.service.ts  ← All HTTP calls to backend      │
│  core/interceptors/auth.interceptor.ts  ← SSO token injection   │
└──────────────────────┬──────────────────────────────────────────┘
                       │ /api/v1/* via proxy.conf.json
┌──────────────────────▼──────────────────────────────────────────┐
│                    FASTAPI BACKEND                               │
│                                                                  │
│  ┌── API Layer ────────────────────────────────────────────┐    │
│  │ POST /jobs/submit       (multipart: file + config)      │    │
│  │ GET  /jobs/{id}/status  (poll for progress)             │    │
│  │ GET  /jobs/{id}/download (result zip)                   │    │
│  │ GET  /solutions          (list available solutions)     │    │
│  │ GET  /health, /usage                                    │    │
│  └─────────────────────┬──────────────────────────────────┘    │
│                        │                                        │
│  ┌── Core ─────────────▼──────────────────────────────────┐    │
│  │ job_manager.py     → Async job lifecycle & tracking     │    │
│  │ solution_registry  → Plugin registration                │    │
│  │ exceptions.py      → Clean error responses              │    │
│  └─────────────────────┬──────────────────────────────────┘    │
│                        │                                        │
│  ┌── Solution Plugins ─▼──────────────────────────────────┐    │
│  │ unit_test_gen/  │ api_doc_gen/  │ func_test_gen/  │    │    │
│  │ sonar_fix/      │                                      │    │
│  └─────────────────────┬──────────────────────────────────┘    │
│                        │                                        │
│  ┌── Shared Services ──▼──────────────────────────────────┐    │
│  │ llm_client.py       → OAuth + Gateway API calls         │    │
│  │ project_analyzer.py → Java/Maven project analysis       │    │
│  │ maven_runner.py     → Build/test with JDK switching     │    │
│  │ coverage_parser.py  → JaCoCo XML parsing                │    │
│  │ file_manager.py     → Zip/workspace management          │    │
│  │ prompt_manager.py   → Template loading                  │    │
│  │ email_service.py    → Job completion notifications      │    │
│  │ cache_service.py    → In-memory TTL cache               │    │
│  └────────────────────────────────────────────────────────┘    │
│                        │                                        │
│  ┌── Prompts ──────────▼──────────────────────────────────┐    │
│  │ unit_test_gen/system.txt, generate_tests.txt, fix.txt   │    │
│  │ api_doc_gen/system.txt, generate_fields.txt             │    │
│  │ func_test_gen/system.txt, generate_tests.txt            │    │
│  │ sonar_fix/system.txt, fix_issues.txt                    │    │
│  └────────────────────────────────────────────────────────┘    │
└──────────────────────┬──────────────────────────────────────────┘
                       │ HTTPS
┌──────────────────────▼──────────────────────────────────────────┐
│  FMR GenAI Gateway                                               │
│  OAuth: esg-qa-oauth2-internal.fmr.com/as/resourceOwner         │
│  LLM:   genaigateway-qa.fmr.com/llm-orchestrator/v2/gen/text   │
│  Routes to: Azure OpenAI, AWS Bedrock (Claude), GCP (Gemini)    │
└──────────────────────────────────────────────────────────────────┘
```

---

## Solution 1: Unit Test Generation

### Flow
```
Upload ZIP → Extract → Parse pom.xml → Detect Java version
→ Set JAVA_HOME to matching JDK → mvn clean test jacoco:report
→ Parse jacoco.xml → Find uncovered classes → For each class:
    Build prompt (source + deps + gaps) → Call Gateway API
    → Write *GenTest.java → mvn test-compile → Fix if errors
    → mvn test -Dtest=TestClass → Retry if fails
→ Final mvn clean test → New coverage % → Package ZIP
```

### Files
| File | Purpose |
|------|---------|
| `solutions/unit_test_gen/solution.py` | Main pipeline |
| `prompts/unit_test_gen/system.txt` | System prompt |
| `prompts/unit_test_gen/generate_tests.txt` | User prompt template |
| `prompts/unit_test_gen/fix_errors.txt` | Error fix prompt |
| `shared/maven_runner.py` | Build/test execution |
| `shared/coverage_parser.py` | JaCoCo XML parsing |

### Config (UI → API)
```json
{ "target_coverage_percent": 80, "max_classes_to_process": 50 }
```

---

## Solution 2: API Documentation DX

### Flow
```
Upload ZIP → Deep scan: controllers, models, services, config, swagger
→ Build context (all code organized by type)
→ System prompt with DX field rules + validation requirements
→ Call Gateway API → Parse JSON response
→ Validate: shortDescription≥30chars, fullDescription≥30words, etc.
→ Save dx-documentation.json + dx-documentation.md
```

### DX Fields Generated
Tag Line, Description, Approved Use Cases, Where Used, Tags,
FAQ Technical, FAQ Business, Conditions for Use, Production Support,
Support Email, Resources, Endpoints, API Metadata

### Files
| File | Purpose |
|------|---------|
| `solutions/api_doc_gen/solution.py` | Main pipeline + DX validation |
| `prompts/api_doc_gen/system.txt` | DX rules system prompt |
| `prompts/api_doc_gen/generate_fields.txt` | Generation template |

---

## Solution 3: Functional Test Generation

### Flow
```
Upload API project → Scan controllers → Extract endpoints
→ User selects: Karate DSL or Cucumber Serenity
→ User selects mode: New Suite / Update / Find Gaps / Coverage
→ User provides: requirements, swagger (optional)
→ Call Gateway API with all context
→ Parse output → Write .feature files and step defs
→ Package as downloadable test suite
```

### Generation Modes
- **new_test_suite**: Creates complete test project (config + features + helpers)
- **update_tests**: Adds missing scenarios to existing suite
- **find_gaps**: Returns JSON of untested endpoints/scenarios
- **coverage_analysis**: Per-endpoint test coverage breakdown

### Files
| File | Purpose |
|------|---------|
| `solutions/func_test_gen/solution.py` | Main pipeline |
| `prompts/func_test_gen/system.txt` | QA Engineer system prompt |
| `prompts/func_test_gen/generate_tests.txt` | Generation template |

---

## Solution 4: Sonar Code Remediation

### Flow
```
Upload project → (Optional) Connect to SonarQube API
→ Fetch issues: bugs, vulnerabilities, code smells
→ OR: AI-based local code analysis (no Sonar needed)
→ Group issues by file → For each file:
    Build prompt (source + issues list) → Call Gateway API
    → Write fixed code → mvn compile → Fix if errors
    → Backup original → Apply fix → Validate build
→ Final build check → Package ZIP
```

### SonarQube Integration
- Provide: `sonar_url`, `sonar_project_key`, `sonar_token`
- API call: `GET /api/issues/search?componentKeys=KEY&types=BUG,VULNERABILITY`
- Falls back to AI-based analysis if no Sonar configured

### Files
| File | Purpose |
|------|---------|
| `solutions/sonar_fix/solution.py` | Main pipeline + Sonar API |
| `prompts/sonar_fix/system.txt` | Code fix system prompt |
| `prompts/sonar_fix/fix_issues.txt` | Fix prompt template |

---

## Shared Services

| Service | File | What It Does |
|---------|------|-------------|
| **LLM Client** | `shared/llm_client.py` | OAuth token management, Gateway API calls, retry with backoff, token/cost tracking |
| **Project Analyzer** | `shared/project_analyzer.py` | Parses pom.xml, detects Java version, finds frameworks, scans files |
| **Maven Runner** | `shared/maven_runner.py` | Runs Maven with correct JDK, compile/test/jacoco commands |
| **Coverage Parser** | `shared/coverage_parser.py` | Parses JaCoCo XML, extracts per-class/method coverage |
| **File Manager** | `shared/file_manager.py` | ZIP handling, workspace creation, output packaging |
| **Prompt Manager** | `shared/prompt_manager.py` | Loads .txt templates, renders with variables |
| **Email Service** | `shared/email_service.py` | SMTP email for job notifications (standalone module) |
| **Cache Service** | `shared/cache_service.py` | In-memory TTL cache for repeated operations |

---

## Error Handling

All errors flow cleanly to the UI:

```
Exception in solution → Caught by job_manager → Sets job.status = FAILED
                       → Sets job.message = "Clear error description"
                       → job.errors[] = [detail1, detail2]

Gateway API error → GatewayAPIError → Retry with backoff
                  → After 3 retries → Logged + added to job.errors

HTTP errors → global_exception_handler → Returns JSON:
  { "error": true, "message": "...", "error_id": "ERR-XXXX" }
```

The UI's `<app-job-progress>` component displays errors in red banners.

---

## Configuration

### .env (Backend)
```bash
OAUTH_TOKEN_URL=https://esg-qa-oauth2-internal.fmr.com/as/resourceOwner
OAUTH_CLIENT_ID=a602449
OAUTH_CLIENT_SECRET=your-secret
GATEWAY_BASE_URL=https://genaigateway-qa.fmr.com/llm-orchestrator/v2/generation/text
GATEWAY_DEFAULT_MODEL=gpt-4o
JAVA_DEFAULT_HOME=/usr/lib/jvm/java-21-openjdk-amd64
```

### Adding a New Model
Edit `config/settings.py` → `model_registry`:
```python
"my-model": {"provider": "Azure", "id": "my-model-id", "version": ""},
```

### Changing Prompts (no code change needed)
Edit text files in `app/prompts/{solution}/`. Changes take effect on next job.

---

## File Map (What to Change for What)

| I want to... | Edit this file |
|---|---|
| Add new solution | `services/solutions/new/solution.py` + register in `main.py` |
| Change LLM prompts | `app/prompts/{solution}/*.txt` |
| Change default model | `.env` → `GATEWAY_DEFAULT_MODEL` |
| Add new model | `config/settings.py` → `model_registry` |
| Change Gateway format | `shared/llm_client.py` → `_build_payload()` / `_parse_response()` |
| Change DX field rules | `solutions/api_doc_gen/solution.py` → `DX_FIELD_RULES` |
| Add UI page | `frontend/src/app/features/new-page/` + routing + module |
| Configure email | `shared/email_service.py` → constructor params |
| Change JDK paths | `config/settings.py` → `jdk_paths` |
| Add API endpoint | `api/routes/main.py` |
| Change error format | `core/exceptions.py` |

---

## Security

- **No model hosting** — All LLM calls through enterprise GenAI Gateway
- **Temporary storage** — Uploaded code in /tmp, cleaned after processing
- **OAuth2** — ESG OAuth client_credentials for Gateway auth
- **SSO-ready** — Auth interceptor + guard in Angular for enterprise SSO
- **No code leaves network** — Gateway routes to internal Azure/AWS/GCP
- **Audit trail** — Every LLM call logged with model, tokens, cost, timestamp
