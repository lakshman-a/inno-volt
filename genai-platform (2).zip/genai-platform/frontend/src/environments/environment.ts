export const environment = {
  production: false,
  apiBaseUrl: '/api/v1',
  appName: 'GenAI Platform',
  version: '0.1.0',
};
