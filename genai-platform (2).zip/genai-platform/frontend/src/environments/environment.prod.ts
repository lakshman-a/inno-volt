export const environment = {
  production: true,
  apiBaseUrl: '/api/v1',
  appName: 'GenAI Platform',
  version: '0.1.0',
};
