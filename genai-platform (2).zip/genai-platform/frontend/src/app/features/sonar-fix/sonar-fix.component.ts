import { Component } from '@angular/core';
import { ApiService } from '@core/services/api.service';
import { AdoptionService } from '@core/services/adoption.service';
import { JobStatusResponse } from '@core/models/api.models';

@Component({
  selector: 'app-sonar-fix',
  template: `
    <div class="page animate-in">
      <div class="page-header">
        <div class="page-icon" style="background: rgba(251,191,36,0.12); color: #FBBF24;">
          <span class="material-icons-outlined">bug_report</span>
        </div>
        <div>
          <h1 class="section-title">Sonar Code Remediation</h1>
          <p class="section-subtitle">Auto-fix SonarQube issues: bugs, vulnerabilities, and code smells.</p>
        </div>
      </div>

      <div class="info-banner" *ngIf="!jobStatus">
        <span class="material-icons-outlined">info</span>
        <div>
          <strong>How it works:</strong> Upload your project and optionally provide your SonarQube project key.
          The platform fetches all open issues, generates fixes via AI, validates they compile, and returns the fixed project.
          <br><strong>No Sonar?</strong> The platform can also do AI-based code analysis to find common issues.
        </div>
      </div>

      <div class="input-section card" *ngIf="!jobStatus || jobStatus.status === 'failed'">
        <h3>Project Input</h3>
        <app-file-upload (fileSelected)="onFileSelected($event)" [showGitOption]="true"></app-file-upload>

        <!-- SonarQube Config -->
        <div class="sonar-config">
          <h4>
            <span class="material-icons-outlined">settings</span>
            SonarQube Connection
            <span class="badge info">Optional</span>
          </h4>
          <div class="config-row">
            <div class="form-group">
              <label>SonarQube URL</label>
              <input class="form-input" [(ngModel)]="sonarUrl" placeholder="https://sonar.fmr.com">
            </div>
            <div class="form-group">
              <label>Project Key</label>
              <input class="form-input" [(ngModel)]="sonarProjectKey" placeholder="com.fidelity:my-api">
            </div>
          </div>
          <div class="form-group">
            <label>SonarQube Token</label>
            <input class="form-input" type="password" [(ngModel)]="sonarToken" placeholder="squ_xxxxxxxx">
          </div>
        </div>

        <!-- Fix Categories -->
        <div class="form-group">
          <label>Issue Categories to Fix</label>
          <div class="checkbox-group">
            <label class="checkbox-item" *ngFor="let cat of categories">
              <input type="checkbox" [(ngModel)]="cat.selected"> {{ cat.label }}
              <span class="cat-badge" [style.background]="cat.color">{{ cat.count || '' }}</span>
            </label>
          </div>
        </div>

        <div class="config-row">
          <div class="form-group">
            <label>AI Model</label>
            <select class="form-select" [(ngModel)]="modelId">
              <option value="">Default (GPT-4o)</option>
              <option value="gpt-4o-mini">GPT-4o Mini</option>
              <option value="claude-sonnet">Claude Sonnet</option>
              <option value="claude-opus">Claude Opus</option>
            </select>
          </div>
          <div class="form-group">
            <label>Max Issues to Fix</label>
            <input class="form-input" type="number" [(ngModel)]="maxIssues" min="1" max="100">
          </div>
        </div>

        <button class="btn-primary submit-btn" [disabled]="!selectedFile || isSubmitting" (click)="submitJob()">
          <span class="material-icons-outlined">build</span>
          {{ isSubmitting ? 'Submitting...' : 'Fix Sonar Issues' }}
        </button>
      </div>

      <app-job-progress *ngIf="jobStatus" [job]="jobStatus"></app-job-progress>

      <div class="results-section" *ngIf="jobStatus?.status === 'completed' && result">
        <h2 class="section-title">Results</h2>

        <div class="result-hero card">
          <div class="hero-stat">
            <div class="stat-value" style="color: var(--success);">{{ result.issues_fixed }}</div>
            <div class="stat-label">Issues Fixed</div>
          </div>
          <div class="hero-divider">/</div>
          <div class="hero-stat">
            <div class="stat-value">{{ result.issues_found }}</div>
            <div class="stat-label">Total Found</div>
          </div>
          <div class="hero-stat" style="margin-left: auto;">
            <span class="badge" [class]="result.final_build_passed ? 'success' : 'error'">
              Build: {{ result.final_build_passed ? 'PASS' : 'FAIL' }}
            </span>
          </div>
        </div>

        <div class="result-stats">
          <div class="stat-card"><div class="stat-value">{{ result.files_modified }}</div><div class="stat-label">Files Modified</div></div>
          <div class="stat-card"><div class="stat-value">{{ result.issues_failed }}</div><div class="stat-label">Could Not Fix</div></div>
          <div class="stat-card"><div class="stat-value">{{ result.total_llm_calls }}</div><div class="stat-label">AI Calls</div></div>
          <div class="stat-card"><div class="stat-value">\${{ result.estimated_cost | number:'1.3-3' }}</div><div class="stat-label">Cost</div></div>
        </div>

        <div class="file-results card" *ngIf="result.file_results?.length">
          <h3>Per-File Results</h3>
          <div class="file-result-item" *ngFor="let fr of result.file_results">
            <span class="material-icons-outlined" [style.color]="fr.success ? 'var(--success)' : 'var(--error)'">
              {{ fr.success ? 'check_circle' : 'cancel' }}
            </span>
            <span class="mono">{{ fr.target_class }}</span>
            <span class="badge" [class]="fr.success ? 'success' : 'error'">{{ fr.success ? 'Fixed' : 'Failed' }}</span>
            <span class="attempts">{{ fr.attempts }} attempt(s)</span>
          </div>
        </div>

        <div class="download-section">
          <button class="btn-primary" (click)="downloadResult()">
            <span class="material-icons-outlined">download</span> Download Fixed Project
          </button>
          <button class="btn-secondary" (click)="resetJob()">
            <span class="material-icons-outlined">replay</span> Run Another
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page { padding: var(--space-xl) var(--space-2xl); max-width: 960px; }
    .page-header { display: flex; align-items: flex-start; gap: var(--space-md); margin-bottom: var(--space-xl); }
    .page-icon { width: 48px; height: 48px; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; span { font-size: 28px; } }
    .info-banner { display: flex; gap: 12px; padding: var(--space-md) var(--space-lg); background: var(--info-bg); border: 1px solid rgba(96,165,250,0.2); border-radius: var(--radius-md); margin-bottom: var(--space-xl); font-size: 0.85rem; color: var(--text-secondary); line-height: 1.6; .material-icons-outlined { color: var(--info); font-size: 20px; flex-shrink: 0; } strong { color: var(--text-primary); } }
    .input-section { margin-bottom: var(--space-xl); h3 { margin-bottom: var(--space-md); font-size: 1rem; } }
    .sonar-config { margin-top: var(--space-lg); padding: var(--space-lg); background: var(--bg-input); border: 1px solid var(--border-default); border-radius: var(--radius-md);
      h4 { display: flex; align-items: center; gap: 8px; font-size: 0.9rem; margin-bottom: var(--space-md); span.material-icons-outlined { font-size: 18px; color: var(--text-muted); } }
    }
    .config-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-md); }
    .checkbox-group { display: flex; gap: var(--space-lg); flex-wrap: wrap; }
    .checkbox-item { display: flex; align-items: center; gap: 6px; font-size: 0.85rem; cursor: pointer; input { accent-color: var(--accent); } }
    .cat-badge { font-size: 0.7rem; padding: 1px 6px; border-radius: 4px; color: white; }
    .submit-btn { margin-top: var(--space-lg); width: 100%; justify-content: center; padding: 14px; font-size: 1rem; }
    .results-section { margin-top: var(--space-xl); }
    .result-hero { display: flex; align-items: center; gap: var(--space-xl); padding: var(--space-xl); margin-bottom: var(--space-lg); }
    .hero-divider { font-size: 2rem; color: var(--text-muted); }
    .result-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-md); margin-bottom: var(--space-lg); }
    .stat-card { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-lg); padding: var(--space-lg); }
    .file-results { margin-bottom: var(--space-lg); h3 { margin-bottom: var(--space-md); font-size: 1rem; } }
    .file-result-item { display: flex; align-items: center; gap: var(--space-sm); padding: 10px 0; border-bottom: 1px solid var(--border-subtle); font-size: 0.85rem; .material-icons-outlined { font-size: 18px; } .mono { flex: 1; } .attempts { font-size: 0.75rem; color: var(--text-muted); } }
    .download-section { display: flex; gap: var(--space-md); margin-top: var(--space-lg); }
  `]
})
export class SonarFixComponent {
  selectedFile: File | null = null;
  sonarUrl = '';
  sonarProjectKey = '';
  sonarToken = '';
  modelId = '';
  maxIssues = 30;
  isSubmitting = false;
  jobStatus: JobStatusResponse | null = null;
  result: any = null;

  categories = [
    { value: 'BUG', label: 'Bugs', selected: true, color: '#F87171', count: '' },
    { value: 'VULNERABILITY', label: 'Vulnerabilities', selected: true, color: '#FBBF24', count: '' },
    { value: 'CODE_SMELL', label: 'Code Smells', selected: true, color: '#60A5FA', count: '' },
  ];

  constructor(private api: ApiService, private adoptionService: AdoptionService) {}

  onFileSelected(file: File): void { this.selectedFile = file; }

  submitJob(): void {
    if (!this.selectedFile) return;
    this.isSubmitting = true;
    const config = JSON.stringify({
      sonar_url: this.sonarUrl,
      sonar_token: this.sonarToken,
      sonar_project_key: this.sonarProjectKey,
      fix_categories: this.categories.filter(c => c.selected).map(c => c.value),
      max_issues_to_fix: this.maxIssues,
    });
    this.api.submitJob(this.selectedFile, 'sonar_fix', this.modelId || undefined, config)
      .subscribe({
        next: (res) => { this.isSubmitting = false; this.pollJob(res.job_id); },
        error: (err) => { this.isSubmitting = false; }
      });
  }

  private pollJob(jobId: string): void {
    this.api.pollJobStatus(jobId, 2000).subscribe({
      next: (status) => {
        this.jobStatus = status;
        if (status.status === 'completed' && status.result) { this.result = status.result; }
      }
    });
  }

  downloadResult(): void {
    if (!this.jobStatus) return;
    this.api.downloadResult(this.jobStatus.job_id).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = `sonar_fixed_${this.jobStatus!.job_id}.zip`; a.click();
    });
  }

  resetJob(): void { this.jobStatus = null; this.result = null; this.selectedFile = null; }
}
