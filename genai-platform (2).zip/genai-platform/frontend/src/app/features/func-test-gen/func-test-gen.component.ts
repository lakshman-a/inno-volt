import { Component } from '@angular/core';
import { ApiService } from '@core/services/api.service';
import { AdoptionService } from '@core/services/adoption.service';
import { JobStatusResponse } from '@core/models/api.models';

@Component({
  selector: 'app-func-test-gen',
  template: `
    <div class="page animate-in">
      <div class="page-header">
        <div class="page-icon" style="background: rgba(167,139,250,0.12); color: #A78BFA;">
          <span class="material-icons-outlined">integration_instructions</span>
        </div>
        <div>
          <h1 class="section-title">Functional Test Generation</h1>
          <p class="section-subtitle">Generate Karate DSL or Cucumber Serenity functional tests from your API project.</p>
        </div>
      </div>

      <div class="info-banner" *ngIf="!jobStatus">
        <span class="material-icons-outlined">info</span>
        <div>
          <strong>How it works:</strong> Upload your API project (required) and optionally a Swagger spec or existing test suite.
          Choose your test framework and generation mode. The AI will scan your endpoints and generate comprehensive functional tests.
        </div>
      </div>

      <div class="input-section card" *ngIf="!jobStatus || jobStatus.status === 'failed'">
        <h3>Project Input</h3>
        <app-file-upload (fileSelected)="onFileSelected($event)" [showGitOption]="true"></app-file-upload>

        <!-- Framework Selection -->
        <div class="option-cards">
          <div class="option-card" [class.selected]="testFramework === 'karate'" (click)="testFramework = 'karate'">
            <span class="material-icons-outlined">bolt</span>
            <strong>Karate DSL</strong>
            <p>Built-in HTTP client, JSON/XML assertions, parallel execution. Best for pure API testing.</p>
          </div>
          <div class="option-card" [class.selected]="testFramework === 'cucumber_serenity'" (click)="testFramework = 'cucumber_serenity'">
            <span class="material-icons-outlined">auto_stories</span>
            <strong>Cucumber + Serenity</strong>
            <p>BDD feature files with rich HTML reports. Best when business stakeholders review tests.</p>
          </div>
        </div>

        <!-- Generation Mode -->
        <div class="form-group">
          <label>Generation Mode</label>
          <div class="mode-cards">
            <div class="mode-card" *ngFor="let mode of modes"
                 [class.selected]="generationMode === mode.value"
                 (click)="generationMode = mode.value">
              <span class="material-icons-outlined">{{ mode.icon }}</span>
              <div>
                <strong>{{ mode.label }}</strong>
                <p>{{ mode.desc }}</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Config -->
        <div class="config-row">
          <div class="form-group">
            <label>AI Model</label>
            <select class="form-select" [(ngModel)]="modelId">
              <option value="">Default (GPT-4o)</option>
              <option value="gpt-4o-mini">GPT-4o Mini</option>
              <option value="claude-sonnet">Claude Sonnet</option>
              <option value="claude-opus">Claude Opus</option>
            </select>
          </div>
        </div>

        <!-- Requirements / User Stories -->
        <div class="form-group">
          <label>Requirements / User Stories (optional - improves test quality)</label>
          <textarea class="form-textarea" rows="5" [(ngModel)]="requirements"
                    placeholder="Paste user stories, acceptance criteria, or API requirements here..."></textarea>
        </div>

        <!-- Swagger input -->
        <div class="form-group">
          <label>Swagger / OpenAPI Spec (optional JSON or YAML)</label>
          <textarea class="form-textarea mono-textarea" rows="4" [(ngModel)]="swaggerContent"
                    placeholder="Paste Swagger JSON/YAML here, or include swagger.json in your ZIP..."></textarea>
        </div>

        <button class="btn-primary submit-btn" [disabled]="!selectedFile || isSubmitting" (click)="submitJob()">
          <span class="material-icons-outlined">play_circle</span>
          {{ isSubmitting ? 'Submitting...' : 'Generate Functional Tests' }}
        </button>
      </div>

      <app-job-progress *ngIf="jobStatus" [job]="jobStatus"></app-job-progress>

      <div class="results-section" *ngIf="jobStatus?.status === 'completed' && result">
        <h2 class="section-title">Results</h2>
        <div class="result-stats">
          <div class="stat-card"><div class="stat-value">{{ result.endpoints_found }}</div><div class="stat-label">Endpoints Found</div></div>
          <div class="stat-card"><div class="stat-value">{{ result.files_generated }}</div><div class="stat-label">Files Generated</div></div>
          <div class="stat-card"><div class="stat-value">{{ result.total_llm_calls }}</div><div class="stat-label">AI Calls</div></div>
          <div class="stat-card"><div class="stat-value">\${{ result.estimated_cost | number:'1.3-3' }}</div><div class="stat-label">Cost</div></div>
        </div>

        <div class="files-list card" *ngIf="result.file_list?.length">
          <h3>Generated Files</h3>
          <div class="file-item" *ngFor="let f of result.file_list">
            <span class="material-icons-outlined">description</span>
            <span class="mono">{{ f }}</span>
          </div>
        </div>

        <div class="download-section">
          <button class="btn-primary" (click)="downloadResult()">
            <span class="material-icons-outlined">download</span> Download Test Suite
          </button>
          <button class="btn-secondary" (click)="resetJob()">
            <span class="material-icons-outlined">replay</span> Run Another
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page { padding: var(--space-xl) var(--space-2xl); max-width: 960px; }
    .page-header { display: flex; align-items: flex-start; gap: var(--space-md); margin-bottom: var(--space-xl); }
    .page-icon { width: 48px; height: 48px; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; span { font-size: 28px; } }
    .info-banner { display: flex; gap: 12px; padding: var(--space-md) var(--space-lg); background: var(--info-bg); border: 1px solid rgba(96,165,250,0.2); border-radius: var(--radius-md); margin-bottom: var(--space-xl); font-size: 0.85rem; color: var(--text-secondary); line-height: 1.6; .material-icons-outlined { color: var(--info); font-size: 20px; flex-shrink: 0; } strong { color: var(--text-primary); } }
    .input-section { margin-bottom: var(--space-xl); h3 { margin-bottom: var(--space-md); font-size: 1rem; } }
    .option-cards { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-md); margin: var(--space-lg) 0; }
    .option-card { padding: var(--space-lg); background: var(--bg-input); border: 2px solid var(--border-default); border-radius: var(--radius-md); cursor: pointer; transition: all var(--transition-fast); text-align: center;
      span { font-size: 28px; color: var(--text-muted); display: block; margin-bottom: 8px; }
      strong { font-size: 0.95rem; display: block; margin-bottom: 4px; }
      p { font-size: 0.8rem; color: var(--text-muted); margin: 0; }
      &.selected { border-color: var(--accent); background: var(--accent-subtle); span { color: var(--accent); } }
      &:hover:not(.selected) { border-color: var(--border-focus); }
    }
    .mode-cards { display: flex; flex-direction: column; gap: var(--space-sm); }
    .mode-card { display: flex; align-items: center; gap: var(--space-md); padding: 12px var(--space-md); background: var(--bg-input); border: 1px solid var(--border-default); border-radius: var(--radius-md); cursor: pointer; transition: all var(--transition-fast);
      span { font-size: 20px; color: var(--text-muted); }
      strong { font-size: 0.85rem; display: block; }
      p { font-size: 0.75rem; color: var(--text-muted); margin: 0; }
      &.selected { border-color: var(--accent); background: var(--accent-subtle); span { color: var(--accent); } }
    }
    .config-row { display: grid; grid-template-columns: 1fr; gap: var(--space-md); margin-top: var(--space-lg); }
    .form-textarea, .mono-textarea { width: 100%; padding: 10px 14px; background: var(--bg-input); border: 1px solid var(--border-default); border-radius: var(--radius-md); color: var(--text-primary); font-family: 'DM Sans', sans-serif; font-size: 0.85rem; resize: vertical; outline: none; &:focus { border-color: var(--accent); } &::placeholder { color: var(--text-muted); } }
    .mono-textarea { font-family: 'JetBrains Mono', monospace; font-size: 0.8rem; }
    .submit-btn { margin-top: var(--space-lg); width: 100%; justify-content: center; padding: 14px; font-size: 1rem; }
    .results-section { margin-top: var(--space-xl); }
    .result-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-md); margin-bottom: var(--space-lg); }
    .stat-card { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-lg); padding: var(--space-lg); }
    .files-list { margin-bottom: var(--space-lg); h3 { margin-bottom: var(--space-md); font-size: 1rem; } }
    .file-item { display: flex; align-items: center; gap: 8px; padding: 8px 0; border-bottom: 1px solid var(--border-subtle); font-size: 0.85rem; span { font-size: 18px; color: var(--accent); } }
    .download-section { display: flex; gap: var(--space-md); }
  `]
})
export class FuncTestGenComponent {
  selectedFile: File | null = null;
  testFramework = 'karate';
  generationMode = 'new_test_suite';
  modelId = '';
  requirements = '';
  swaggerContent = '';
  isSubmitting = false;
  jobStatus: JobStatusResponse | null = null;
  result: any = null;

  modes = [
    { value: 'new_test_suite', label: 'New Test Suite', desc: 'Generate a complete test project from scratch', icon: 'add_circle' },
    { value: 'update_tests', label: 'Update Existing Tests', desc: 'Add missing scenarios to your existing test suite', icon: 'edit' },
    { value: 'find_gaps', label: 'Find Gaps', desc: 'Analyze what endpoints/scenarios are missing tests', icon: 'search' },
    { value: 'coverage_analysis', label: 'Coverage Analysis', desc: 'Analyze test coverage per endpoint', icon: 'analytics' },
  ];

  constructor(private api: ApiService, private adoptionService: AdoptionService) {}

  onFileSelected(file: File): void { this.selectedFile = file; }

  submitJob(): void {
    if (!this.selectedFile) return;
    this.isSubmitting = true;
    const config = JSON.stringify({
      test_framework: this.testFramework,
      generation_mode: this.generationMode,
      requirements: this.requirements,
      swagger_content: this.swaggerContent,
    });
    this.api.submitJob(this.selectedFile, 'func_test_gen', this.modelId || undefined, config)
      .subscribe({
        next: (res) => { this.isSubmitting = false; this.pollJob(res.job_id); },
        error: (err) => { this.isSubmitting = false; console.error(err); }
      });
  }

  private pollJob(jobId: string): void {
    this.api.pollJobStatus(jobId, 2000).subscribe({
      next: (status) => {
        this.jobStatus = status;
        if (status.status === 'completed' && status.result) { this.result = status.result; }
      }
    });
  }

  downloadResult(): void {
    if (!this.jobStatus) return;
    this.api.downloadResult(this.jobStatus.job_id).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = `func_tests_${this.jobStatus!.job_id}.zip`; a.click();
    });
  }

  resetJob(): void { this.jobStatus = null; this.result = null; this.selectedFile = null; }
}
