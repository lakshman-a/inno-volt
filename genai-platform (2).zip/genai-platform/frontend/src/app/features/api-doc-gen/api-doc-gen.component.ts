import { Component } from '@angular/core';
import { ApiService } from '@core/services/api.service';
import { AdoptionService } from '@core/services/adoption.service';
import { JobStatusResponse, ApiDocGenResult } from '@core/models/api.models';

@Component({
  selector: 'app-api-doc-gen',
  template: `
    <div class="page animate-in">
      <div class="page-header">
        <div class="page-icon" style="background: rgba(96,165,250,0.12); color: #60A5FA;">
          <span class="material-icons-outlined">description</span>
        </div>
        <div>
          <h1 class="section-title">API Documentation DX</h1>
          <p class="section-subtitle">Automatically populate API documentation fields by analyzing your REST API codebase.</p>
        </div>
      </div>

      <div class="info-banner" *ngIf="!jobStatus">
        <span class="material-icons-outlined">info</span>
        <div>
          <strong>How it works:</strong> Upload your Java REST API project. The platform scans controllers, DTOs, and annotations
          to populate documentation fields. You can provide custom field definitions or use the default template.
        </div>
      </div>

      <!-- Input Section -->
      <div class="input-section card" *ngIf="!jobStatus || jobStatus.status === 'failed'">
        <h3>Project Input</h3>
        <app-file-upload (fileSelected)="onFileSelected($event)"></app-file-upload>

        <div class="config-row">
          <div class="form-group">
            <label>AI Model</label>
            <select class="form-select" [(ngModel)]="modelId">
              <option value="">Default (GPT-4o)</option>
              <option value="gpt-4o-mini">GPT-4o Mini (faster, cheaper)</option>
              <option value="claude-sonnet">Claude Sonnet (recommended)</option>
              <option value="claude-opus">Claude Opus (best quality)</option>
              <option value="gemini">Gemini</option>
            </select>
          </div>
          <div class="form-group">
            <label>Output Format</label>
            <select class="form-select" [(ngModel)]="outputFormat">
              <option value="markdown">Markdown</option>
              <option value="json">JSON</option>
              <option value="html">HTML</option>
            </select>
          </div>
        </div>

        <!-- Custom Fields -->
        <div class="form-group">
          <label>Custom Documentation Fields (optional JSON)</label>
          <textarea class="form-textarea" rows="6" [(ngModel)]="customFieldsJson"
                    placeholder='[{"field": "endpoint_path", "description": "API path"}, ...]'>
          </textarea>
        </div>

        <button class="btn-primary submit-btn" [disabled]="!selectedFile || isSubmitting" (click)="submitJob()">
          <span class="material-icons-outlined">auto_stories</span>
          {{ isSubmitting ? 'Submitting...' : 'Generate Documentation' }}
        </button>
      </div>

      <app-job-progress *ngIf="jobStatus" [job]="jobStatus"></app-job-progress>

      <!-- Results -->
      <div class="results-section" *ngIf="jobStatus?.status === 'completed' && result">
        <h2 class="section-title">Results</h2>

        <div class="result-stats">
          <div class="stat-card">
            <div class="stat-value">{{ result.endpoints_found }}</div>
            <div class="stat-label">Endpoints Found</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">{{ result.endpoints_documented }}</div>
            <div class="stat-label">Documented</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">{{ result.fields_populated }}</div>
            <div class="stat-label">Fields Populated</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">\${{ result.estimated_cost | number:'1.3-3' }}</div>
            <div class="stat-label">Cost</div>
          </div>
        </div>

        <div class="download-section">
          <button class="btn-primary" (click)="downloadResult()">
            <span class="material-icons-outlined">download</span>
            Download Documentation
          </button>
          <button class="btn-secondary" (click)="resetJob()">
            <span class="material-icons-outlined">replay</span>
            Run Another
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page { padding: var(--space-xl) var(--space-2xl); max-width: 960px; }
    .page-header { display: flex; align-items: flex-start; gap: var(--space-md); margin-bottom: var(--space-xl); }
    .page-icon { width: 48px; height: 48px; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; span { font-size: 28px; } }
    .info-banner { display: flex; gap: 12px; padding: var(--space-md) var(--space-lg); background: var(--info-bg); border: 1px solid rgba(96,165,250,0.2); border-radius: var(--radius-md); margin-bottom: var(--space-xl); font-size: 0.85rem; color: var(--text-secondary); line-height: 1.6; .material-icons-outlined { color: var(--info); font-size: 20px; flex-shrink: 0; } strong { color: var(--text-primary); } }
    .input-section { margin-bottom: var(--space-xl); h3 { margin-bottom: var(--space-md); font-size: 1rem; } }
    .config-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-md); margin-top: var(--space-lg); }
    .form-textarea { width: 100%; padding: 10px 14px; background: var(--bg-input); border: 1px solid var(--border-default); border-radius: var(--radius-md); color: var(--text-primary); font-family: 'JetBrains Mono', monospace; font-size: 0.8rem; resize: vertical; outline: none; &:focus { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-subtle); } &::placeholder { color: var(--text-muted); } }
    .submit-btn { margin-top: var(--space-lg); width: 100%; justify-content: center; padding: 14px; font-size: 1rem; }
    .results-section { margin-top: var(--space-xl); }
    .result-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-md); margin-bottom: var(--space-lg); }
    .stat-card { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-lg); padding: var(--space-lg); }
    .download-section { display: flex; gap: var(--space-md); margin-top: var(--space-lg); }
  `]
})
export class ApiDocGenComponent {
  selectedFile: File | null = null;
  modelId = '';
  outputFormat = 'markdown';
  customFieldsJson = '';
  isSubmitting = false;
  jobStatus: JobStatusResponse | null = null;
  result: ApiDocGenResult | null = null;

  constructor(private api: ApiService, private adoptionService: AdoptionService) {}

  onFileSelected(file: File): void { this.selectedFile = file; }

  submitJob(): void {
    if (!this.selectedFile) return;
    this.isSubmitting = true;

    const config: any = { output_format: this.outputFormat };
    if (this.customFieldsJson.trim()) {
      try { config.doc_fields = JSON.parse(this.customFieldsJson); } catch (e) {}
    }

    this.api.submitJob(this.selectedFile, 'api_doc_gen', this.modelId || undefined, JSON.stringify(config))
      .subscribe({
        next: (res) => { this.isSubmitting = false; this.pollJob(res.job_id); },
        error: () => { this.isSubmitting = false; }
      });
  }

  private pollJob(jobId: string): void {
    this.api.pollJobStatus(jobId, 2000).subscribe({
      next: (status) => {
        this.jobStatus = status;
        if (status.status === 'completed' && status.result) {
          this.result = status.result as ApiDocGenResult;
          this.adoptionService.addRecord({
            solution_type: 'api_doc_gen', team_name: 'default', job_id: jobId,
            input_summary: this.selectedFile?.name || '', output_summary: `${this.result.endpoints_documented} endpoints documented`,
            value_metrics: { docs_generated: this.result.endpoints_documented, tokens: this.result.total_tokens_used, cost: this.result.estimated_cost }
          });
        }
      }
    });
  }

  downloadResult(): void {
    if (!this.jobStatus) return;
    this.api.downloadResult(this.jobStatus.job_id).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = `api_docs_${this.jobStatus!.job_id}.zip`; a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  resetJob(): void { this.jobStatus = null; this.result = null; this.selectedFile = null; }
}
