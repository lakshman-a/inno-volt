import { Component } from '@angular/core';
import { ApiService } from '@core/services/api.service';
import { AdoptionService } from '@core/services/adoption.service';
import { JobStatusResponse, UnitTestGenResult } from '@core/models/api.models';

@Component({
  selector: 'app-unit-test-gen',
  template: `
    <div class="page animate-in">
      <!-- Header -->
      <div class="page-header">
        <div class="page-icon" style="background: rgba(45,212,191,0.12); color: #2DD4BF;">
          <span class="material-icons-outlined">science</span>
        </div>
        <div>
          <h1 class="section-title">Unit Test Generation</h1>
          <p class="section-subtitle">Upload a Java Maven project to automatically generate unit tests and improve code coverage.</p>
        </div>
      </div>

      <!-- Instructions -->
      <div class="info-banner" *ngIf="!jobStatus">
        <span class="material-icons-outlined">info</span>
        <div>
          <strong>How it works:</strong> Upload your Java Maven project (ZIP). The platform will build it, analyze coverage gaps using JaCoCo,
          generate unit tests via AI, validate they compile and pass, then return the improved project.
          <br>
          <strong>Requirements:</strong> Java Maven project with pom.xml. JaCoCo will be auto-configured if missing.
        </div>
      </div>

      <!-- Input Section -->
      <div class="input-section card" *ngIf="!jobStatus || jobStatus.status === 'failed'">
        <h3>Project Input</h3>

        <app-file-upload
          (fileSelected)="onFileSelected($event)"
          [showGitOption]="true">
        </app-file-upload>

        <!-- Config -->
        <div class="config-row">
          <div class="form-group">
            <label>AI Model</label>
            <select class="form-select" [(ngModel)]="modelId">
              <option value="">Default (GPT-4o)</option>
              <option value="gpt-4o-mini">GPT-4o Mini (faster, cheaper)</option>
              <option value="claude-sonnet">Claude Sonnet (recommended)</option>
              <option value="claude-opus">Claude Opus (best quality)</option>
              <option value="gemini">Gemini</option>
            </select>
          </div>
          <div class="form-group">
            <label>Target Coverage %</label>
            <input class="form-input" type="number" [(ngModel)]="targetCoverage" min="50" max="100">
          </div>
          <div class="form-group">
            <label>Max Classes</label>
            <input class="form-input" type="number" [(ngModel)]="maxClasses" min="1" max="100">
          </div>
        </div>

        <button class="btn-primary submit-btn"
                [disabled]="!selectedFile || isSubmitting"
                (click)="submitJob()">
          <span class="material-icons-outlined">rocket_launch</span>
          {{ isSubmitting ? 'Submitting...' : 'Generate Unit Tests' }}
        </button>
      </div>

      <!-- Progress -->
      <app-job-progress *ngIf="jobStatus" [job]="jobStatus"></app-job-progress>

      <!-- Results -->
      <div class="results-section" *ngIf="jobStatus?.status === 'completed' && result">
        <h2 class="section-title">Results</h2>

        <!-- Coverage Delta Hero -->
        <div class="coverage-hero card">
          <div class="coverage-before">
            <div class="stat-value">{{ result.baseline_coverage | number:'1.1-1' }}%</div>
            <div class="stat-label">Before</div>
          </div>
          <div class="coverage-arrow">
            <span class="material-icons-outlined">trending_up</span>
          </div>
          <div class="coverage-after">
            <div class="stat-value" style="color: var(--success)">{{ result.new_coverage | number:'1.1-1' }}%</div>
            <div class="stat-label">After</div>
          </div>
          <div class="coverage-delta">
            <div class="delta-value">+{{ result.coverage_delta | number:'1.1-1' }}%</div>
            <div class="stat-label">Improvement</div>
          </div>
        </div>

        <!-- Result Stats -->
        <div class="result-stats">
          <div class="stat-card">
            <div class="stat-value">{{ result.classes_succeeded }}</div>
            <div class="stat-label">Classes Covered</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">{{ result.test_methods_generated }}</div>
            <div class="stat-label">Test Methods</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">{{ result.total_llm_calls }}</div>
            <div class="stat-label">AI Calls</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">{{ result.total_tokens_used | number }}</div>
            <div class="stat-label">Tokens Used</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">\${{ result.estimated_cost | number:'1.3-3' }}</div>
            <div class="stat-label">Estimated Cost</div>
          </div>
        </div>

        <!-- Per-class results -->
        <div class="class-results card">
          <h3>Per-Class Breakdown</h3>
          <div class="class-list">
            <div *ngFor="let cr of result.class_results" class="class-item">
              <span class="material-icons-outlined" [style.color]="cr.success ? 'var(--success)' : 'var(--error)'">
                {{ cr.success ? 'check_circle' : 'cancel' }}
              </span>
              <span class="class-name mono">{{ cr.target_class }}</span>
              <span class="badge" [class]="cr.success ? 'success' : 'error'">
                {{ cr.success ? 'Pass' : 'Failed' }}
              </span>
              <span class="attempts">{{ cr.attempts }} attempt{{ cr.attempts > 1 ? 's' : '' }}</span>
              <span class="tokens mono">{{ cr.tokens_used }} tok</span>
            </div>
          </div>
        </div>

        <!-- Download -->
        <div class="download-section">
          <button class="btn-primary" (click)="downloadResult()">
            <span class="material-icons-outlined">download</span>
            Download Improved Project
          </button>
          <button class="btn-secondary" (click)="resetJob()">
            <span class="material-icons-outlined">replay</span>
            Run Another
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page { padding: var(--space-xl) var(--space-2xl); max-width: 960px; }
    .page-header {
      display: flex;
      align-items: flex-start;
      gap: var(--space-md);
      margin-bottom: var(--space-xl);
    }
    .page-icon {
      width: 48px;
      height: 48px;
      border-radius: var(--radius-md);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      span { font-size: 28px; }
    }
    .info-banner {
      display: flex;
      gap: 12px;
      padding: var(--space-md) var(--space-lg);
      background: var(--info-bg);
      border: 1px solid rgba(96,165,250,0.2);
      border-radius: var(--radius-md);
      margin-bottom: var(--space-xl);
      font-size: 0.85rem;
      color: var(--text-secondary);
      line-height: 1.6;
      .material-icons-outlined { color: var(--info); font-size: 20px; flex-shrink: 0; margin-top: 2px; }
      strong { color: var(--text-primary); }
    }
    .input-section {
      margin-bottom: var(--space-xl);
      h3 { margin-bottom: var(--space-md); font-size: 1rem; }
    }
    .config-row {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr;
      gap: var(--space-md);
      margin-top: var(--space-lg);
    }
    .submit-btn {
      margin-top: var(--space-lg);
      width: 100%;
      justify-content: center;
      padding: 14px;
      font-size: 1rem;
    }
    .results-section { margin-top: var(--space-xl); }
    .coverage-hero {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: var(--space-2xl);
      padding: var(--space-2xl);
      margin-bottom: var(--space-lg);
      text-align: center;
    }
    .coverage-arrow {
      span {
        font-size: 32px;
        color: var(--success);
      }
    }
    .delta-value {
      font-size: 2.5rem;
      font-weight: 800;
      color: var(--success);
      font-family: 'JetBrains Mono', monospace;
    }
    .result-stats {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: var(--space-md);
      margin-bottom: var(--space-lg);
    }
    .stat-card {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-lg);
      padding: var(--space-lg);
    }
    .class-results {
      margin-bottom: var(--space-lg);
      h3 { margin-bottom: var(--space-md); font-size: 1rem; }
    }
    .class-item {
      display: flex;
      align-items: center;
      gap: var(--space-sm);
      padding: 10px 0;
      border-bottom: 1px solid var(--border-subtle);
      font-size: 0.85rem;
      &:last-child { border-bottom: none; }
      .material-icons-outlined { font-size: 18px; }
    }
    .class-name { flex: 1; }
    .attempts { color: var(--text-muted); font-size: 0.75rem; }
    .tokens { color: var(--text-muted); font-size: 0.75rem; }
    .download-section {
      display: flex;
      gap: var(--space-md);
      margin-top: var(--space-lg);
    }
  `]
})
export class UnitTestGenComponent {
  selectedFile: File | null = null;
  modelId = '';
  targetCoverage = 80;
  maxClasses = 50;
  isSubmitting = false;
  jobStatus: JobStatusResponse | null = null;
  result: UnitTestGenResult | null = null;

  constructor(
    private api: ApiService,
    private adoptionService: AdoptionService
  ) {}

  onFileSelected(file: File): void {
    this.selectedFile = file;
  }

  submitJob(): void {
    if (!this.selectedFile) return;

    this.isSubmitting = true;
    const config = JSON.stringify({
      target_coverage_percent: this.targetCoverage,
      max_classes_to_process: this.maxClasses,
    });

    this.api.submitJob(
      this.selectedFile,
      'unit_test_gen',
      this.modelId || undefined,
      config
    ).subscribe({
      next: (response) => {
        this.isSubmitting = false;
        this.pollJob(response.job_id);
      },
      error: (err) => {
        this.isSubmitting = false;
        console.error('Submit failed:', err);
      }
    });
  }

  private pollJob(jobId: string): void {
    this.api.pollJobStatus(jobId, 2000).subscribe({
      next: (status) => {
        this.jobStatus = status;
        if (status.status === 'completed' && status.result) {
          this.result = status.result as UnitTestGenResult;
          this.trackAdoption(jobId, this.result);
        }
      },
      error: (err) => console.error('Polling error:', err)
    });
  }

  downloadResult(): void {
    if (!this.jobStatus) return;
    this.api.downloadResult(this.jobStatus.job_id).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `unit_tests_${this.jobStatus!.job_id}.zip`;
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  resetJob(): void {
    this.jobStatus = null;
    this.result = null;
    this.selectedFile = null;
  }

  private trackAdoption(jobId: string, result: UnitTestGenResult): void {
    this.adoptionService.addRecord({
      solution_type: 'unit_test_gen',
      team_name: 'default',
      job_id: jobId,
      input_summary: this.selectedFile?.name || 'unknown',
      output_summary: `+${result.coverage_delta}% coverage, ${result.tests_generated} tests`,
      value_metrics: {
        coverage_delta: result.coverage_delta,
        tests_generated: result.tests_generated,
        tokens: result.total_tokens_used,
        cost: result.estimated_cost,
      }
    });
  }
}
