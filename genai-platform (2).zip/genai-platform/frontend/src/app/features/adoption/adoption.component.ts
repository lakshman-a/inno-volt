import { Component, OnInit } from '@angular/core';
import { AdoptionService } from '@core/services/adoption.service';
import { AdoptionRecord } from '@core/models/api.models';

@Component({
  selector: 'app-adoption',
  template: `
    <div class="page animate-in">
      <div class="page-header">
        <div class="page-icon" style="background: rgba(251,191,36,0.12); color: #FBBF24;">
          <span class="material-icons-outlined">trending_up</span>
        </div>
        <div>
          <h1 class="section-title">Adoption & Value</h1>
          <p class="section-subtitle">Track platform usage, generated value, and ROI across all solutions.</p>
        </div>
      </div>

      <!-- Value Hero Cards -->
      <div class="value-grid">
        <div class="value-card card" style="border-left: 3px solid var(--accent);">
          <div class="stat-label">Coverage Improved</div>
          <div class="stat-value">+{{ stats.valueMetrics.coverageDelta | number:'1.1-1' }}%</div>
          <div class="value-subtitle">Cumulative across all runs</div>
        </div>
        <div class="value-card card" style="border-left: 3px solid #60A5FA;">
          <div class="stat-label">APIs Documented</div>
          <div class="stat-value" style="color: #60A5FA;">{{ stats.valueMetrics.docsGenerated }}</div>
          <div class="value-subtitle">Endpoints with auto-generated docs</div>
        </div>
        <div class="value-card card" style="border-left: 3px solid #A78BFA;">
          <div class="stat-label">Total Runs</div>
          <div class="stat-value" style="color: #A78BFA;">{{ stats.totalJobs }}</div>
          <div class="value-subtitle">Across all solutions</div>
        </div>
        <div class="value-card card" style="border-left: 3px solid var(--success);">
          <div class="stat-label">Total Cost</div>
          <div class="stat-value" style="color: var(--success);">\${{ stats.totalCost | number:'1.2-2' }}</div>
          <div class="value-subtitle">LLM API spend</div>
        </div>
      </div>

      <!-- ROI Estimate -->
      <div class="roi-section card">
        <h3>Estimated ROI</h3>
        <p class="roi-text">
          Based on industry averages: a developer spends ~30 min per unit test and ~45 min per API doc field.
          The platform's estimated time savings represent significant productivity gains.
        </p>
        <div class="roi-grid">
          <div>
            <div class="stat-value">{{ getTimeSaved() | number:'1.0-0' }}h</div>
            <div class="stat-label">Developer Hours Saved</div>
          </div>
          <div>
            <div class="stat-value">\${{ getCostSaved() | number:'1.0-0' }}</div>
            <div class="stat-label">Estimated Value (@ $75/hr)</div>
          </div>
          <div>
            <div class="stat-value">{{ getROI() | number:'1.0-0' }}x</div>
            <div class="stat-label">Return on Investment</div>
          </div>
        </div>
      </div>

      <!-- History Table -->
      <div class="history-section card">
        <h3>Run History</h3>
        <div class="table-wrapper">
          <table class="data-table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Solution</th>
                <th>Project</th>
                <th>Output</th>
                <th>Cost</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let r of records">
                <td class="mono">{{ r.timestamp | date:'short' }}</td>
                <td><span class="badge accent">{{ formatType(r.solution_type) }}</span></td>
                <td>{{ r.input_summary }}</td>
                <td>{{ r.output_summary }}</td>
                <td class="mono">\${{ r.value_metrics['cost'] | number:'1.3-3' }}</td>
              </tr>
              <tr *ngIf="records.length === 0">
                <td colspan="5" class="empty-row">No runs yet. Start using a solution to see history here.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page { padding: var(--space-xl) var(--space-2xl); max-width: 1100px; }
    .page-header { display: flex; align-items: flex-start; gap: var(--space-md); margin-bottom: var(--space-xl); }
    .page-icon { width: 48px; height: 48px; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; span { font-size: 28px; } }
    .value-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-md); margin-bottom: var(--space-xl); }
    .value-card { padding: var(--space-lg); }
    .value-subtitle { font-size: 0.75rem; color: var(--text-muted); margin-top: 4px; }
    .roi-section { margin-bottom: var(--space-xl); h3 { margin-bottom: var(--space-sm); } }
    .roi-text { font-size: 0.85rem; color: var(--text-secondary); margin-bottom: var(--space-lg); line-height: 1.5; }
    .roi-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--space-lg); text-align: center; }
    .history-section { h3 { margin-bottom: var(--space-md); } }
    .table-wrapper { overflow-x: auto; }
    .data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.85rem;
      th {
        text-align: left;
        padding: 10px 14px;
        border-bottom: 1px solid var(--border-default);
        color: var(--text-muted);
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }
      td {
        padding: 10px 14px;
        border-bottom: 1px solid var(--border-subtle);
        color: var(--text-secondary);
      }
    }
    .empty-row { text-align: center; color: var(--text-muted); padding: 32px !important; }
  `]
})
export class AdoptionComponent implements OnInit {
  stats: any = { totalJobs: 0, totalTokens: 0, totalCost: 0, bySolution: {}, valueMetrics: { coverageDelta: 0, docsGenerated: 0, issuesFixed: 0 } };
  records: AdoptionRecord[] = [];

  constructor(private adoptionService: AdoptionService) {}

  ngOnInit(): void {
    this.stats = this.adoptionService.getStats();
    this.adoptionService.getRecords().subscribe(r => this.records = r);
  }

  formatType(type: string): string {
    return type.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  }

  getTimeSaved(): number {
    const testHours = (this.stats.valueMetrics.coverageDelta / 5) * 0.5; // rough: 0.5h per 5% coverage
    const docHours = this.stats.valueMetrics.docsGenerated * 0.75; // 45 min per endpoint doc
    return testHours + docHours;
  }

  getCostSaved(): number { return this.getTimeSaved() * 75; }

  getROI(): number {
    if (this.stats.totalCost === 0) return 0;
    return this.getCostSaved() / this.stats.totalCost;
  }
}
