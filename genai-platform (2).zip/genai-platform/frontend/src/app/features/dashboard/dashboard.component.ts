import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '@core/services/api.service';
import { AdoptionService } from '@core/services/adoption.service';
import { SolutionCard } from '@core/models/api.models';

@Component({
  selector: 'app-dashboard',
  template: `
    <div class="page animate-in">
      <div class="page-header">
        <h1 class="section-title">GenAI Platform</h1>
        <p class="section-subtitle">AI-powered code quality solutions. Select a solution below to get started.</p>
      </div>

      <!-- Quick Stats -->
      <div class="stats-row">
        <div class="stat-card">
          <div class="stat-value">{{ stats.totalJobs }}</div>
          <div class="stat-label">Total Runs</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">+{{ stats.valueMetrics.coverageDelta | number:'1.1-1' }}%</div>
          <div class="stat-label">Coverage Improved</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">{{ stats.valueMetrics.docsGenerated }}</div>
          <div class="stat-label">APIs Documented</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">\${{ stats.totalCost | number:'1.2-2' }}</div>
          <div class="stat-label">Total Cost</div>
        </div>
      </div>

      <!-- Solution Cards -->
      <div class="solutions-grid">
        <div *ngFor="let sol of solutions; let i = index"
             class="solution-card card"
             [class.interactive]="sol.status === 'ready'"
             [class.disabled]="sol.status !== 'ready'"
             [style.animation-delay]="(i * 80) + 'ms'"
             (click)="sol.status === 'ready' && navigate(sol.route)">

          <div class="sol-header">
            <div class="sol-icon" [style.background]="sol.color + '18'" [style.color]="sol.color">
              <span class="material-icons-outlined">{{ sol.icon }}</span>
            </div>
            <span class="badge" [class]="sol.status === 'ready' ? 'success' : 'info'">
              {{ sol.status === 'ready' ? 'Ready' : 'Coming Soon' }}
            </span>
          </div>

          <h3 class="sol-name">{{ sol.name }}</h3>
          <p class="sol-desc">{{ sol.description }}</p>

          <div class="sol-footer" *ngIf="sol.status === 'ready'">
            <span class="sol-action">
              Open Solution
              <span class="material-icons-outlined">arrow_forward</span>
            </span>
          </div>
        </div>
      </div>

      <!-- How it Works -->
      <div class="how-it-works">
        <h2 class="section-title">How It Works</h2>
        <div class="steps-row">
          <div class="step">
            <div class="step-num">1</div>
            <h4>Upload Project</h4>
            <p>Upload your Java Maven project as a ZIP file or connect via Git URL.</p>
          </div>
          <div class="step-arrow">
            <span class="material-icons-outlined">arrow_forward</span>
          </div>
          <div class="step">
            <div class="step-num">2</div>
            <h4>AI Analysis</h4>
            <p>The platform analyzes your codebase, identifies gaps, and generates improvements.</p>
          </div>
          <div class="step-arrow">
            <span class="material-icons-outlined">arrow_forward</span>
          </div>
          <div class="step">
            <div class="step-num">3</div>
            <h4>Validated Output</h4>
            <p>Generated code is compiled, tested, and validated before delivery.</p>
          </div>
          <div class="step-arrow">
            <span class="material-icons-outlined">arrow_forward</span>
          </div>
          <div class="step">
            <div class="step-num">4</div>
            <h4>Download & Review</h4>
            <p>Download the improved project with full metrics and coverage reports.</p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page {
      padding: var(--space-xl) var(--space-2xl);
      max-width: 1200px;
    }
    .page-header { margin-bottom: var(--space-xl); }
    .stats-row {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: var(--space-md);
      margin-bottom: var(--space-2xl);
    }
    .stat-card {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-lg);
      padding: var(--space-lg);
    }
    .solutions-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: var(--space-lg);
      margin-bottom: var(--space-2xl);
    }
    .solution-card {
      animation: fadeInUp 0.4s ease both;
      &.disabled {
        opacity: 0.5;
        cursor: default !important;
      }
    }
    .sol-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: var(--space-md);
    }
    .sol-icon {
      width: 44px;
      height: 44px;
      border-radius: var(--radius-md);
      display: flex;
      align-items: center;
      justify-content: center;
      span { font-size: 24px; }
    }
    .sol-name {
      font-size: 1.1rem;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: 6px;
    }
    .sol-desc {
      font-size: 0.85rem;
      color: var(--text-secondary);
      line-height: 1.5;
      margin-bottom: var(--space-md);
    }
    .sol-footer {
      border-top: 1px solid var(--border-subtle);
      padding-top: var(--space-md);
    }
    .sol-action {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--accent);
      span { font-size: 16px; }
    }
    .how-it-works {
      margin-top: var(--space-2xl);
    }
    .steps-row {
      display: flex;
      align-items: flex-start;
      gap: var(--space-md);
      margin-top: var(--space-lg);
    }
    .step {
      flex: 1;
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-lg);
      padding: var(--space-lg);
      h4 { font-size: 0.95rem; margin-bottom: 6px; color: var(--text-primary); }
      p { font-size: 0.8rem; color: var(--text-secondary); line-height: 1.5; }
    }
    .step-num {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: var(--accent-subtle);
      color: var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 0.85rem;
      margin-bottom: var(--space-sm);
    }
    .step-arrow {
      display: flex;
      align-items: center;
      padding-top: 40px;
      color: var(--text-muted);
      span { font-size: 20px; }
    }
  `]
})
export class DashboardComponent implements OnInit {
  solutions: SolutionCard[] = [
    {
      type: 'unit_test_gen', name: 'Unit Test Generation',
      description: 'Analyzes your Java project, identifies coverage gaps, and generates compilable unit tests with validation.',
      icon: 'science', status: 'ready', route: '/unit-test-gen', color: '#2DD4BF'
    },
    {
      type: 'api_doc_gen', name: 'API Documentation DX',
      description: 'Scans REST controllers and auto-populates 200+ DX documentation fields from your codebase.',
      icon: 'description', status: 'ready', route: '/api-doc-gen', color: '#60A5FA'
    },
    {
      type: 'func_test_gen', name: 'Functional Test Generation',
      description: 'Generates Karate DSL or Cucumber Serenity tests from API code, Swagger specs, and user stories.',
      icon: 'integration_instructions', status: 'ready', route: '/func-test-gen', color: '#A78BFA'
    },
    {
      type: 'sonar_fix', name: 'Sonar Code Remediation',
      description: 'Fetches SonarQube issues and auto-generates validated fixes for bugs, vulnerabilities, and code smells.',
      icon: 'bug_report', status: 'ready', route: '/sonar-fix', color: '#FBBF24'
    },
  ];

  stats: any = { totalJobs: 0, totalCost: 0, valueMetrics: { coverageDelta: 0, docsGenerated: 0, issuesFixed: 0 } };

  constructor(
    private router: Router,
    private adoptionService: AdoptionService
  ) {}

  ngOnInit(): void {
    this.stats = this.adoptionService.getStats();
  }

  navigate(route: string): void {
    this.router.navigate([route]);
  }
}
