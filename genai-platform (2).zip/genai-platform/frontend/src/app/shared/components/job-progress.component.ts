import { Component, Input } from '@angular/core';
import { JobStatusResponse } from '@core/models/api.models';

@Component({
  selector: 'app-job-progress',
  template: `
    <div class="progress-card" *ngIf="job">
      <div class="progress-header">
        <div class="progress-status">
          <span class="status-dot" [class]="job.status"></span>
          <span class="status-text">{{ formatStatus(job.status) }}</span>
        </div>
        <span class="job-id mono">{{ job.job_id }}</span>
      </div>

      <div class="progress-bar-wrapper">
        <div class="progress-bar">
          <div class="progress-fill"
               [style.width.%]="job.progress_percent"
               [class.completed]="job.status === 'completed'"
               [class.failed]="job.status === 'failed'">
          </div>
        </div>
        <span class="progress-pct mono">{{ job.progress_percent | number:'1.0-0' }}%</span>
      </div>

      <div class="progress-phase">
        <span class="material-icons-outlined phase-icon" [class.spinning]="isActive()">
          {{ getPhaseIcon() }}
        </span>
        <span>{{ job.current_phase }}</span>
      </div>

      <div class="progress-message" *ngIf="job.message">
        {{ job.message }}
      </div>

      <div class="progress-errors" *ngIf="job.errors && job.errors.length > 0">
        <div class="error-item" *ngFor="let err of job.errors">
          <span class="material-icons-outlined">error_outline</span>
          {{ err }}
        </div>
      </div>
    </div>
  `,
  styles: [`
    .progress-card {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-lg);
      padding: var(--space-lg);
    }
    .progress-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--space-md);
    }
    .progress-status {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--text-muted);
      &.pending, &.validating { background: var(--warning); }
      &.analyzing, &.processing, &.generating, &.validating_output {
        background: var(--accent);
        animation: pulse 1.5s infinite;
      }
      &.completed { background: var(--success); }
      &.failed { background: var(--error); }
      &.partially_completed { background: var(--warning); }
    }
    .status-text {
      font-weight: 600;
      font-size: 0.9rem;
      text-transform: capitalize;
    }
    .job-id {
      font-size: 0.75rem;
      color: var(--text-muted);
    }
    .progress-bar-wrapper {
      display: flex;
      align-items: center;
      gap: var(--space-md);
      margin-bottom: var(--space-md);
    }
    .progress-bar {
      flex: 1;
      height: 6px;
      background: var(--bg-elevated);
      border-radius: 3px;
      overflow: hidden;
    }
    .progress-fill {
      height: 100%;
      background: var(--accent);
      border-radius: 3px;
      transition: width 0.5s ease;
      &.completed { background: var(--success); }
      &.failed { background: var(--error); }
    }
    .progress-pct {
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--accent);
      min-width: 40px;
      text-align: right;
    }
    .progress-phase {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 0.85rem;
      color: var(--text-secondary);
    }
    .phase-icon {
      font-size: 18px;
      color: var(--accent);
      &.spinning { animation: spin 1.5s linear infinite; }
    }
    .progress-message {
      margin-top: var(--space-sm);
      font-size: 0.8rem;
      color: var(--text-muted);
    }
    .progress-errors {
      margin-top: var(--space-md);
    }
    .error-item {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      padding: 8px 12px;
      background: var(--error-bg);
      border-radius: var(--radius-sm);
      font-size: 0.8rem;
      color: var(--error);
      margin-bottom: 4px;
      span { font-size: 16px; flex-shrink: 0; margin-top: 1px; }
    }
    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
  `]
})
export class JobProgressComponent {
  @Input() job!: JobStatusResponse;

  isActive(): boolean {
    return ['analyzing', 'processing', 'generating', 'validating_output'].includes(this.job?.status);
  }

  getPhaseIcon(): string {
    if (this.job?.status === 'completed') return 'check_circle';
    if (this.job?.status === 'failed') return 'error';
    return 'sync';
  }

  formatStatus(status: string): string {
    return status?.replace(/_/g, ' ') || '';
  }
}
