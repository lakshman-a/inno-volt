import { Component, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-file-upload',
  template: `
    <div class="upload-zone"
         [class.dragging]="isDragging"
         [class.has-file]="selectedFile"
         (dragover)="onDragOver($event)"
         (dragleave)="onDragLeave($event)"
         (drop)="onDrop($event)"
         (click)="fileInput.click()">
      <input #fileInput type="file" [accept]="accept" (change)="onFileSelect($event)" hidden>

      <div *ngIf="!selectedFile" class="upload-prompt">
        <span class="material-icons-outlined upload-icon">cloud_upload</span>
        <p class="upload-title">Drop your project ZIP here</p>
        <p class="upload-hint">or click to browse &middot; Max 100MB</p>
      </div>

      <div *ngIf="selectedFile" class="upload-selected">
        <span class="material-icons-outlined file-icon">folder_zip</span>
        <div class="file-info">
          <span class="file-name">{{ selectedFile.name }}</span>
          <span class="file-size">{{ formatSize(selectedFile.size) }}</span>
        </div>
        <button class="remove-btn" (click)="removeFile($event)">
          <span class="material-icons-outlined">close</span>
        </button>
      </div>
    </div>

    <!-- Git URL alternative (placeholder) -->
    <div class="alt-input" *ngIf="showGitOption">
      <div class="divider-text"><span>or connect via Git</span></div>
      <div class="git-fields">
        <input class="form-input" placeholder="Repository URL" [(ngModel)]="gitUrl">
        <input class="form-input" placeholder="Branch (default: main)" [(ngModel)]="gitBranch">
        <input class="form-input" type="password" placeholder="Access Token" [(ngModel)]="gitToken">
      </div>
    </div>
  `,
  styles: [`
    .upload-zone {
      border: 2px dashed var(--border-default);
      border-radius: var(--radius-lg);
      padding: var(--space-2xl) var(--space-xl);
      text-align: center;
      cursor: pointer;
      transition: all var(--transition-base);
      background: var(--bg-input);

      &:hover, &.dragging {
        border-color: var(--accent);
        background: var(--accent-subtle);
      }
      &.has-file {
        border-style: solid;
        border-color: var(--accent);
        padding: var(--space-lg);
      }
    }
    .upload-icon {
      font-size: 40px;
      color: var(--text-muted);
      margin-bottom: var(--space-sm);
    }
    .upload-title {
      font-size: 1rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: 4px;
    }
    .upload-hint {
      font-size: 0.8rem;
      color: var(--text-muted);
    }
    .upload-selected {
      display: flex;
      align-items: center;
      gap: var(--space-md);
      text-align: left;
    }
    .file-icon {
      font-size: 32px;
      color: var(--accent);
    }
    .file-info {
      flex: 1;
    }
    .file-name {
      display: block;
      font-weight: 600;
      color: var(--text-primary);
      font-family: 'JetBrains Mono', monospace;
      font-size: 0.85rem;
    }
    .file-size {
      font-size: 0.75rem;
      color: var(--text-muted);
    }
    .remove-btn {
      background: none;
      border: none;
      color: var(--text-muted);
      cursor: pointer;
      padding: 4px;
      border-radius: var(--radius-sm);
      display: flex;
      &:hover { color: var(--error); background: var(--error-bg); }
    }
    .alt-input { margin-top: var(--space-lg); }
    .divider-text {
      text-align: center;
      position: relative;
      margin-bottom: var(--space-md);
      &::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 0;
        right: 0;
        height: 1px;
        background: var(--border-subtle);
      }
      span {
        position: relative;
        background: var(--bg-card);
        padding: 0 12px;
        font-size: 0.75rem;
        color: var(--text-muted);
      }
    }
    .git-fields {
      display: flex;
      flex-direction: column;
      gap: var(--space-sm);
    }
  `]
})
export class FileUploadComponent {
  @Input() accept = '.zip';
  @Input() showGitOption = false;
  @Output() fileSelected = new EventEmitter<File>();

  selectedFile: File | null = null;
  isDragging = false;
  gitUrl = '';
  gitBranch = '';
  gitToken = '';

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.isDragging = true;
  }

  onDragLeave(event: DragEvent): void {
    this.isDragging = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.isDragging = false;
    const files = event.dataTransfer?.files;
    if (files && files.length > 0) {
      this.setFile(files[0]);
    }
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.setFile(input.files[0]);
    }
  }

  removeFile(event: Event): void {
    event.stopPropagation();
    this.selectedFile = null;
  }

  formatSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  }

  private setFile(file: File): void {
    this.selectedFile = file;
    this.fileSelected.emit(file);
  }
}
