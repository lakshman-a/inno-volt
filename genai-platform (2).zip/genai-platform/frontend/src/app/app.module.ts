import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { TopbarComponent } from './layout/topbar/topbar.component';
import { SidenavComponent } from './layout/sidenav/sidenav.component';

import { FileUploadComponent } from './shared/components/file-upload.component';
import { JobProgressComponent } from './shared/components/job-progress.component';

import { DashboardComponent } from './features/dashboard/dashboard.component';
import { UnitTestGenComponent } from './features/unit-test-gen/unit-test-gen.component';
import { ApiDocGenComponent } from './features/api-doc-gen/api-doc-gen.component';
import { FuncTestGenComponent } from './features/func-test-gen/func-test-gen.component';
import { SonarFixComponent } from './features/sonar-fix/sonar-fix.component';
import { AdoptionComponent } from './features/adoption/adoption.component';

import { AuthInterceptor } from './core/interceptors/auth.interceptor';

@NgModule({
  declarations: [
    AppComponent,
    TopbarComponent,
    SidenavComponent,
    FileUploadComponent,
    JobProgressComponent,
    DashboardComponent,
    UnitTestGenComponent,
    ApiDocGenComponent,
    FuncTestGenComponent,
    SonarFixComponent,
    AdoptionComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
