import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-topbar',
  template: `
    <header class="topbar">
      <div class="topbar-left">
        <button class="menu-toggle" (click)="toggleSidenav.emit()">
          <span class="material-icons-outlined">menu</span>
        </button>
        <div class="logo-group">
          <div class="logo-icon">
            <span class="material-icons-outlined">auto_awesome</span>
          </div>
          <div class="logo-text">
            <span class="logo-name">GenAI Platform</span>
            <span class="logo-tag">Platform Engineering</span>
          </div>
        </div>
      </div>
      <div class="topbar-right">
        <div class="env-badge">
          <span class="dot"></span>
          DEV
        </div>
        <button class="topbar-btn" title="API Health">
          <span class="material-icons-outlined">monitor_heart</span>
        </button>
        <div class="user-avatar" title="User">
          <span>U</span>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .topbar {
      height: var(--topbar-height);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 var(--space-md);
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border-subtle);
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
    }
    .topbar-left {
      display: flex;
      align-items: center;
      gap: var(--space-md);
    }
    .menu-toggle {
      background: none;
      border: none;
      color: var(--text-secondary);
      cursor: pointer;
      padding: 6px;
      border-radius: var(--radius-sm);
      display: flex;
      &:hover { color: var(--text-primary); background: rgba(255,255,255,0.05); }
    }
    .logo-group {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .logo-icon {
      width: 32px;
      height: 32px;
      border-radius: var(--radius-sm);
      background: var(--accent-subtle);
      display: flex;
      align-items: center;
      justify-content: center;
      span { font-size: 18px; color: var(--accent); }
    }
    .logo-name {
      font-size: 1rem;
      font-weight: 700;
      color: var(--text-primary);
      display: block;
      line-height: 1.2;
    }
    .logo-tag {
      font-size: 0.65rem;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .topbar-right {
      display: flex;
      align-items: center;
      gap: var(--space-sm);
    }
    .env-badge {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      background: var(--success-bg);
      color: var(--success);
      border-radius: 100px;
      font-size: 0.7rem;
      font-weight: 700;
      letter-spacing: 0.04em;
      .dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--success);
      }
    }
    .topbar-btn {
      background: none;
      border: none;
      color: var(--text-muted);
      cursor: pointer;
      padding: 6px;
      border-radius: var(--radius-sm);
      display: flex;
      &:hover { color: var(--text-primary); background: rgba(255,255,255,0.05); }
      span { font-size: 20px; }
    }
    .user-avatar {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background: var(--bg-elevated);
      border: 1px solid var(--border-default);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.75rem;
      font-weight: 600;
      color: var(--text-secondary);
      cursor: pointer;
    }
  `]
})
export class TopbarComponent {
  @Output() toggleSidenav = new EventEmitter<void>();
}
