import { Component, Input } from '@angular/core';

interface NavItem {
  label: string;
  icon: string;
  route: string;
  badge?: string;
}

@Component({
  selector: 'app-sidenav',
  template: `
    <nav class="sidenav" [class.collapsed]="collapsed">
      <div class="nav-section">
        <div class="nav-section-title" *ngIf="!collapsed">OVERVIEW</div>
        <a *ngFor="let item of overviewItems"
           [routerLink]="item.route"
           routerLinkActive="active"
           class="nav-item"
           [title]="item.label">
          <span class="material-icons-outlined nav-icon">{{item.icon}}</span>
          <span class="nav-label" *ngIf="!collapsed">{{item.label}}</span>
          <span class="nav-badge" *ngIf="item.badge && !collapsed">{{item.badge}}</span>
        </a>
      </div>

      <div class="nav-section">
        <div class="nav-section-title" *ngIf="!collapsed">SOLUTIONS</div>
        <a *ngFor="let item of solutionItems"
           [routerLink]="item.route"
           routerLinkActive="active"
           class="nav-item"
           [title]="item.label">
          <span class="material-icons-outlined nav-icon">{{item.icon}}</span>
          <span class="nav-label" *ngIf="!collapsed">{{item.label}}</span>
          <span class="nav-badge" *ngIf="item.badge && !collapsed">{{item.badge}}</span>
        </a>
      </div>

      <div class="nav-section">
        <div class="nav-section-title" *ngIf="!collapsed">INSIGHTS</div>
        <a *ngFor="let item of insightItems"
           [routerLink]="item.route"
           routerLinkActive="active"
           class="nav-item"
           [title]="item.label">
          <span class="material-icons-outlined nav-icon">{{item.icon}}</span>
          <span class="nav-label" *ngIf="!collapsed">{{item.label}}</span>
        </a>
      </div>

      <div class="nav-bottom" *ngIf="!collapsed">
        <div class="nav-info-card">
          <span class="material-icons-outlined">security</span>
          <div>
            <strong>Secure by Design</strong>
            <p>All data processed via enterprise gateway. Temporary storage only.</p>
          </div>
        </div>
      </div>
    </nav>
  `,
  styles: [`
    .sidenav {
      width: var(--sidenav-width);
      height: calc(100vh - var(--topbar-height));
      position: fixed;
      top: var(--topbar-height);
      left: 0;
      background: var(--bg-secondary);
      border-right: 1px solid var(--border-subtle);
      padding: var(--space-md) 0;
      overflow-y: auto;
      overflow-x: hidden;
      transition: width var(--transition-base);
      display: flex;
      flex-direction: column;
      z-index: 900;

      &.collapsed {
        width: var(--sidenav-collapsed);
        .nav-section-title { display: none; }
      }
    }
    .nav-section {
      margin-bottom: var(--space-lg);
    }
    .nav-section-title {
      padding: 0 var(--space-lg);
      font-size: 0.65rem;
      font-weight: 700;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.08em;
      margin-bottom: var(--space-sm);
    }
    .nav-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 9px var(--space-lg);
      color: var(--text-secondary);
      text-decoration: none;
      font-size: 0.85rem;
      font-weight: 500;
      transition: all var(--transition-fast);
      border-left: 3px solid transparent;
      cursor: pointer;

      &:hover {
        color: var(--text-primary);
        background: rgba(255,255,255,0.03);
      }
      &.active {
        color: var(--accent);
        background: var(--accent-subtle);
        border-left-color: var(--accent);
        .nav-icon { color: var(--accent); }
      }
    }
    .nav-icon {
      font-size: 20px;
      flex-shrink: 0;
    }
    .nav-label {
      white-space: nowrap;
    }
    .nav-badge {
      margin-left: auto;
      padding: 1px 7px;
      background: var(--accent-subtle);
      color: var(--accent);
      border-radius: 100px;
      font-size: 0.65rem;
      font-weight: 700;
    }
    .nav-bottom {
      margin-top: auto;
      padding: var(--space-md) var(--space-lg);
    }
    .nav-info-card {
      display: flex;
      gap: 10px;
      padding: 12px;
      background: rgba(45, 212, 191, 0.06);
      border: 1px solid rgba(45, 212, 191, 0.12);
      border-radius: var(--radius-md);
      font-size: 0.75rem;
      color: var(--text-secondary);
      span.material-icons-outlined {
        font-size: 20px;
        color: var(--accent);
        flex-shrink: 0;
        margin-top: 2px;
      }
      strong {
        color: var(--text-primary);
        display: block;
        font-size: 0.8rem;
        margin-bottom: 2px;
      }
      p { margin: 0; line-height: 1.4; }
    }
  `]
})
export class SidenavComponent {
  @Input() collapsed = false;

  overviewItems: NavItem[] = [
    { label: 'Dashboard', icon: 'dashboard', route: '/dashboard' },
  ];

  solutionItems: NavItem[] = [
    { label: 'Unit Test Gen', icon: 'science', route: '/unit-test-gen', badge: 'LIVE' },
    { label: 'API Doc Gen', icon: 'description', route: '/api-doc-gen', badge: 'LIVE' },
    { label: 'Functional Tests', icon: 'integration_instructions', route: '/func-test-gen', badge: 'LIVE' },
    { label: 'Sonar Remediation', icon: 'bug_report', route: '/sonar-fix', badge: 'LIVE' },
  ];

  insightItems: NavItem[] = [
    { label: 'Adoption & Value', icon: 'trending_up', route: '/adoption' },
  ];
}
