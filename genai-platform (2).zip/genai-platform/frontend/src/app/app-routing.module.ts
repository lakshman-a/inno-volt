import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '@core/guards/auth.guard';

import { DashboardComponent } from '@features/dashboard/dashboard.component';
import { UnitTestGenComponent } from '@features/unit-test-gen/unit-test-gen.component';
import { ApiDocGenComponent } from '@features/api-doc-gen/api-doc-gen.component';
import { FuncTestGenComponent } from '@features/func-test-gen/func-test-gen.component';
import { SonarFixComponent } from '@features/sonar-fix/sonar-fix.component';
import { AdoptionComponent } from '@features/adoption/adoption.component';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'unit-test-gen', component: UnitTestGenComponent, canActivate: [AuthGuard] },
  { path: 'api-doc-gen', component: ApiDocGenComponent, canActivate: [AuthGuard] },
  { path: 'func-test-gen', component: FuncTestGenComponent, canActivate: [AuthGuard] },
  { path: 'sonar-fix', component: SonarFixComponent, canActivate: [AuthGuard] },
  { path: 'adoption', component: AdoptionComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '/dashboard' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
