import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-topbar (toggleSidenav)="sidenavCollapsed = !sidenavCollapsed"></app-topbar>
    <app-sidenav [collapsed]="sidenavCollapsed"></app-sidenav>
    <main class="main-content" [class.sidenav-collapsed]="sidenavCollapsed">
      <router-outlet></router-outlet>
    </main>
  `,
  styles: [`
    .main-content {
      margin-top: var(--topbar-height);
      margin-left: var(--sidenav-width);
      min-height: calc(100vh - var(--topbar-height));
      transition: margin-left var(--transition-base);

      &.sidenav-collapsed {
        margin-left: var(--sidenav-collapsed);
      }
    }
  `]
})
export class AppComponent {
  sidenavCollapsed = false;
}
