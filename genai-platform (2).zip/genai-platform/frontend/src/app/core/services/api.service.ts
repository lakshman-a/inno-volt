import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable, timer, switchMap, takeWhile, tap, map } from 'rxjs';
import { environment } from '@env/environment';
import {
  SolutionMeta, JobSubmitResponse, JobStatusResponse,
  UsageSummary, SolutionType
} from '@core/models/api.models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private baseUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  /* ──────── Solutions ──────── */

  getSolutions(): Observable<{ solutions: SolutionMeta[] }> {
    return this.http.get<{ solutions: SolutionMeta[] }>(`${this.baseUrl}/solutions`);
  }

  /* ──────── Job Submission ──────── */

  submitJob(
    file: File,
    solutionType: SolutionType,
    modelId?: string,
    configJson?: string
  ): Observable<JobSubmitResponse> {
    const formData = new FormData();
    formData.append('file', file, file.name);
    formData.append('solution_type', solutionType);
    if (modelId) formData.append('model_id', modelId);
    if (configJson) formData.append('config_json', configJson);

    return this.http.post<JobSubmitResponse>(`${this.baseUrl}/jobs/submit`, formData);
  }

  /* ──────── Job Status ──────── */

  getJobStatus(jobId: string): Observable<JobStatusResponse> {
    return this.http.get<JobStatusResponse>(`${this.baseUrl}/jobs/${jobId}/status`);
  }

  /**
   * Polls job status every `intervalMs` until it reaches a terminal state.
   * Emits each status update.
   */
  pollJobStatus(jobId: string, intervalMs: number = 3000): Observable<JobStatusResponse> {
    const terminalStates: string[] = ['completed', 'failed', 'partially_completed'];
    return timer(0, intervalMs).pipe(
      switchMap(() => this.getJobStatus(jobId)),
      takeWhile(status => !terminalStates.includes(status.status), true)
    );
  }

  listJobs(solutionType?: SolutionType): Observable<JobStatusResponse[]> {
    const params = solutionType ? { solution_type: solutionType } : {};
    return this.http.get<JobStatusResponse[]>(`${this.baseUrl}/jobs`, { params });
  }

  /* ──────── Download ──────── */

  downloadResult(jobId: string): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/jobs/${jobId}/download`, {
      responseType: 'blob'
    });
  }

  /* ──────── Usage ──────── */

  getUsage(): Observable<UsageSummary> {
    return this.http.get<UsageSummary>(`${this.baseUrl}/usage`);
  }

  /* ──────── Health ──────── */

  healthCheck(): Observable<any> {
    return this.http.get(`${this.baseUrl}/health`);
  }
}
