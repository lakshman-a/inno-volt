import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { AdoptionRecord, SolutionType } from '@core/models/api.models';

@Injectable({ providedIn: 'root' })
export class AdoptionService {
  private readonly STORAGE_KEY = 'genai_adoption_records';
  private records$ = new BehaviorSubject<AdoptionRecord[]>(this.loadRecords());

  getRecords(): Observable<AdoptionRecord[]> {
    return this.records$.asObservable();
  }

  addRecord(record: Omit<AdoptionRecord, 'id' | 'timestamp'>): void {
    const full: AdoptionRecord = {
      ...record,
      id: this.generateId(),
      timestamp: new Date().toISOString(),
    };
    const current = this.records$.value;
    const updated = [full, ...current].slice(0, 500); // Keep last 500
    this.records$.next(updated);
    this.saveRecords(updated);
  }

  getStats(): {
    totalJobs: number;
    bySolution: { [key in SolutionType]?: number };
    totalTokens: number;
    totalCost: number;
    valueMetrics: { coverageDelta: number; docsGenerated: number; issuesFixed: number }
  } {
    const records = this.records$.value;
    const bySolution: { [key in SolutionType]?: number } = {};
    let totalTokens = 0;
    let totalCost = 0;
    let coverageDelta = 0;
    let docsGenerated = 0;
    let issuesFixed = 0;

    records.forEach(r => {
      bySolution[r.solution_type] = (bySolution[r.solution_type] || 0) + 1;
      totalTokens += Number(r.value_metrics['tokens'] || 0);
      totalCost += Number(r.value_metrics['cost'] || 0);
      coverageDelta += Number(r.value_metrics['coverage_delta'] || 0);
      docsGenerated += Number(r.value_metrics['docs_generated'] || 0);
      issuesFixed += Number(r.value_metrics['issues_fixed'] || 0);
    });

    return {
      totalJobs: records.length,
      bySolution,
      totalTokens,
      totalCost,
      valueMetrics: { coverageDelta, docsGenerated, issuesFixed }
    };
  }

  private loadRecords(): AdoptionRecord[] {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  private saveRecords(records: AdoptionRecord[]): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(records));
  }

  private generateId(): string {
    return Math.random().toString(36).substring(2, 10);
  }
}
