import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  // Placeholder for SSO integration
  // Replace with your enterprise SSO check
  private isAuthenticated = true;

  constructor(private router: Router) {}

  canActivate(): boolean {
    if (!this.isAuthenticated) {
      // Redirect to SSO login page
      // window.location.href = '/sso/login';
      return false;
    }
    return true;
  }
}
