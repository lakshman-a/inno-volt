/* Core data models - mirrors backend Pydantic schemas */

export type SolutionType = 'unit_test_gen' | 'api_doc_gen' | 'func_test_gen' | 'sonar_fix';

export type JobStatus =
  | 'pending' | 'validating' | 'analyzing' | 'processing'
  | 'generating' | 'validating_output' | 'completed' | 'failed'
  | 'partially_completed';

export type InputMode = 'zip_upload' | 'git_repo';

export interface SolutionMeta {
  solution_type: SolutionType;
  name: string;
  description: string;
  requires_build: boolean;
  requires_coverage: boolean;
  supported_languages: string[];
  additional_inputs: { name: string; type: string; description: string }[];
}

export interface JobSubmitResponse {
  job_id: string;
  status: string;
  message: string;
}

export interface JobStatusResponse {
  job_id: string;
  status: JobStatus;
  solution_type: SolutionType;
  progress_percent: number;
  current_phase: string;
  message: string;
  created_at: string;
  updated_at: string;
  result: any;
  errors: string[];
}

export interface GenerationResult {
  target_class: string;
  generated_file_path: string | null;
  success: boolean;
  compilation_passed: boolean;
  tests_passed: boolean;
  error_message: string | null;
  attempts: number;
  tokens_used: number;
  cost_estimate: number;
}

export interface UnitTestGenResult {
  baseline_coverage: number;
  new_coverage: number;
  coverage_delta: number;
  classes_processed: number;
  classes_succeeded: number;
  classes_failed: number;
  tests_generated: number;
  test_methods_generated: number;
  total_tokens_used: number;
  total_llm_calls: number;
  estimated_cost: number;
  class_results: GenerationResult[];
  output_zip_path: string | null;
}

export interface ApiDocGenResult {
  endpoints_found: number;
  endpoints_documented: number;
  fields_populated: number;
  total_fields: number;
  total_tokens_used: number;
  total_llm_calls: number;
  estimated_cost: number;
  output_path: string | null;
}

export interface UsageSummary {
  total_calls: number;
  successful_calls: number;
  failed_calls: number;
  total_tokens: number;
  total_cost: number;
}

export interface AdoptionRecord {
  id: string;
  solution_type: SolutionType;
  team_name: string;
  job_id: string;
  timestamp: string;
  input_summary: string;
  output_summary: string;
  value_metrics: { [key: string]: number | string };
}

/* Solution card config for the UI */
export interface SolutionCard {
  type: SolutionType;
  name: string;
  description: string;
  icon: string;
  status: 'ready' | 'coming_soon';
  route: string;
  color: string;
  stats?: { label: string; value: string }[];
}
