"""
GenAI Platform - Main Application Entry Point.
Multi-solution platform for AI-powered code quality improvements.
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger
import sys

from config.settings import settings
from app.api.routes.main import router
from app.core.solution_registry import solution_registry, SolutionMetadata
from app.core.exceptions import global_exception_handler, http_exception_handler
from app.models.schemas import SolutionType

# Configure logging
logger.remove()
logger.add(sys.stdout, level="DEBUG" if settings.debug else "INFO",
           format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>")


def register_solutions():
    """Register all available solutions."""

    solution_registry.register(SolutionMetadata(
        solution_type=SolutionType.UNIT_TEST_GEN,
        name="Unit Test Generation",
        description="Analyzes Java projects, identifies coverage gaps, and generates unit tests to improve coverage.",
        requires_build=True,
        requires_coverage=True,
        supported_languages=["java"],
        additional_inputs=[],
    ))

    solution_registry.register(SolutionMetadata(
        solution_type=SolutionType.API_DOC_GEN,
        name="API Documentation Generation",
        description="Analyzes REST API code and populates DX documentation fields automatically.",
        requires_build=False,
        requires_coverage=False,
        supported_languages=["java"],
        additional_inputs=[
            {"name": "doc_fields", "type": "json", "description": "List of documentation fields to populate"},
            {"name": "template", "type": "file", "description": "Optional documentation template"},
        ],
    ))

    solution_registry.register(SolutionMetadata(
        solution_type=SolutionType.FUNC_TEST_GEN,
        name="Functional Test Generation",
        description="Generates functional/integration tests from API specs and requirements.",
        requires_build=True,
        requires_coverage=False,
        supported_languages=["java"],
        additional_inputs=[
            {"name": "swagger_file", "type": "file", "description": "Swagger/OpenAPI specification"},
            {"name": "requirements", "type": "text", "description": "Requirements document"},
        ],
    ))

    solution_registry.register(SolutionMetadata(
        solution_type=SolutionType.SONAR_FIX,
        name="Sonar Issue Remediation",
        description="Automatically fixes Sonar code quality issues (code smells, bugs, vulnerabilities).",
        requires_build=True,
        requires_coverage=False,
        supported_languages=["java"],
        additional_inputs=[
            {"name": "sonar_url", "type": "text", "description": "SonarQube server URL"},
            {"name": "sonar_token", "type": "text", "description": "SonarQube API token"},
        ],
    ))

    logger.info(f"Registered {len(solution_registry.list_all())} solutions")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""

    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Multi-solution GenAI platform for code quality and developer productivity",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Global exception handlers
    app.add_exception_handler(Exception, global_exception_handler)
    app.add_exception_handler(HTTPException, http_exception_handler)

    # Register solutions
    register_solutions()

    # Include routes
    app.include_router(router, prefix="/api/v1")

    # Startup/shutdown events
    @app.on_event("startup")
    async def startup():
        # Ensure workspace directories exist
        settings.workspace_base.mkdir(parents=True, exist_ok=True)
        settings.upload_dir.mkdir(parents=True, exist_ok=True)
        settings.output_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"🚀 {settings.app_name} v{settings.app_version} started")
        logger.info(f"   Solutions: {[s['name'] for s in solution_registry.list_all()]}")
        logger.info(f"   Gateway: {settings.gateway.base_url}")
        logger.info(f"   Default model: {settings.gateway.default_model}")

    @app.on_event("shutdown")
    async def shutdown():
        logger.info("Shutting down...")

    return app


# Create the app instance
app = create_app()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
