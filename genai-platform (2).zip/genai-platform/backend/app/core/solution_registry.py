"""
Solution Registry - Plugin architecture for solutions.
Each solution registers itself here with metadata and its executor.
This allows the platform to dynamically discover and run solutions.
"""
from typing import Dict, Optional, Callable, Any, List
from loguru import logger

from app.models.schemas import SolutionType


class SolutionMetadata:
    """Describes a solution's capabilities and requirements."""

    def __init__(
        self,
        solution_type: SolutionType,
        name: str,
        description: str,
        requires_build: bool = True,
        requires_coverage: bool = False,
        supported_languages: List[str] = None,
        additional_inputs: List[Dict[str, str]] = None,
        executor: Callable = None,
    ):
        self.solution_type = solution_type
        self.name = name
        self.description = description
        self.requires_build = requires_build
        self.requires_coverage = requires_coverage
        self.supported_languages = supported_languages or ["java"]
        self.additional_inputs = additional_inputs or []
        self.executor = executor

    def to_dict(self) -> dict:
        return {
            "solution_type": self.solution_type.value,
            "name": self.name,
            "description": self.description,
            "requires_build": self.requires_build,
            "requires_coverage": self.requires_coverage,
            "supported_languages": self.supported_languages,
            "additional_inputs": self.additional_inputs,
        }


class SolutionRegistry:
    """Central registry for all available solutions."""

    def __init__(self):
        self._solutions: Dict[SolutionType, SolutionMetadata] = {}

    def register(self, metadata: SolutionMetadata):
        """Register a solution."""
        self._solutions[metadata.solution_type] = metadata
        logger.info(f"Registered solution: {metadata.name} ({metadata.solution_type.value})")

    def get(self, solution_type: SolutionType) -> Optional[SolutionMetadata]:
        """Get a solution's metadata."""
        return self._solutions.get(solution_type)

    def list_all(self) -> List[dict]:
        """List all registered solutions."""
        return [s.to_dict() for s in self._solutions.values()]

    def get_executor(self, solution_type: SolutionType) -> Optional[Callable]:
        """Get the executor function for a solution."""
        meta = self._solutions.get(solution_type)
        return meta.executor if meta else None


# Singleton instance
solution_registry = SolutionRegistry()
