from app.core.job_manager import job_manager, JobManager
from app.core.solution_registry import solution_registry, SolutionRegistry
