"""
Global Exception Handler - Catches all errors and returns clean JSON responses.
Ensures the UI always gets a structured error message, never raw stack traces.
"""
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from loguru import logger
import traceback


async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Catch-all exception handler for unhandled errors."""
    error_id = id(exc) & 0xFFFF  # Short error ID for correlation
    logger.error(f"[ERR-{error_id:04X}] Unhandled exception on {request.method} {request.url.path}: {exc}")
    logger.debug(traceback.format_exc())

    return JSONResponse(
        status_code=500,
        content={
            "error": True,
            "error_id": f"ERR-{error_id:04X}",
            "message": "An internal error occurred. Please try again or contact support.",
            "detail": str(exc) if str(exc) else "Unknown error",
            "path": str(request.url.path),
        }
    )


async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """Handler for HTTPException - returns structured error."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": True,
            "message": exc.detail,
            "status_code": exc.status_code,
            "path": str(request.url.path),
        }
    )


class GatewayAPIError(Exception):
    """Raised when the LLM Gateway API returns an error."""
    def __init__(self, message: str, status_code: int = 0, response_body: str = ""):
        self.message = message
        self.status_code = status_code
        self.response_body = response_body[:500]
        super().__init__(self.message)


class BuildError(Exception):
    """Raised when Maven build/test fails."""
    def __init__(self, message: str, phase: str = "build"):
        self.message = message
        self.phase = phase
        super().__init__(self.message)


class ValidationError(Exception):
    """Raised when input validation fails."""
    def __init__(self, message: str, field: str = ""):
        self.message = message
        self.field = field
        super().__init__(self.message)
