"""
Job Manager - Tracks and manages async solution jobs.
Each solution run is a "job" with its own lifecycle, status, and results.
"""
import asyncio
import uuid
from datetime import datetime
from typing import Dict, Optional, Callable, Any
from loguru import logger

from app.models.schemas import JobStatus, JobStatusResponse, SolutionType


class Job:
    """Represents a single solution execution job."""

    def __init__(self, job_id: str, solution_type: SolutionType):
        self.job_id = job_id
        self.solution_type = solution_type
        self.status = JobStatus.PENDING
        self.progress_percent = 0.0
        self.current_phase = "Initializing"
        self.message = ""
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        self.result: Optional[Dict[str, Any]] = None
        self.errors: list = []
        self.workspace_path: Optional[str] = None
        self._task: Optional[asyncio.Task] = None

    def update(self, status: Optional[JobStatus] = None,
               progress: Optional[float] = None,
               phase: Optional[str] = None,
               message: Optional[str] = None):
        """Update job state."""
        if status:
            self.status = status
        if progress is not None:
            self.progress_percent = progress
        if phase:
            self.current_phase = phase
        if message:
            self.message = message
        self.updated_at = datetime.utcnow()
        logger.info(f"Job {self.job_id}: [{self.status}] {self.current_phase} - {self.progress_percent:.0f}%")

    def to_response(self) -> JobStatusResponse:
        """Convert to API response."""
        return JobStatusResponse(
            job_id=self.job_id,
            status=self.status,
            solution_type=self.solution_type,
            progress_percent=self.progress_percent,
            current_phase=self.current_phase,
            message=self.message,
            created_at=self.created_at,
            updated_at=self.updated_at,
            result=self.result,
            errors=self.errors,
        )


class JobManager:
    """Manages all active and completed jobs."""

    def __init__(self):
        self._jobs: Dict[str, Job] = {}
        self._max_history = 100  # Keep last N completed jobs

    def create_job(self, solution_type: SolutionType) -> Job:
        """Create a new job and return it."""
        job_id = str(uuid.uuid4())[:8]  # Short ID for readability
        job = Job(job_id=job_id, solution_type=solution_type)
        self._jobs[job_id] = job
        logger.info(f"Created job {job_id} for solution {solution_type.value}")
        return job

    def get_job(self, job_id: str) -> Optional[Job]:
        """Retrieve a job by ID."""
        return self._jobs.get(job_id)

    def list_jobs(self, solution_type: Optional[SolutionType] = None) -> list:
        """List all jobs, optionally filtered by solution type."""
        jobs = self._jobs.values()
        if solution_type:
            jobs = [j for j in jobs if j.solution_type == solution_type]
        return [j.to_response() for j in sorted(jobs, key=lambda x: x.created_at, reverse=True)]

    async def run_job(self, job: Job, executor: Callable, **kwargs):
        """Run a job asynchronously using the given executor function."""
        async def _execute():
            try:
                job.update(status=JobStatus.PROCESSING, phase="Starting")
                result = await executor(job, **kwargs)
                job.result = result
                if job.status != JobStatus.FAILED:
                    job.update(
                        status=JobStatus.COMPLETED,
                        progress=100.0,
                        phase="Completed",
                        message="Job completed successfully"
                    )
            except Exception as e:
                logger.exception(f"Job {job.job_id} failed: {e}")
                job.errors.append(str(e))
                job.update(
                    status=JobStatus.FAILED,
                    phase="Failed",
                    message=f"Error: {str(e)}"
                )

        job._task = asyncio.create_task(_execute())
        return job.job_id


# Singleton instance
job_manager = JobManager()
