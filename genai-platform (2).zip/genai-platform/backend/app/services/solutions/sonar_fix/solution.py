"""
Sonar Code Remediation Solution.
Connects to SonarQube API → fetches issues → generates fixes via LLM → validates build.
"""
import re
import json
from pathlib import Path
from typing import List, Dict, Optional, Any
from loguru import logger
import httpx

from app.core.job_manager import Job
from app.models.schemas import JobStatus, GenerationResult
from app.services.shared.llm_client import llm_client
from app.services.shared.project_analyzer import ProjectAnalyzer
from app.services.shared.maven_runner import MavenRunner
from app.services.shared.prompt_manager import prompt_manager
from config.settings import settings


class SonarFixSolution:
    """Fetches SonarQube issues and auto-generates fixes."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.results: List[GenerationResult] = []

    async def execute(self, job: Job, project_dir: str, model_id: Optional[str] = None) -> Dict[str, Any]:
        llm_client.reset_tracking()

        sonar_url = self.config.get("sonar_url", "")
        sonar_token = self.config.get("sonar_token", "")
        sonar_project_key = self.config.get("sonar_project_key", "")
        fix_categories = self.config.get("fix_categories", ["BUG", "VULNERABILITY", "CODE_SMELL"])
        max_issues = self.config.get("max_issues_to_fix", 30)

        # Phase 1: Analyze project
        job.update(status=JobStatus.ANALYZING, progress=5.0, phase="Analyzing project")
        analyzer = ProjectAnalyzer(project_dir)
        project_info = analyzer.analyze()
        maven = MavenRunner(project_dir, project_info.java_version)

        # Phase 2: Get Sonar issues
        job.update(progress=10.0, phase="Fetching SonarQube issues")

        if sonar_url and sonar_project_key:
            issues = await self._fetch_sonar_issues(sonar_url, sonar_token, sonar_project_key, fix_categories)
        else:
            # No Sonar connection - do static analysis via LLM
            job.update(progress=15.0, phase="No Sonar config - running AI-based code analysis")
            issues = self._analyze_code_locally(analyzer)

        if not issues:
            job.update(status=JobStatus.COMPLETED, progress=100.0, phase="No issues found")
            return {"message": "No fixable issues found", "issues_found": 0, "issues_fixed": 0}

        total_issues = len(issues)
        issues = issues[:max_issues]
        logger.info(f"Found {total_issues} issues, processing {len(issues)}")

        # Phase 3: Validate build first
        job.update(progress=20.0, phase="Validating initial build")
        build_ok, build_err = await maven.validate_build()
        if not build_ok:
            logger.warning(f"Initial build failed: {build_err[:200]}")

        # Phase 4: Group issues by file and fix
        job.update(status=JobStatus.GENERATING, progress=25.0, phase="Generating fixes")
        issues_by_file = self._group_by_file(issues)

        fixed_count = 0
        failed_count = 0

        for idx, (file_path, file_issues) in enumerate(issues_by_file.items()):
            progress = 25.0 + (60.0 * (idx + 1) / len(issues_by_file))
            job.update(progress=progress, phase=f"Fixing: {Path(file_path).stem} ({idx+1}/{len(issues_by_file)})")

            result = await self._fix_file_issues(
                project_dir=project_dir,
                file_path=file_path,
                issues=file_issues,
                project_info=project_info,
                maven=maven,
                model_id=model_id,
            )
            self.results.append(result)
            if result.success:
                fixed_count += len(file_issues)
            else:
                failed_count += len(file_issues)

        # Phase 5: Final build validation
        job.update(progress=90.0, phase="Validating final build")
        final_build_ok, _ = await maven.validate_build()

        usage = llm_client.get_usage_summary()
        result = {
            "issues_found": total_issues,
            "issues_processed": len(issues),
            "issues_fixed": fixed_count,
            "issues_failed": failed_count,
            "files_modified": sum(1 for r in self.results if r.success),
            "final_build_passed": final_build_ok,
            "fix_categories": fix_categories,
            "total_tokens_used": usage["total_tokens"],
            "total_llm_calls": usage["total_calls"],
            "estimated_cost": usage["total_cost"],
            "file_results": [r.model_dump() for r in self.results],
        }

        logger.info(f"Sonar fix complete: {fixed_count} fixed, {failed_count} failed, build={'OK' if final_build_ok else 'FAIL'}")
        return result

    async def _fetch_sonar_issues(
        self, sonar_url: str, token: str, project_key: str, categories: List[str]
    ) -> List[Dict]:
        """Fetch issues from SonarQube API."""
        issues = []
        try:
            types = ",".join(categories)
            url = f"{sonar_url.rstrip('/')}/api/issues/search"
            params = {
                "componentKeys": project_key,
                "types": types,
                "statuses": "OPEN,CONFIRMED,REOPENED",
                "ps": 100,
                "p": 1,
            }
            headers = {}
            if token:
                import base64
                encoded = base64.b64encode(f"{token}:".encode()).decode()
                headers["Authorization"] = f"Basic {encoded}"

            async with httpx.AsyncClient(timeout=30, verify=False) as client:
                resp = await client.get(url, params=params, headers=headers)
                resp.raise_for_status()
                data = resp.json()

            for issue in data.get("issues", []):
                component = issue.get("component", "")
                # Extract relative file path
                file_path = component.split(":")[-1] if ":" in component else component
                issues.append({
                    "key": issue.get("key", ""),
                    "type": issue.get("type", ""),
                    "severity": issue.get("severity", ""),
                    "message": issue.get("message", ""),
                    "rule": issue.get("rule", ""),
                    "file_path": file_path,
                    "line": issue.get("line", 0),
                    "effort": issue.get("effort", ""),
                })

            logger.info(f"Fetched {len(issues)} issues from SonarQube")
        except Exception as e:
            logger.error(f"SonarQube API error: {e}")

        return issues

    def _analyze_code_locally(self, analyzer: ProjectAnalyzer) -> List[Dict]:
        """Fallback: find common issues via pattern matching (no Sonar needed)."""
        issues = []
        for source_file in analyzer.get_all_source_files():
            content = analyzer.read_file(source_file)
            rel_path = str(source_file.relative_to(analyzer.root))
            lines = content.split("\n")

            for i, line in enumerate(lines, 1):
                # Common patterns
                if "catch (Exception e)" in line and ("e.printStackTrace()" in "\n".join(lines[i:i+3]) or "// TODO" in line):
                    issues.append({"type": "CODE_SMELL", "severity": "MAJOR", "message": "Generic exception catch with poor handling", "file_path": rel_path, "line": i, "rule": "java:S2221"})
                if re.search(r'System\.(out|err)\.print', line):
                    issues.append({"type": "CODE_SMELL", "severity": "MINOR", "message": "Use a logger instead of System.out/err", "file_path": rel_path, "line": i, "rule": "java:S106"})
                if "password" in line.lower() and ("=" in line) and ('"' in line) and "test" not in rel_path.lower():
                    issues.append({"type": "VULNERABILITY", "severity": "CRITICAL", "message": "Potential hardcoded password", "file_path": rel_path, "line": i, "rule": "java:S2068"})

        return issues[:50]

    def _group_by_file(self, issues: List[Dict]) -> Dict[str, List[Dict]]:
        """Group issues by source file."""
        grouped: Dict[str, List[Dict]] = {}
        for issue in issues:
            fp = issue.get("file_path", "")
            if fp:
                grouped.setdefault(fp, []).append(issue)
        return grouped

    async def _fix_file_issues(
        self, project_dir: str, file_path: str, issues: List[Dict],
        project_info: Any, maven: MavenRunner, model_id: Optional[str],
    ) -> GenerationResult:
        """Fix all issues in a single file."""
        result = GenerationResult(target_class=Path(file_path).stem)
        full_path = Path(project_dir) / file_path

        if not full_path.exists():
            result.error_message = f"File not found: {file_path}"
            return result

        source_content = full_path.read_text(encoding="utf-8", errors="replace")
        issues_text = "\n".join(
            f"- [{issue['type']}] {issue['severity']}: {issue['message']} (line {issue.get('line', '?')}, rule: {issue.get('rule', '?')})"
            for issue in issues
        )

        system_prompt = prompt_manager.get_prompt("sonar_fix", "system")
        user_prompt = prompt_manager.render_prompt(
            "sonar_fix", "fix_issues",
            file_path=file_path,
            source_content=source_content,
            issues_list=issues_text,
        )

        for attempt in range(1, 3):
            result.attempts = attempt
            try:
                llm_response = await llm_client.generate(
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                    model_id=model_id,
                )
                result.tokens_used += llm_response["tokens"]["total"]
                result.cost_estimate += llm_response["cost"]

                fixed_code = self._extract_java_code(llm_response["content"])
                if not fixed_code:
                    continue

                # Backup original and write fix
                backup = full_path.with_suffix(".java.bak")
                backup.write_text(source_content, encoding="utf-8")
                full_path.write_text(fixed_code, encoding="utf-8")

                # Validate
                compile_ok, err = await maven.compile_only()
                if compile_ok:
                    result.success = True
                    result.compilation_passed = True
                    result.generated_content = fixed_code
                    backup.unlink(missing_ok=True)
                    return result
                else:
                    # Restore original
                    full_path.write_text(source_content, encoding="utf-8")
                    backup.unlink(missing_ok=True)
                    user_prompt = f"The fix caused compilation errors:\n{err[:1500]}\n\nOriginal code:\n{source_content}\n\nFix the issues without breaking compilation."

            except Exception as e:
                result.error_message = str(e)

        result.error_message = f"Failed after {result.attempts} attempts"
        return result

    def _extract_java_code(self, content: str) -> Optional[str]:
        content = content.strip()
        if content.startswith("```java"): content = content[7:]
        elif content.startswith("```"): content = content[3:]
        if content.endswith("```"): content = content[:-3]
        content = content.strip()
        return content if ("class " in content or "interface " in content) else None
