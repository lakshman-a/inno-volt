"""
API Documentation Generation Solution for Digital Xchange (DX).
Scans Java REST API project → generates all DX fields via LLM → validates against rules.
"""
import re
import json
from pathlib import Path
from typing import List, Dict, Optional, Any, Tuple
from loguru import logger

from app.core.job_manager import Job
from app.models.schemas import JobStatus, ApiDocGenConfig, ApiDocGenResult
from app.services.shared.llm_client import llm_client
from app.services.shared.project_analyzer import ProjectAnalyzer
from app.services.shared.prompt_manager import prompt_manager


# DX field validation rules
DX_FIELD_RULES = {
    "shortDescription": {"min_chars": 30, "type": "chars"},
    "fullDescription": {"min_words": 30, "type": "words"},
    "toolUseCase": {"min_words": 10, "type": "words"},
    "currentUsage": {"min_words": 10, "type": "words"},
    "tags": {"min_count": 1, "type": "list"},
    "developer_responsibilities": {"min_words": 10, "type": "words"},
    "product_owner_responsibilities": {"min_words": 10, "type": "words"},
    "escalationProcess": {"min_words": 10, "type": "words"},
    "prodSup": {"min_chars": 10, "type": "chars"},
    "conditionsForUse": {"min_words": 10, "type": "words"},
}


class ApiDocGenSolution:
    """Generates DX-compliant API documentation from codebase analysis."""

    def __init__(self, config: Optional[ApiDocGenConfig] = None):
        self.config = config or ApiDocGenConfig()

    async def execute(self, job: Job, project_dir: str, model_id: Optional[str] = None) -> Dict[str, Any]:
        """Main pipeline: scan project → build context → call LLM → validate → output."""
        llm_client.reset_tracking()

        # Phase 1: Deep project scan
        job.update(status=JobStatus.ANALYZING, progress=5.0, phase="Scanning project structure")
        scan = self._deep_scan_project(project_dir)

        logger.info(
            f"Scan complete: {scan['controller_count']} controllers, "
            f"{scan['model_count']} models, {scan['service_count']} services, "
            f"swagger={'yes' if scan['swagger_content'] else 'no'}"
        )

        if scan["controller_count"] == 0 and not scan["swagger_content"]:
            job.update(status=JobStatus.COMPLETED, progress=100.0,
                       phase="No API endpoints or Swagger found")
            return ApiDocGenResult(
                endpoints_found=0, endpoints_documented=0,
                fields_populated=0, total_fields=len(DX_FIELD_RULES),
                total_tokens_used=0, total_llm_calls=0, estimated_cost=0.0,
            ).model_dump()

        # Phase 2: Build LLM context
        job.update(progress=20.0, phase="Building documentation context")
        system_prompt = prompt_manager.get_prompt("api_doc_gen", "system")

        # Build grounding from swagger + config
        grounding_parts = []
        if scan["swagger_content"]:
            grounding_parts.append(f"SWAGGER SPEC:\n{scan['swagger_content'][:8000]}")
        if scan["readme_content"]:
            grounding_parts.append(f"README:\n{scan['readme_content'][:3000]}")
        grounding = "\n\n".join(grounding_parts) if grounding_parts else None

        user_prompt = prompt_manager.render_prompt(
            "api_doc_gen", "generate_fields",
            project_metadata=scan["pom_content"][:3000],
            controller_content=scan["controller_content"][:12000],
            model_content=scan["model_content"][:8000],
            service_content=scan["service_content"][:6000],
            config_content=scan["config_content"][:3000],
            swagger_content=scan["swagger_content"][:8000] if scan["swagger_content"] else "Not available",
            readme_content=scan["readme_content"][:3000] if scan["readme_content"] else "Not available",
        )

        # Phase 3: Generate documentation via LLM
        job.update(status=JobStatus.GENERATING, progress=35.0, phase="Generating DX documentation via AI")

        llm_response = await llm_client.generate(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            model_id=model_id,
            grounding=grounding,
            max_tokens=4096,
        )

        # Phase 4: Parse and validate
        job.update(progress=70.0, phase="Parsing and validating documentation")
        dx_doc = self._parse_json_response(llm_response["content"])

        if not dx_doc:
            # Retry once with a simpler prompt
            job.update(progress=75.0, phase="Retrying generation...")
            llm_response = await llm_client.generate(
                system_prompt=system_prompt,
                user_prompt=user_prompt + "\n\nIMPORTANT: Return ONLY valid JSON. No text before or after the JSON object.",
                model_id=model_id,
                max_tokens=4096,
            )
            dx_doc = self._parse_json_response(llm_response["content"])

        if not dx_doc:
            job.update(status=JobStatus.FAILED, phase="Failed to generate valid JSON documentation")
            return {"error": "LLM did not return valid JSON after retries"}

        # Phase 5: Validate against DX rules
        job.update(progress=80.0, phase="Validating against DX field rules")
        validation = self._validate_dx_fields(dx_doc)
        dx_doc["_validation"] = validation

        # Phase 6: Count endpoints
        endpoints = dx_doc.get("endpoints", [])
        endpoint_count = len(endpoints)

        # Phase 7: Save outputs
        job.update(progress=90.0, phase="Saving documentation")
        output_paths = self._save_outputs(project_dir, dx_doc)

        # Build result
        fields_populated = self._count_populated_fields(dx_doc)
        usage = llm_client.get_usage_summary()

        result = ApiDocGenResult(
            endpoints_found=max(endpoint_count, scan["controller_count"]),
            endpoints_documented=endpoint_count,
            fields_populated=fields_populated,
            total_fields=len(DX_FIELD_RULES) + 10,  # DX rules + extra fields
            total_tokens_used=usage["total_tokens"],
            total_llm_calls=usage["total_calls"],
            estimated_cost=usage["total_cost"],
            output_path=output_paths["json"],
        )

        logger.info(
            f"API Doc Gen complete: {endpoint_count} endpoints, "
            f"{fields_populated} fields populated, "
            f"validation: {validation['passed']}/{validation['total']} rules passed"
        )

        return result.model_dump()

    # ================================================================
    # Deep Project Scanner
    # ================================================================

    def _deep_scan_project(self, project_dir: str) -> Dict[str, Any]:
        """Scan the entire project and collect all relevant content."""
        root = Path(project_dir)

        result = {
            "pom_content": "",
            "controller_content": "",
            "model_content": "",
            "service_content": "",
            "config_content": "",
            "swagger_content": "",
            "readme_content": "",
            "controller_count": 0,
            "model_count": 0,
            "service_count": 0,
        }

        # POM / build file
        for pom in root.rglob("pom.xml"):
            result["pom_content"] += self._safe_read(pom) + "\n"
            break  # Just root pom

        # README
        for readme in root.rglob("README*"):
            result["readme_content"] += self._safe_read(readme) + "\n"
            break

        # Swagger/OpenAPI files
        for pattern in ["**/swagger*.json", "**/swagger*.yml", "**/swagger*.yaml",
                        "**/openapi*.json", "**/openapi*.yml", "**/openapi*.yaml",
                        "**/api-docs*"]:
            for f in root.rglob(pattern.replace("**/", "")):
                if f.is_file() and f.stat().st_size < 500_000:
                    result["swagger_content"] += self._safe_read(f) + "\n"

        # Java source files - categorize by type
        controllers = []
        models = []
        services = []
        configs = []

        for java_file in root.rglob("*.java"):
            if "target/" in str(java_file) or "test/" in str(java_file):
                continue

            content = self._safe_read(java_file)
            name_lower = java_file.stem.lower()

            if any(ann in content for ann in ["@RestController", "@Controller",
                                               "@RequestMapping", "@GetMapping",
                                               "@PostMapping"]):
                controllers.append((java_file.stem, content))
            elif any(kw in name_lower for kw in ["dto", "model", "entity", "request",
                                                   "response", "vo", "bean"]):
                models.append((java_file.stem, content))
            elif any(ann in content for ann in ["@Entity", "@Document", "@Data",
                                                 "@Table"]):
                models.append((java_file.stem, content))
            elif any(kw in name_lower for kw in ["service", "manager", "handler",
                                                   "processor", "facade"]):
                services.append((java_file.stem, content))
            elif any(kw in name_lower for kw in ["config", "properties", "security",
                                                   "swagger", "openapi"]):
                configs.append((java_file.stem, content))

        # Also check application.yml / application.properties
        for cfg_file in root.rglob("application*"):
            if cfg_file.is_file():
                configs.append((cfg_file.name, self._safe_read(cfg_file)))

        result["controller_content"] = "\n\n".join(
            f"// === {name}.java ===\n{content}" for name, content in controllers
        )
        result["model_content"] = "\n\n".join(
            f"// === {name}.java ===\n{content}" for name, content in models[:15]
        )
        result["service_content"] = "\n\n".join(
            f"// === {name}.java ===\n{content}" for name, content in services[:10]
        )
        result["config_content"] = "\n\n".join(
            f"// === {name} ===\n{content}" for name, content in configs[:5]
        )

        result["controller_count"] = len(controllers)
        result["model_count"] = len(models)
        result["service_count"] = len(services)

        return result

    # ================================================================
    # DX Field Validation
    # ================================================================

    def _validate_dx_fields(self, doc: Dict) -> Dict[str, Any]:
        """Validate the generated doc against DX field rules."""
        results = []
        passed = 0
        total = len(DX_FIELD_RULES)

        for field, rules in DX_FIELD_RULES.items():
            value = doc.get(field, "")
            ok = False
            message = ""

            if rules["type"] == "chars":
                length = len(str(value)) if value else 0
                min_req = rules.get("min_chars", 0)
                ok = length >= min_req
                message = f"{length}/{min_req} chars" if not ok else "OK"

            elif rules["type"] == "words":
                word_count = len(str(value).split()) if value else 0
                min_req = rules.get("min_words", 0)
                ok = word_count >= min_req
                message = f"{word_count}/{min_req} words" if not ok else "OK"

            elif rules["type"] == "list":
                count = len(value) if isinstance(value, list) else 0
                min_req = rules.get("min_count", 0)
                ok = count >= min_req
                message = f"{count}/{min_req} items" if not ok else "OK"

            if ok:
                passed += 1
            results.append({"field": field, "passed": ok, "message": message})

        return {"passed": passed, "total": total, "details": results}

    # ================================================================
    # Helpers
    # ================================================================

    def _parse_json_response(self, content: str) -> Optional[Dict]:
        """Extract JSON from LLM response."""
        content = content.strip()
        # Remove markdown fences
        if content.startswith("```json"):
            content = content[7:]
        if content.startswith("```"):
            content = content[3:]
        if content.endswith("```"):
            content = content[:-3]
        content = content.strip()

        # Try to find JSON object
        start = content.find("{")
        end = content.rfind("}") + 1
        if start >= 0 and end > start:
            try:
                return json.loads(content[start:end])
            except json.JSONDecodeError as e:
                logger.error(f"JSON parse error: {e}")
        return None

    def _save_outputs(self, project_dir: str, doc: Dict) -> Dict[str, str]:
        """Save documentation as JSON and Markdown."""
        base = Path(project_dir)

        # JSON (DX-ready format for upload)
        json_path = base / "dx-documentation.json"
        with open(json_path, "w") as f:
            json.dump(doc, f, indent=2)

        # Markdown (human-readable)
        md_path = base / "dx-documentation.md"
        with open(md_path, "w") as f:
            f.write(self._generate_markdown(doc))

        return {"json": str(json_path), "markdown": str(md_path)}

    def _generate_markdown(self, doc: Dict) -> str:
        """Generate human-readable markdown from DX doc."""
        lines = [
            f"# {doc.get('toolName', 'API')} - Digital Xchange Documentation\n",
            f"**Tag Line:** {doc.get('shortDescription', '')}\n",
            f"**API Type:** {doc.get('apiType', '')}\n",
            f"**Domain:** {doc.get('domain', '')}\n",
            f"\n## Description\n\n{doc.get('fullDescription', '')}\n",
            f"\n## Approved Use Cases\n\n{doc.get('toolUseCase', '')}\n",
            f"\n## Where Currently Used\n\n{doc.get('currentUsage', '')}\n",
            f"\n## Conditions for Use\n\n{doc.get('conditionsForUse', '')}\n",
            f"\n## Tags\n\n{', '.join(doc.get('tags', []))}\n",
            f"\n## FAQ - Technical\n\n{doc.get('developer_responsibilities', '')}\n",
            f"\n## FAQ - Business\n\n{doc.get('product_owner_responsibilities', '')}\n",
            f"\n## Production Support\n\n{doc.get('escalationProcess', '')}\n",
            f"\n## Support Contact\n\n{doc.get('prodSup', '')}\n",
        ]

        endpoints = doc.get("endpoints", [])
        if endpoints:
            lines.append("\n## Endpoints\n")
            for ep in endpoints:
                lines.append(f"\n### {ep.get('method', 'GET')} {ep.get('path', '')}\n")
                lines.append(f"{ep.get('summary', '')}\n")

        # Validation results
        validation = doc.get("_validation", {})
        if validation:
            lines.append(f"\n---\n## DX Validation: {validation.get('passed', 0)}/{validation.get('total', 0)} rules passed\n")
            for detail in validation.get("details", []):
                icon = "✅" if detail["passed"] else "❌"
                lines.append(f"- {icon} **{detail['field']}**: {detail['message']}\n")

        return "\n".join(lines)

    def _count_populated_fields(self, doc: Dict) -> int:
        """Count non-empty fields."""
        count = 0
        for k, v in doc.items():
            if k.startswith("_"):
                continue
            if isinstance(v, dict):
                count += sum(1 for val in v.values() if val)
            elif isinstance(v, list):
                count += len(v)
            elif v and str(v).strip() and v != "N/A":
                count += 1
        return count

    @staticmethod
    def _safe_read(path: Path, max_size: int = 100_000) -> str:
        """Read file safely with size limit."""
        try:
            if path.stat().st_size > max_size:
                return path.read_text(encoding="utf-8", errors="replace")[:max_size]
            return path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return f"// Error reading {path.name}: {e}"
