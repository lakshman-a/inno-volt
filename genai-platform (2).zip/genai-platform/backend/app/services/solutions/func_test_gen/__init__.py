from app.services.solutions.func_test_gen.solution import FuncTestGenSolution
