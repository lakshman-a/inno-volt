"""
Unit Test Generation Solution - Main pipeline.
Orchestrates the full flow: analyze → plan → generate → validate → iterate → package.
"""
import re
from pathlib import Path
from typing import List, Dict, Optional, Any
from loguru import logger

from app.core.job_manager import Job
from app.models.schemas import (
    JobStatus, CoverageData, GenerationTarget,
    GenerationResult, UnitTestGenResult, UnitTestGenConfig,
)
from app.services.shared.llm_client import llm_client
from app.services.shared.project_analyzer import ProjectAnalyzer
from app.services.shared.maven_runner import MavenRunner
from app.services.shared.coverage_parser import JacocoParser
from app.services.shared.file_manager import FileManager
from app.services.shared.prompt_manager import prompt_manager
from config.settings import settings


class UnitTestGenSolution:
    """Generates unit tests to improve code coverage."""

    def __init__(self, config: Optional[UnitTestGenConfig] = None):
        self.config = config or UnitTestGenConfig()
        self.results: List[GenerationResult] = []

    async def execute(self, job: Job, project_dir: str, model_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Main execution pipeline.
        Called by the job manager with the extracted project directory.
        """
        llm_client.reset_tracking()

        # Phase 1: Analyze project
        job.update(status=JobStatus.ANALYZING, progress=5.0, phase="Analyzing project structure")
        analyzer = ProjectAnalyzer(project_dir)
        project_info = analyzer.analyze()
        logger.info(f"Project: {project_info.artifact_id}, Java {project_info.java_version}")

        # Phase 2: Build & baseline coverage
        job.update(progress=10.0, phase="Building project and generating baseline coverage")
        maven = MavenRunner(project_dir, project_info.java_version)

        # Inject JaCoCo if not present
        if not project_info.has_jacoco:
            maven.inject_jacoco_plugin()

        # Validate build
        build_ok, build_error = await maven.validate_build()
        if not build_ok:
            job.update(status=JobStatus.FAILED, phase="Build failed",
                      message=f"Project build failed: {build_error[:200]}")
            return {"error": build_error}

        # Run baseline coverage
        cov_ok, jacoco_path = await maven.run_tests_with_coverage()
        baseline_coverage = 0.0

        if jacoco_path:
            parser = JacocoParser(jacoco_path)
            overall = parser.get_overall_coverage()
            baseline_coverage = overall["line_coverage"]
            logger.info(f"Baseline coverage: {baseline_coverage}%")

            # Phase 3: Identify coverage gaps
            job.update(progress=20.0, phase="Identifying coverage gaps")
            uncovered_classes = parser.get_uncovered_classes(
                threshold=self.config.target_coverage_percent
            )
        else:
            # No coverage report - analyze all classes
            logger.warning("No coverage report, will attempt to generate tests for all classes")
            uncovered_classes = []

        # Phase 4: Build generation targets
        job.update(progress=25.0, phase="Building generation plan")
        targets = self._build_targets(analyzer, project_info, uncovered_classes)

        if not targets:
            job.update(status=JobStatus.COMPLETED, progress=100.0,
                      phase="No targets found",
                      message="All classes meet coverage threshold or no testable classes found")
            return UnitTestGenResult(
                baseline_coverage=baseline_coverage,
                new_coverage=baseline_coverage,
                coverage_delta=0.0,
                classes_processed=0, classes_succeeded=0, classes_failed=0,
                tests_generated=0, test_methods_generated=0,
                total_tokens_used=0, total_llm_calls=0, estimated_cost=0.0,
            ).model_dump()

        # Limit classes to process
        targets = targets[:self.config.max_classes_to_process]
        logger.info(f"Will generate tests for {len(targets)} classes")

        # Phase 5: Generate tests for each target
        job.update(status=JobStatus.GENERATING, progress=30.0,
                  phase=f"Generating tests for {len(targets)} classes")

        for i, target in enumerate(targets):
            progress = 30.0 + (60.0 * (i + 1) / len(targets))
            job.update(
                progress=progress,
                phase=f"Generating tests: {target.class_name} ({i+1}/{len(targets)})"
            )

            result = await self._generate_and_validate(
                target=target,
                project_dir=project_dir,
                project_info=project_info,
                maven=maven,
                model_id=model_id,
            )
            self.results.append(result)

        # Phase 6: Final coverage measurement
        job.update(progress=92.0, phase="Measuring final coverage")
        cov_ok, jacoco_path = await maven.run_tests_with_coverage()
        new_coverage = baseline_coverage

        if jacoco_path:
            parser = JacocoParser(jacoco_path)
            overall = parser.get_overall_coverage()
            new_coverage = overall["line_coverage"]

        # Build result
        usage = llm_client.get_usage_summary()
        succeeded = sum(1 for r in self.results if r.success)
        failed = sum(1 for r in self.results if not r.success)

        total_test_methods = sum(
            self._count_test_methods(r.generated_content or "")
            for r in self.results if r.success
        )

        result = UnitTestGenResult(
            baseline_coverage=baseline_coverage,
            new_coverage=new_coverage,
            coverage_delta=round(new_coverage - baseline_coverage, 2),
            classes_processed=len(self.results),
            classes_succeeded=succeeded,
            classes_failed=failed,
            tests_generated=succeeded,
            test_methods_generated=total_test_methods,
            total_tokens_used=usage["total_tokens"],
            total_llm_calls=usage["total_calls"],
            estimated_cost=usage["total_cost"],
            class_results=self.results,
        )

        logger.info(
            f"Unit test generation complete: "
            f"coverage {baseline_coverage}% → {new_coverage}% (+{result.coverage_delta}%), "
            f"{succeeded}/{len(self.results)} classes succeeded, "
            f"{total_test_methods} test methods generated"
        )

        return result.model_dump()

    def _build_targets(
        self,
        analyzer: ProjectAnalyzer,
        project_info,
        uncovered_classes: List[CoverageData],
    ) -> List[GenerationTarget]:
        """Build generation targets from coverage analysis."""
        targets = []
        source_files = analyzer.get_all_source_files()

        # Build a map of class name → source path
        class_to_path = {}
        for sf in source_files:
            class_name = sf.stem
            class_to_path[class_name] = sf

        for cov in uncovered_classes:
            source_path = class_to_path.get(cov.class_name)
            if not source_path:
                continue

            # Skip based on config patterns
            rel_path = str(source_path.relative_to(analyzer.root))
            if any(self._matches_pattern(rel_path, p) for p in self.config.skip_patterns):
                continue

            # Read source content
            source_content = analyzer.read_file(source_path)

            # Skip interfaces, enums, annotations (usually don't need tests)
            if self._is_skip_type(source_content):
                continue

            # Find existing test
            test_path = analyzer.find_test_for_source(source_path)
            existing_test_content = None
            if test_path:
                existing_test_content = analyzer.read_file(test_path)

            # Find dependencies
            dep_files = analyzer.find_dependencies(source_path)
            dependency_map = {}
            for dep in dep_files:
                dependency_map[dep.name] = analyzer.read_file(dep)

            package = analyzer.get_package_from_path(source_path, project_info.source_dir)

            targets.append(GenerationTarget(
                class_name=cov.class_name,
                package_name=package,
                source_file_path=str(source_path),
                source_content=source_content,
                existing_test_path=str(test_path) if test_path else None,
                existing_test_content=existing_test_content,
                dependency_files=dependency_map,
                coverage=cov,
                priority=int(100 - cov.line_coverage),
            ))

        # Sort by priority (lowest coverage first)
        targets.sort(key=lambda t: t.priority, reverse=True)
        return targets

    async def _generate_and_validate(
        self,
        target: GenerationTarget,
        project_dir: str,
        project_info,
        maven: MavenRunner,
        model_id: Optional[str] = None,
    ) -> GenerationResult:
        """Generate tests for a single class with retry loop."""

        result = GenerationResult(target_class=target.class_name)

        # Build the prompt
        system_prompt = prompt_manager.render_prompt(
            "unit_test_gen", "system",
            test_framework=project_info.test_framework.replace("junit5", "JUnit 5").replace("junit4", "JUnit 4"),
            mock_framework=project_info.mock_framework.capitalize(),
            test_class_name=f"{target.class_name}GenTest",
            package_name=target.package_name,
        )

        dep_content = "\n\n".join(
            f"// File: {name}\n{content}"
            for name, content in target.dependency_files.items()
        ) or "No project dependencies to show."

        existing_test = target.existing_test_content or "No existing tests found. Use standard conventions."

        coverage = target.coverage
        user_prompt = prompt_manager.render_prompt(
            "unit_test_gen", "generate_tests",
            source_file_name=f"{target.class_name}.java",
            source_content=target.source_content,
            dependency_content=dep_content,
            existing_test_content=existing_test,
            line_coverage=coverage.line_coverage if coverage else 0,
            branch_coverage=coverage.branch_coverage if coverage else 0,
            missed_methods=", ".join(coverage.missed_methods) if coverage else "all methods",
        )

        # Generation + retry loop
        generated_code = None
        max_retries = settings.max_llm_retries_per_class

        for attempt in range(1, max_retries + 1):
            result.attempts = attempt

            try:
                # Build grounding context from dependencies
                grounding_content = "\n\n".join(
                    f"// Dependency: {name}\n{content}"
                    for name, content in target.dependency_files.items()
                )
                if target.existing_test_content:
                    grounding_content += f"\n\n// Existing test style reference:\n{target.existing_test_content}"

                if attempt == 1:
                    # Initial generation
                    llm_response = await llm_client.generate(
                        system_prompt=system_prompt,
                        user_prompt=user_prompt,
                        model_id=model_id,
                        grounding=grounding_content if grounding_content.strip() else None,
                    )
                else:
                    # Fix attempt
                    fix_prompt = prompt_manager.render_prompt(
                        "unit_test_gen", "fix_errors",
                        source_content=target.source_content,
                        generated_test_content=generated_code,
                        error_output=last_error[:2000],
                    )
                    llm_response = await llm_client.generate(
                        system_prompt=system_prompt,
                        user_prompt=fix_prompt,
                        model_id=model_id,
                    )

                generated_code = self._extract_java_code(llm_response["content"])
                result.tokens_used += llm_response["tokens"]["total"]
                result.cost_estimate += llm_response["cost"]

                if not generated_code:
                    last_error = "LLM returned empty or non-Java content"
                    logger.warning(f"Empty generation for {target.class_name}, attempt {attempt}")
                    continue

                # Write the test file
                test_file_path = self._write_test_file(
                    project_dir=project_dir,
                    package_name=target.package_name,
                    class_name=target.class_name,
                    test_content=generated_code,
                    test_dir=project_info.test_dir,
                )

                # Try to compile
                compile_ok, compile_error = await maven.compile_only()
                if not compile_ok:
                    last_error = compile_error
                    logger.warning(f"Compilation failed for {target.class_name}, attempt {attempt}")
                    result.compilation_passed = False
                    continue

                result.compilation_passed = True

                # Try to run the specific test
                test_class_fqn = f"{target.package_name}.{target.class_name}GenTest"
                test_ok, test_stdout, test_stderr = await maven.run_specific_test(test_class_fqn)

                if test_ok:
                    result.success = True
                    result.tests_passed = True
                    result.generated_file_path = test_file_path
                    result.generated_content = generated_code
                    logger.info(f"Successfully generated tests for {target.class_name}")
                    return result
                else:
                    last_error = test_stderr[-2000:] if test_stderr else test_stdout[-2000:]
                    logger.warning(f"Tests failed for {target.class_name}, attempt {attempt}")
                    result.tests_passed = False

            except Exception as e:
                last_error = str(e)
                logger.error(f"Error generating tests for {target.class_name}: {e}")

        # All attempts exhausted
        result.error_message = f"Failed after {max_retries} attempts. Last error: {last_error[:500]}"
        logger.warning(f"Giving up on {target.class_name}: {result.error_message}")

        # Clean up the failed test file
        self._remove_test_file(project_dir, target.package_name,
                              target.class_name, project_info.test_dir)

        return result

    def _extract_java_code(self, content: str) -> Optional[str]:
        """Extract Java code from LLM response, handling markdown fences."""
        if not content:
            return None

        # Remove markdown code fences
        content = content.strip()
        if content.startswith("```java"):
            content = content[7:]
        elif content.startswith("```"):
            content = content[3:]
        if content.endswith("```"):
            content = content[:-3]
        content = content.strip()

        # Validate it looks like Java
        if "class " in content or "interface " in content:
            return content

        return None

    def _write_test_file(
        self, project_dir: str, package_name: str,
        class_name: str, test_content: str, test_dir: str,
    ) -> str:
        """Write the generated test file to the correct location."""
        package_path = package_name.replace(".", "/")
        test_file = Path(project_dir) / test_dir / package_path / f"{class_name}GenTest.java"
        test_file.parent.mkdir(parents=True, exist_ok=True)
        test_file.write_text(test_content, encoding="utf-8")
        logger.info(f"Wrote test file: {test_file}")
        return str(test_file)

    def _remove_test_file(
        self, project_dir: str, package_name: str,
        class_name: str, test_dir: str,
    ):
        """Remove a generated test file (cleanup on failure)."""
        package_path = package_name.replace(".", "/")
        test_file = Path(project_dir) / test_dir / package_path / f"{class_name}GenTest.java"
        if test_file.exists():
            test_file.unlink()
            logger.info(f"Removed failed test file: {test_file}")

    @staticmethod
    def _count_test_methods(content: str) -> int:
        """Count @Test methods in generated content."""
        return len(re.findall(r'@Test', content))

    @staticmethod
    def _is_skip_type(content: str) -> bool:
        """Check if the source is an interface, enum, or annotation."""
        # Simple heuristic - check for class declaration type
        if re.search(r'\binterface\s+\w+', content) and not re.search(r'\bclass\s+\w+', content):
            return True
        if re.search(r'\benum\s+\w+', content) and not re.search(r'\bclass\s+\w+', content):
            return True
        if re.search(r'\b@interface\s+\w+', content):
            return True
        return False

    @staticmethod
    def _matches_pattern(path: str, pattern: str) -> bool:
        """Simple glob-like pattern matching."""
        import fnmatch
        return fnmatch.fnmatch(path, pattern)
