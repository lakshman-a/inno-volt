"""
Maven Runner - Executes Maven builds, tests, and coverage with proper JDK management.
Handles JDK version detection and switching based on the project's requirements.
"""
import os
import asyncio
import shutil
from pathlib import Path
from typing import Optional, Dict, Tuple
from loguru import logger

from config.settings import settings


class MavenRunner:
    """Runs Maven commands with appropriate JDK version."""

    def __init__(self, project_root: str, java_version: str = "17"):
        self.root = Path(project_root)
        self.java_version = java_version
        self.java_home = self._resolve_java_home(java_version)
        self.maven_home = settings.java.maven_home
        self.build_timeout = settings.java.build_timeout_seconds
        self.test_timeout = settings.java.test_timeout_seconds

    def _resolve_java_home(self, version: str) -> str:
        """Find the appropriate JAVA_HOME for the requested version."""
        # Check configured paths
        jdk_path = settings.java.jdk_paths.get(version)
        if jdk_path and os.path.exists(jdk_path):
            return jdk_path

        # Check common system locations
        common_paths = [
            f"/usr/lib/jvm/java-{version}-openjdk-amd64",
            f"/usr/lib/jvm/java-{version}-openjdk",
            f"/usr/lib/jvm/temurin-{version}-jdk",
            f"/usr/lib/jvm/java-{version}",
        ]
        for path in common_paths:
            if os.path.exists(path):
                return path

        # Fallback to default
        logger.warning(f"JDK {version} not found, using default: {settings.java.default_java_home}")
        return settings.java.default_java_home

    def _get_env(self) -> Dict[str, str]:
        """Build environment variables for Maven execution."""
        env = os.environ.copy()
        env["JAVA_HOME"] = self.java_home
        env["PATH"] = f"{self.java_home}/bin:{env.get('PATH', '')}"
        env["MAVEN_OPTS"] = settings.java.maven_opts
        return env

    async def _run_command(self, cmd: str, timeout: int = 300) -> Tuple[int, str, str]:
        """Run a shell command asynchronously and capture output."""
        logger.info(f"Running: {cmd} (cwd={self.root}, JAVA_HOME={self.java_home})")

        try:
            process = await asyncio.create_subprocess_shell(
                cmd,
                cwd=str(self.root),
                env=self._get_env(),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=timeout
            )
            stdout_str = stdout.decode("utf-8", errors="replace")
            stderr_str = stderr.decode("utf-8", errors="replace")

            logger.debug(f"Command exit code: {process.returncode}")
            if process.returncode != 0:
                logger.warning(f"Command failed. stderr: {stderr_str[-500:]}")

            return process.returncode, stdout_str, stderr_str

        except asyncio.TimeoutError:
            logger.error(f"Command timed out after {timeout}s: {cmd}")
            if process:
                process.kill()
            return -1, "", f"Command timed out after {timeout}s"

    async def validate_build(self) -> Tuple[bool, str]:
        """
        Run mvn compile to validate the project builds.
        Returns (success, error_message).
        """
        logger.info("Validating project build...")
        code, stdout, stderr = await self._run_command(
            "mvn compile -q -DskipTests",
            timeout=self.build_timeout
        )
        if code == 0:
            logger.info("Build validation passed")
            return True, ""
        else:
            error = self._extract_build_error(stdout + stderr)
            return False, error

    async def run_tests(self) -> Tuple[bool, str, str]:
        """
        Run mvn test.
        Returns (success, stdout, stderr).
        """
        logger.info("Running tests...")
        code, stdout, stderr = await self._run_command(
            "mvn test -q",
            timeout=self.test_timeout
        )
        return code == 0, stdout, stderr

    async def run_tests_with_coverage(self) -> Tuple[bool, str]:
        """
        Run tests with JaCoCo coverage.
        Returns (success, path_to_jacoco_xml).
        """
        logger.info("Running tests with coverage...")

        # Run the full test + coverage lifecycle
        code, stdout, stderr = await self._run_command(
            "mvn clean test jacoco:report -q",
            timeout=self.test_timeout
        )

        if code != 0:
            logger.warning(f"Test run failed: {stderr[-500:]}")
            # Still check if coverage report was generated (some test failures are ok)

        # Find the JaCoCo XML report
        jacoco_xml = self._find_jacoco_report()
        if jacoco_xml:
            logger.info(f"Coverage report found: {jacoco_xml}")
            return True, str(jacoco_xml)
        else:
            logger.warning("No JaCoCo report found")
            return code == 0, ""

    async def run_specific_test(self, test_class: str) -> Tuple[bool, str, str]:
        """
        Run a specific test class.
        Returns (success, stdout, stderr).
        """
        logger.info(f"Running specific test: {test_class}")
        code, stdout, stderr = await self._run_command(
            f"mvn test -Dtest={test_class} -DfailIfNoTests=false -q",
            timeout=self.test_timeout
        )
        return code == 0, stdout, stderr

    async def compile_only(self) -> Tuple[bool, str]:
        """
        Just compile (including test sources) without running tests.
        Returns (success, error_message).
        """
        code, stdout, stderr = await self._run_command(
            "mvn test-compile -q -DskipTests",
            timeout=self.build_timeout
        )
        if code == 0:
            return True, ""
        return False, self._extract_build_error(stdout + stderr)

    def inject_jacoco_plugin(self, pom_path: Optional[str] = None):
        """
        Inject JaCoCo plugin into pom.xml if not already present.
        This ensures coverage works even for projects without JaCoCo configured.
        """
        pom_file = Path(pom_path) if pom_path else self.root / "pom.xml"
        content = pom_file.read_text(encoding="utf-8")

        if "jacoco-maven-plugin" in content:
            logger.info("JaCoCo already configured in pom.xml")
            return

        logger.info("Injecting JaCoCo plugin into pom.xml")

        jacoco_plugin = """
    <plugin>
        <groupId>org.jacoco</groupId>
        <artifactId>jacoco-maven-plugin</artifactId>
        <version>0.8.12</version>
        <executions>
            <execution>
                <goals>
                    <goal>prepare-agent</goal>
                </goals>
            </execution>
            <execution>
                <id>report</id>
                <phase>test</phase>
                <goals>
                    <goal>report</goal>
                </goals>
            </execution>
        </executions>
    </plugin>
"""
        # Find or create the build/plugins section
        if "<plugins>" in content:
            content = content.replace("<plugins>", f"<plugins>{jacoco_plugin}", 1)
        elif "<build>" in content:
            content = content.replace("<build>", f"<build>\n<plugins>{jacoco_plugin}</plugins>")
        else:
            # Insert before closing </project>
            content = content.replace(
                "</project>",
                f"<build><plugins>{jacoco_plugin}</plugins></build>\n</project>"
            )

        pom_file.write_text(content, encoding="utf-8")
        logger.info("JaCoCo plugin injected successfully")

    def _find_jacoco_report(self) -> Optional[Path]:
        """Find the JaCoCo XML report in the project."""
        candidates = list(self.root.rglob("jacoco.xml"))
        # Prefer target/site/jacoco/jacoco.xml
        for c in candidates:
            if "target" in str(c) and "site" in str(c):
                return c
        return candidates[0] if candidates else None

    def _extract_build_error(self, output: str) -> str:
        """Extract meaningful error from Maven build output."""
        lines = output.split("\n")
        error_lines = []
        capture = False
        for line in lines:
            if "[ERROR]" in line:
                capture = True
                error_lines.append(line.strip())
            elif capture and line.strip():
                error_lines.append(line.strip())
                if len(error_lines) > 20:
                    break

        return "\n".join(error_lines) if error_lines else output[-500:]
