"""
LLM Client - FMR GenAI Gateway Integration.

Handles:
1. OAuth2 token acquisition and caching (ESG OAuth endpoint)
2. Request building in FMR's custom promptSpec format
3. Response parsing from the generations[] format
4. Token tracking and cost estimation
5. Retry logic with exponential backoff

Gateway API Format:
  POST https://genaigateway-qa.fmr.com/llm-orchestrator/v2/generation/text

  Request: { promptSpec, model, gatewayParams }
  Response: { generations: [{ message: { content }, finishReason }], usage }
"""
import asyncio
import time
import uuid
from typing import Optional, Dict, List, Any, Tuple
from datetime import datetime, timedelta
from loguru import logger

import httpx

from config.settings import settings
from app.models.schemas import LLMCall


class TokenManager:
    """
    Manages OAuth2 Bearer token lifecycle.
    Acquires token via client_credentials grant and caches it.
    Auto-refreshes when expired.
    """

    def __init__(self):
        self._token: Optional[str] = None
        self._expires_at: Optional[datetime] = None

    async def get_token(self) -> str:
        """Get a valid Bearer token, refreshing if needed."""
        if self._token and self._expires_at and datetime.utcnow() < self._expires_at:
            return self._token

        logger.info("Acquiring new OAuth token...")
        token, expires_in = await self._acquire_token()
        self._token = token
        # Buffer: expire 5 minutes early to avoid edge-case expiry during a call
        self._expires_at = datetime.utcnow() + timedelta(seconds=expires_in - 300)
        logger.info(f"OAuth token acquired, expires in {expires_in}s")
        return self._token

    async def _acquire_token(self) -> Tuple[str, int]:
        """Call the ESG OAuth endpoint to get a Bearer token."""
        oauth = settings.oauth

        params = {
            "client_id": oauth.client_id,
            "client_secret": oauth.client_secret,
            "grant_type": oauth.grant_type,
            "scope": oauth.scope,
        }

        async with httpx.AsyncClient(timeout=30, verify=False) as client:
            response = await client.post(oauth.token_url, params=params)
            response.raise_for_status()
            data = response.json()

        access_token = data.get("access_token")
        expires_in = data.get("expires_in", 43201)

        if not access_token:
            raise RuntimeError(f"OAuth response missing access_token: {data}")

        return access_token, expires_in

    def invalidate(self):
        """Force token refresh on next call."""
        self._token = None
        self._expires_at = None


class LLMClient:
    """
    FMR GenAI Gateway client.

    Builds requests in the gateway's custom format:
    - promptSpec.contexts[] for instructions and grounding
    - promptSpec.messages[] for conversation history
    - model{} for provider/model selection
    - gatewayParams{} for gateway-level config

    Usage:
        response = await llm_client.generate(
            system_prompt="You are a Java test expert.",
            user_prompt="Generate tests for this class...",
            model_id="gpt-4o",
        )
        print(response["content"])
    """

    def __init__(self):
        self.gateway_url = settings.gateway.base_url
        self.timeout = settings.gateway.timeout_seconds
        self.max_retries = settings.gateway.max_retries
        self.token_manager = TokenManager()

        # Tracking
        self._call_history: List[LLMCall] = []
        self._total_tokens = 0
        self._total_cost = 0.0

    # ================================================================
    # Public API
    # ================================================================

    async def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        model_id: Optional[str] = None,
        grounding: Optional[str] = None,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Call the FMR GenAI Gateway and return generated content.

        Args:
            system_prompt: Main instruction for the model (role: instruction)
            user_prompt: The actual user query/task (added to messages)
            model_id: Model alias from registry (e.g., "gpt-4o", "claude-sonnet")
            grounding: Optional grounding/context content (role: grounding)
            conversation_history: Optional prior messages for multi-turn
            temperature: Override default temperature
            max_tokens: Override default max_tokens
            top_p: Override default top_p

        Returns:
            {
                "content": "generated text",
                "finish_reason": "stop",
                "tokens": {"prompt": N, "completion": N, "total": N},
                "cost": float,
                "call_id": str,
                "latency_ms": int,
                "model_used": str,
            }
        """
        call_id = str(uuid.uuid4())[:8]
        start_time = time.time()

        # Resolve model
        model_config = self._resolve_model(model_id)
        model_display = model_config["id"]

        # Build payload
        payload = self._build_payload(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            grounding=grounding,
            conversation_history=conversation_history,
            model_config=model_config,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
        )

        logger.info(
            f"LLM Call {call_id}: model={model_display}, "
            f"prompt_len={len(user_prompt)}, "
            f"system_len={len(system_prompt)}"
        )

        # Execute with retries
        last_error = None
        for attempt in range(1, self.max_retries + 1):
            try:
                # Get OAuth token
                bearer_token = await self.token_manager.get_token()

                headers = {
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {bearer_token}",
                }

                async with httpx.AsyncClient(
                    timeout=self.timeout, verify=False
                ) as client:
                    response = await client.post(
                        self.gateway_url,
                        headers=headers,
                        json=payload,
                    )

                    # Handle 401 - token expired mid-flight
                    if response.status_code == 401:
                        logger.warning(f"Call {call_id}: 401 - refreshing token")
                        self.token_manager.invalidate()
                        continue

                    response.raise_for_status()
                    response_data = response.json()

                # Parse response
                parsed = self._parse_response(response_data)
                latency_ms = int((time.time() - start_time) * 1000)

                # Track cost
                cost = self._estimate_cost(
                    model_display,
                    parsed["prompt_tokens"],
                    parsed["completion_tokens"],
                )

                # Record
                call_record = LLMCall(
                    call_id=call_id,
                    model=model_display,
                    prompt_tokens=parsed["prompt_tokens"],
                    completion_tokens=parsed["completion_tokens"],
                    total_tokens=parsed["total_tokens"],
                    latency_ms=latency_ms,
                    success=True,
                )
                self._call_history.append(call_record)
                self._total_tokens += parsed["total_tokens"]
                self._total_cost += cost

                logger.info(
                    f"LLM Call {call_id} OK: {parsed['total_tokens']} tokens, "
                    f"{latency_ms}ms, ${cost:.4f}, finish={parsed['finish_reason']}"
                )

                return {
                    "content": parsed["content"],
                    "finish_reason": parsed["finish_reason"],
                    "tokens": {
                        "prompt": parsed["prompt_tokens"],
                        "completion": parsed["completion_tokens"],
                        "total": parsed["total_tokens"],
                    },
                    "cost": cost,
                    "call_id": call_id,
                    "latency_ms": latency_ms,
                    "model_used": model_display,
                }

            except httpx.HTTPStatusError as e:
                last_error = e
                status = e.response.status_code
                logger.warning(
                    f"Call {call_id} attempt {attempt}: HTTP {status} - "
                    f"{e.response.text[:300]}"
                )
                if status == 429:
                    wait = min(2 ** attempt * 2, 30)
                    logger.info(f"Rate limited, waiting {wait}s...")
                    await asyncio.sleep(wait)
                elif status >= 500:
                    await asyncio.sleep(2)
                else:
                    break  # 4xx (non-401, non-429) don't retry

            except httpx.TimeoutException as e:
                last_error = e
                logger.warning(f"Call {call_id} attempt {attempt}: timeout after {self.timeout}s")
                await asyncio.sleep(1)

            except Exception as e:
                last_error = e
                logger.error(f"Call {call_id} attempt {attempt}: {type(e).__name__}: {e}")
                await asyncio.sleep(1)

        # All retries exhausted
        error_msg = f"LLM call {call_id} failed after {self.max_retries} attempts: {last_error}"
        logger.error(error_msg)
        self._call_history.append(
            LLMCall(call_id=call_id, model=model_display, success=False, error=error_msg)
        )
        raise RuntimeError(error_msg)

    # ================================================================
    # Payload Building (FMR Gateway Format)
    # ================================================================

    def _build_payload(
        self,
        system_prompt: str,
        user_prompt: str,
        grounding: Optional[str],
        conversation_history: Optional[List[Dict[str, str]]],
        model_config: Dict[str, str],
        temperature: Optional[float],
        max_tokens: Optional[int],
        top_p: Optional[float],
    ) -> Dict[str, Any]:
        """
        Build the FMR Gateway request payload.

        Structure:
        {
          "promptSpec": {
            "contexts": [
              { "role": "instruction", "content": "..." },   ← system prompt(s)
              { "role": "grounding", "content": "..." }      ← optional context
            ],
            "examples": [],                                   ← few-shot (optional)
            "messages": [
              { "role": "user", "content": "..." },
              { "role": "assistant", "content": "..." },
              ...
            ]
          },
          "model": {
            "provider": "Azure",
            "id": "gpt-4o",
            "version": "",
            "params": { "temperature": 0, "max_tokens": 4096, ... }
          },
          "gatewayParams": { "tokenTracking": "provided" }
        }
        """

        # --- Build contexts (instructions + grounding) ---
        contexts = [
            {
                "role": "instruction",
                "content": system_prompt,
            }
        ]

        if grounding:
            contexts.append({
                "role": "grounding",
                "content": grounding,
            })

        # --- Build messages ---
        messages = []

        # Add conversation history if provided (for multi-turn)
        if conversation_history:
            for msg in conversation_history:
                messages.append({
                    "role": msg.get("role", "user"),
                    "content": msg.get("content", ""),
                })

        # Add the current user prompt
        messages.append({
            "role": "user",
            "content": user_prompt,
        })

        # --- Build model config ---
        gw = settings.gateway
        model_section = {
            "provider": model_config.get("provider", gw.default_provider),
            "id": model_config.get("id", gw.default_model_id),
            "version": model_config.get("version", gw.default_model_version),
            "params": {
                "temperature": temperature if temperature is not None else gw.default_temperature,
                "max_tokens": max_tokens if max_tokens is not None else gw.default_max_tokens,
                "top_p": top_p if top_p is not None else gw.default_top_p,
                "timeout": self.timeout,
            }
        }

        # --- Assemble full payload ---
        payload = {
            "promptSpec": {
                "contexts": contexts,
                "examples": [],
                "messages": messages,
            },
            "model": model_section,
            "gatewayParams": {
                "tokenTracking": gw.token_tracking,
            }
        }

        return payload

    # ================================================================
    # Response Parsing (FMR Gateway Format)
    # ================================================================

    def _parse_response(self, response_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse the FMR Gateway response.

        Response format:
        {
          "generations": [
            {
              "index": 0,
              "message": { "role": "output", "content": "..." },
              "finishReason": "stop",
              "contentFilterResults": null
            }
          ],
          "usage": {
            "promptTokens": 93,
            "generatedTokens": 2,
            "totalTokens": 95
          }
        }
        """
        try:
            generations = response_json.get("generations", [])
            if not generations:
                raise ValueError("Empty generations array in response")

            first_gen = generations[0]
            message = first_gen.get("message", {})
            content = message.get("content", "")
            finish_reason = first_gen.get("finishReason", "unknown")

            usage = response_json.get("usage", {})
            prompt_tokens = usage.get("promptTokens", 0)
            completion_tokens = usage.get("generatedTokens", 0)
            total_tokens = usage.get("totalTokens", 0)

            # If totalTokens is 0 but we have the parts, calculate it
            if total_tokens == 0 and (prompt_tokens or completion_tokens):
                total_tokens = prompt_tokens + completion_tokens

            return {
                "content": content,
                "finish_reason": finish_reason,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": total_tokens,
            }

        except (KeyError, IndexError, TypeError) as e:
            logger.error(f"Failed to parse gateway response: {e}")
            logger.debug(f"Raw response: {response_json}")
            raise ValueError(f"Invalid gateway response format: {e}")

    # ================================================================
    # Model Resolution
    # ================================================================

    def _resolve_model(self, model_id: Optional[str] = None) -> Dict[str, str]:
        """
        Resolve a model alias to its gateway configuration.
        Falls back to default model if not found.
        """
        if not model_id:
            model_id = settings.gateway.default_model_id

        registry = settings.gateway.model_registry
        if model_id in registry:
            return registry[model_id]

        # If the model_id itself looks like a direct model name, use it with default provider
        logger.warning(f"Model '{model_id}' not in registry, using as direct ID")
        return {
            "provider": settings.gateway.default_provider,
            "id": model_id,
            "version": "",
        }

    # ================================================================
    # Cost Tracking
    # ================================================================

    def _estimate_cost(self, model_id: str, prompt_tokens: int, completion_tokens: int) -> float:
        """Estimate cost based on token usage and model rates."""
        rates = settings.gateway.cost_rates.get(model_id, {"input": 0.005, "output": 0.015})
        cost = (prompt_tokens / 1000 * rates["input"]) + (completion_tokens / 1000 * rates["output"])
        return round(cost, 6)

    def get_usage_summary(self) -> Dict[str, Any]:
        """Get cumulative usage statistics for the current session."""
        return {
            "total_calls": len(self._call_history),
            "successful_calls": sum(1 for c in self._call_history if c.success),
            "failed_calls": sum(1 for c in self._call_history if not c.success),
            "total_tokens": self._total_tokens,
            "total_cost": round(self._total_cost, 4),
            "call_history": [c.model_dump() for c in self._call_history[-20:]],
        }

    def reset_tracking(self):
        """Reset usage tracking between jobs."""
        self._call_history.clear()
        self._total_tokens = 0
        self._total_cost = 0.0


# Singleton
llm_client = LLMClient()
