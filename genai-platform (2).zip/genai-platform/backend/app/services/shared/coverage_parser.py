"""
JaCoCo Coverage Parser - Extracts detailed coverage metrics from JaCoCo XML reports.
Used by unit test generation to identify coverage gaps.
"""
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from lxml import etree
from loguru import logger

from app.models.schemas import CoverageData


class JacocoParser:
    """Parses JaCoCo XML coverage reports."""

    def __init__(self, report_path: str):
        self.report_path = Path(report_path)
        self._tree = None

    def parse(self) -> List[CoverageData]:
        """Parse the full JaCoCo report and return per-class coverage data."""
        if not self.report_path.exists():
            raise FileNotFoundError(f"JaCoCo report not found: {self.report_path}")

        self._tree = etree.parse(str(self.report_path))
        root = self._tree.getroot()

        coverage_list = []

        for package in root.findall(".//package"):
            package_name = package.get("name", "").replace("/", ".")

            for cls in package.findall("class"):
                class_name = cls.get("name", "").split("/")[-1]
                source_file = cls.get("sourcefilename", "")

                # Get counters
                counters = self._parse_counters(cls)

                line_cov = self._calc_coverage(
                    counters.get("LINE", {}).get("covered", 0),
                    counters.get("LINE", {}).get("missed", 0),
                )
                branch_cov = self._calc_coverage(
                    counters.get("BRANCH", {}).get("covered", 0),
                    counters.get("BRANCH", {}).get("missed", 0),
                )
                method_cov = self._calc_coverage(
                    counters.get("METHOD", {}).get("covered", 0),
                    counters.get("METHOD", {}).get("missed", 0),
                )

                total_lines = (
                    counters.get("LINE", {}).get("covered", 0) +
                    counters.get("LINE", {}).get("missed", 0)
                )
                covered_lines = counters.get("LINE", {}).get("covered", 0)

                # Find missed methods
                missed_methods = []
                for method in cls.findall("method"):
                    method_counters = self._parse_counters(method)
                    m_line = method_counters.get("LINE", {})
                    if m_line.get("covered", 0) == 0 and m_line.get("missed", 0) > 0:
                        method_name = method.get("name", "")
                        if method_name not in ("<init>", "<clinit>"):
                            missed_methods.append(method_name)

                coverage_list.append(CoverageData(
                    class_name=class_name,
                    package_name=package_name,
                    source_file=source_file,
                    line_coverage=line_cov,
                    branch_coverage=branch_cov,
                    method_coverage=method_cov,
                    missed_methods=missed_methods,
                    total_lines=total_lines,
                    covered_lines=covered_lines,
                ))

        logger.info(f"Parsed coverage for {len(coverage_list)} classes")
        return coverage_list

    def get_overall_coverage(self) -> Dict[str, float]:
        """Get the aggregate project coverage metrics."""
        if self._tree is None:
            self.parse()

        root = self._tree.getroot()
        counters = self._parse_counters(root)

        return {
            "line_coverage": self._calc_coverage(
                counters.get("LINE", {}).get("covered", 0),
                counters.get("LINE", {}).get("missed", 0),
            ),
            "branch_coverage": self._calc_coverage(
                counters.get("BRANCH", {}).get("covered", 0),
                counters.get("BRANCH", {}).get("missed", 0),
            ),
            "method_coverage": self._calc_coverage(
                counters.get("METHOD", {}).get("covered", 0),
                counters.get("METHOD", {}).get("missed", 0),
            ),
            "class_coverage": self._calc_coverage(
                counters.get("CLASS", {}).get("covered", 0),
                counters.get("CLASS", {}).get("missed", 0),
            ),
        }

    def get_uncovered_classes(self, threshold: float = 50.0) -> List[CoverageData]:
        """Get classes with coverage below threshold, sorted by priority."""
        all_coverage = self.parse()

        uncovered = [
            c for c in all_coverage
            if c.line_coverage < threshold and c.total_lines > 0
        ]

        # Sort: zero coverage first, then by most missed lines
        uncovered.sort(key=lambda c: (c.line_coverage, -c.total_lines))

        return uncovered

    def _parse_counters(self, element) -> Dict[str, Dict[str, int]]:
        """Parse counter elements from a JaCoCo XML node."""
        counters = {}
        for counter in element.findall("counter"):
            counter_type = counter.get("type", "")
            counters[counter_type] = {
                "missed": int(counter.get("missed", 0)),
                "covered": int(counter.get("covered", 0)),
            }
        return counters

    @staticmethod
    def _calc_coverage(covered: int, missed: int) -> float:
        """Calculate coverage percentage."""
        total = covered + missed
        if total == 0:
            return 100.0  # No code = fully covered
        return round((covered / total) * 100, 2)
