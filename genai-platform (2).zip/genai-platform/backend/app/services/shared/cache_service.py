"""
Cache Service - Simple in-memory TTL cache for repeated operations.
Useful for: project analysis results, LLM responses for same inputs, token caching.
"""
import time
import hashlib
from typing import Any, Optional, Dict
from loguru import logger


class CacheService:
    """Simple TTL cache with max size eviction."""

    def __init__(self, max_size: int = 200, default_ttl: int = 3600):
        self._store: Dict[str, Dict[str, Any]] = {}
        self.max_size = max_size
        self.default_ttl = default_ttl

    def get(self, key: str) -> Optional[Any]:
        entry = self._store.get(key)
        if entry and entry["expires_at"] > time.time():
            return entry["value"]
        if entry:
            del self._store[key]
        return None

    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        if len(self._store) >= self.max_size:
            self._evict_expired()
            if len(self._store) >= self.max_size:
                oldest = min(self._store, key=lambda k: self._store[k]["expires_at"])
                del self._store[oldest]
        self._store[key] = {"value": value, "expires_at": time.time() + (ttl or self.default_ttl)}

    def clear(self):
        self._store.clear()

    def _evict_expired(self):
        now = time.time()
        expired = [k for k, v in self._store.items() if v["expires_at"] <= now]
        for k in expired:
            del self._store[k]

    @staticmethod
    def make_key(*parts: str) -> str:
        combined = "|".join(str(p) for p in parts)
        return hashlib.md5(combined.encode()).hexdigest()[:16]


cache = CacheService()
