"""
Prompt Manager - Manages system prompts and user prompt templates.
Loads prompts from files so they can be version-controlled and updated
without code changes. Each solution has its own prompt directory.
"""
from pathlib import Path
from typing import Dict, Optional
from loguru import logger


class PromptManager:
    """Loads and templates prompts from the prompts directory."""

    def __init__(self, prompts_dir: str = "app/prompts"):
        self.base_dir = Path(prompts_dir)
        self._cache: Dict[str, str] = {}

    def get_prompt(self, solution: str, prompt_name: str) -> str:
        """
        Load a prompt template.
        Args:
            solution: e.g., "unit_test_gen"
            prompt_name: e.g., "system" or "generate_tests"
        """
        cache_key = f"{solution}/{prompt_name}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        prompt_path = self.base_dir / solution / f"{prompt_name}.txt"
        if not prompt_path.exists():
            logger.warning(f"Prompt file not found: {prompt_path}")
            return ""

        content = prompt_path.read_text(encoding="utf-8")
        self._cache[cache_key] = content
        return content

    def render_prompt(self, solution: str, prompt_name: str, **kwargs) -> str:
        """
        Load and render a prompt template with variables.
        Uses simple {variable_name} replacement.
        """
        template = self.get_prompt(solution, prompt_name)
        if not template:
            return ""

        try:
            return template.format(**kwargs)
        except KeyError as e:
            logger.error(f"Missing template variable in {solution}/{prompt_name}: {e}")
            # Return template with available substitutions
            for key, value in kwargs.items():
                template = template.replace(f"{{{key}}}", str(value))
            return template

    def clear_cache(self):
        """Clear the prompt cache (useful after updating prompts)."""
        self._cache.clear()


# Singleton instance
prompt_manager = PromptManager()
