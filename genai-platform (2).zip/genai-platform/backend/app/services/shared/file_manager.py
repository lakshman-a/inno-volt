"""
File Manager - Handles file I/O, zip operations, workspace management.
Used by all solutions for project extraction and output packaging.
"""
import os
import shutil
import zipfile
from pathlib import Path
from typing import Optional
from loguru import logger

from config.settings import settings


class FileManager:
    """Manages workspaces, file operations, and zip handling."""

    @staticmethod
    def create_workspace(job_id: str) -> Path:
        """Create an isolated workspace directory for a job."""
        workspace = settings.workspace_base / job_id
        workspace.mkdir(parents=True, exist_ok=True)

        # Sub-directories
        (workspace / "input").mkdir(exist_ok=True)
        (workspace / "output").mkdir(exist_ok=True)
        (workspace / "logs").mkdir(exist_ok=True)

        logger.info(f"Created workspace: {workspace}")
        return workspace

    @staticmethod
    def extract_zip(zip_path: str, dest_dir: str) -> str:
        """
        Extract a zip file and return the project root directory.
        Handles both flat zips and zips with a single root folder.
        """
        dest = Path(dest_dir)

        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(dest)

        # Detect if zip has a single wrapper directory
        items = list(dest.iterdir())

        # Filter out hidden/system files
        items = [i for i in items if not i.name.startswith('.') and i.name != '__MACOSX']

        if len(items) == 1 and items[0].is_dir():
            # Single folder wrapper - this is the project root
            project_root = items[0]
            logger.info(f"Extracted project root: {project_root.name}")
            return str(project_root)

        # Flat zip - dest_dir is the project root
        logger.info(f"Extracted flat zip to: {dest}")
        return str(dest)

    @staticmethod
    def package_output(project_dir: str, output_dir: str, job_id: str) -> str:
        """
        Package the project directory into a zip for download.
        Returns the path to the output zip.
        """
        output_path = Path(output_dir) / f"result_{job_id}.zip"

        with zipfile.ZipFile(str(output_path), 'w', zipfile.ZIP_DEFLATED) as zf:
            project = Path(project_dir)
            for file_path in project.rglob("*"):
                if file_path.is_file():
                    # Skip build artifacts to reduce zip size
                    rel_path = file_path.relative_to(project)
                    if any(part in str(rel_path) for part in [
                        "target/", ".idea/", ".git/", "node_modules/", ".class"
                    ]):
                        continue
                    zf.write(file_path, rel_path)

        logger.info(f"Packaged output: {output_path} ({output_path.stat().st_size / 1024:.1f} KB)")
        return str(output_path)

    @staticmethod
    def cleanup_workspace(job_id: str):
        """Remove a job's workspace."""
        workspace = settings.workspace_base / job_id
        if workspace.exists():
            shutil.rmtree(workspace, ignore_errors=True)
            logger.info(f"Cleaned up workspace: {workspace}")

    @staticmethod
    def save_upload(file_content: bytes, filename: str, job_id: str) -> str:
        """Save an uploaded file to the job's input directory."""
        workspace = settings.workspace_base / job_id / "input"
        workspace.mkdir(parents=True, exist_ok=True)
        file_path = workspace / filename
        file_path.write_bytes(file_content)
        logger.info(f"Saved upload: {file_path} ({len(file_content) / 1024:.1f} KB)")
        return str(file_path)
