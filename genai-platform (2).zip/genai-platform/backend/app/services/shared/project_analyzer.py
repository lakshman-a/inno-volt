"""
Project Analyzer - Understands the structure of uploaded projects.
Detects project type, Java version, test frameworks, module structure, etc.
This is used by all solutions to understand what they're working with.
"""
import os
import re
from pathlib import Path
from typing import Optional, List, Tuple
from lxml import etree
from loguru import logger

from app.models.schemas import ProjectInfo, ProjectType


class ProjectAnalyzer:
    """Analyzes a Java/Maven project structure."""

    def __init__(self, project_root: str):
        self.root = Path(project_root)
        self._pom_tree = None

    def analyze(self) -> ProjectInfo:
        """Run full project analysis and return ProjectInfo."""
        logger.info(f"Analyzing project at: {self.root}")

        pom_path = self._find_pom()
        if not pom_path:
            raise ValueError(f"No pom.xml found in {self.root}")

        self._pom_tree = self._parse_pom(pom_path)

        info = ProjectInfo(
            project_type=ProjectType.MAVEN,
            java_version=self._detect_java_version(),
            group_id=self._get_pom_value("groupId"),
            artifact_id=self._get_pom_value("artifactId"),
            modules=self._detect_modules(),
            test_framework=self._detect_test_framework(),
            mock_framework=self._detect_mock_framework(),
            has_jacoco=self._has_jacoco_plugin(),
            source_dir=self._detect_source_dir(),
            test_dir=self._detect_test_dir(),
            build_file_path=str(pom_path.relative_to(self.root)),
        )

        logger.info(f"Project analyzed: {info.artifact_id}, Java {info.java_version}, "
                     f"test={info.test_framework}, mock={info.mock_framework}, "
                     f"jacoco={info.has_jacoco}")
        return info

    def _find_pom(self) -> Optional[Path]:
        """Find the root pom.xml."""
        pom = self.root / "pom.xml"
        if pom.exists():
            return pom
        # Check one level deep (in case zip has a wrapper folder)
        for child in self.root.iterdir():
            if child.is_dir():
                child_pom = child / "pom.xml"
                if child_pom.exists():
                    return child_pom
        return None

    def _parse_pom(self, pom_path: Path) -> etree._Element:
        """Parse pom.xml with namespace handling."""
        tree = etree.parse(str(pom_path))
        return tree.getroot()

    def _ns(self, tag: str) -> str:
        """Add Maven namespace to tag."""
        return f"{{{self._get_namespace()}}}{tag}"

    def _get_namespace(self) -> str:
        """Get the Maven POM namespace."""
        if self._pom_tree is not None:
            ns = self._pom_tree.tag.split("}")[0].lstrip("{") if "}" in self._pom_tree.tag else ""
            return ns
        return "http://maven.apache.org/POM/4.0.0"

    def _get_pom_value(self, tag: str) -> Optional[str]:
        """Get a direct child value from the POM root."""
        ns = self._get_namespace()
        if ns:
            elem = self._pom_tree.find(f"{{{ns}}}{tag}")
        else:
            elem = self._pom_tree.find(tag)
        return elem.text if elem is not None else None

    def _detect_java_version(self) -> str:
        """Detect Java version from pom.xml properties."""
        ns = self._get_namespace()
        prefix = f"{{{ns}}}" if ns else ""

        # Check properties section
        properties = self._pom_tree.find(f"{prefix}properties")
        if properties is not None:
            # Common property names for Java version
            for prop_name in [
                "maven.compiler.source",
                "maven.compiler.target",
                "maven.compiler.release",
                "java.version",
                "java.source.version",
            ]:
                elem = properties.find(f"{prefix}{prop_name}")
                if elem is not None and elem.text:
                    return self._normalize_java_version(elem.text.strip())

        # Check compiler plugin configuration
        pom_text = etree.tostring(self._pom_tree, encoding="unicode")
        match = re.search(r"<source>(\d+\.?\d*)</source>", pom_text)
        if match:
            return self._normalize_java_version(match.group(1))

        match = re.search(r"<release>(\d+)</release>", pom_text)
        if match:
            return self._normalize_java_version(match.group(1))

        logger.warning("Could not detect Java version, defaulting to 17")
        return "17"

    def _normalize_java_version(self, version: str) -> str:
        """Normalize Java version string to major version number."""
        version = version.strip()
        if version.startswith("1."):
            return version.split(".")[1]  # 1.8 -> 8
        return version.split(".")[0]  # 17.0.1 -> 17

    def _detect_modules(self) -> List[str]:
        """Detect Maven modules in multi-module project."""
        ns = self._get_namespace()
        prefix = f"{{{ns}}}" if ns else ""
        modules_elem = self._pom_tree.find(f"{prefix}modules")
        if modules_elem is not None:
            return [m.text for m in modules_elem.findall(f"{prefix}module") if m.text]
        return []

    def _detect_test_framework(self) -> str:
        """Detect which test framework the project uses."""
        pom_text = etree.tostring(self._pom_tree, encoding="unicode").lower()

        if "junit-jupiter" in pom_text or "junit-bom" in pom_text:
            return "junit5"
        if "junit" in pom_text and "4." in pom_text:
            return "junit4"
        if "testng" in pom_text:
            return "testng"

        # Check for Spring Boot test starter (includes JUnit 5)
        if "spring-boot-starter-test" in pom_text:
            return "junit5"

        return "junit5"  # Default to JUnit 5

    def _detect_mock_framework(self) -> str:
        """Detect mocking framework."""
        pom_text = etree.tostring(self._pom_tree, encoding="unicode").lower()

        if "mockito" in pom_text:
            return "mockito"
        if "easymock" in pom_text:
            return "easymock"
        if "powermock" in pom_text:
            return "powermock"

        return "mockito"  # Default

    def _has_jacoco_plugin(self) -> bool:
        """Check if JaCoCo plugin is configured."""
        pom_text = etree.tostring(self._pom_tree, encoding="unicode").lower()
        return "jacoco-maven-plugin" in pom_text

    def _detect_source_dir(self) -> str:
        """Detect source directory."""
        for candidate in ["src/main/java", "src/main/kotlin"]:
            if (self.root / candidate).exists():
                return candidate
        return "src/main/java"

    def _detect_test_dir(self) -> str:
        """Detect test directory."""
        for candidate in ["src/test/java", "src/test/kotlin"]:
            if (self.root / candidate).exists():
                return candidate
        return "src/test/java"

    def get_all_source_files(self) -> List[Path]:
        """Get all Java source files in the project."""
        source_root = self.root / self._detect_source_dir()
        if not source_root.exists():
            return []
        return sorted(source_root.rglob("*.java"))

    def get_all_test_files(self) -> List[Path]:
        """Get all Java test files in the project."""
        test_root = self.root / self._detect_test_dir()
        if not test_root.exists():
            return []
        return sorted(test_root.rglob("*.java"))

    def read_file(self, file_path: Path) -> str:
        """Read a file's content."""
        return file_path.read_text(encoding="utf-8", errors="replace")

    def get_package_from_path(self, file_path: Path, base_dir: str) -> str:
        """Extract Java package from file path."""
        base = self.root / base_dir
        try:
            relative = file_path.relative_to(base)
            parts = list(relative.parts[:-1])  # Remove filename
            return ".".join(parts)
        except ValueError:
            return ""

    def find_test_for_source(self, source_path: Path) -> Optional[Path]:
        """Find the corresponding test file for a source file."""
        source_name = source_path.stem
        test_name = f"{source_name}Test.java"
        test_root = self.root / self._detect_test_dir()

        # Try same package structure
        source_base = self.root / self._detect_source_dir()
        try:
            relative = source_path.relative_to(source_base)
            test_path = test_root / relative.parent / test_name
            if test_path.exists():
                return test_path
        except ValueError:
            pass

        # Search by name
        matches = list(test_root.rglob(test_name))
        return matches[0] if matches else None

    def find_dependencies(self, source_path: Path, max_depth: int = 2) -> List[Path]:
        """
        Find imported dependencies for a source file.
        Looks at import statements and finds matching files in the project.
        """
        content = self.read_file(source_path)
        imports = re.findall(r'^import\s+([\w.]+);', content, re.MULTILINE)

        source_root = self.root / self._detect_source_dir()
        dep_files = []

        for imp in imports:
            # Skip standard library and third-party imports
            if imp.startswith(("java.", "javax.", "org.junit", "org.mockito",
                             "org.springframework", "org.apache", "org.slf4j",
                             "lombok", "com.fasterxml")):
                continue

            # Convert import to file path
            parts = imp.replace(".", "/")
            candidate = source_root / f"{parts}.java"
            if candidate.exists() and candidate != source_path:
                dep_files.append(candidate)

        return dep_files[:10]  # Limit to prevent context bloat
