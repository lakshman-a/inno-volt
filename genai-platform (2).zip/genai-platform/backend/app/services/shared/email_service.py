"""
Email Service - Sends job completion notifications.
Standalone module that can be invoked independently.
Configure SMTP settings in .env for your enterprise mail server.
"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional, List
from loguru import logger


class EmailService:
    """Sends email notifications for job events."""

    def __init__(
        self,
        smtp_host: str = "smtp.fmr.com",
        smtp_port: int = 25,
        from_address: str = "genai-platform@fmr.com",
        use_tls: bool = False,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.from_address = from_address
        self.use_tls = use_tls
        self.username = username
        self.password = password

    def send_job_completion(
        self,
        to_emails: List[str],
        job_id: str,
        solution_name: str,
        status: str,
        summary: dict,
    ) -> bool:
        """Send job completion notification email."""
        subject = f"[GenAI Platform] {solution_name} - Job {job_id} {status.upper()}"

        html_body = f"""
        <html>
        <body style="font-family: -apple-system, sans-serif; color: #1a1a2e; max-width: 600px;">
            <div style="background: #0B0F1A; color: #F1F5F9; padding: 20px 24px; border-radius: 12px 12px 0 0;">
                <h2 style="margin:0; color: #2DD4BF;">GenAI Platform</h2>
                <p style="margin:4px 0 0; color: #94A3B8; font-size: 13px;">{solution_name} — Job {job_id}</p>
            </div>
            <div style="background: #f8fafc; padding: 24px; border: 1px solid #e2e8f0; border-radius: 0 0 12px 12px;">
                <p style="font-size: 15px;">
                    <strong>Status:</strong>
                    <span style="color: {'#34D399' if status == 'completed' else '#F87171'};">
                        {status.upper()}
                    </span>
                </p>
                <table style="width:100%; border-collapse:collapse; margin: 16px 0;">
                    {''.join(f'<tr><td style="padding:6px 0; color:#64748B; font-size:13px;">{k}</td><td style="padding:6px 0; font-weight:600; font-size:13px;">{v}</td></tr>' for k, v in summary.items())}
                </table>
                <p style="font-size: 12px; color: #94A3B8; margin-top: 20px;">
                    This is an automated notification from the GenAI Platform.
                </p>
            </div>
        </body>
        </html>
        """

        return self._send(to_emails, subject, html_body)

    def send_report(
        self,
        to_emails: List[str],
        subject: str,
        report_html: str,
    ) -> bool:
        """Send a custom report email."""
        return self._send(to_emails, subject, report_html)

    def _send(self, to_emails: List[str], subject: str, html_body: str) -> bool:
        """Internal send method."""
        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = self.from_address
            msg["To"] = ", ".join(to_emails)
            msg.attach(MIMEText(html_body, "html"))

            with smtplib.SMTP(self.smtp_host, self.smtp_port, timeout=30) as server:
                if self.use_tls:
                    server.starttls()
                if self.username:
                    server.login(self.username, self.password or "")
                server.sendmail(self.from_address, to_emails, msg.as_string())

            logger.info(f"Email sent to {to_emails}: {subject}")
            return True

        except Exception as e:
            logger.error(f"Email send failed: {e}")
            return False


# Singleton (configure via env vars or direct init)
email_service = EmailService()
