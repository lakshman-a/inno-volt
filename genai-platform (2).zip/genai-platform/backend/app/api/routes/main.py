"""
API Routes - Handles all HTTP endpoints for the platform.
Solution-agnostic routing that delegates to the appropriate solution plugin.
"""
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from typing import Optional
from pathlib import Path
from loguru import logger

from app.core.job_manager import job_manager
from app.core.solution_registry import solution_registry
from app.models.schemas import (
    SolutionType, JobStatus, JobStatusResponse,
    SolutionListResponse, UnitTestGenConfig, ApiDocGenConfig,
)
from app.services.shared.file_manager import FileManager
from app.services.shared.llm_client import llm_client
from app.services.solutions.unit_test_gen.solution import UnitTestGenSolution
from app.services.solutions.api_doc_gen.solution import ApiDocGenSolution
from config.settings import settings

router = APIRouter()


# ============================================================
# Solution Discovery
# ============================================================

@router.get("/solutions", response_model=SolutionListResponse)
async def list_solutions():
    """List all available solutions with their metadata."""
    return SolutionListResponse(solutions=solution_registry.list_all())


# ============================================================
# Job Execution
# ============================================================

@router.post("/jobs/submit")
async def submit_job(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    solution_type: str = Form(...),
    model_id: Optional[str] = Form(None),
    config_json: Optional[str] = Form(None),
):
    """
    Submit a new solution job.
    Uploads a zip file and starts processing in the background.
    """
    # Validate solution type
    try:
        sol_type = SolutionType(solution_type)
    except ValueError:
        raise HTTPException(400, f"Invalid solution type: {solution_type}. "
                          f"Valid types: {[s.value for s in SolutionType]}")

    # Validate file
    if not file.filename.endswith(".zip"):
        raise HTTPException(400, "Please upload a .zip file")

    # Create job
    job = job_manager.create_job(sol_type)
    job.update(status=JobStatus.VALIDATING, phase="Receiving upload")

    try:
        # Save uploaded file
        file_content = await file.read()
        zip_path = FileManager.save_upload(file_content, file.filename, job.job_id)

        # Create workspace and extract
        workspace = FileManager.create_workspace(job.job_id)
        project_dir = FileManager.extract_zip(zip_path, str(workspace / "project"))

        job.workspace_path = str(workspace)

        # Parse solution-specific config
        import json
        sol_config = json.loads(config_json) if config_json else {}

        # Route to appropriate solution
        if sol_type == SolutionType.UNIT_TEST_GEN:
            config = UnitTestGenConfig(**sol_config)
            solution = UnitTestGenSolution(config=config)
            executor = solution.execute
        elif sol_type == SolutionType.API_DOC_GEN:
            config = ApiDocGenConfig(**sol_config)
            solution = ApiDocGenSolution(config=config)
            executor = solution.execute
        elif sol_type == SolutionType.FUNC_TEST_GEN:
            from app.services.solutions.func_test_gen.solution import FuncTestGenSolution
            solution = FuncTestGenSolution(config=sol_config)
            executor = solution.execute
        elif sol_type == SolutionType.SONAR_FIX:
            from app.services.solutions.sonar_fix.solution import SonarFixSolution
            solution = SonarFixSolution(config=sol_config)
            executor = solution.execute
        else:
            raise HTTPException(400, f"Solution {sol_type.value} not recognized")

        # Run in background
        async def run_solution(job_instance, **kwargs):
            result = await executor(job_instance, project_dir=project_dir, model_id=model_id)

            # Package output
            if result and not result.get("error"):
                output_zip = FileManager.package_output(
                    project_dir=project_dir,
                    output_dir=str(workspace / "output"),
                    job_id=job_instance.job_id,
                )
                result["output_zip_path"] = output_zip

            return result

        await job_manager.run_job(job, run_solution)

        return JSONResponse({
            "job_id": job.job_id,
            "status": job.status.value,
            "message": "Job submitted successfully. Use /jobs/{job_id}/status to track progress.",
        })

    except Exception as e:
        logger.exception(f"Failed to submit job: {e}")
        job.update(status=JobStatus.FAILED, message=str(e))
        raise HTTPException(500, f"Failed to process upload: {str(e)}")


# ============================================================
# Job Status & Results
# ============================================================

@router.get("/jobs/{job_id}/status", response_model=JobStatusResponse)
async def get_job_status(job_id: str):
    """Get the current status of a job."""
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(404, f"Job not found: {job_id}")
    return job.to_response()


@router.get("/jobs")
async def list_jobs(solution_type: Optional[str] = None):
    """List all jobs, optionally filtered by solution type."""
    sol_type = SolutionType(solution_type) if solution_type else None
    return job_manager.list_jobs(sol_type)


@router.get("/jobs/{job_id}/download")
async def download_result(job_id: str):
    """Download the output zip for a completed job."""
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(404, f"Job not found: {job_id}")

    if job.status not in (JobStatus.COMPLETED, JobStatus.PARTIALLY_COMPLETED):
        raise HTTPException(400, f"Job not ready. Status: {job.status.value}")

    if not job.result or not job.result.get("output_zip_path"):
        raise HTTPException(404, "No output file available")

    zip_path = job.result["output_zip_path"]
    if not Path(zip_path).exists():
        raise HTTPException(404, "Output file no longer available")

    return FileResponse(
        zip_path,
        media_type="application/zip",
        filename=f"genai_result_{job_id}.zip",
    )


# ============================================================
# Usage & Monitoring
# ============================================================

@router.get("/usage")
async def get_usage():
    """Get LLM usage statistics."""
    return llm_client.get_usage_summary()


# ============================================================
# Health Check
# ============================================================

@router.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "version": settings.app_version,
        "solutions": len(solution_registry.list_all()),
    }
