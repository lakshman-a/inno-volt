"""
Shared Pydantic models for API requests, responses, and internal data.
These models are solution-agnostic and used across the platform.
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime


# ============================================================
# Enums
# ============================================================

class SolutionType(str, Enum):
    """Available solutions on the platform."""
    UNIT_TEST_GEN = "unit_test_gen"
    API_DOC_GEN = "api_doc_gen"
    FUNC_TEST_GEN = "func_test_gen"
    SONAR_FIX = "sonar_fix"


class JobStatus(str, Enum):
    """Job lifecycle states."""
    PENDING = "pending"
    VALIDATING = "validating"
    ANALYZING = "analyzing"
    PROCESSING = "processing"
    GENERATING = "generating"
    VALIDATING_OUTPUT = "validating_output"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIALLY_COMPLETED = "partially_completed"


class ProjectType(str, Enum):
    """Supported project types."""
    MAVEN = "maven"
    GRADLE = "gradle"  # future


class InputMode(str, Enum):
    """How the project is provided."""
    ZIP_UPLOAD = "zip_upload"
    GIT_REPO = "git_repo"  # future


# ============================================================
# Request Models
# ============================================================

class JobRequest(BaseModel):
    """Base request to start a solution job."""
    solution_type: SolutionType
    model_id: Optional[str] = None  # Override default model
    input_mode: InputMode = InputMode.ZIP_UPLOAD

    # Git mode (future)
    git_url: Optional[str] = None
    git_branch: Optional[str] = None
    git_token: Optional[str] = None

    # Solution-specific config (passed to the solution plugin)
    solution_config: Dict[str, Any] = {}


class UnitTestGenConfig(BaseModel):
    """Configuration specific to unit test generation."""
    target_coverage_percent: float = 80.0
    max_classes_to_process: int = 50
    skip_patterns: List[str] = ["**/config/**", "**/model/**", "**/dto/**"]
    focus_packages: List[str] = []  # empty = all packages
    generate_for_zero_coverage_only: bool = False
    test_framework: Optional[str] = None  # auto-detect if None


class ApiDocGenConfig(BaseModel):
    """Configuration specific to API documentation generation."""
    doc_fields: List[Dict[str, str]] = []  # [{field_name, description, example}]
    template_path: Optional[str] = None
    output_format: str = "markdown"  # markdown, json, html
    include_request_examples: bool = True
    include_response_examples: bool = True


# ============================================================
# Internal Data Models
# ============================================================

class ProjectInfo(BaseModel):
    """Detected project metadata."""
    project_type: ProjectType
    java_version: Optional[str] = None
    group_id: Optional[str] = None
    artifact_id: Optional[str] = None
    modules: List[str] = []
    test_framework: str = "junit5"
    mock_framework: str = "mockito"
    has_jacoco: bool = False
    source_dir: str = "src/main/java"
    test_dir: str = "src/test/java"
    build_file_path: str = "pom.xml"


class CoverageData(BaseModel):
    """Coverage information for a single class."""
    class_name: str
    package_name: str
    source_file: str
    line_coverage: float = 0.0
    branch_coverage: float = 0.0
    method_coverage: float = 0.0
    missed_lines: List[int] = []
    missed_methods: List[str] = []
    total_lines: int = 0
    covered_lines: int = 0


class GenerationTarget(BaseModel):
    """A single target for code generation (e.g., a class needing tests)."""
    class_name: str
    package_name: str
    source_file_path: str
    source_content: str
    existing_test_path: Optional[str] = None
    existing_test_content: Optional[str] = None
    dependency_files: Dict[str, str] = {}  # filename -> content
    coverage: Optional[CoverageData] = None
    priority: int = 0


class GenerationResult(BaseModel):
    """Result of a single generation attempt."""
    target_class: str
    generated_file_path: Optional[str] = None
    generated_content: Optional[str] = None
    success: bool = False
    compilation_passed: bool = False
    tests_passed: bool = False
    error_message: Optional[str] = None
    attempts: int = 0
    tokens_used: int = 0
    cost_estimate: float = 0.0


class LLMCall(BaseModel):
    """Record of a single LLM API call for tracking."""
    call_id: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    latency_ms: int = 0
    success: bool = False
    error: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# Response Models
# ============================================================

class JobStatusResponse(BaseModel):
    """Response for job status check."""
    job_id: str
    status: JobStatus
    solution_type: SolutionType
    progress_percent: float = 0.0
    current_phase: str = ""
    message: str = ""
    created_at: datetime
    updated_at: datetime
    result: Optional[Dict[str, Any]] = None
    errors: List[str] = []


class UnitTestGenResult(BaseModel):
    """Final result of unit test generation."""
    baseline_coverage: float
    new_coverage: float
    coverage_delta: float
    classes_processed: int
    classes_succeeded: int
    classes_failed: int
    tests_generated: int
    test_methods_generated: int
    total_tokens_used: int
    total_llm_calls: int
    estimated_cost: float
    class_results: List[GenerationResult] = []
    output_zip_path: Optional[str] = None


class ApiDocGenResult(BaseModel):
    """Final result of API documentation generation."""
    endpoints_found: int
    endpoints_documented: int
    fields_populated: int
    total_fields: int
    total_tokens_used: int
    total_llm_calls: int
    estimated_cost: float
    output_path: Optional[str] = None


class FuncTestGenConfig(BaseModel):
    """Configuration for functional test generation."""
    test_framework: str = "karate"  # karate | cucumber_serenity
    generation_mode: str = "new_test_suite"  # new_test_suite | update_tests | find_gaps | coverage_analysis
    requirements: str = ""
    swagger_content: str = ""
    test_suite_dir: str = ""


class FuncTestGenResult(BaseModel):
    """Result of functional test generation."""
    test_framework: str
    generation_mode: str
    endpoints_found: int
    files_generated: int
    file_list: List[str] = []
    compilation_passed: bool = True
    total_tokens_used: int = 0
    total_llm_calls: int = 0
    estimated_cost: float = 0.0


class SonarFixConfig(BaseModel):
    """Configuration for sonar remediation."""
    sonar_url: str = ""
    sonar_token: str = ""
    sonar_project_key: str = ""
    fix_categories: List[str] = ["BUG", "VULNERABILITY", "CODE_SMELL"]
    max_issues_to_fix: int = 30


class SonarFixResult(BaseModel):
    """Result of sonar remediation."""
    issues_found: int
    issues_processed: int
    issues_fixed: int
    issues_failed: int
    files_modified: int
    final_build_passed: bool = False
    fix_categories: List[str] = []
    total_tokens_used: int = 0
    total_llm_calls: int = 0
    estimated_cost: float = 0.0
    file_results: List[Dict[str, Any]] = []


class SolutionListResponse(BaseModel):
    """Available solutions."""
    solutions: List[Dict[str, Any]]
