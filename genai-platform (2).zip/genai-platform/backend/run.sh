#!/bin/bash
# GenAI Platform - Backend Run Script
# Usage: ./run.sh [dev|prod]

set -e

MODE=${1:-dev}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Create workspace directories
mkdir -p /tmp/genai-workspace /tmp/genai-uploads /tmp/genai-outputs

# Load .env if exists
if [ -f .env ]; then
    echo "Loading .env file..."
    export $(cat .env | grep -v '^#' | xargs)
fi

if [ "$MODE" = "dev" ]; then
    echo "🚀 Starting GenAI Platform Backend (DEV mode)..."
    echo "   Docs: http://localhost:8000/docs"
    echo "   API:  http://localhost:8000/api/v1"
    python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
elif [ "$MODE" = "prod" ]; then
    echo "🚀 Starting GenAI Platform Backend (PROD mode)..."
    python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
fi
