"""
Application configuration - centralized settings for all solutions.
Configured for FMR GenAI Gateway API.
"""
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional, Dict
from pathlib import Path


class OAuthConfig(BaseSettings):
    """OAuth2 Token configuration for FMR ESG Gateway."""
    token_url: str = Field(
        default="https://esg-qa-oauth2-internal.fmr.com/as/resourceOwner",
        env="OAUTH_TOKEN_URL"
    )
    client_id: str = Field(default="", env="OAUTH_CLIENT_ID")
    client_secret: str = Field(default="", env="OAUTH_CLIENT_SECRET")
    grant_type: str = Field(default="client_credentials", env="OAUTH_GRANT_TYPE")
    scope: str = Field(default="AppIdClaimsTrust", env="OAUTH_SCOPE")
    # Token cache TTL slightly less than actual expiry (43201s ~ 12hrs)
    token_cache_ttl_seconds: int = Field(default=42000, env="OAUTH_CACHE_TTL")

    class Config:
        env_prefix = "OAUTH_"


class GatewayConfig(BaseSettings):
    """FMR GenAI Gateway API configuration."""
    base_url: str = Field(
        default="https://genaigateway-qa.fmr.com/llm-orchestrator/v2/generation/text",
        env="GATEWAY_BASE_URL"
    )
    timeout_seconds: int = Field(default=180, env="GATEWAY_TIMEOUT")
    max_retries: int = Field(default=3, env="GATEWAY_MAX_RETRIES")

    # Default model
    default_provider: str = Field(default="Azure", env="GATEWAY_DEFAULT_PROVIDER")
    default_model_id: str = Field(default="gpt-4o", env="GATEWAY_DEFAULT_MODEL")
    default_model_version: str = Field(default="", env="GATEWAY_DEFAULT_MODEL_VERSION")

    # Default generation params
    default_temperature: float = Field(default=0.0, env="GATEWAY_TEMPERATURE")
    default_max_tokens: int = Field(default=4096, env="GATEWAY_MAX_TOKENS")
    default_top_p: float = Field(default=1.0, env="GATEWAY_TOP_P")

    # Gateway params
    token_tracking: str = Field(default="provided", env="GATEWAY_TOKEN_TRACKING")

    # Model registry: friendly alias -> (provider, id, version)
    model_registry: Dict[str, Dict[str, str]] = {
        "gpt-4o": {"provider": "Azure", "id": "gpt-4o", "version": ""},
        "gpt-4o-mini": {"provider": "Azure", "id": "gpt-4o-mini", "version": ""},
        "claude-sonnet": {"provider": "AWS Bedrock", "id": "Claude", "version": "claude-sonnet-4-20250514"},
        "claude-opus": {"provider": "AWS Bedrock", "id": "Claude", "version": "claude-opus-4-20250514"},
        "gemini": {"provider": "GCP Vertex AI", "id": "Gemini", "version": ""},
    }

    # Cost per 1K tokens for tracking
    cost_rates: Dict[str, Dict[str, float]] = {
        "gpt-4o": {"input": 0.005, "output": 0.015},
        "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
        "Claude": {"input": 0.003, "output": 0.015},
        "Gemini": {"input": 0.00125, "output": 0.005},
    }

    class Config:
        env_prefix = "GATEWAY_"


class JavaConfig(BaseSettings):
    """Java/Maven build configuration."""
    default_java_home: str = Field(default="/usr/lib/jvm/java-21-openjdk-amd64", env="JAVA_DEFAULT_HOME")
    maven_home: str = Field(default="/usr/share/maven", env="MAVEN_HOME")
    maven_opts: str = Field(default="-Xmx1024m", env="MAVEN_OPTS")
    build_timeout_seconds: int = Field(default=300, env="BUILD_TIMEOUT")
    test_timeout_seconds: int = Field(default=600, env="TEST_TIMEOUT")

    jdk_paths: Dict[str, str] = {
        "8": "/usr/lib/jvm/java-8-openjdk-amd64",
        "11": "/usr/lib/jvm/java-11-openjdk-amd64",
        "17": "/usr/lib/jvm/java-17-openjdk-amd64",
        "21": "/usr/lib/jvm/java-21-openjdk-amd64",
    }

    class Config:
        env_prefix = "JAVA_"


class AppConfig(BaseSettings):
    """Main application configuration."""
    app_name: str = "GenAI Platform"
    app_version: str = "0.1.0"
    debug: bool = Field(default=True, env="DEBUG")

    workspace_base: Path = Field(default=Path("/tmp/genai-workspace"), env="WORKSPACE_BASE")
    upload_dir: Path = Field(default=Path("/tmp/genai-uploads"), env="UPLOAD_DIR")
    output_dir: Path = Field(default=Path("/tmp/genai-outputs"), env="OUTPUT_DIR")

    max_concurrent_jobs: int = Field(default=3, env="MAX_CONCURRENT_JOBS")
    job_timeout_seconds: int = Field(default=1800, env="JOB_TIMEOUT")
    max_llm_retries_per_class: int = 3
    max_classes_per_batch: int = 10

    cors_origins: list = ["http://localhost:4200", "http://localhost:3000"]

    oauth: OAuthConfig = OAuthConfig()
    gateway: GatewayConfig = GatewayConfig()
    java: JavaConfig = JavaConfig()

    class Config:
        env_prefix = "APP_"


settings = AppConfig()
