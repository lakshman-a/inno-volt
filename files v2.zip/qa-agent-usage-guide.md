# QA Automation Agent — Developer Quick Start Guide

## TL;DR — How to Use

1. Open Copilot Chat in your IDE
2. Select **"Senior QA Automation Engineer"** mode
3. Say **"hi"** or describe what you need
4. The agent handles everything else — it will guide you

That's it. The agent auto-detects your framework, scans existing tests, and walks you through a structured flow.

---

## What the Agent Does Automatically (You Don't Need To)

| What | How |
|------|-----|
| **Detect framework** | Reads your pom.xml for Cucumber+Serenity or Karate dependencies |
| **Scan existing tests** | Reads all feature files, step defs, test data already in your project |
| **Present options** | Shows you a menu of what you can do (create / enhance / update / fix / etc.) |
| **Collect inputs** | Asks structured questions based on your selection |
| **Choose the right patterns** | Automatically applies Cucumber or Karate best practices |
| **Design before coding** | Shows you a test plan for approval before writing any test code |
| **Generate complete suites** | Feature files, step defs, test data, schemas, config, runners |
| **Provide execution commands** | Exact Maven commands to run tests and view reports |

---

## The 7 Things You Can Ask It To Do

| # | Action | When to Use | What You Provide |
|---|--------|-------------|-----------------|
| **1** | Create New Test Suite | No tests exist for a feature | Swagger, code, requirements, or API description |
| **2** | Enhance Existing Tests | Tests exist but coverage is incomplete | Just say "enhance" — it auto-analyzes gaps |
| **3** | Update Tests for Changes | API changed, schema changed, new rules | Description of what changed |
| **4** | Single Endpoint Tests | Working on one specific endpoint/ticket | The endpoint details or code |
| **5** | Coverage Analysis | Want to see what's missing without generating code | Just say "analyze coverage" |
| **6** | Fix Failing Tests | Tests are broken | Error output or point to the failing test |
| **7** | Scaffold Framework | Starting from scratch, no test project exists | Framework choice + project details |

---

## Example Conversations

### Example 1: Starting Fresh
```
You: "I need to create API tests for our user management service"
Agent: [Auto-scans workspace, detects Karate, presents menu]
Agent: "What input do you have? A) Swagger, B) Code, C) Requirements..."
You: "B — look at the UserController"
Agent: [Reads controller, presents test plan with 45 scenarios]
You: "Approved"
Agent: [Generates all files]
```

### Example 2: Quick Single Endpoint
```
You: "Write tests for POST /api/v1/payments"
Agent: [Detects framework, asks for endpoint details or code reference]
You: "Here's the swagger section: [paste]"
Agent: [Generates focused test suite for that one endpoint]
```

### Example 3: Enhance Existing Suite
```
You: "Our tests are missing negative cases"
Agent: [Scans all existing tests, builds gap report]
Agent: "Found 15 gaps across 4 features. Here's the breakdown..."
You: "Fill all the gaps"
Agent: [Generates only the missing tests, matching existing patterns]
```

### Example 4: Fix Failures
```
You: "These tests are failing: [paste error]"
Agent: [Analyzes error, identifies root cause, fixes tests]
```

---

## Model Recommendation

The agent will recommend the best Claude model during initialization:

| Your Task | Recommended Model |
|-----------|-------------------|
| Quick tests for 1-3 endpoints | **Claude Sonnet 4** (fast) |
| Full suite for a microservice | **Claude Opus 4.5** (thorough) |
| Gap analysis on large suite | **Claude Opus 4.5** (deep reasoning) |
| Fix failing tests | **Claude Sonnet 4** (fast iteration) |

Switch models in: **Copilot Settings → Model Selector**

---

## What Makes This Agent Different

| Traditional Copilot | This QA Agent Mode |
|--------------------|-------------------|
| Generates code when you ask | Discovers → Plans → Gets approval → Then generates |
| May assume API behavior | Never assumes — asks or reads source of truth |
| Basic happy-path tests | Positive + Negative + Edge + Business rule coverage |
| Technical scenarios | Business-readable scenarios |
| Hardcoded values | Externalized config, test data, schemas |
| No logging | Comprehensive logging at every step |
| Flat output | Organized by feature, type, and priority with proper tags |
| May conflict with existing tests | Scans existing suite first, matches patterns |

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Agent doesn't detect my framework | Check that pom.xml is in workspace root. If it's in a subdirectory, tell the agent the path. |
| Agent generates wrong framework patterns | Explicitly say: "Use Karate" or "Use Cucumber+Serenity" |
| Agent skips negative cases | Say: "Include comprehensive negative and edge cases" |
| Tests don't match my project structure | Say: "@workspace scan src/test/ and match the existing test patterns" |
| Agent makes assumptions | Say: "Don't assume anything. Ask me for any missing information." |
| Generated tests won't compile | Share the error — the agent will diagnose and fix |

---

## Feedback

Help us improve the agent! After using it, note:
- Did the generated tests pass on first run?
- Were any scenarios missing or incorrect?
- Was the test plan accurate before generation?
- Did the agent match your project's existing patterns?

Share feedback with the QA Platform team to refine the agent's instructions.
