# GitHub Copilot — Global Project Instructions

## Project Context
This workspace uses GitHub Copilot with custom QA Agent Mode for API functional test automation.

## Auto-Detection Rules (Applied to All Modes)

### Framework Detection (Automatic)
When any test-related request is made, Copilot must auto-detect the framework:

1. **Check pom.xml** in workspace root and submodules:
   - If `serenity-cucumber` or `serenity-rest-assured` dependency found → **Cucumber + Serenity BDD**
   - If `karate-junit5` or `karate-core` dependency found → **Karate DSL**
   - If both found → ask user which to target
   - If neither found → ask user which to set up, offer to scaffold

2. **Check existing test files**:
   - `.feature` files with `Given/When/Then` + Java step defs → Cucumber
   - `.feature` files with `* def`, `* url`, `match` → Karate
   - Both patterns → ask user

3. **Check directory structure**:
   - `stepdefinitions/` or `steps/` folders → Cucumber
   - `karate-config.js` present → Karate

### Existing Test Suite Detection (Automatic)
Before ANY test generation, always:
1. Scan `src/test/` recursively for existing `.feature` files
2. Scan for existing step definitions (`.java` files in step packages)
3. Scan for existing test data files (`src/test/resources/testdata/`)
4. Scan for existing schemas (`src/test/resources/schemas/`)
5. Scan for existing runners
6. Build an internal map of what is already covered

### Never Hallucinate or Assume
- NEVER generate test cases based on assumptions about API behavior
- NEVER invent endpoints, schemas, or business rules
- If input is ambiguous or incomplete, ASK for clarification
- If you cannot determine expected behavior, say so explicitly
