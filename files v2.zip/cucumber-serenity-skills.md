# Cucumber + Serenity BDD — Framework Skills (Auto-Loaded)

> **This file is automatically loaded by the QA Agent when Cucumber+Serenity is detected.**
> **Developers do not need to reference this file directly.**

---

## 1. Project Structure Standard

When generating Cucumber+Serenity tests, ALWAYS use this structure:

```
src/test/
├── java/com/{org}/{project}/
│   ├── runners/
│   │   ├── TestSuiteRunner.java              # Full regression
│   │   ├── SmokeTestRunner.java              # @smoke tagged tests
│   │   └── {Feature}Runner.java              # Per-feature runners
│   ├── stepdefinitions/
│   │   ├── common/
│   │   │   ├── CommonApiSteps.java           # Reusable: status checks, header checks
│   │   │   ├── AuthenticationSteps.java      # Auth-related steps
│   │   │   └── ValidationSteps.java          # Schema validation, field checks
│   │   ├── {feature}/
│   │   │   └── {Feature}Steps.java           # Feature-specific steps
│   │   └── Hooks.java                        # @Before/@After hooks
│   ├── models/
│   │   ├── request/{Entity}Request.java      # Request POJOs with Builder pattern
│   │   └── response/{Entity}Response.java    # Response POJOs
│   ├── utils/
│   │   ├── ApiClient.java                    # Centralized REST client wrapper
│   │   ├── TestDataBuilder.java              # Fluent test data factory
│   │   ├── ConfigManager.java                # Environment config reader
│   │   ├── JsonHelper.java                   # JSON read/write/compare utilities
│   │   └── TestContext.java                  # Shared state (PicoContainer injected)
│   └── constants/
│       ├── Endpoints.java                    # API path constants
│       └── ErrorMessages.java               # Expected error message constants
└── resources/
    ├── features/
    │   ├── {feature}/
    │   │   ├── {feature}_positive.feature
    │   │   ├── {feature}_negative.feature
    │   │   └── {feature}_edge_cases.feature
    │   └── smoke/
    │       └── smoke_tests.feature
    ├── testdata/{feature}/
    │   ├── valid_requests.json
    │   ├── invalid_requests.json
    │   └── boundary_data.json
    ├── schemas/{feature}/
    │   ├── success_response.json
    │   └── error_response.json
    ├── environments/
    │   ├── dev.properties
    │   ├── qa.properties
    │   └── staging.properties
    ├── serenity.conf
    └── logback-test.xml
```

**Adaptation Rule:** If the existing project has a different structure, MATCH the existing structure. Only use this standard for new projects or when no tests exist yet.

---

## 2. POM Dependencies Template

```xml
<properties>
    <java.version>11</java.version>
    <serenity.version>4.1.4</serenity.version>
    <cucumber.version>7.15.0</cucumber.version>
    <restassured.version>5.4.0</restassured.version>
    <allure.version>2.25.0</allure.version>
    <assertj.version>3.25.1</assertj.version>
    <jackson.version>2.16.1</jackson.version>
    <maven.compiler.source>${java.version}</maven.compiler.source>
    <maven.compiler.target>${java.version}</maven.compiler.target>
</properties>

<dependencies>
    <!-- Serenity BDD Core + Cucumber + REST -->
    <dependency>
        <groupId>net.serenity-bdd</groupId>
        <artifactId>serenity-core</artifactId>
        <version>${serenity.version}</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>net.serenity-bdd</groupId>
        <artifactId>serenity-cucumber</artifactId>
        <version>${serenity.version}</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>net.serenity-bdd</groupId>
        <artifactId>serenity-rest-assured</artifactId>
        <version>${serenity.version}</version>
        <scope>test</scope>
    </dependency>

    <!-- Cucumber -->
    <dependency>
        <groupId>io.cucumber</groupId>
        <artifactId>cucumber-java</artifactId>
        <version>${cucumber.version}</version>
        <scope>test</scope>
    </dependency>

    <!-- Reporting: Allure (Optional but Recommended) -->
    <dependency>
        <groupId>io.qameta.allure</groupId>
        <artifactId>allure-cucumber7-jvm</artifactId>
        <version>${allure.version}</version>
        <scope>test</scope>
    </dependency>

    <!-- Assertions -->
    <dependency>
        <groupId>org.assertj</groupId>
        <artifactId>assertj-core</artifactId>
        <version>${assertj.version}</version>
        <scope>test</scope>
    </dependency>

    <!-- JSON Processing -->
    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-databind</artifactId>
        <version>${jackson.version}</version>
        <scope>test</scope>
    </dependency>

    <!-- Test Data Generation -->
    <dependency>
        <groupId>com.github.javafaker</groupId>
        <artifactId>javafaker</artifactId>
        <version>1.0.2</version>
        <scope>test</scope>
    </dependency>

    <!-- Logging -->
    <dependency>
        <groupId>org.slf4j</groupId>
        <artifactId>slf4j-api</artifactId>
        <version>2.0.11</version>
        <scope>test</scope>
    </dependency>
</dependencies>

<build>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-surefire-plugin</artifactId>
            <version>3.2.3</version>
            <configuration>
                <skip>true</skip>
            </configuration>
        </plugin>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-failsafe-plugin</artifactId>
            <version>3.2.3</version>
            <configuration>
                <includes>
                    <include>**/*Runner.java</include>
                </includes>
                <systemPropertyVariables>
                    <environment>${env}</environment>
                </systemPropertyVariables>
            </configuration>
            <executions>
                <execution>
                    <goals>
                        <goal>integration-test</goal>
                        <goal>verify</goal>
                    </goals>
                </execution>
            </executions>
        </plugin>
        <plugin>
            <groupId>net.serenity-bdd.maven.plugins</groupId>
            <artifactId>serenity-maven-plugin</artifactId>
            <version>${serenity.version}</version>
            <executions>
                <execution>
                    <id>serenity-reports</id>
                    <phase>post-integration-test</phase>
                    <goals>
                        <goal>aggregate</goal>
                    </goals>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```

---

## 3. Feature File Standards

### File Naming
- `{feature_name}_positive.feature` — Happy path and valid cases
- `{feature_name}_negative.feature` — Error handling and invalid input cases
- `{feature_name}_edge_cases.feature` — Boundary, special character, concurrency cases
- `{feature_name}_business_rules.feature` — Business logic specific cases (if substantial)

### Mandatory Tags
```gherkin
@{feature-name} @api @{test-type} @{suite} @{severity}
```

### Scenario Writing Pattern
```gherkin
@customer-management @api @positive @regression @severity-critical @jira-PROJ-101
Scenario: Successfully create a new customer with all required information
  # CONTEXT: Set up the preconditions
  Given the customer management API is available
  And I am authenticated as a user with "ADMIN" role

  # DATA: Prepare the request
  And I prepare a new customer request with the following details
    | firstName | lastName | email                | phone        |
    | John      | Smith    | john.smith@email.com | 555-123-4567 |

  # ACTION: Execute the API call
  When I send the create customer request

  # VERIFICATION: Validate the response
  Then the response status should be 201 Created
  And the response should contain the customer details matching my request
  And the customer should have a system-generated unique ID
  And the response should include creation and update timestamps
  And the response Location header should contain the customer resource URL
```

### Data Table Format
Always use readable data tables with business-meaningful column headers:
```gherkin
# GOOD — Business terms
| Customer Name | Email Address       | Contact Number |
| John Smith    | john@example.com    | 555-123-4567   |

# BAD — Technical terms
| firstName | email            | phone       |
| John      | john@example.com | 5551234567  |
```

---

## 4. Step Definition Patterns

### Mandatory Structure Per Step
```java
@Given("description")
@Step("Serenity step description for reports")
public void stepMethod() {
    LOG.info("STEP START: [description of what this step does]");

    // ... implementation ...

    LOG.info("STEP COMPLETE: [result summary]");
}
```

### Assertion Standard — AssertJ Only
```java
// ALWAYS use descriptive .as() messages
assertThat(response.getStatusCode())
    .as("API should return 201 Created for successful customer creation")
    .isEqualTo(201);

assertThat(response.jsonPath().getString("id"))
    .as("Customer ID should be a valid UUID format")
    .matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
```

### TestContext Pattern (Sharing State Between Steps)
```java
public class TestContext {
    private String baseUrl;
    private String authToken;
    private RequestSpecification currentRequest;
    private Response lastResponse;
    private Map<String, Object> scenarioData = new HashMap<>();

    // Inject via PicoContainer — Cucumber instantiates one per scenario
    // All step definition classes receive the SAME TestContext instance
}
```

---

## 5. Configuration (serenity.conf)

```hocon
serenity {
    project.name = "API Functional Tests"
    test.root = "com.org.project"
    take.screenshots = FOR_FAILURES
    logging = VERBOSE
}

environments {
    default {
        base.url = "http://localhost:8080"
        auth.url = "http://localhost:8080/auth"
        api.timeout = 30000
    }
    dev {
        base.url = "https://dev-api.example.com"
        auth.url = "https://dev-auth.example.com"
    }
    qa {
        base.url = "https://qa-api.example.com"
        auth.url = "https://qa-auth.example.com"
        api.timeout = 45000
    }
    staging {
        base.url = "https://staging-api.example.com"
        auth.url = "https://staging-auth.example.com"
        api.timeout = 60000
    }
}
```

---

## 6. Execution Commands

```bash
# Full regression in QA environment
mvn clean verify -Denvironment=qa

# Smoke tests only
mvn clean verify -Dcucumber.filter.tags="@smoke" -Denvironment=qa

# Specific feature
mvn clean verify -Dcucumber.filter.tags="@customer-management" -Denvironment=qa

# By priority
mvn clean verify -Dcucumber.filter.tags="@severity-critical or @severity-high" -Denvironment=qa

# Generate reports
mvn serenity:aggregate
# Report at: target/site/serenity/index.html
```

---

## 7. Runner Template

```java
@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("features")
@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME, value = "io.cucumber.core.plugin.SerenityReporterParallelPlugin")
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "com.org.project.stepdefinitions")
@ConfigurationParameter(key = FILTER_TAGS_PROPERTY_NAME, value = "@regression and not @wip")
public class RegressionTestRunner {
}
```
