# QA Test Design Methodology — Skills (Auto-Loaded)

> **This file is automatically loaded by the QA Agent for every test generation request.**
> **Developers do not need to reference this file directly.**

---

## 1. Input Analysis Framework

### From Swagger/OpenAPI Spec
Extract and catalog:
- ALL endpoints: method + path + summary
- Request schemas: required fields, optional fields, data types, constraints (minLength, maxLength, pattern, enum, min, max, format)
- Response schemas: 2xx success bodies, 4xx/5xx error bodies, response headers
- Authentication: security schemes
- Path/query parameters: required, optional, defaults
- Content types: JSON, XML, multipart

### From Java Codebase
Extract and catalog:
- Controller annotations: `@GetMapping`, `@PostMapping`, `@PutMapping`, `@DeleteMapping`, `@PatchMapping`
- DTO validation: `@NotNull`, `@NotBlank`, `@Size`, `@Pattern`, `@Min`, `@Max`, `@Email`, `@Valid`, `@Future`, `@Past`
- Service layer: business logic, conditional flows, exceptions thrown
- Exception handlers: `@ControllerAdvice`, response structures for errors
- Security: `@PreAuthorize`, `@Secured`, role-based access
- Entity relationships: cascading, constraints, unique indexes

### From Requirements/Jira
Extract and catalog:
- Each acceptance criterion → 1+ test scenarios
- Business rules (explicit and implied)
- User roles and permissions
- Data constraints and valid ranges
- Error scenarios mentioned
- Preconditions and dependencies

---

## 2. Coverage Matrix Template

**The agent MUST build this matrix for every feature before generating tests:**

```
┌─────────────────────────┬──────────┬──────────┬───────────┬──────────┬───────┐
│ Endpoint / Functionality│ Positive │ Negative │ Edge Case │ Business │ Total │
├─────────────────────────┼──────────┼──────────┼───────────┼──────────┼───────┤
│ POST /customers         │    3     │    6     │    4      │    2     │  15   │
│ GET /customers/{id}     │    2     │    3     │    2      │    1     │   8   │
│ GET /customers (list)   │    3     │    2     │    3      │    1     │   9   │
│ PUT /customers/{id}     │    3     │    5     │    3      │    3     │  14   │
│ DELETE /customers/{id}  │    1     │    3     │    2      │    2     │   8   │
├─────────────────────────┼──────────┼──────────┼───────────┼──────────┼───────┤
│ TOTALS                  │   12     │   19     │   14      │    9     │  54   │
└─────────────────────────┴──────────┴──────────┴───────────┴──────────┴───────┘
```

---

## 3. Systematic Scenario Design — CRUD Pattern

### CREATE (POST)

**Positive Scenarios (Minimum 3):**
| # | Scenario | Priority |
|---|----------|----------|
| P1 | All required fields with valid data → 201 | Critical |
| P2 | All fields (required + optional) with valid data → 201 | High |
| P3 | Multiple valid data combinations via Scenario Outline → 201 | High |
| P4 | Create with minimum valid values for all fields → 201 | Medium |
| P5 | Create with maximum valid values for all fields → 201 | Medium |

**Negative Scenarios (Minimum 5):**
| # | Scenario | Priority |
|---|----------|----------|
| N1 | Missing each required field (one per example row) → 400 | Critical |
| N2 | Invalid data type for each field (string where int expected, etc.) → 400 | High |
| N3 | Invalid format (bad email, bad phone, bad date) → 400 | High |
| N4 | Value exceeds max length/size → 400 | High |
| N5 | Duplicate unique field (e.g., email already exists) → 409 | High |
| N6 | No authentication → 401 | Critical |
| N7 | Invalid/expired authentication → 401 | High |
| N8 | Insufficient permissions (wrong role) → 403 | High |
| N9 | Malformed request body (invalid JSON) → 400 | Medium |

**Edge Cases (Minimum 3):**
| # | Scenario | Priority |
|---|----------|----------|
| E1 | Boundary values: min, min+1, max-1, max for numeric fields | High |
| E2 | Special characters in strings (O'Brien, unicode, emojis) | Medium |
| E3 | Empty string vs null vs missing key distinction | Medium |
| E4 | Very large payload (many optional fields filled) | Low |
| E5 | Concurrent creation with same unique value → 409 | Medium |
| E6 | Request with extra unknown fields (should ignore or reject?) | Low |

**Business Rule Scenarios:**
| # | Scenario | Priority |
|---|----------|----------|
| B1 | Cross-field validation (endDate must be after startDate) | High |
| B2 | Computed field validation (totalPrice = quantity × unitPrice) | High |
| B3 | State-dependent creation (can only create if parent exists) | Medium |
| B4 | Business constraint (discount cannot exceed 100%) | Medium |

### READ Single (GET /{id})

**Positive:**
| P1 | Retrieve existing resource → 200 with full body | Critical |
| P2 | Verify all fields match what was created | High |

**Negative:**
| N1 | Non-existent ID (valid format) → 404 | Critical |
| N2 | Invalid ID format → 400 | High |
| N3 | No authentication → 401 | Critical |
| N4 | Access another user's resource (if ownership matters) → 403 | High |

**Edge:**
| E1 | Retrieve immediately after creation (consistency) | Medium |
| E2 | Retrieve after update (verify latest data) | Medium |

### READ List (GET with query params)

**Positive:**
| P1 | List with default pagination → 200 | Critical |
| P2 | List with custom page and size → 200 | High |
| P3 | Filter by each filterable field → correct results | High |
| P4 | Sort by each sortable field (asc and desc) → correct order | Medium |

**Negative:**
| N1 | Invalid page/size (negative, zero, non-numeric) → 400 | Medium |
| N2 | Invalid filter value → 400 or empty results | Medium |

**Edge:**
| E1 | Empty result set (no matching data) → 200 with empty array | High |
| E2 | Exactly one result → 200 with array of 1 | Medium |
| E3 | Page beyond available data → 200 with empty array | Medium |
| E4 | Very large page size → capped or rejected | Low |

### UPDATE (PUT/PATCH)

**Positive:**
| P1 | Full update with all fields → 200 | Critical |
| P2 | Partial update single field (PATCH) → 200 | High |
| P3 | Update multiple fields → 200 | High |

**Negative:**
| N1 | Update read-only field (ID, createdAt) → 400 or ignored | High |
| N2 | Update with invalid values → 400 (same as CREATE negatives) | High |
| N3 | Update non-existent resource → 404 | High |
| N4 | Update without auth / wrong auth → 401/403 | Critical |
| N5 | Optimistic locking conflict (if applicable) → 409 | Medium |

**Edge:**
| E1 | Update with identical values (idempotency) → 200 | Medium |
| E2 | Update to boundary values → 200 or 400 | Medium |
| E3 | Concurrent updates to same resource | Low |

**Business:**
| B1 | State-dependent update (cannot update if status is CLOSED) | High |
| B2 | Cascading effects (updating parent affects children) | Medium |

### DELETE

**Positive:**
| P1 | Delete existing resource → 204 (or 200) | Critical |
| P2 | Verify resource gone after delete (GET → 404) | Critical |

**Negative:**
| N1 | Delete non-existent resource → 404 | High |
| N2 | Delete without auth / wrong auth → 401/403 | Critical |
| N3 | Delete protected resource (has dependencies) → 409 | High |

**Edge:**
| E1 | Double delete (idempotency) → 404 on second | Medium |
| E2 | Delete then recreate with same data | Low |

**Business:**
| B1 | Soft delete verification (is data really gone or just flagged?) | High |
| B2 | Cascading delete effects | Medium |

---

## 4. Authentication & Authorization Matrix

| # | Scenario | Expected | Priority |
|---|----------|----------|----------|
| A1 | Valid credentials → successful auth | 200 + token | Critical |
| A2 | Valid token → authorized access | 200 | Critical |
| A3 | No token → rejected | 401 | Critical |
| A4 | Expired token → rejected | 401 | High |
| A5 | Malformed token (random string) → rejected | 401 | High |
| A6 | Token for wrong API / audience → rejected | 401 | Medium |
| A7 | Correct role → access granted | 200 | High |
| A8 | Wrong role → access denied | 403 | High |
| A9 | Token with modified payload (tampered) → rejected | 401 | Medium |

---

## 5. Test Data Design Rules

### Rule 1: External Files Only
```
NEVER:  * def data = { "firstName": "John", "lastName": "Smith" }
ALWAYS: * def data = read('classpath:testdata/customer/valid_customer.json')
```
Exception: Inline data is OK for Scenario Outline examples where data varies per row.

### Rule 2: Realistic and Self-Documenting
```json
// GOOD
{
  "firstName": "John",
  "lastName": "Smith",
  "email": "john.smith@example.com",
  "phone": "+1-555-123-4567",
  "dateOfBirth": "1990-05-15"
}

// BAD
{
  "firstName": "test",
  "lastName": "test",
  "email": "test@test.com",
  "phone": "1234567890",
  "dateOfBirth": "2000-01-01"
}
```

### Rule 3: Boundary Data Template
```json
{
  "_description": "Boundary test data for customer fields",
  "firstName": {
    "valid_min": "A",
    "valid_max": "ABCDEFGHIJ...exactly50chars",
    "invalid_below_min": "",
    "invalid_above_max": "ABCDEFGHIJ...51chars",
    "special_chars": "O'Brien-Smith",
    "unicode": "田中太郎",
    "with_spaces": "Mary Jane"
  },
  "age": {
    "valid_min": 18,
    "valid_max": 120,
    "invalid_below_min": 17,
    "invalid_above_max": 121,
    "boundary_min_minus_1": 17,
    "boundary_min": 18,
    "boundary_min_plus_1": 19,
    "boundary_max_minus_1": 119,
    "boundary_max": 120,
    "boundary_max_plus_1": 121
  }
}
```

### Rule 4: Independent Test Data
Each scenario creates its own data or uses its own unique slice. No scenario depends on another scenario's data.

### Rule 5: Cleanup
If a test creates data, it should tag for cleanup or include cleanup steps. Use `@After` hooks (Cucumber) or `karate.call('cleanup.feature')` (Karate).

---

## 6. Response Validation Checklist

For EVERY API response, the agent validates:

**Status Code:**
- [ ] Correct HTTP status code

**Headers:**
- [ ] Content-Type is correct
- [ ] Custom headers present (Location, X-Request-Id, etc.)
- [ ] Cache headers correct (if applicable)

**Body — Structure:**
- [ ] All expected fields present
- [ ] Correct data types
- [ ] Null handling correct
- [ ] No sensitive data leaked (passwords, tokens, internal IDs)

**Body — Values:**
- [ ] Returned values match input
- [ ] System fields valid (UUID format, timestamp format, enum values)
- [ ] Computed fields correct
- [ ] Collections: correct count, order, pagination metadata

**Error Responses:**
- [ ] Error structure follows API convention
- [ ] Error message is specific and helpful
- [ ] Error code is correct
- [ ] No stack traces or internal details exposed

---

## 7. Anti-Patterns Checklist

The agent NEVER produces tests with these anti-patterns:

| # | Anti-Pattern | Rule |
|---|-------------|------|
| 1 | **Shallow test** — only checks status code | Every test validates body + headers too |
| 2 | **Copy-paste scenarios** — identical logic, different name | Each scenario tests something distinct |
| 3 | **Assumption-based** — tests behavior not in inputs | Ask user if behavior is unclear |
| 4 | **Sequential dependency** — scenario B needs scenario A to run first | Each scenario is independent |
| 5 | **Magic numbers** — unexplained values inline | Use constants, config, or documented data files |
| 6 | **Missing negatives** — happy path only | Every positive has 2+ negative counterparts |
| 7 | **Technical jargon** — unreadable by business users | Scenario names describe business behavior |
| 8 | **Empty assertions** — Then step with no actual check | Every Then asserts something specific |
| 9 | **Swallowed errors** — failures not captured | Clear error messages and logging on failure |
| 10 | **Flaky patterns** — Thread.sleep, time-dependent, order-dependent | Use waits, retries, and independent data |
| 11 | **Hardcoded URLs** — base URL in feature files | All URLs from config |
| 12 | **Hardcoded auth** — tokens/creds in feature files | Auth from config or auth feature |

---

## 8. Gap Analysis Algorithm

When analyzing existing test suites for gaps:

```
1. CATALOG: List every existing scenario with:
   - Endpoint it tests
   - Type (positive/negative/edge/business)
   - What it validates

2. MAP TO MATRIX: Compare against the CRUD coverage matrix (Section 3)
   - For each endpoint, count existing tests per category
   - Compare to minimum expected counts

3. CALCULATE GAPS:
   Gap = Expected minimum - Actual count
   If gap > 0 → Missing coverage (flag)
   If gap < 0 → Over-covered (note, not a problem)
   If gap = 0 → Adequately covered

4. PRIORITIZE GAPS:
   Critical: Missing positive happy-path or auth tests
   High: Missing negative tests for required field validation
   Medium: Missing edge cases or boundary tests
   Low: Missing advanced edge cases (concurrency, large payload)

5. PRESENT: Show gap report with actionable recommendations
```

---

## 9. Test Suite Organization Tags

**Mandatory tag set for every scenario:**
```
@{feature}                     # Feature group: @customer-management
@api                           # Test type: always @api for API tests
@{positive|negative|edge-case|business-rule}  # Scenario category
@{smoke|regression}            # Suite inclusion
@{severity-critical|severity-high|severity-medium|severity-low}  # Priority
@jira-{KEY}-{NUM}              # Traceability (when Jira ID provided)
```

**Optional tags:**
```
@wip                           # Work in progress — excluded from CI
@skip                          # Temporarily disabled
@flaky                         # Known flaky — needs investigation
@data-driven                   # Parameterized scenario
@security                      # Security-focused test
@performance-hint              # Has performance validation (response time)
```
