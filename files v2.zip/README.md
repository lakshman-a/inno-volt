# QA Automation Agent for GitHub Copilot — v2.0

## What This Is

A **self-driving QA agent** for GitHub Copilot that:
- **Auto-detects** your test framework (Cucumber+Serenity or Karate)
- **Auto-scans** existing test suites for current coverage
- **Guides developers** through structured menus (no guessing what to type)
- **Plans before coding** (presents test plan for approval)
- **Generates production-ready test suites** (not stubs or placeholders)
- **Never hallucinates** (asks instead of assuming)
- **Auto-loads the right skills** (framework patterns, test design methodology)

### The Developer Experience
```
Developer: "hi"
Agent: [scans workspace → detects Karate → finds 12 existing tests]
Agent: "Framework: Karate. 12 existing scenarios found. What would you like to do?"
Agent: [presents 7-option menu]
Developer: "1 — create new test suite"
Agent: "What input do you have? A) Swagger B) Code C) Requirements..."
Developer: "A — read the swagger.yaml"
Agent: [reads swagger, presents test plan: 54 scenarios across 5 endpoints]
Developer: "approved"
Agent: [generates all files: features, test data, schemas, config, runners]
Agent: "Done! Run: mvn test -Dkarate.env=dev"
```

---

## File Structure

```
.github/
├── copilot-instructions.md                  ← Global rules (auto-loaded by Copilot)
├── modes/
│   └── senior-qa-automation.md              ← The QA agent persona & workflow engine
├── skills/
│   ├── cucumber-serenity-skills.md          ← Cucumber+Serenity patterns (auto-loaded)
│   ├── karate-dsl-skills.md                 ← Karate DSL patterns (auto-loaded)
│   └── test-design-methodology.md           ← QA test design brain (auto-loaded)
└── instructions/
    └── qa-agent-usage-guide.md              ← Developer quick-start guide
```

### How Files Work Together

```
User activates "Senior QA Automation Engineer" mode
    │
    ├─→ copilot-instructions.md loads (global rules: no hallucination, auto-detect)
    │
    ├─→ senior-qa-automation.md loads (persona, workflow, menus, phases)
    │
    │   Agent auto-detects framework from workspace:
    │   ├─→ Cucumber detected? → cucumber-serenity-skills.md auto-applied
    │   ├─→ Karate detected?   → karate-dsl-skills.md auto-applied
    │   └─→ Always             → test-design-methodology.md auto-applied
    │
    └─→ Agent drives the flow. User follows guided menus.
```

**Key design principle:** Skills are loaded transparently. Developers never reference skill files. The agent knows when to use what.

---

## Setup Instructions

### Step 1: Copy to Your Repository
```bash
# Copy the .github directory into your project root
cp -r .github/ /path/to/your-project/.github/

# If .github already exists, merge carefully (don't overwrite workflows)
```

### Step 2: Verify VS Code Settings
```json
{
    "github.copilot.chat.agent.enabled": true,
    "github.copilot.chat.useCustomInstructions": true
}
```

### Step 3: Select the Mode
1. Open Copilot Chat (`Ctrl+Shift+I`)
2. Click the mode selector dropdown at the top
3. Select **"Senior QA Automation Engineer"**
4. Done — the agent will initialize automatically

### Step 4: Set Claude Model (Recommended)
In Copilot settings → Model selector:
- **Claude Sonnet 4** — recommended for most tasks (fast + high quality)
- **Claude Opus 4.5** — for complex full-suite generation or large gap analysis

The agent will also recommend the optimal model during initialization.

---

## What the Agent Supports

### 7 Use Cases

| # | Use Case | Input Required | Output |
|---|----------|---------------|--------|
| 1 | **Create New Test Suite** | Swagger / Code / Requirements / Manual | Complete test suite with all files |
| 2 | **Enhance Existing Tests** | Nothing (auto-scans) | Gap analysis + missing tests only |
| 3 | **Update for Changes** | Description of changes | Updated existing tests + new ones |
| 4 | **Single Endpoint** | Endpoint details | Focused test set for one endpoint |
| 5 | **Coverage Analysis** | Nothing (auto-scans) | Gap report (no code generated) |
| 6 | **Fix Failing Tests** | Error output | Fixed tests |
| 7 | **Scaffold Framework** | Framework choice + project details | Complete project structure from scratch |

### 5 Input Types

| Input Type | What It Is | How to Provide |
|-----------|-----------|----------------|
| **Swagger/OpenAPI** | API spec (JSON/YAML) | Paste content, file path, or `@workspace` reference |
| **Java Code** | Controllers, Services, DTOs | `@workspace` reference or paste code |
| **Requirements** | Jira story, acceptance criteria | Paste text |
| **Documentation** | Confluence page, API docs | Paste content |
| **Manual Description** | You describe the API | Agent asks structured questions |

### 2 Frameworks

| Framework | Detection | Config | Reports |
|-----------|-----------|--------|---------|
| **Cucumber + Serenity BDD** | `serenity-cucumber` in pom.xml | `serenity.conf` | Serenity HTML + optional Allure |
| **Karate DSL** | `karate-junit5` in pom.xml | `karate-config.js` | Karate HTML + optional Allure |

---

## The Agent's Workflow (4 Phases)

```
PHASE 0: INITIALIZE
├── Auto-detect framework (pom.xml scan)
├── Auto-scan existing tests (feature files, step defs)
├── Present discovery results + model recommendation
└── Show guided menu (7 options)

PHASE 1: COLLECT INPUTS
├── Based on user's menu selection
├── Ask structured questions (not open-ended)
├── Collect all needed info before proceeding
└── Confirm framework, scope, and preferences

PHASE 2: PLAN & APPROVE
├── Build coverage matrix
├── Design all test scenarios (positive/negative/edge/business)
├── Present test plan with file list
└── WAIT for user approval before generating

PHASE 3: GENERATE & DELIVER
├── Generate files in order: config → data → schemas → features → steps → runners
├── Follow framework-specific patterns (auto-loaded)
├── Present summary with execution commands
└── Offer next steps
```

---

## Quality Guarantees

The agent is designed to ensure:

| Guarantee | How |
|-----------|-----|
| **No hallucination** | Never invents endpoints, schemas, or business rules |
| **No empty tests** | Every scenario has real assertions (not just status code) |
| **Business readable** | Scenarios describe business behavior, not technical calls |
| **Comprehensive** | Positive + Negative + Edge + Business for every feature |
| **No hardcoding** | All URLs, data, auth in config files |
| **Proper logging** | Log at every scenario step for debugging |
| **Proper tagging** | Feature, type, suite, severity, traceability tags |
| **Independent tests** | No scenario depends on another scenario |
| **Existing patterns** | Matches your project's existing test conventions |
| **Proper structure** | Follows standard project layout per framework |

---

## Rollout Plan

### Phase 1: Pilot (Current)
- Deploy to 2-3 pilot teams
- Collect feedback on agent quality
- Refine mode and skill files based on real usage
- Validate with actual project codebases

### Phase 2: Team Rollout
- Share refined agent files to all teams via shared repo or template
- Create team-specific customizations (company naming conventions, etc.)
- Add more skill files for company-specific patterns

### Phase 3: Platform
- Build centralized test generation platform
- API-driven test creation from CI/CD pipelines
- Dashboard for coverage tracking
- Multi-repo, multi-team management

---

## Customization Guide

### Add Your Company's Standards
Edit `.github/copilot-instructions.md`:
```markdown
## Company-Specific Standards
- All test class names must end with `IT` (e.g., `CustomerApiIT`)
- Use tag format: `@jira-{TEAM}-{NUMBER}` (e.g., `@jira-PAY-1234`)
- Always include `@owner-{team}` tag
- Test data must use Faker library for dynamic generation
```

### Add Environment URLs
Edit the appropriate skills file to include your actual environment URLs.

### Add Authentication Details
Edit the auth patterns in skills files to match your auth flow (OAuth, API Key, JWT, etc.).

---

## FAQ

**Q: Do developers need to learn special prompts?**
A: No. The agent presents menus and asks structured questions. Just select options.

**Q: What if the agent picks the wrong framework?**
A: Just say "Use Karate" or "Use Cucumber" — it will switch immediately.

**Q: Can I use this for non-API tests?**
A: Currently optimized for API functional testing. UI and other test types are planned for future phases.

**Q: Does the agent execute tests?**
A: It provides exact Maven commands. In Copilot Agent Mode, it can also execute them if terminal access is enabled.

**Q: What if my project uses a different test structure?**
A: The agent scans existing tests first and matches your patterns. It only uses the standard structure for greenfield projects.
