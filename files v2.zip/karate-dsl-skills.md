# Karate DSL — Framework Skills (Auto-Loaded)

> **This file is automatically loaded by the QA Agent when Karate DSL is detected.**
> **Developers do not need to reference this file directly.**

---

## 1. Project Structure Standard

```
src/test/
├── java/com/{org}/{project}/
│   ├── KarateTestRunner.java                 # Main parallel runner
│   ├── SmokeTestRunner.java                  # Smoke suite runner
│   ├── {Feature}Runner.java                  # Per-feature runners
│   └── helpers/
│       ├── DataGenerator.java                # Java-based dynamic data
│       └── CustomUtils.java                  # Java helper functions callable from Karate
└── resources/
    ├── karate-config.js                      # Global config (env switching)
    ├── logback-test.xml                      # Logging config
    ├── features/
    │   ├── {feature}/
    │   │   ├── {feature}_positive.feature
    │   │   ├── {feature}_negative.feature
    │   │   ├── {feature}_edge_cases.feature
    │   │   └── {Feature}Runner.java          # Optional feature-level runner
    │   ├── common/
    │   │   ├── auth.feature                  # Reusable auth (callSingle)
    │   │   ├── health-check.feature          # API availability check
    │   │   └── cleanup.feature               # Data cleanup utilities
    │   └── smoke/
    │       └── smoke_tests.feature
    ├── testdata/
    │   ├── {feature}/
    │   │   ├── valid_requests.json
    │   │   ├── invalid_requests.json
    │   │   ├── boundary_data.json
    │   │   └── dynamic_data.js               # JS-based dynamic data
    │   └── common/
    │       └── users.json
    ├── schemas/
    │   └── {feature}/
    │       ├── success_response.json
    │       └── error_response.json
    └── mocks/                                # Karate mock definitions (optional)
        └── {feature}-mock.feature
```

**Adaptation Rule:** Match existing project structure if tests already exist.

---

## 2. POM Dependencies Template

```xml
<properties>
    <java.version>11</java.version>
    <karate.version>1.4.1</karate.version>
    <maven.compiler.source>${java.version}</maven.compiler.source>
    <maven.compiler.target>${java.version}</maven.compiler.target>
</properties>

<dependencies>
    <dependency>
        <groupId>com.intuit.karate</groupId>
        <artifactId>karate-junit5</artifactId>
        <version>${karate.version}</version>
        <scope>test</scope>
    </dependency>
    <!-- Optional: Allure Reporting -->
    <dependency>
        <groupId>io.qameta.allure</groupId>
        <artifactId>allure-karate</artifactId>
        <version>2.25.0</version>
        <scope>test</scope>
    </dependency>
</dependencies>

<build>
    <testResources>
        <testResource>
            <directory>src/test/resources</directory>
        </testResource>
        <testResource>
            <directory>src/test/java</directory>
            <excludes>
                <exclude>**/*.java</exclude>
            </excludes>
        </testResource>
    </testResources>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-surefire-plugin</artifactId>
            <version>3.2.3</version>
            <configuration>
                <argLine>-Dfile.encoding=UTF-8</argLine>
                <systemPropertyVariables>
                    <karate.env>${karate.env}</karate.env>
                </systemPropertyVariables>
            </configuration>
        </plugin>
    </plugins>
</build>
```

---

## 3. karate-config.js Template

```javascript
function fn() {
    var env = karate.env || 'dev';
    karate.log('=== Karate Environment:', env, '===');

    var config = {
        connectTimeout: 30000,
        readTimeout: 30000,
        retryCount: 0,
        retryInterval: 1000,
        baseUrl: '',
        authUrl: '',
        authToken: ''
    };

    // Environment-specific URLs
    var envConfig = {
        dev:     { baseUrl: 'https://dev-api.example.com',     authUrl: 'https://dev-auth.example.com' },
        qa:      { baseUrl: 'https://qa-api.example.com',      authUrl: 'https://qa-auth.example.com', readTimeout: 45000 },
        staging: { baseUrl: 'https://staging-api.example.com',  authUrl: 'https://staging-auth.example.com', readTimeout: 60000 }
    };

    var selected = envConfig[env] || envConfig['dev'];
    config.baseUrl = selected.baseUrl;
    config.authUrl = selected.authUrl;
    if (selected.readTimeout) config.readTimeout = selected.readTimeout;

    // Authenticate once per suite (callSingle caches across scenarios)
    var authResult = karate.callSingle('classpath:features/common/auth.feature', config);
    config.authToken = authResult.authToken;
    karate.log('Authentication successful. Token obtained.');

    // Global Karate configuration
    karate.configure('connectTimeout', config.connectTimeout);
    karate.configure('readTimeout', config.readTimeout);
    karate.configure('retry', { count: config.retryCount, interval: config.retryInterval });
    karate.configure('logPrettyRequest', true);
    karate.configure('logPrettyResponse', true);

    // Default headers for all requests
    karate.configure('headers', {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + config.authToken
    });

    return config;
}
```

---

## 4. Feature File Standards

### Scenario Writing Pattern (Business-Readable Karate)

```gherkin
@customer-management @api @positive @regression @severity-critical @jira-PROJ-101
Scenario: Successfully create a new customer with all required information
    # ── SETUP: Prepare test data ──
    * def customerData = read('classpath:testdata/customer/valid_customer.json')
    * def expectedSchema = read('classpath:schemas/customer/create_success.json')
    * karate.log('Creating customer with data:', karate.pretty(customerData))

    # ── ACTION: Send the create customer request ──
    Given url baseUrl + '/api/v1/customers'
    And request customerData
    When method post

    # ── VERIFY: Status and response structure ──
    Then status 201
    * karate.log('Customer created. Response:', karate.pretty(response))

    # Verify response matches expected schema
    And match response == expectedSchema

    # Verify returned data matches input
    And match response.firstName == customerData.firstName
    And match response.lastName == customerData.lastName
    And match response.email == customerData.email

    # Verify system-generated fields
    And match response.id == '#uuid'
    And match response.createdAt == '#string'
    And match response.updatedAt == '#string'

    # Verify response headers
    And match responseHeaders['Location'][0] contains response.id

    # ── CLEANUP: Store ID for teardown ──
    * def createdId = response.id
    * karate.log('Test passed. Created customer ID:', createdId)
```

### Negative Scenario Pattern
```gherkin
@customer-management @api @negative @regression @severity-high @jira-PROJ-102
Scenario Outline: Reject customer creation when required field "<missingField>" is missing
    # ── SETUP ──
    * def baseData = read('classpath:testdata/customer/valid_customer.json')
    * remove baseData.<missingField>
    * karate.log('Testing missing required field:', '<missingField>')
    * karate.log('Request body:', karate.pretty(baseData))

    # ── ACTION ──
    Given url baseUrl + '/api/v1/customers'
    And request baseData
    When method post

    # ── VERIFY: Should reject with 400 ──
    Then status 400
    And match response.errors[*].field contains '<missingField>'
    And match response.errors[*].message == '#notnull'
    * karate.log('Correctly rejected. Error:', karate.pretty(response.errors))

    Examples:
        | missingField |
        | firstName    |
        | lastName     |
        | email        |
```

### Edge Case Pattern
```gherkin
@customer-management @api @edge-case @regression @severity-medium
Scenario Outline: Handle boundary values for field "<field>"
    * def customerData = read('classpath:testdata/customer/valid_customer.json')
    * set customerData.<field> = '<testValue>'
    * karate.log('Testing boundary for <field>:', '<testValue>', '→ expecting status <expectedStatus>')

    Given url baseUrl + '/api/v1/customers'
    And request customerData
    When method post
    Then status <expectedStatus>
    * karate.log('Boundary test result — status:', responseStatus, '(expected: <expectedStatus>)')

    Examples:
        | field     | testValue | expectedStatus | description              |
        | firstName | A         | 201            | Minimum length (1 char)  |
        | firstName |           | 400            | Empty string             |
        | email     | a@b.c     | 201            | Minimum valid email      |
        | email     | notanemail| 400            | Invalid email format     |
```

---

## 5. Reusable Feature Calls

### Authentication (common/auth.feature)
```gherkin
@ignore
Feature: Authentication Helper
    Scenario: Obtain authentication token
        Given url authUrl
        And path '/oauth/token'
        And form field grant_type = 'client_credentials'
        And form field client_id = karate.properties['auth.client.id']
        And form field client_secret = karate.properties['auth.client.secret']
        When method post
        Then status 200
        * def authToken = response.access_token
        * karate.log('Auth token obtained successfully')
```

### Health Check (common/health-check.feature)
```gherkin
@ignore
Feature: Health Check Helper
    Scenario: Verify API is running
        Given url baseUrl
        And path '/health'
        And retry until responseStatus == 200
        When method get
        Then status 200
        * karate.log('API health check: PASSED')
```

### Cleanup Utility (common/cleanup.feature)
```gherkin
@ignore
Feature: Data Cleanup
    Scenario: Delete a resource by ID
        * karate.log('Cleaning up resource:', resourceType, 'ID:', resourceId)
        Given url baseUrl
        And path '/api/v1/' + resourceType + '/' + resourceId
        When method delete
        * karate.log('Cleanup result — status:', responseStatus)
```

---

## 6. Karate Match Expressions (Quick Reference)

| Expression | Meaning |
|-----------|---------|
| `#null` | Value is null |
| `#notnull` | Value is not null |
| `#present` | Key exists (even if null) |
| `#notpresent` | Key does not exist |
| `#ignore` | Skip this field |
| `#uuid` | Valid UUID format |
| `#string` | Value is a string |
| `#number` | Value is a number |
| `#boolean` | Value is a boolean |
| `#array` | Value is an array |
| `#object` | Value is an object |
| `#regex <pattern>` | Matches regex pattern |
| `#? _ > 0` | Custom JS expression |
| `##string` | Optional string (null or string) |
| `#[5]` | Array of exactly 5 elements |
| `#[_ > 0]` | Array where each element > 0 |

---

## 7. Test Runners

### Parallel Runner
```java
class KarateTestRunner {
    @Test
    void testAll() {
        Results results = Runner.path("classpath:features")
                .tags("~@ignore", "~@wip")
                .parallel(5);
        assertEquals(0, results.getFailCount(), results.getErrorMessages());
    }
}
```

### Smoke Runner
```java
class SmokeTestRunner {
    @Test
    void testSmoke() {
        Results results = Runner.path("classpath:features")
                .tags("@smoke")
                .parallel(3);
        assertEquals(0, results.getFailCount(), results.getErrorMessages());
    }
}
```

---

## 8. Execution Commands

```bash
# All tests (default dev)
mvn test

# Specific environment
mvn test -Dkarate.env=qa

# Specific tags
mvn test -Dkarate.options="--tags @smoke"

# Specific feature
mvn test -Dkarate.options="classpath:features/customer/customer_positive.feature"

# With parallel threads
mvn test -Dkarate.options="--threads 10"

# Karate HTML report: target/karate-reports/karate-summary.html
# Allure report: mvn allure:serve
```

---

## 9. Logging Standard

Every scenario must include these log points:
```gherkin
* karate.log('══ SCENARIO START:', 'Scenario description here', '══')
* karate.log('SETUP:', 'Loading test data from ...', karate.pretty(data))
* karate.log('ACTION:', 'Sending', method, 'to', url + path)
* karate.log('RESPONSE: Status =', responseStatus, 'Body =', karate.pretty(response))
* karate.log('VERIFY:', 'Checking that [description of assertion]')
* karate.log('══ SCENARIO COMPLETE ══')
```
