# Karate DSL — Framework Skills & Standards

## Overview
This document defines the standards, patterns, and best practices for generating API test automation using **Karate DSL**, Java 11+, and Maven.

---

## 1. Project Structure (Mandatory)

```
src/
├── test/
│   ├── java/
│   │   └── com/{org}/{project}/
│   │       ├── KarateTestRunner.java               # Main parallel runner
│   │       ├── SmokeTestRunner.java                 # Smoke suite runner
│   │       └── helpers/
│   │           ├── DataGenerator.java               # Java-based data factories
│   │           └── CustomUtils.java                 # Java helper functions
│   └── resources/
│       ├── karate-config.js                         # Global configuration
│       ├── logback-test.xml                         # Logging configuration
│       ├── features/
│       │   ├── {feature}/
│       │   │   ├── {feature}_positive.feature       # Positive scenarios
│       │   │   ├── {feature}_negative.feature       # Negative scenarios
│       │   │   ├── {feature}_edge_cases.feature     # Edge cases
│       │   │   └── {FeatureName}.java               # Feature-level runner (optional)
│       │   ├── common/
│       │   │   ├── auth.feature                     # Reusable auth flow
│       │   │   ├── health-check.feature             # Health check utility
│       │   │   └── cleanup.feature                  # Data cleanup utilities
│       │   └── smoke/
│       │       └── smoke_tests.feature              # Smoke test scenarios
│       ├── testdata/
│       │   ├── {feature}/
│       │   │   ├── valid_requests.json
│       │   │   ├── invalid_requests.json
│       │   │   ├── boundary_data.csv                # CSV for data-driven tests
│       │   │   └── dynamic_data.js                  # JS-based dynamic data
│       │   └── common/
│       │       └── users.json
│       ├── schemas/
│       │   └── {feature}/
│       │       ├── success_response.json            # JSON schema for match
│       │       └── error_response.json
│       └── mocks/                                   # Karate mock server definitions
│           └── {feature}-mock.feature
pom.xml
```

---

## 2. Maven POM Dependencies (Template)

```xml
<properties>
    <java.version>11</java.version>
    <karate.version>1.4.1</karate.version>
    <maven.compiler.source>${java.version}</maven.compiler.source>
    <maven.compiler.target>${java.version}</maven.compiler.target>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
</properties>

<dependencies>
    <dependency>
        <groupId>com.intuit.karate</groupId>
        <artifactId>karate-junit5</artifactId>
        <version>${karate.version}</version>
        <scope>test</scope>
    </dependency>
    <!-- Optional: Allure Reporting -->
    <dependency>
        <groupId>io.qameta.allure</groupId>
        <artifactId>allure-karate</artifactId>
        <version>2.25.0</version>
        <scope>test</scope>
    </dependency>
</dependencies>

<build>
    <testResources>
        <testResource>
            <directory>src/test/resources</directory>
        </testResource>
        <testResource>
            <directory>src/test/java</directory>
            <excludes>
                <exclude>**/*.java</exclude>
            </excludes>
        </testResource>
    </testResources>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-surefire-plugin</artifactId>
            <version>3.2.3</version>
            <configuration>
                <argLine>-Dfile.encoding=UTF-8</argLine>
                <systemPropertyVariables>
                    <karate.env>${karate.env}</karate.env>
                </systemPropertyVariables>
            </configuration>
        </plugin>
    </plugins>
</build>
```

---

## 3. karate-config.js (Template)

```javascript
function fn() {
    var env = karate.env || 'dev';
    karate.log('Running in environment:', env);

    var config = {
        // Common config
        connectTimeout: 30000,
        readTimeout: 30000,
        retryCount: 0,
        retryInterval: 1000,

        // Environment-specific URLs
        baseUrl: '',
        authUrl: '',

        // Auth token (populated by auth.feature)
        authToken: ''
    };

    if (env === 'dev') {
        config.baseUrl = 'https://dev-api.example.com';
        config.authUrl = 'https://dev-auth.example.com';
    } else if (env === 'qa') {
        config.baseUrl = 'https://qa-api.example.com';
        config.authUrl = 'https://qa-auth.example.com';
        config.readTimeout = 45000;
    } else if (env === 'staging') {
        config.baseUrl = 'https://staging-api.example.com';
        config.authUrl = 'https://staging-auth.example.com';
        config.readTimeout = 60000;
    }

    // Authenticate and set token
    var authResult = karate.callSingle('classpath:features/common/auth.feature', config);
    config.authToken = authResult.authToken;

    // Configure Karate
    karate.configure('connectTimeout', config.connectTimeout);
    karate.configure('readTimeout', config.readTimeout);
    karate.configure('retry', { count: config.retryCount, interval: config.retryInterval });

    // Global request headers
    karate.configure('headers', {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + config.authToken
    });

    // Custom logging
    karate.configure('logPrettyRequest', true);
    karate.configure('logPrettyResponse', true);

    return config;
}
```

---

## 4. Feature File Writing Standards

### Tag Strategy
```gherkin
@feature-name           # Feature grouping
@api                    # Test type
@positive / @negative / @edge-case  # Scenario type
@smoke / @regression    # Test suite level
@severity-critical / @severity-high / @severity-medium  # Priority
@jira-PROJ-1234         # Traceability
```

### Feature File Template (Business-Readable Karate)
```gherkin
@customer-management @api @regression
Feature: Customer Management API
  As a client application
  I want to manage customer records via the API
  So that I can create, retrieve, update, and delete customer information

  Background:
    # Setup: Load configuration and verify API availability
    * url baseUrl
    * def healthCheck = call read('classpath:features/common/health-check.feature')
    * assert healthCheck.responseStatus == 200
    * karate.log('API is accessible. Starting test scenarios.')

  # ─────────────────────────────────────────────
  # POSITIVE SCENARIOS
  # ─────────────────────────────────────────────

  @positive @severity-critical @smoke @jira-PROJ-101
  Scenario: Successfully create a new customer with all required fields
    # Prepare: Load valid customer test data
    * def customerData = read('classpath:testdata/customer/valid_customer.json')
    * def expectedSchema = read('classpath:schemas/customer/create_success.json')
    * karate.log('Creating customer with data:', customerData)

    # Action: Send create customer request
    Given path '/api/v1/customers'
    And request customerData
    When method post

    # Validate: Verify successful creation
    Then status 201
    * karate.log('Customer created successfully. Response:', response)

    # Verify response structure matches expected schema
    And match response == expectedSchema

    # Verify response contains correct data
    And match response.firstName == customerData.firstName
    And match response.lastName == customerData.lastName
    And match response.email == customerData.email

    # Verify system-generated fields
    And match response.id == '#uuid'
    And match response.createdAt == '#notnull'
    And match response.updatedAt == '#notnull'

    # Verify response headers
    And match responseHeaders['Location'][0] contains response.id

    # Cleanup: Store customer ID for potential cleanup
    * def createdCustomerId = response.id
    * karate.log('Created customer ID:', createdCustomerId)

  @positive @severity-high @jira-PROJ-101
  Scenario Outline: Successfully create customers with various valid data combinations
    # Prepare: Build customer data dynamically
    * def customerData =
      """
      {
        "firstName": "<firstName>",
        "lastName": "<lastName>",
        "email": "<email>",
        "phone": "<phone>"
      }
      """
    * karate.log('Testing customer creation with:', customerData)

    # Action: Create customer
    Given path '/api/v1/customers'
    And request customerData
    When method post

    # Validate
    Then status 201
    And match response.firstName == '<firstName>'
    And match response.lastName == '<lastName>'
    * karate.log('Successfully created customer: <firstName> <lastName>')

    Examples:
      | firstName | lastName  | email                    | phone            |
      | Jane      | Doe       | jane.doe@example.com     | +1-555-987-6543  |
      | María     | González  | maria.gonzalez@email.com | +34-612-345-678  |
      | 田中       | 太郎      | tanaka@example.jp        | +81-90-1234-5678 |

  # ─────────────────────────────────────────────
  # NEGATIVE SCENARIOS
  # ─────────────────────────────────────────────

  @negative @severity-high @jira-PROJ-102
  Scenario Outline: Reject customer creation when required field is missing
    # Prepare: Create request with specific field removed
    * def baseData = read('classpath:testdata/customer/valid_customer.json')
    * remove baseData.<missingField>
    * karate.log('Testing missing field: <missingField>. Request:', baseData)

    # Action: Send incomplete request
    Given path '/api/v1/customers'
    And request baseData
    When method post

    # Validate: Should reject with 400 Bad Request
    Then status 400
    And match response.errors[*].field contains '<missingField>'
    * karate.log('Correctly rejected request missing <missingField>')

    Examples:
      | missingField |
      | firstName    |
      | lastName     |
      | email        |

  @negative @severity-high @jira-PROJ-102
  Scenario Outline: Reject customer creation with invalid field values
    # Prepare: Create request with invalid value for specific field
    * def customerData = read('classpath:testdata/customer/valid_customer.json')
    * set customerData.<field> = '<invalidValue>'
    * karate.log('Testing invalid value for <field>: <invalidValue>')

    # Action
    Given path '/api/v1/customers'
    And request customerData
    When method post

    # Validate
    Then status 400
    And match response.errors[*].field contains '<field>'
    And match response.errors[*].message contains '<expectedError>'
    * karate.log('Correctly rejected invalid <field> with error: <expectedError>')

    Examples:
      | field     | invalidValue          | expectedError           |
      | email     | not-an-email          | valid email format      |
      | email     |                       | must not be blank       |
      | phone     | 123                   | valid phone format      |
      | firstName | A123!@#               | alphabetic characters   |

  @negative @severity-medium
  Scenario: Reject request without authentication
    # Action: Send request without auth header
    * configure headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' }
    Given path '/api/v1/customers'
    And request read('classpath:testdata/customer/valid_customer.json')
    When method post

    # Validate
    Then status 401
    And match response.error == '#notnull'
    * karate.log('Correctly rejected unauthenticated request')

  # ─────────────────────────────────────────────
  # EDGE CASES
  # ─────────────────────────────────────────────

  @edge-case @severity-medium @jira-PROJ-104
  Scenario: Handle special characters in customer name
    * def customerData =
      """
      {
        "firstName": "O'Brien-Smith",
        "lastName": "de la Cruz",
        "email": "obrien.smith@test.com",
        "phone": "+1-555-000-0001"
      }
      """
    Given path '/api/v1/customers'
    And request customerData
    When method post
    Then status 201
    And match response.firstName == "O'Brien-Smith"
    * karate.log('Successfully handled special characters in name')

  @edge-case @severity-medium
  Scenario: Handle concurrent creation with same email
    # First request should succeed
    * def customerData = read('classpath:testdata/customer/valid_customer.json')
    * def uniqueEmail = 'concurrent_' + java.util.UUID.randomUUID() + '@test.com'
    * set customerData.email = uniqueEmail

    Given path '/api/v1/customers'
    And request customerData
    When method post
    Then status 201

    # Second request with same email should fail
    Given path '/api/v1/customers'
    And request customerData
    When method post
    Then status 409
    * karate.log('Correctly prevented duplicate email creation')
```

---

## 5. Reusable Feature Calls

### Authentication (common/auth.feature)
```gherkin
@ignore
Feature: Authentication Helper
  Scenario: Get authentication token
    Given url authUrl
    And path '/oauth/token'
    And form field grant_type = 'client_credentials'
    And form field client_id = karate.properties['auth.client.id']
    And form field client_secret = karate.properties['auth.client.secret']
    When method post
    Then status 200
    * def authToken = response.access_token
    * karate.log('Authentication successful. Token obtained.')
```

### Health Check (common/health-check.feature)
```gherkin
@ignore
Feature: Health Check Helper
  Scenario: Verify API is accessible
    Given url baseUrl
    And path '/health'
    And retry until responseStatus == 200
    When method get
    Then status 200
    * karate.log('Health check passed')
```

---

## 6. Test Runners

### Main Parallel Runner
```java
package com.org.project;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class KarateTestRunner {

    @Test
    void testAll() {
        Results results = Runner.path("classpath:features")
                .tags("~@ignore")
                .parallel(5);
        assertEquals(0, results.getFailCount(), results.getErrorMessages());
    }
}
```

### Smoke Test Runner
```java
class SmokeTestRunner {

    @Test
    void testSmoke() {
        Results results = Runner.path("classpath:features")
                .tags("@smoke")
                .parallel(3);
        assertEquals(0, results.getFailCount(), results.getErrorMessages());
    }
}
```

---

## 7. Karate Match Expressions (Quick Reference)

Use these for robust validation:
```
#null        - value is null
#notnull     - value is not null
#present     - key exists (even if null)
#notpresent  - key does not exist
#ignore      - skip validation
#uuid        - valid UUID format
#string      - value is a string
#number      - value is a number
#boolean     - value is a boolean
#array       - value is an array
#object      - value is an object
#regex <pattern> - matches regex
#? <expression>  - custom JS expression (e.g., #? _ > 0)
##string     - optional string (null or string)
```

---

## 8. Execution Commands

```bash
# Run all tests (default dev environment)
mvn test

# Run in specific environment
mvn test -Dkarate.env=qa

# Run specific tags
mvn test -Dkarate.options="--tags @smoke"

# Run specific feature file
mvn test -Dkarate.options="classpath:features/customer/customer_positive.feature"

# Run with parallel threads
mvn test -Dkarate.options="--threads 10"

# Generate Allure report
mvn allure:serve

# Karate HTML report is auto-generated at: target/karate-reports/karate-summary.html
```

---

## 9. Logging Standards (Karate-Specific)

```gherkin
# At the start of every scenario
* karate.log('=== Starting Scenario: <scenario name> ===')

# Before every API call
* karate.log('Sending', method, 'request to:', url + path)
* karate.log('Request body:', request)

# After every API call
* karate.log('Response status:', responseStatus)
* karate.log('Response body:', response)

# At assertion points
* karate.log('Validating:', '<what is being validated>')

# At scenario end
* karate.log('=== Scenario Complete ===')
```

---

## 10. JSON Schema Validation Pattern

### Define schema files:
```json
// schemas/customer/create_success.json
{
  "id": "#uuid",
  "firstName": "#string",
  "lastName": "#string",
  "email": "#string",
  "phone": "##string",
  "createdAt": "#string",
  "updatedAt": "#string",
  "status": "ACTIVE"
}
```

### Use in feature:
```gherkin
* def expectedSchema = read('classpath:schemas/customer/create_success.json')
And match response == expectedSchema
```
