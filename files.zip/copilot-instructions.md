# GitHub Copilot - Global Project Instructions

## Project Context
This project uses GitHub Copilot Agent Mode with Claude to assist developers and QA engineers in generating, maintaining, and executing comprehensive functional API test cases. The project supports two automation frameworks:

1. **Cucumber + Serenity BDD** (Java, Maven)
2. **Karate DSL** (Java, Maven)

## General Rules for All Copilot Interactions

### Never Hallucinate or Assume
- **NEVER** generate test cases based on assumptions about the API or business logic.
- **ALWAYS** ask for or read the source of truth: codebase, Swagger/OpenAPI spec, requirement documents, Jira stories, or Confluence pages.
- If input is ambiguous or incomplete, **ASK** the user for clarification before proceeding.
- If you cannot determine the expected behavior from provided inputs, say so explicitly.

### Always Discover Before Creating
Before writing any test case:
1. **Scan** the existing test suite in the project to understand current coverage.
2. **Identify** existing feature files, step definitions, runners, and utilities.
3. **Map** what is already tested vs. what is missing.
4. **Plan** before writing — present the test plan to the user for review.

### Quality Standards
- All test cases must be written in **business language**, not technical jargon.
- Every test scenario must have a clear **Given-When-Then** structure (Cucumber) or clear **Scenario-Request-Validation** structure (Karate).
- Test data must be realistic, meaningful, and cover all data boundaries.
- Logging must be explicit and descriptive at every step.
- No hardcoded values — use configuration files and environment variables.
- Follow the existing project structure and naming conventions exactly.

### Framework Detection
- If the project contains `pom.xml` with `serenity-cucumber` dependencies → use Cucumber + Serenity patterns.
- If the project contains `pom.xml` with `karate` dependencies → use Karate DSL patterns.
- If both exist, ask the user which framework to target.
- If neither exists, ask the user which framework to set up.
