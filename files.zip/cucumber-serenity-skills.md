# Cucumber + Serenity BDD — Framework Skills & Standards

## Overview
This document defines the standards, patterns, and best practices for generating API test automation using **Cucumber BDD** with **Serenity BDD** reporting framework, **RestAssured** (via Serenity REST), Java 11+, and Maven.

---

## 1. Project Structure (Mandatory)

```
src/
├── test/
│   ├── java/
│   │   └── com/{org}/{project}/
│   │       ├── runners/
│   │       │   ├── TestSuiteRunner.java            # Main test runner
│   │       │   ├── SmokeTestRunner.java             # Smoke tests only
│   │       │   └── RegressionTestRunner.java        # Full regression
│   │       ├── stepdefinitions/
│   │       │   ├── common/
│   │       │   │   ├── CommonApiSteps.java          # Reusable API steps
│   │       │   │   ├── AuthenticationSteps.java     # Auth-related steps
│   │       │   │   └── ValidationSteps.java         # Common validations
│   │       │   ├── {feature}/
│   │       │   │   └── {Feature}Steps.java          # Feature-specific steps
│   │       │   └── Hooks.java                       # Before/After hooks
│   │       ├── models/
│   │       │   ├── request/
│   │       │   │   └── {Entity}Request.java         # Request POJOs
│   │       │   └── response/
│   │       │       └── {Entity}Response.java        # Response POJOs
│   │       ├── utils/
│   │       │   ├── ApiClient.java                   # Centralized API client
│   │       │   ├── TestDataBuilder.java             # Test data factory
│   │       │   ├── ConfigManager.java               # Configuration reader
│   │       │   ├── JsonHelper.java                  # JSON utilities
│   │       │   └── TestContext.java                  # Shared state across steps
│   │       └── constants/
│   │           ├── Endpoints.java                   # API endpoint constants
│   │           └── TestConstants.java               # Reusable constants
│   └── resources/
│       ├── features/
│       │   ├── {feature}/
│       │   │   ├── {feature}_positive.feature       # Positive scenarios
│       │   │   ├── {feature}_negative.feature       # Negative scenarios
│       │   │   └── {feature}_edge_cases.feature     # Edge case scenarios
│       │   └── smoke/
│       │       └── smoke_tests.feature              # Smoke test scenarios
│       ├── testdata/
│       │   ├── {feature}/
│       │   │   ├── valid_requests.json              # Valid test data
│       │   │   ├── invalid_requests.json            # Invalid test data
│       │   │   └── boundary_data.json               # Boundary test data
│       │   └── common/
│       │       └── auth_tokens.json                 # Auth test data
│       ├── schemas/
│       │   └── {feature}/
│       │       ├── success_response_schema.json     # JSON schema for validation
│       │       └── error_response_schema.json       # Error schema
│       ├── environments/
│       │   ├── dev.properties
│       │   ├── qa.properties
│       │   ├── staging.properties
│       │   └── prod.properties
│       ├── serenity.conf                            # Serenity configuration
│       └── logback-test.xml                         # Logging configuration
pom.xml
```

---

## 2. Maven POM Dependencies (Template)

```xml
<properties>
    <java.version>11</java.version>
    <serenity.version>4.1.4</serenity.version>
    <cucumber.version>7.15.0</cucumber.version>
    <restassured.version>5.4.0</restassured.version>
    <allure.version>2.25.0</allure.version>
    <maven.compiler.source>${java.version}</maven.compiler.source>
    <maven.compiler.target>${java.version}</maven.compiler.target>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
</properties>

<dependencies>
    <!-- Serenity BDD -->
    <dependency>
        <groupId>net.serenity-bdd</groupId>
        <artifactId>serenity-core</artifactId>
        <version>${serenity.version}</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>net.serenity-bdd</groupId>
        <artifactId>serenity-cucumber</artifactId>
        <version>${serenity.version}</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>net.serenity-bdd</groupId>
        <artifactId>serenity-rest-assured</artifactId>
        <version>${serenity.version}</version>
        <scope>test</scope>
    </dependency>

    <!-- Cucumber -->
    <dependency>
        <groupId>io.cucumber</groupId>
        <artifactId>cucumber-java</artifactId>
        <version>${cucumber.version}</version>
        <scope>test</scope>
    </dependency>

    <!-- Allure Reporting (Optional) -->
    <dependency>
        <groupId>io.qameta.allure</groupId>
        <artifactId>allure-cucumber7-jvm</artifactId>
        <version>${allure.version}</version>
        <scope>test</scope>
    </dependency>

    <!-- Utilities -->
    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-databind</artifactId>
        <version>2.16.1</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.assertj</groupId>
        <artifactId>assertj-core</artifactId>
        <version>3.25.1</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>com.github.javafaker</groupId>
        <artifactId>javafaker</artifactId>
        <version>1.0.2</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.slf4j</groupId>
        <artifactId>slf4j-api</artifactId>
        <version>2.0.11</version>
        <scope>test</scope>
    </dependency>
</dependencies>

<build>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-surefire-plugin</artifactId>
            <version>3.2.3</version>
            <configuration>
                <skip>true</skip>
            </configuration>
        </plugin>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-failsafe-plugin</artifactId>
            <version>3.2.3</version>
            <configuration>
                <includes>
                    <include>**/*Runner.java</include>
                </includes>
                <systemPropertyVariables>
                    <environment>${env}</environment>
                </systemPropertyVariables>
            </configuration>
            <executions>
                <execution>
                    <goals>
                        <goal>integration-test</goal>
                        <goal>verify</goal>
                    </goals>
                </execution>
            </executions>
        </plugin>
        <plugin>
            <groupId>net.serenity-bdd.maven.plugins</groupId>
            <artifactId>serenity-maven-plugin</artifactId>
            <version>${serenity.version}</version>
            <executions>
                <execution>
                    <id>serenity-reports</id>
                    <phase>post-integration-test</phase>
                    <goals>
                        <goal>aggregate</goal>
                    </goals>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```

---

## 3. Feature File Writing Standards

### Naming Convention
- Feature file name: `{feature_name}_{test_type}.feature`
- Example: `customer_management_positive.feature`

### Tag Strategy
```gherkin
@feature-name           # Feature grouping
@api                    # Test type
@positive / @negative / @edge-case  # Scenario type
@smoke / @regression    # Test suite level
@severity-critical / @severity-high / @severity-medium / @severity-low  # Priority
@jira-PROJ-1234         # Traceability
```

### Feature File Template
```gherkin
@customer-management @api @regression
Feature: Customer Management API
  As a client application
  I want to manage customer records via the API
  So that I can create, retrieve, update, and delete customer information

  Background:
    Given the API is running and accessible
    And I am authenticated as a valid API consumer

  # ─────────────────────────────────────────────
  # POSITIVE SCENARIOS
  # ─────────────────────────────────────────────

  @positive @severity-critical @smoke @jira-PROJ-101
  Scenario: Successfully create a new customer with all required fields
    Given I have prepared a valid customer creation request
      | field     | value                |
      | firstName | John                 |
      | lastName  | Smith                |
      | email     | john.smith@email.com |
      | phone     | +1-555-123-4567      |
    When I send a POST request to the create customer endpoint
    Then the response status code should be 201
    And the response body should contain the customer details
    And the customer ID in the response should be a valid UUID
    And the response should include "createdAt" timestamp
    And the response header "Location" should contain the new customer URL

  @positive @severity-high @jira-PROJ-101
  Scenario Outline: Successfully create customers with various valid data combinations
    Given I have prepared a customer creation request with "<firstName>", "<lastName>", "<email>", and "<phone>"
    When I send a POST request to the create customer endpoint
    Then the response status code should be 201
    And the response body should contain firstName "<firstName>"
    And the response body should contain lastName "<lastName>"

    Examples: Standard customer data
      | firstName | lastName  | email                    | phone          |
      | Jane      | Doe       | jane.doe@example.com     | +1-555-987-6543 |
      | María     | González  | maria.gonzalez@email.com | +34-612-345-678 |
      | 田中       | 太郎      | tanaka@example.jp        | +81-90-1234-5678 |

  # ─────────────────────────────────────────────
  # NEGATIVE SCENARIOS
  # ─────────────────────────────────────────────

  @negative @severity-high @jira-PROJ-102
  Scenario Outline: Reject customer creation when required field is missing
    Given I have prepared a customer creation request without the "<missingField>" field
    When I send a POST request to the create customer endpoint
    Then the response status code should be 400
    And the response error message should indicate "<missingField>" is required
    And no customer record should be created

    Examples: Required fields
      | missingField |
      | firstName    |
      | lastName     |
      | email        |

  @negative @severity-high @jira-PROJ-103
  Scenario: Reject customer creation with duplicate email address
    Given a customer with email "existing@email.com" already exists
    And I have prepared a customer creation request with email "existing@email.com"
    When I send a POST request to the create customer endpoint
    Then the response status code should be 409
    And the response error message should indicate the email already exists

  @negative @severity-medium
  Scenario: Reject request with invalid authentication token
    Given I have an expired authentication token
    And I have prepared a valid customer creation request
    When I send a POST request to the create customer endpoint
    Then the response status code should be 401
    And the response should indicate authentication failure

  # ─────────────────────────────────────────────
  # EDGE CASES
  # ─────────────────────────────────────────────

  @edge-case @severity-medium @jira-PROJ-104
  Scenario Outline: Handle boundary values for customer name fields
    Given I have prepared a customer creation request with firstName "<nameValue>"
    When I send a POST request to the create customer endpoint
    Then the response status code should be <expectedStatus>

    Examples: Name length boundaries
      | nameValue                                              | expectedStatus |
      | A                                                      | 201            |
      | ABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJ50CH | 201            |
      |                                                        | 400            |
```

---

## 4. Step Definition Patterns

### Common API Steps (Reusable)
```java
package com.org.project.stepdefinitions.common;

import io.cucumber.java.en.*;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import io.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static org.assertj.core.api.Assertions.*;

public class CommonApiSteps {

    private static final Logger LOG = LoggerFactory.getLogger(CommonApiSteps.class);
    private final TestContext context;

    public CommonApiSteps(TestContext context) {
        this.context = context;
    }

    @Given("the API is running and accessible")
    @Step("Verify API health check endpoint is responding")
    public void verifyApiIsAccessible() {
        LOG.info("Verifying API is accessible at: {}", context.getBaseUrl());
        Response response = SerenityRest.given()
            .baseUri(context.getBaseUrl())
            .when()
            .get("/health")
            .then()
            .extract().response();

        assertThat(response.getStatusCode())
            .as("API health check should return 200")
            .isEqualTo(200);
        LOG.info("API is accessible and healthy");
    }

    @Given("I am authenticated as a valid API consumer")
    @Step("Authenticate and obtain valid access token")
    public void authenticateAsValidConsumer() {
        LOG.info("Authenticating as valid API consumer");
        String token = context.getAuthenticationToken();
        assertThat(token)
            .as("Authentication token should not be empty")
            .isNotBlank();
        context.setCurrentAuthToken(token);
        LOG.info("Successfully authenticated");
    }

    @Then("the response status code should be {int}")
    @Step("Verify response status code is {0}")
    public void verifyResponseStatusCode(int expectedStatusCode) {
        int actualStatusCode = SerenityRest.lastResponse().getStatusCode();
        LOG.info("Expected status: {}, Actual status: {}", expectedStatusCode, actualStatusCode);
        assertThat(actualStatusCode)
            .as("Response status code should be %d", expectedStatusCode)
            .isEqualTo(expectedStatusCode);
    }

    @Then("the response error message should indicate {string}")
    @Step("Verify error message contains: {0}")
    public void verifyErrorMessage(String expectedMessage) {
        String responseBody = SerenityRest.lastResponse().getBody().asString();
        LOG.info("Verifying error message contains: '{}' in response: {}", expectedMessage, responseBody);
        assertThat(responseBody.toLowerCase())
            .as("Error response should mention '%s'", expectedMessage)
            .contains(expectedMessage.toLowerCase());
    }
}
```

### Test Context (Shared State)
```java
package com.org.project.utils;

import io.restassured.response.Response;
import java.util.HashMap;
import java.util.Map;

/**
 * Thread-safe context for sharing state between step definitions.
 * Uses Cucumber's built-in PicoContainer DI for injection.
 */
public class TestContext {

    private String baseUrl;
    private String currentAuthToken;
    private Response lastResponse;
    private Map<String, Object> scenarioData = new HashMap<>();

    public String getBaseUrl() {
        return ConfigManager.getInstance().getProperty("base.url");
    }

    // ... getters/setters for shared state
}
```

---

## 5. Configuration (serenity.conf)

```hocon
serenity {
  project.name = "API Functional Tests"
  test.root = "com.org.project"
  take.screenshots = FOR_FAILURES
  logging = VERBOSE
}

environments {
  default {
    base.url = "http://localhost:8080"
    auth.url = "http://localhost:8080/auth"
    api.timeout = 30000
  }
  dev {
    base.url = "https://dev-api.example.com"
    auth.url = "https://dev-auth.example.com"
    api.timeout = 30000
  }
  qa {
    base.url = "https://qa-api.example.com"
    auth.url = "https://qa-auth.example.com"
    api.timeout = 45000
  }
  staging {
    base.url = "https://staging-api.example.com"
    auth.url = "https://staging-auth.example.com"
    api.timeout = 60000
  }
}
```

---

## 6. Execution Commands

```bash
# Run all tests in QA environment
mvn clean verify -Denvironment=qa

# Run only smoke tests
mvn clean verify -Dcucumber.filter.tags="@smoke" -Denvironment=qa

# Run specific feature tests
mvn clean verify -Dcucumber.filter.tags="@customer-management and @positive" -Denvironment=qa

# Run regression suite
mvn clean verify -Dcucumber.filter.tags="@regression" -Denvironment=qa

# Generate Serenity report
mvn serenity:aggregate

# Open report (located at target/site/serenity/index.html)
```

---

## 7. Logging Standards

Every step definition must include:
- `LOG.info()` at the START of the step with context
- `LOG.info()` at the END of the step with result
- `LOG.debug()` for request/response payloads
- `LOG.error()` in catch blocks with full exception details

---

## 8. Assertion Standards

- Use **AssertJ** for all assertions (not JUnit assertions)
- Always include `.as("descriptive message")` for every assertion
- Chain multiple related assertions where possible
- Use soft assertions for non-critical validations within a single step
