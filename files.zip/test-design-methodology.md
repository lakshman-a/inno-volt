# QA Test Design Methodology — Skills & Standards

## Overview
This document defines the systematic approach to test case design that the QA agent must follow for every test generation request. This is the "QA mindset" that ensures comprehensive, robust, and business-relevant test coverage.

---

## 1. Input Analysis Framework

### For Swagger/OpenAPI Specifications
Extract and document:
1. **All endpoints** — method, path, summary
2. **Request schemas** — required fields, optional fields, data types, constraints (minLength, maxLength, pattern, enum, min, max)
3. **Response schemas** — success responses (2xx), error responses (4xx, 5xx), response headers
4. **Authentication** — security schemes (Bearer, OAuth, API Key)
5. **Path parameters** — required path variables
6. **Query parameters** — required and optional query params with defaults
7. **Request headers** — custom headers required

### For Java Codebase
Extract and document:
1. **Controller classes** — `@RestController`, `@RequestMapping`, endpoint methods
2. **DTOs/Models** — `@NotNull`, `@NotBlank`, `@Size`, `@Pattern`, `@Min`, `@Max`, `@Email`, `@Valid` annotations
3. **Service logic** — business rules, conditional flows, exception handling
4. **Exception handlers** — `@ControllerAdvice`, custom error responses
5. **Security config** — roles, permissions, endpoint security rules
6. **Entity relationships** — foreign keys, cascading rules, constraints

### For Requirement Documents / Jira Stories
Extract and document:
1. **Acceptance criteria** — each criterion becomes one or more test scenarios
2. **Business rules** — explicit and implied rules
3. **User personas** — different user roles and their permissions
4. **Preconditions** — system state required for the feature
5. **Data constraints** — valid ranges, formats, dependencies
6. **Error scenarios** — explicitly mentioned error cases
7. **Non-functional hints** — performance expectations, data volume expectations

---

## 2. Test Coverage Matrix (Mandatory for Every Feature)

Before writing test cases, create this coverage matrix:

```
┌─────────────────────┬──────────┬──────────┬───────────┬──────────┐
│ Functionality       │ Positive │ Negative │ Edge Case │ Business │
├─────────────────────┼──────────┼──────────┼───────────┼──────────┤
│ Create Customer     │ 3        │ 5        │ 4         │ 2        │
│ Get Customer        │ 2        │ 3        │ 2         │ 1        │
│ Update Customer     │ 3        │ 5        │ 3         │ 3        │
│ Delete Customer     │ 1        │ 3        │ 2         │ 2        │
│ List Customers      │ 2        │ 2        │ 3         │ 1        │
├─────────────────────┼──────────┼──────────┼───────────┼──────────┤
│ TOTAL               │ 11       │ 18       │ 14        │ 9        │
└─────────────────────┴──────────┴──────────┴───────────┴──────────┘
Grand Total: 52 test scenarios
```

---

## 3. Systematic Test Case Design Patterns

### Pattern 1: CRUD API Testing
For each entity's CRUD operations:

**CREATE (POST)**
| Category | Scenario |
|----------|----------|
| Positive | All required fields with valid data |
| Positive | All fields (required + optional) with valid data |
| Positive | Multiple valid data combinations (parameterized) |
| Negative | Missing each required field (one per scenario) |
| Negative | Invalid data type for each field |
| Negative | Invalid format (email, phone, date) |
| Negative | Value exceeds maximum length/size |
| Negative | Duplicate unique field (e.g., email) |
| Negative | No authentication / Invalid authentication |
| Negative | Insufficient permissions (wrong role) |
| Edge | Minimum allowed values for all fields |
| Edge | Maximum allowed values for all fields |
| Edge | Special characters (unicode, emojis, HTML entities) |
| Edge | Empty string vs null vs missing key |
| Edge | Extremely large payload |
| Business | Business rule validations specific to entity |
| Business | Cross-field validation rules |

**READ (GET by ID)**
| Category | Scenario |
|----------|----------|
| Positive | Retrieve existing resource by valid ID |
| Positive | Verify all fields in response match created data |
| Negative | Non-existent ID (valid format) → 404 |
| Negative | Invalid ID format → 400 |
| Negative | No authentication → 401 |
| Negative | Access another user's resource (if applicable) → 403 |
| Edge | Retrieve immediately after creation |
| Edge | Retrieve after update (verify updated data) |

**READ (GET list/search)**
| Category | Scenario |
|----------|----------|
| Positive | List all with default pagination |
| Positive | List with specific page and size |
| Positive | Filter by each filterable field |
| Positive | Sort by each sortable field (asc/desc) |
| Negative | Invalid pagination parameters |
| Negative | Invalid filter values |
| Edge | Empty result set (no matching data) |
| Edge | Exactly one result |
| Edge | Maximum page size |
| Edge | Page number beyond available data |
| Business | Verify only authorized data is returned |

**UPDATE (PUT/PATCH)**
| Category | Scenario |
|----------|----------|
| Positive | Update each modifiable field individually |
| Positive | Update multiple fields simultaneously |
| Positive | Partial update (PATCH) with single field |
| Negative | Update non-modifiable field (e.g., ID, createdAt) |
| Negative | Update with invalid data (same as CREATE negatives) |
| Negative | Update non-existent resource → 404 |
| Negative | Update without authentication → 401 |
| Negative | Concurrent update conflict (if applicable) → 409 |
| Edge | Update with same values (idempotency) |
| Edge | Update to boundary values |
| Business | State-dependent updates (can only update in certain states) |
| Business | Cascading effects of update |

**DELETE**
| Category | Scenario |
|----------|----------|
| Positive | Delete existing resource → 204/200 |
| Positive | Verify resource is no longer retrievable after delete |
| Negative | Delete non-existent resource → 404 |
| Negative | Delete without authentication → 401 |
| Negative | Delete without permission → 403 |
| Edge | Double delete (idempotency check) |
| Business | Delete with dependent records (cascade vs prevent) |
| Business | Soft delete verification (if applicable) |

### Pattern 2: Authentication & Authorization
| Category | Scenario |
|----------|----------|
| Positive | Valid credentials → successful auth |
| Positive | Access with valid token → authorized |
| Negative | Invalid credentials → 401 |
| Negative | Expired token → 401 |
| Negative | Malformed token → 401 |
| Negative | Missing token → 401 |
| Negative | Wrong role accessing restricted endpoint → 403 |
| Negative | Revoked token (if applicable) → 401 |
| Edge | Token at expiry boundary |
| Edge | Concurrent sessions (if applicable) |

### Pattern 3: Data-Driven Testing
Use parameterized tests for:
- Multiple valid input combinations
- All possible enum values
- International data (names, addresses, phone formats)
- Date format variations
- Numeric precision and scale variations

---

## 4. Test Data Design Principles

### Golden Rules
1. **Never hardcode** — use JSON/CSV files or data factories
2. **Make data realistic** — use meaningful names, valid formats
3. **Make data self-documenting** — data should explain the scenario
4. **Ensure independence** — each test creates its own data
5. **Clean up** — tests clean up data they create (or use shared cleanup)

### Test Data Structure
```json
// testdata/customer/valid_customers.json
[
  {
    "description": "Standard US customer with all fields",
    "data": {
      "firstName": "John",
      "lastName": "Smith",
      "email": "john.smith@example.com",
      "phone": "+1-555-123-4567",
      "address": {
        "street": "123 Main St",
        "city": "Springfield",
        "state": "IL",
        "zip": "62701",
        "country": "US"
      }
    }
  },
  {
    "description": "International customer with unicode characters",
    "data": {
      "firstName": "田中",
      "lastName": "太郎",
      "email": "tanaka.taro@example.jp",
      "phone": "+81-90-1234-5678"
    }
  }
]
```

### Boundary Value Data Template
```json
// testdata/customer/boundary_data.json
{
  "firstName": {
    "minValid": "A",
    "maxValid": "ABCDEFGHIJ...50chars",
    "belowMin": "",
    "aboveMax": "ABCDEFGHIJ...51chars",
    "atMin": "A",
    "atMax": "ABCDEFGHIJ...50chars"
  },
  "age": {
    "minValid": 18,
    "maxValid": 120,
    "belowMin": 17,
    "aboveMax": 121,
    "atMin": 18,
    "atMax": 120
  }
}
```

---

## 5. Response Validation Checklist

For EVERY API response, validate:

### Status Code
- Correct HTTP status code for the scenario

### Response Headers
- Content-Type is correct (application/json, etc.)
- Custom headers are present (X-Request-Id, Location, etc.)
- CORS headers (if applicable)

### Response Body — Structure
- All expected fields are present
- No unexpected extra fields (if strict validation needed)
- Correct data types for all fields
- Null handling is correct (null vs missing vs empty)

### Response Body — Values
- Returned values match input values where expected
- System-generated fields have valid formats (UUID, timestamp)
- Computed fields have correct values
- Enum values are valid

### Response Body — Collections
- Pagination metadata is correct (total, page, size)
- Array ordering is correct (if sorted)
- Array size respects limit parameters

### Error Responses
- Error structure follows API's error format
- Error messages are meaningful and specific
- Error codes are correct
- Sensitive information is NOT leaked in errors

---

## 6. Step-by-Step Workflow Summary

```
INPUT RECEIVED
     │
     ▼
┌──────────────────┐
│ 1. DISCOVER      │ → Read inputs, scan existing tests, identify framework
└──────┬───────────┘
       │
       ▼
┌──────────────────┐
│ 2. ANALYZE       │ → Extract endpoints, schemas, business rules, constraints
└──────┬───────────┘
       │
       ▼
┌──────────────────┐
│ 3. MAP COVERAGE  │ → Create coverage matrix (positive/negative/edge/business)
└──────┬───────────┘
       │
       ▼
┌──────────────────┐
│ 4. PLAN          │ → Present test plan to user, get approval
└──────┬───────────┘
       │ (User approves)
       ▼
┌──────────────────┐
│ 5. DESIGN DATA   │ → Create test data files, schemas, configs
└──────┬───────────┘
       │
       ▼
┌──────────────────┐
│ 6. GENERATE      │ → Write feature files, step defs, utilities
└──────┬───────────┘
       │
       ▼
┌──────────────────┐
│ 7. VALIDATE      │ → Self-review for completeness, no hardcoding, proper structure
└──────┬───────────┘
       │
       ▼
┌──────────────────┐
│ 8. DELIVER       │ → Present summary, execution commands, report instructions
└──────────────────┘
```

---

## 7. Anti-Patterns to AVOID

1. **No Shallow Tests** — "Then status 200" alone is not a test. Always validate response body.
2. **No Copy-Paste Scenarios** — Each scenario must test something distinct.
3. **No Assumption-Based Tests** — If you don't know the expected behavior, ask.
4. **No Sequential Dependencies** — Each scenario should be independently executable.
5. **No Magic Numbers** — All values must be in named constants or config.
6. **No Missing Negative Cases** — Every positive case has at least 2 corresponding negative cases.
7. **No Technical Jargon** — Scenarios readable by business stakeholders.
8. **No Empty Assertions** — Every "Then" step must assert something specific.
9. **No Ignored Errors** — If a test can fail, it must fail with clear diagnostics.
10. **No Flaky Patterns** — No `Thread.sleep()`, no time-dependent assertions, no order-dependent tests.
