# QA Automation Agent — Prompt & Instructions Reference

## Quick Start Guide for Developers

This document explains how to use the **Senior QA Automation Engineer** mode in GitHub Copilot to generate comprehensive functional API test cases.

---

## 1. How to Activate the QA Agent

### In VS Code / IDE with GitHub Copilot:
1. Open the Copilot Chat panel (`Ctrl+Shift+I` or `Cmd+Shift+I`)
2. Click the **mode selector** (top of chat panel)
3. Select **"Senior QA Automation Engineer"**
4. The agent is now active and will follow QA-specific instructions

### Verifying the Mode is Active:
Ask: `What mode are you in?`
Expected: The agent confirms it's in Senior QA Automation Engineer mode.

---

## 2. Input Types & How to Provide Them

### Option A: From Codebase (Controller/Service Classes)
```
@workspace Generate comprehensive API test cases for the CustomerController.
Use Cucumber + Serenity framework.
Scan existing tests before creating new ones.
```

Or be more specific:
```
@workspace Analyze the OrderService.java and OrderController.java files.
Generate test cases for all order management APIs using Karate framework.
Cover positive, negative, and edge cases.
```

### Option B: From Swagger/OpenAPI Spec
```
Here is our API Swagger spec: [paste or attach swagger.json/yaml]
Generate comprehensive test cases for all endpoints using Cucumber + Serenity.
Focus on the /api/v1/payments endpoints.
```

Or if the spec is in the project:
```
@workspace Read the swagger.yaml file in src/main/resources/
Generate Karate test cases for the User Management API group.
```

### Option C: From Requirement Document / Jira Story
```
Here are the acceptance criteria for our new feature:

**Story: As a merchant, I want to refund a payment so that I can handle customer returns**

Acceptance Criteria:
1. Full refund can be processed for payments in "COMPLETED" status
2. Partial refund amount cannot exceed original payment amount
3. Refund request must include a reason
4. Multiple partial refunds are allowed until total equals original amount
5. Refund should be reflected in the merchant's balance within 24 hours

Generate comprehensive Cucumber + Serenity test cases covering all criteria.
```

### Option D: Enhance Existing Test Suite
```
@workspace Analyze the existing test suite in src/test/resources/features/
Identify coverage gaps — what's missing in terms of negative and edge cases?
Generate only the missing test cases following the existing patterns.
```

### Option E: From Confluence/External Documentation
```
Based on the following API documentation:
[paste the content]

Generate Karate test cases covering all documented behaviors.
Include error cases mentioned in the documentation.
```

---

## 3. Controlling What Gets Generated

### Specifying Framework
```
Use Cucumber + Serenity framework for all tests.
```
or
```
Use Karate DSL framework for all tests.
```

### Specifying Scope
```
Focus only on the POST /api/v1/orders endpoint.
```
or
```
Generate tests for the entire payment processing module.
```

### Specifying Coverage Depth
```
Generate smoke tests only — cover the happy path for each endpoint.
```
or
```
Generate full regression coverage — positive, negative, edge cases, and business rules.
```

### Specifying Environment Config
```
Configure tests for these environments:
- dev: https://dev-api.example.com
- qa: https://qa-api.example.com
- staging: https://staging-api.example.com
Auth endpoint: /oauth/token with client_credentials grant
```

---

## 4. Iterative Refinement Prompts

After the agent generates the initial suite, refine with:

### Add More Negative Cases
```
Add more negative test cases for the create order endpoint.
Specifically cover: invalid currencies, negative amounts, and expired payment methods.
```

### Add Data-Driven Scenarios
```
Convert the single customer creation scenario into a data-driven test
covering 10 different valid customer profiles from various countries.
```

### Add Business Logic Tests
```
Add test cases for these business rules:
1. Orders above $10,000 require manager approval
2. Discount codes cannot be combined
3. Free shipping applies only to domestic orders above $50
```

### Update for Schema Changes
```
The response schema has changed — "createdDate" is now "createdAt" and returns ISO-8601.
Update all affected test cases and assertions.
```

### Fix Failing Tests
```
These tests are failing:
[paste error output]
Analyze the failures and fix the test cases.
```

---

## 5. Expected Output Quality Checklist

Every test suite the agent generates should have:

- [ ] **Test Plan** presented before code generation
- [ ] **Feature files** organized by feature and test type (positive/negative/edge)
- [ ] **Step definitions** with proper logging and assertions
- [ ] **Test data** in external JSON/CSV files (not hardcoded)
- [ ] **Response schemas** for validation
- [ ] **Configuration** for multiple environments
- [ ] **Tags** for filtering (smoke, regression, priority)
- [ ] **Business-readable** scenario descriptions
- [ ] **Execution commands** for running tests and viewing reports
- [ ] **Coverage summary** showing what is and isn't covered

---

## 6. Troubleshooting

### Agent generates incomplete tests
Ask: `Review the generated tests against the test plan. What scenarios are missing?`

### Agent makes assumptions about API behavior
Ask: `Do not assume any behavior. List what information you need from me to complete the test cases.`

### Tests don't match project structure
Ask: `@workspace Scan the project structure and adapt the test generation to match existing patterns and conventions.`

### Agent uses wrong framework
Explicitly specify: `Use only Karate DSL. Do not use Cucumber or Serenity.`

---

## 7. Best Practices for Using the Agent

1. **Always provide concrete inputs** — the more context, the better the tests
2. **Review the test plan** before approving code generation
3. **Start with one feature** — validate quality, then expand
4. **Use iterative refinement** — generate base, then add depth
5. **Provide existing test examples** — the agent will match your patterns
6. **Specify your team's conventions** — naming, tagging, data management
7. **Run generated tests immediately** — don't batch-generate without testing
