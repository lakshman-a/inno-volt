# QA Automation Agent for GitHub Copilot

## Overview

This package provides a **custom GitHub Copilot Agent Mode** that transforms Copilot into a **Senior QA Automation Engineer** capable of generating comprehensive, robust, business-readable functional API test cases.

### Supported Frameworks
- **Cucumber + Serenity BDD** (Java, Maven, RestAssured)
- **Karate DSL** (Java, Maven)

### Accepted Inputs
- Java codebase (Controllers, Services, DTOs)
- Swagger/OpenAPI specifications
- Requirement documents / Jira stories
- Confluence documentation
- Existing test suites (for gap analysis and enhancement)

---

## File Structure & Purpose

```
.github/
├── copilot-instructions.md              # Global Copilot instructions (auto-loaded)
├── modes/
│   └── senior-qa-automation.md          # Custom mode definition (the QA persona)
├── skills/
│   ├── cucumber-serenity-skills.md      # Cucumber+Serenity framework knowledge
│   ├── karate-dsl-skills.md             # Karate DSL framework knowledge
│   └── test-design-methodology.md       # QA test design methodology & patterns
└── instructions/
    └── qa-agent-usage-guide.md          # Developer guide on how to use the agent
```

### What Each File Does

| File | Purpose | When Copilot Uses It |
|------|---------|---------------------|
| `copilot-instructions.md` | Global rules: no hallucination, discover-before-create, quality standards | Every conversation in this workspace |
| `modes/senior-qa-automation.md` | Defines the QA persona, step-by-step workflow, test design principles, writing style | When the "Senior QA Automation Engineer" mode is selected |
| `skills/cucumber-serenity-skills.md` | Cucumber+Serenity project structure, POM template, feature file standards, step patterns | When generating Cucumber+Serenity tests |
| `skills/karate-dsl-skills.md` | Karate project structure, POM template, karate-config.js, feature patterns | When generating Karate tests |
| `skills/test-design-methodology.md` | CRUD testing matrix, coverage patterns, test data design, validation checklist | Every test generation request |
| `instructions/qa-agent-usage-guide.md` | How developers should interact with the agent (prompts, examples, tips) | Reference for developers |

---

## Setup Instructions

### Step 1: Copy Files to Your Repository

Copy the entire `.github/` directory structure into your project's root:

```bash
cp -r .github/ /path/to/your/project/.github/
```

If your project already has a `.github/` folder, merge the contents (do not overwrite existing files like workflows).

### Step 2: Verify GitHub Copilot Settings

Ensure your VS Code / IDE settings include:
```json
{
    "github.copilot.chat.agent.enabled": true,
    "github.copilot.chat.useCustomInstructions": true
}
```

### Step 3: Select the Custom Mode

1. Open Copilot Chat in your IDE
2. Click the mode selector dropdown
3. Select **"Senior QA Automation Engineer"**
4. Start generating tests

### Step 4: Choose Claude Model (Recommended)

In Copilot settings, set the model to:
- **Claude Sonnet 4** (recommended for daily use — fast + high quality)
- **Claude Opus 4.5** (for complex test suite generation — highest quality)

---

## Recommended Claude Model Selection

| Use Case | Recommended Model | Reason |
|----------|-------------------|--------|
| Generate tests for a single endpoint | Claude Sonnet 4 | Fast, accurate, cost-effective |
| Full test suite for a microservice | Claude Opus 4.5 | Better at complex multi-file generation |
| Analyze and enhance existing suite | Claude Opus 4.5 | Superior reasoning for gap analysis |
| Quick smoke test generation | Claude Sonnet 4 | Speed over depth |
| Complex business logic testing | Claude Opus 4.5 | Better understanding of business rules |

---

## Usage Examples

### Generate from Swagger
```
@workspace Read the swagger.yaml file and generate comprehensive 
Karate test cases for the Payment API endpoints.
Cover positive, negative, edge cases, and business rules.
```

### Generate from Code
```
@workspace Analyze src/main/java/com/example/controllers/OrderController.java
and generate Cucumber + Serenity test cases for all order management APIs.
Use existing test patterns from src/test/.
```

### Enhance Existing Suite
```
@workspace Analyze the existing test coverage in src/test/resources/features/
Identify gaps in negative and edge case coverage.
Generate only the missing test cases.
```

---

## Customization

### Changing the Persona
Edit `modes/senior-qa-automation.md` to adjust:
- Years of experience mentioned
- Specific domain expertise
- Default framework preference
- Response format

### Adding Company-Specific Standards
Edit `copilot-instructions.md` to add:
- Your organization's naming conventions
- Required tags and traceability patterns
- Custom assertion libraries
- CI/CD integration requirements

### Adding Custom Test Data Patterns
Edit `skills/test-design-methodology.md` to add:
- Your organization's test data management approach
- Shared test environments and data
- Custom data generation utilities

---

## Iteration & Improvement Plan

### Phase 1 (Current): Copilot Agent Mode
- Developers use the custom mode to generate test cases
- Collect feedback on quality, completeness, accuracy
- Refine prompt and skills files based on real-world usage

### Phase 2: Claude Code Integration
- For teams wanting CLI-based autonomous test generation
- CLAUDE.md files mirror the Copilot instructions
- Can run batch test generation across repositories

### Phase 3: Platform Solution
- Centralized test generation platform
- API-driven test creation from CI/CD pipelines
- Dashboard for coverage tracking and reporting
- Multi-repo, multi-team test suite management

---

## FAQ

**Q: Why Claude over GPT-4 for test generation?**
A: Claude models demonstrate stronger adherence to complex multi-step instructions, better understanding of business context, and more consistent output quality for structured test generation. Claude Sonnet 4 offers the best balance of speed and quality for this use case.

**Q: Can I use this without the custom mode?**
A: Yes, the `copilot-instructions.md` file provides basic guidance to any Copilot interaction. However, the custom mode provides the full QA persona and workflow.

**Q: Will the agent execute the tests?**
A: The agent can provide execution commands and help debug failures. In Agent Mode, it can execute Maven commands if your environment is configured for it.

**Q: What if the agent generates wrong test cases?**
A: The agent is designed to present a test plan before generating code. Review the plan, provide corrections, then approve. If outputs are still wrong, provide more specific input (actual Swagger spec, actual code, actual requirements).

---

## Support & Feedback

Collect feedback from developers using this agent to continuously improve the skills and instructions files. Key metrics to track:
- Test case accuracy (do generated tests pass on first run?)
- Coverage completeness (are positive/negative/edge cases all present?)
- Business readability (can non-technical stakeholders understand the scenarios?)
- Framework correctness (proper structure, imports, conventions?)
- Time saved (how long would manual test creation have taken?)
